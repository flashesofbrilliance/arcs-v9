# Hypotheses: each one exists to be broken

Every row is grounded in something the client said or something we measured. Predictions and
confidence are written into the flight log (`kind: ex_ante`) before the test exists, then scored
(`kind: ex_post`). A falsified hypothesis becomes a KINTSUGI entry and changes the plan.

| # | Hypothesis | Grounded in | Falsifying test | Falsified if | Status |
|---|---|---|---|---|---|
| H1 | Amendment resolution is correct whatever the ingest order | Doug, discovery call: amendments ingested as new RFPs or ignored | M1: 30,000 random orders, duplicates, conflicts | Any run governs a clause with the wrong amendment | Survived (0/30,000) |
| H2 | A local 7B model is good enough to be primary | Sam Ito's data-residency preference | Same 18-case eval, Claude vs Qwen 2.5 7B | Below 18/18 | Falsified (14/18); Claude stays primary |
| H3 | The rule-based amendment parser handles real grid-operator addenda, not just the brief's tidy sample | The sample's formulaic wording; K1 (ingest is the weak point) | PJM test set: real addenda + altered copies with known answers | A real addendum is misclassified instead of flagged for a human | Partly falsified on synthetic rewording (K17, K18 fixed); PJM run pending |
| H4 | Lexical retrieval + glossary holds at real document size | K5 vocabulary miss; brief: documents up to ~600 pages | Golden-style questions over a real PJM package | Citation recall falls below the golden bar | Pre-registered |
| H5 | Each external dependency is swappable behind one adapter | Sam Ito: "keep the moving parts countable" | Ports refactor; swap each adapter and rerun the eval | A swap needs changes outside its adapter | Pre-registered |
| H6 | RET's enrichment data (project value, win/loss) lives in a reachable system | Elena owns bid/no-bid; the brief gives no outcome data | DATA-MODEL.md questions, asked in discovery | "Not tracked" or "in someone's head" | Open: answered by the client, not by us |
| H7 | A monday.com seat, not AI, is the main running cost | TCO evidence: model calls ~$8/yr | Seat price from the monday.com account team | Seat price or plan rules change the picture | Open: needs a price we do not have |
