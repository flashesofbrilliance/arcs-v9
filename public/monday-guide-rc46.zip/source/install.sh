#!/bin/sh
# One-step setup after unzipping: ./install.sh   (macOS or Linux; nothing is downloaded or installed system-wide)
#
# 1. checks Python 3.9 or newer (the only requirement; standard library only)
# 2. proves the pipeline works with no keys (the free mock, about 5 seconds)
# 3. writes .env from .env.example, asking for the two keys; typed input is not shown, never printed, and the file
#    is readable by you only. An existing .env is kept unless you say so.
# 4. runs ./rfp doctor, then prints the one command to start
#
# --no-keys   stop after step 2 (reviewing without accounts)
set -eu
here=$(cd "$(dirname "$0")" && pwd)
cd "$here"

say() { printf '%s\n' "$*"; }
fail() { printf 'install: %s\n' "$*" >&2; exit 1; }

say "RET RFP Intelligence: setup"
say ""

# 1. Python
command -v python3 >/dev/null 2>&1 || fail "python3 not found. Install Python 3.9 or newer from python.org, then run ./install.sh again."
python3 -c 'import sys; sys.exit(0 if sys.version_info >= (3, 9) else 1)' \
  || fail "Python 3.9 or newer is required; this computer has $(python3 -V 2>&1)."
say "OK   Python        $(python3 -V 2>&1)"
chmod +x ./rfp 2>/dev/null || true

# 2. No-key proof
if ./rfp e2e --provider mock --runs 1 >/dev/null 2>&1; then
  say "OK   self-test     the full pipeline passed on the free mock (no keys, no network)"
else
  fail "the self-test failed. Run ./rfp e2e --provider mock --runs 1 to see why, and see TROUBLESHOOT.md."
fi

if [ "${1:-}" = "--no-keys" ]; then
  say ""
  say "Done without keys. To review: open docs/site/index.html. To run it for real later: ./install.sh"
  exit 0
fi

# 3. Keys
write_env=yes
if [ -f .env ]; then
  printf 'A .env file already exists. Replace it? [y/N] '
  read -r answer || answer=""
  case "$answer" in y|Y|yes|YES) write_env=yes ;; *) write_env=no ;; esac
fi
if [ "$write_env" = yes ]; then
  ask() {   # $1 prompt; reads one line without echo when attached to a terminal
    printf '%s' "$1" >&2
    if [ -t 0 ]; then stty -echo; read -r v || v=""; stty echo; printf '\n' >&2; else read -r v || v=""; fi
    printf '%s' "$v"
  }
  say ""
  say "Two keys (see ONBOARDING.md step 4 for where to get them). Input is hidden."
  tok=$(ask "monday.com API token (starts eyJ): ")
  case "$tok" in eyJ*) ;; *) fail "that does not look like a monday.com token (it starts eyJ). Nothing was written." ;; esac
  key=$(ask "Anthropic API key (Enter to skip and use the local model): ")
  umask 077
  { printf 'MONDAY_API_TOKEN=%s\n' "$tok"; printf 'ANTHROPIC_API_KEY=%s\n' "$key"; } > .env
  unset tok key
  say "OK   .env          written, readable by you only"
fi

# 4. Doctor
say ""
./rfp doctor || fail "fix the line above marked FAIL, then run ./rfp doctor again."
say ""
say "Ready. Start a working session with:  ./rfp start"
say "Check what is running:  ./rfp status      Stop it:  ./rfp stop"
