# RET RFP Intelligence: Maple Creek proof of concept

Key facts on a monday.com board the day an RFP or amendment lands, and cited answers to staff questions in minutes.

Submitted by Zach Harris | Zach.Harris@gmail.com

Walkthrough video: https://youtu.be/w7b-FVA3qSE

## What I decided and why

1. **Rules, not the AI, read amendments.** Doug's incident was a missed amendment; a rule either recognises the
   wording or sends it to a person. The AI only picks clauses and writes a sentence.
2. **A figure is quoted word for word or withheld.** Nina's test: verifiable in thirty seconds, never a guess.
3. **monday.com is where people work; the pipeline runs beside it.** Boards for facts and questions, written through
   one narrow client, so RET adopts it without a new tool.
4. **Few moving parts, chosen for Sam Ito.** Python standard library, a local database, one poller; a local model
   when nothing may leave the machine.
5. **Not built, on purpose:** portal scraping, auto-submission, drafting bid language, the document-system link,
   Doug's tracker. Each is named in `DECISIONS.md` with what would change the call.

## Overview

A take-home build for monday.com's Forward Deployed Engineer assessment: intake and Q&A for the Ridgeline Energy
Transmission (RET) Maple Creek solicitation. The pipeline runs locally and lands its results in monday.com.

**What it does**

- **Key facts the same day:** every RFP and amendment in `data/` is parsed into clauses; deadlines, deposits and
  requirements land on the RET · Key Facts board with the text that governs them, and which amendment changed it.
- **Amendments read by rules:** an amendment that revises a clause supersedes it, and both texts are cited; wording the
  rules cannot read goes to a person as "needs review", never a guess.
- **Cited answers in minutes:** anyone adds a question to the RET · Questions board; it is picked up within a minute and
  answered with the clauses it rests on. Every figure in an answer must appear word for word in a cited clause, or the
  summary is withheld. "Not addressed in the RFP" beats a guess.

**The code that matters** is five files in `source/rfp/`: `parse.py` (clauses), `resolve.py` (amendments),
`answer.py` (search, the AI call, the figure check), `monday.py` and `sink.py` (the monday.com client and board writes).
Everything else is tests, the test bench, and the record of how it was built.

## What's inside

| Path | What it is |
|---|---|
| `../presentation/RET-RFP-Intelligence.pdf` | The proposal deck, 10 slides |
| `source/` | The proof of concept: ingest, amendment resolution, cited Q&A, monday.com sync, the test bench |
| `docs/site/` | The review pages: start here, the deck as a web page, how we got here, the boards, find anything, the evidence |
| `data/` | The RFP package exactly as provided in the brief |
| `evidence/` | Every figure on a slide with its source and grade, the controls, the test cases |
| `flightlog/` | Every AI call, monday.com call and test run, as plain JSON lines |
| `KINTSUGI.md`, `DECISIONS.md` | Every mistake with its repair; every decision with the alternative rejected |
| `ONBOARDING.md` | Install and run, step by step |

## Quick start

1. Read the deck: `../presentation/RET-RFP-Intelligence.pdf`.
2. Open the review pages: `docs/site/index.html` in a browser. No install needed.
3. Try it with no keys or accounts: in a terminal in this folder, run `./rfp e2e --provider mock --runs 1` and
   `./rfp serve`, and open http://127.0.0.1:8765 for the test bench.

**Choose how it answers.** The key facts on the board (deadlines, deposits and the other facts an amendment governs) are
read from the documents with no AI and no keys. A question about one of them is answered the same way only when it is
phrased like the fast-path examples ("What is the bid deposit?", "When are proposals due?"); any other wording, and every
other question, needs one of these:

| Mode | What you need | What leaves the machine |
|---|---|---|
| `--provider mock` | nothing | nothing; a stand-in model for trying the pipeline and its safety checks, not real answers |
| `--provider local` | [Ollama](https://ollama.com) and `ollama pull qwen2.5:7b-instruct` | nothing |
| `--provider claude` (default) | `ANTHROPIC_API_KEY` in `.env` in this folder (template: `.env.example`; the file is never committed or shipped) | To the AI: fixed instructions, the question and a few clauses. |

The monday.com boards also need `MONDAY_API_TOKEN` in the same `.env`. Without a key the tool says so and names
these options; it never answers from a guess.

## Run it yourself

New here? [ONBOARDING.md](ONBOARDING.md) installs it in about 15 minutes; steps 1 to 3 need no keys. If you
only use the monday.com boards, read [docs/using-the-boards.md](docs/using-the-boards.md).

1. In a terminal in this folder, run `./install.sh` (or `./install.sh --no-keys` to try it with no accounts).
2. Put the two keys in `.env` (template: `.env.example`).
3. `./rfp start` checks everything, syncs the boards, starts the test bench and answers the Questions board until
   Ctrl-C. One poller per computer, and it keeps 100 calls a day in reserve.
4. `./rfp status` shows what is running and the calls left today; `./rfp stop` stops it from any terminal.

## Configuration

| Setting | What it does | Required | Default |
|---|---|---|---|
| `MONDAY_API_TOKEN` | monday.com API token for the four RET boards | for a live run | none |
| `ANTHROPIC_API_KEY` | Claude API key for answers | for `--provider claude` | none |
| `MODEL_PROVIDER` | `claude`, `local` (Ollama) or `mock` | no | `claude` |
| `CLAUDE_MODEL` | the Claude model that answers | no | `claude-sonnet-5-5` |
| `LOCAL_MODEL` | the Ollama model for `--provider local` | no | `qwen2.5:7b-instruct` |
| `MONDAY_API_VERSION` | the pinned monday.com API version | no | `2026-07` |
| `RFP_CALL_RESERVE` | monday.com calls a day the poller leaves unused | no | `100` |
| `MODEL_CALL_LOG`, `MONDAY_CALL_LOG` | where the call logs are written | no | `flightlog/` |
| `HARNESS_PORT` | the test bench port | no | `8765` |
| `RFP_ALLOW_PAID` | lets the test bench page make paid Claude calls (`./rfp serve --paid`) | no | off |

## How to review it

<!-- how-to-review: generated by scripts/home.py from the start page's How-to-use data; do not edit -->
**In short.** RET's intake takes ~650 team hours per intake cycle today. This pilot puts the key facts on a monday.com board the day an RFP or amendment lands, and answers staff questions on the board in minutes, every figure quoted word for word from the clause it cites or withheld.

Each of the assignment's five stages, and where it is answered:

| Assignment stage | Where to look | What you will find |
|---|---|---|
| 01 Review the brief and scenario | The deck | the problem in RET's own words and numbers (slides 1 to 3), and what we ask for and how it is judged (slides 1 and 7) |
| 02 Explore the sample data | What the boards hold; Read (Proof of one answer) | the 14 key facts the data yields as they landed in monday.com, and one answer traced clause by clause |
| 03 Design your solution | How we got here; the deck, slides 4, 5, 8 and 9 | how we worked the problem from discovery to handoff: architecture, integration and AI choices, risks, trade-offs, each stakeholder's acceptance |
| 04 Build, test, and document | Try it live; Read (the catch net, the build log); README | the working system; every mistake with what caught it and what guards it now; tests, cost and forecasts |
| 05 Package your final submission | Read | every shipped file with one line on what it is, the change history (HISTORY.txt), and the controls |

The pages: [Start](docs/site/index.html) · [Deck](docs/site/deck.html) · [Read](docs/site/wiki.html) · [Proof of one answer](docs/site/proof-of-one-answer.html) · [The catch net](docs/site/mistakes.html) · [The build log](docs/site/build-log.html). They open from the unzipped folder; with `./rfp serve` running, open http://127.0.0.1:8765/source/docs/site/index.html and every code and document link opens as a readable page.
<!-- /how-to-review -->

## What has not been tested yet

Named so nobody has to find it. Each has the step that would close it.

| Not tested | Why not yet | What closes it |
|---|---|---|
| Real PDF or Word RFPs | the brief supplied text versions; an unfamiliar format is refused with a reason, never answered as "not addressed" (K42) | a reader per real format, first in phase 2 (D-600) |
| A real 400 to 600 page package | only the Maple Creek text exists; a 600-page synthetic document was used to test size limits | run a public package end to end; add meaning-based search if word search misses clauses |
| Accuracy on RET staff's own questions | no staff have used it; RET's 14 sample questions, our traps and two blind sets stand in | the pilot counts answers verified and corrected per cycle |
| iPhone and iPad Safari | grade explanations were fixed for tap and checked in a desktop browser at phone size, not on a real device | open the deck on a phone on the same network |
| Windows | the `./rfp` launcher is a shell script, and UTF-8 is now forced; neither was run on Windows | run `python rfp_cli.py <command>` on a Windows machine |
| A paid monday.com plan | built and measured on the free trial the brief asks for: 1,000 API calls a day, no automations, no API usage analytics | repeat the eval set and the live-question path on the client's own plan before relying on any figure here (D-PLAN) |
| Answers through monday.com's own AI models | the `monday` provider is written but returned 403 on the free account, so it has never answered a question | run the three golden sets (46 cases) with `--provider monday` and report its score beside Claude's; until then Claude or the local model answers |
| Questions pushed by an event instead of polling | the poller checks once a minute, because a webhook needs a public endpoint into RET; polling all day would need 1,440 calls, over the free plan's 1,000, so it stops when idle and keeps 100 in reserve | an event-driven path (a board automation, or a monday.com app or MCP tool inside RET's account, D-MCP) depends on a paid plan; which tier, and how its events reach RET without a public endpoint, are not yet verified (D-PLAN) |

## Limits and disclaimers

One place for what this system is not, so nobody relies on it for more than it does (D-DISCLAIM).

- **A research aid, not advice.** Answers quote the RFP and say where; they are not legal, contractual or bid advice.
  A person at RET decides every bid and signs every document.
- **It never drafts bid language** and never gives a bid/no-bid verdict; it refuses both, in the client's own terms.
- **A figure is quoted word for word from a cited clause, or withheld.** A figure that would need working out (a
  difference, a day count) is not stated; the clauses are shown instead.
- **A figure is quoted as the document writes it.** "$100K" or "$100 000" stays as written and is never normalised to
  "$100,000"; a test that expects one spelling reads it as a miss, though the answer matches its source.
- **Citations give the section's page range, not a page.** An amendment has no page numbers, so its citation names the
  amendment, its issue date and the clause.
- **"Not addressed in the RFP" means the search did not find it,** not that the RFP is silent. Search is by words, not
  meaning: a question that never uses the RFP's own word can miss the right clause (test X4).
- **A new requirement travels with its section.** Amendment §A1.3 adds §5.5 (a cybersecurity attestation under
  Appendix F, which was not provided), so every Section 5 answer carries it and its "not provided" note. A reader may
  see one note too many; never miss a new eligibility rule.
- **Carve-outs travel with the rule.** Liability, indemnity and damages answers keep their conditions (force majeure,
  negligence, caps), and the clause is always shown beside the answer.
- **No certification is claimed.** It shows the kind of controls audit and change-management teams look for
  (traceability, change control, release gates, a mistakes log); it is not certified against any standard.
- **Logs are on by default, and this ZIP ships them whole.** Every AI call, monday.com call, test run and live run is
  written to `flightlog/` as plain JSON lines, and none is trimmed here. Where logs live is RET's choice:
  `MODEL_CALL_LOG` and `MONDAY_CALL_LOG` point them anywhere, such as an archive.
- **The AI call log is a plain file with no retention policy.** `flightlog/model_calls.jsonl` keeps every question
  and the clauses sent, so it is a copy of bid strategy readable by anyone with access to that machine, and nothing
  deletes it. RET sets the retention: an encrypted disk, a folder only the service account can read, a purge when the
  bid closes, or a fingerprint of each payload instead of its text. The submission ZIP carries the whole log; it holds
  only the sample RFP and test questions.
- **Tested on the free monday.com plan and on text versions of the RFP only** (see "What has not been tested yet").

## Requirements and architecture

**Requirements:** Python 3.9 or newer, standard library only; nothing to install (`requirements.txt` says so). Keys go
in `.env` (template: `.env.example`). Optional: Ollama for `--provider local`; Google Chrome only to re-render the PDF.

**Data model** (`source/rfp/store.py`, SQLite, local to the machine running the pipeline):

| Table | One row per | Key | Notes |
|---|---|---|---|
| `documents` | RFP or amendment | content hash | a byte-different copy of the same text is a duplicate; a conflicting Amendment No. N stops for a person |
| `clauses` | citable clause | (document, clause id) | section, title, pages and verbatim text: what every citation quotes |
| `effects` | amendment clause | (amendment, clause id) | replaces, supplements or confirms which base clause; unreadable wording is flagged, never "no change" |

On monday.com these become four boards, written only through `source/rfp/sink.py`, which allows four named boards and nothing
else: **Solicitations** (one row per document, the file attached, what each amendment changes), **Key Facts** (the
governing text for each deadline, deposit and requirement), **Questions** (staff ask, the poller answers with citations)
and **Pilot Scorecard**.

**monday.com integration** (`source/rfp/monday.py`): GraphQL with the API version pinned; every query also asks for its
complexity cost, which is logged, so the daily budget is measured; retries honour monday.com's `Retry-After`; items
are upserted on our own `Key` column, so a re-run creates nothing; unchanged values are not re-written; reads follow
the cursor 500 items at a time. Questions are polled once a minute rather than pushed by webhook, because a webhook
needs a public endpoint into RET's network.

## How AI was used

**Building it.** Most of the code, tests and documents were written with Claude Code, an AI coding assistant, working
under my direction in short loops: I set the scope and each decision (`DECISIONS.md` records who decided what), it
drafted, the repo's own checks ran on every commit, and I reviewed and rehearsed. Separate AI sessions did focused
jobs: researching monday.com's developer documentation, writing blind test questions from the RFP and brief alone, and
reviewing the work cold.

**In the product.** The AI does one narrow job: given the question and a few clauses that search found, pick the clauses
that answer it and write one or two sentences. The fixed instructions are in `source/rfp/answer.py` (the `SYSTEM`
prompt), and every request is logged word for word in `flightlog/model_calls.jsonl`. Code, not the AI, reads the
amendments, checks every figure and writes to monday.com.

**Two places I stepped in:**

- **A prompt change that made things worse.** To fix weak refusals, a new instruction and a "partly addressed" answer
  were added; the main test set dropped from passing every case to missing three, because the AI started hedging answers
  it used to get right. It was reverted, weak refusals are now handled in code (`DECISIONS.md` D-K33), and every change
  to the answer path now re-runs both test sets before it can be committed (`KINTSUGI.md` K27).
- **Slides that said more than the code did.** AI-drafted slides understated what leaves RET (they omitted the fixed
  instructions sent to the AI, and the RFP files attached on monday.com) and called AI-written blind sets "reviewers".
  I had every sentence on the 10 slides checked against the brief, the logs and the code; four were false and sixteen
  overstated, all were corrected, and the build now refuses those phrasings (`DECISIONS.md` D-CLAIMS, `KINTSUGI.md` K54).

## The evidence behind each slide

The slides carry one idea each; the detail they rest on lives here and in the generated files.

- **Every figure** has a row in `evidence/evidence.jsonl` with its source, grade and, for calculated figures, the formula
  and inputs. The letter beside each figure on a slide is that grade.
- **Pilot estimates (slides 1 and 7)** were written down before the pilot with a confidence each (85%, 80%, 70%, 50%) and
  are scored later in `flightlog/predictions.jsonl` (`python3 scripts/calibration.py`).
- **Test results (slide 6)** show the latest run and the record across every run; runs that missed a case are kept, not
  dropped. The main set is RET's own 14 sample questions plus 5 traps we added; two sets written blind by separate AI
  sessions that saw only the RFP and brief, never our tests, scored 16 of 20 and 17 of 20 before fixes (`evidence/blind/`).
- **Sources:** every figure carries a letter: A from RET's documents, B measured in this build, C cited from a published
  source (monday.com and Anthropic documentation, each with the date it was read), D our estimate. The cited sources are
  listed at the deepest reading level of `docs/site/how-we-decided.html`.
- **One answer proved end to end (the December 4 row on slide 4):** `docs/site/proof-of-one-answer.html` quotes the clauses behind
  "December 4", names what would make it false and the test guarding each, and carries checkable hashes
  (`./rfp verify-proof`).
- **Open questions for RET's counsel, security and procurement:** the AI provider's data terms; who owns the
  review step; the monday.com plan tier; who supports it after handover; how success is counted; and the costs the RFP
  leaves with RET (§7.4 cost cap, §7.5 delay damages, force-majeure terms not in the package).
- **Mistakes:** every one, with what caught it and its repair, in `KINTSUGI.md`.
- **What the prototype cost to build:** two different kinds of cost, kept apart: API-equivalent compute for the coding assistant, on a subscription (not a cash charge) (`E-build-session-spend`, grade B, at least $173.29: two sessions' cost readouts at 2026-10-10 17:35 EDT; the build continued in more sessions after that, not totalled, so it is a floor), and the measured pipeline API spend (`E-build-spend`, grade B, from the call log). **Disclosure:** that cash spend is optional. Key facts are read deterministically with no AI call; answers can run on a local model with nothing leaving the machine and no API bill (`E-local-eval`); and the free mock runs every test with no model. Running cost ranges from nothing to about $0.76 of AI per response cycle [E:E-cycle-cost] depending on the mode; the build log (`docs/site/build-log.html`) lays out the four modes, what each measured, and when to spend.
- **Costs for finance (slide 7):** `docs/site/cost-model.csv` opens in a spreadsheet with live formulas.

## If RET hits its own targets (arithmetic, not a forecast)

From RET's own figures (Q2 2026 review): intake from ~650 to <=150 hours a cycle is at least 500 hours saved per cycle;
over roughly a dozen solicitations a year that is about 6,000 hours; reaching the >=50% recovery target on ~$1.6M of
manual cost is about $800K a year. Our own pre-registered pilot estimate is smaller: at least 200 hours on Maple Creek
(50% confident). Every figure is generated in `evidence/evidence.jsonl` with its inputs.

## Engineering-led growth: why it compounds (a projection, not a measurement)

One point is measured: RET's ~250-seat expansion is worth about $86K a year at its current seat price [E:E-elg].
Everything below is a labelled projection; its inputs are assumptions to be replaced by pilot data.

Why it compounds: the harness (flight recorder, evidence generator, gates, tests) carries to the next client
unchanged (D-REUSE); only the thin client surface is rebuilt. So each client costs less to land than the one
before, and lands sooner, while each landed pilot opens its own seat expansion.

| Input | Value | Source |
|---|---|---|
| Share of the build reused per new client | 80% [ASSUMPTION] | D-REUSE split; to be measured on client two |
| Time to land a pilot, first client | the take-home build [ASSUMPTION] | this build's session clocks |
| Each later client lands in | about 1/5 of the first's time, if 80% is reused [ASSUMPTION] | arithmetic on the row above |
| Expansion per landed client | similar to RET's, about $86K a year [ASSUMPTION] | RET's figure [E:E-elg] reused as a stand-in |

What would make it false: reuse well below 80% [ASSUMPTION] (the surface was not thin after all), or expansion that does not follow
a working pilot. Both are measurable on the second client; until then, treat the curve as a hypothesis.

## What's next, after the pilot

Three proposals, none built yet. Each is measured against RET's own targets.

- **Learn from outcomes.** At intake, record a bid/no-bid call (or a win chance) with its reasons, before the outcome
  is known. When the CRM records won or lost, score the call (Brier score, the same log `scripts/calibration.py`
  already keeps for our own predictions) and see which signals predicted wins. Caveats: a dozen RFPs a year means the
  trend takes years; RFPs RET passes on never resolve; price and incumbency confound; CRM data is a new data flow that
  needs Sam Ito's sign-off and Nina's confidentiality check.
- **Data worth tracking, cheapest first.** "Verified by" plus a corrected flag (accuracy on real questions; corrections
  become test cases) -> review minutes and release time (hours saved) -> Doug's expected-change list per amendment
  (amendments caught out of expected) -> the bid decision and reasons at intake -> won/lost and award price -> staff
  cost, seat price and project value (return on investment, computed with RET). Each needs an owner, a validation rule,
  and enough cases before it means anything (set with RET).
- **A rubric each stakeholder uses to accept the pilot.** Per person, in their own words: what would earn trust, what
  would break it, and the test or board check that shows which.

## Where the thinking lives

The deck stays at 10 slides; the working files behind it ship in this repository, in the order they were produced.

| Stage | Files |
|---|---|
| Understanding the ask | `CONSTRAINTS.md` (hard constraints from the brief and the invitation email), `docs/briefing-video.md`, and what the brief left open in `docs/site/how-we-decided.html` |
| Research | `docs/monday-platform.md`, `docs/monday-native.md`, `docs/market-scan.md`, `docs/native-agent-comparison.md` |
| Decisions | `DECISIONS.md` (each choice with the alternative rejected, the evidence and its grade, and when to revisit); the key ones, with what each unlocks, in `docs/site/how-we-decided.html` |
| Build and proof | `source/`, `source/eval/` (test questions and rubrics), `flightlog/` (every model call, monday call and test run), `evidence/evidence.jsonl` (every figure on a slide, with its source) |
| Mistakes and repairs | `KINTSUGI.md`: every mistake we made, its repair, and what it changed |
| Reviews and snapshots | `snapshots/` (progress grades at T+2h and T+4h, the brief reread, the skeptic review, the plan-hardening review), `flightlog/predictions.jsonl` (our predictions, scored) |
| Story | `JOURNEY.md` (generated timeline), `../presentation/RET-RFP-Intelligence.pdf` |

## For the curious: the flight recorder

Each span records one unit of work along the analyze, assess, evaluate, synthesize, recapitulate
arc (plus `build` for commits):

- **belief_before / belief_after**: what I thought, and what I think now
- **evidence**: where it says so (brief page, RFP section, commit)
- **grade**: rubric scores; each score must cite a rubric criterion and give a reason, or it is rejected
- **cost**: model tokens, dollars, wall minutes, human minutes
- **cost_basis**: `measured`, `estimated` or `unknown`. Estimates are never shown as measurements.

```bash
python3 -m flight.report            # the audit, as markdown
python3 -m flight.report --check    # fails if any commit has no span
```

Setup: `git config core.hooksPath hooks`.
