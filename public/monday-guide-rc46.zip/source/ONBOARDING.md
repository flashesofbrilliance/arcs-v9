# Onboarding: install and first run (about 15 minutes)

For whoever installs it: an RET admin, or a reviewer opening the ZIP cold. Every step gives the exact command and
the output you should see. Steps 1 to 3 need no keys and no account. Staff who only use the boards want
[docs/using-the-boards.md](docs/using-the-boards.md) instead.

Steps marked *(checked)* are run from the built ZIP on every push (`scripts/doc_test.py`), so they cannot drift.

**Shortcut:** `./install.sh` in the `source/` folder does steps 1 to 5 in one go: it checks Python, runs the no-key
self-test, asks for the two keys (hidden as you type, saved readable by you only) and runs `./rfp doctor`.
`./install.sh --no-keys` stops after the self-test. The steps below are the same thing by hand.

## 1. Unzip and check Python *(checked)*

Unzip `submission.zip` (skip this if it is already unzipped). It holds two folders:
`presentation/` (the deck as a PDF) and `source/`. Open a terminal in the `source/` folder: it is the one containing a file named
`rfp` and this guide. Python 3.9 or newer is the only requirement;
there is nothing to install.

<!-- doc-test -->
```bash
python3 --version
```
<!-- expect: Python 3. -->

Expected: `Python 3.9.6` or any later 3.x.

## 2. Prove it works with no keys *(checked)*

<!-- doc-test -->
```bash
./rfp e2e --provider mock --runs 1
```
<!-- expect: e2e: 5 of 5 runs passed (mock, monday fake) -->

Expected, last line: `e2e: 5 of 5 runs passed (mock, monday fake)`. This runs the whole path (documents in,
amendment resolved, boards synced, questions answered) on a built-in stand-in for both the AI and monday.com,
including four deliberately broken passes (AI timeout, garbage reply, wrong figure, invented citation).

## 3. Ask one question, still with no keys *(checked)*

<!-- doc-test -->
```bash
./rfp ask --provider mock "When are proposals due?"
```
<!-- expect: [answered] -->
<!-- expect: DECEMBER 4, 2026 -->

Expected: `[answered]`, the amended deadline (DECEMBER 4, 2026, 5:00 PM CT), and two citations: §3.2 of the RFP and
§A1.1 of Amendment No. 1. This question is phrased like the fast-path examples, so it is read straight from the documents with no AI; other wordings go to the model.

## 4. Add the two keys

Create a plain-text file named exactly `.env` (a dot, then env, with no `.txt` on the end) in the `source/` folder,
next to the `rfp` file. Exactly two lines, no quotes, no spaces:

```
MONDAY_API_TOKEN=<your monday.com personal API token>
ANTHROPIC_API_KEY=<your Claude API key>
```

How to make the file so the name stays `.env`:

- **Mac:** in TextEdit choose **Format → Make Plain Text**, paste the two lines, **Save**, type `.env` as the name,
  and untick "If no extension is provided, use .txt". Confirm "Use .env" if asked.
- **Windows:** in Notepad paste the two lines, **File → Save As**, set **Save as type** to **All files**, and name it
  `.env`.

The folder should then look like this:

```
source/
  .env          <- the file you just made
  ONBOARDING.md
  rfp
  source/ scripts/ data/ ...
```

- **monday.com token:** in monday.com, click your profile picture (top right), then **Developers**, then
  **My access tokens**, then **Show**, and copy it. An account admin can also find it under **Administration →
  Connections → Personal API token**. A personal token acts with your own permissions, so use an account that may
  create boards in the target workspace.
- **Claude key:** at console.anthropic.com, **API Keys → Create Key**. Needed only for questions that are not
  dates or figures; without it, use `--provider mock`, or run a local model so nothing leaves the machine: install Ollama, run `ollama pull qwen2.5:7b-instruct`, then add `--provider local`.
- **Never commit `.env`.** It is already excluded from git; `./rfp doctor` fails if it ever becomes tracked.

## 5. Check the machine

```bash
./rfp doctor
```

Expected:

```
OK       Python 3.9 or newer              3.9.6
OK       .env file                        found
OK       Claude key (ANTHROPIC_API_KEY)   present (not shown)
OK       monday.com token                 works: account <your account>, plan <your plan>
doctor: ready for the live path
```

It makes one free monday.com read and no AI call, and never prints a key. Any `FAIL` line says what to fix.

## 6. Create the boards

```bash
./rfp sync
```

Expected: three boards appear in monday.com (**RET · Solicitations**, **RET · Key Facts**, **RET · Questions**; the
fourth, **RET · Pilot Scorecard**, comes from `./rfp scorecard`),
in the main workspace of the account that owns the token, visible to that account's members
and the output ends with a count of items created. Run it again:

```bash
./rfp sync
```

Expected the second time: `"created": 0, "updated": 0`, everything `unchanged`. Re-running is always safe.

## 7. Answer questions from the board

```bash
./rfp poll
```

Leave it running in its own terminal window; the computer must stay awake and online (if it sleeps, questions
wait until it wakes and the next check picks them up). Anyone can now add an item to **RET · Questions**, type the question in the Question column, and
within about a minute the answer, its state and its citations appear on the item. Stop it with Ctrl-C, or from any terminal with `./rfp stop`;
`./rfp poll --once` checks a single time and exits. `./rfp status` shows what is running on this computer, from
any copy, and the monday.com calls left today. Only one poller can run per computer; a second refuses and says where
the first one is. The poller stops by itself when 100 calls are left for the day, so a demo always has calls.

## If it breaks

Start with [TROUBLESHOOT.md](TROUBLESHOOT.md): ten symptoms ranked by how often they happen, each with the first
thing to check. The most common: an unanswered question means the poller is not running or the item's State is not
empty (row 1); writes stopping means the daily monday.com call budget ran out (row 6).

## Day 2: running it

- **Rotate the monday.com token:** regenerate it on the same **My access tokens** page (the old one stops working
  at once), replace the line in `.env`, and run `./rfp doctor`.
- **Rotate the Claude key:** create a new key, replace the line, delete the old key in the console.
- **Call budget:** the free monday.com plan allows 1,000 API calls a day; every write also spends complexity
  points. An unchanged re-sync is cheap. An idle poll costs one call per check, so the default one-minute interval uses about 60 calls an hour; answering a question costs a few more. Watch
  `flightlog/monday_calls.jsonl` (one line per call) and slow the poll with `./rfp poll --interval 120` if needed.
- **Where the logs live:** `flightlog/` (one JSON line per AI call, monday.com call, test run and rehearsal), the
  local database `rfp.db`, and the boards themselves.
- **Before a live cycle:** `./rfp rehearse` runs every check end to end in under a minute, free.
