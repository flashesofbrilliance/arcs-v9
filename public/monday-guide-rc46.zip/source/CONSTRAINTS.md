# Hard constraints

These come from two places: Sam Turner's email (2026-10-08) and the brief
(`energy-rfp-take-home-v1.md.pdf`). `scripts/package.py` checks the ones a machine can check. A human
ticks the rest before submitting.

## Submission (Sam Turner's email, 2026-10-08)

| # | Constraint | Checked by |
|---|---|---|
| E1 | Exactly one ZIP file, under 10 MB | `package.py` |
| E2 | Top level is exactly `source/` and `presentation/` (portal package structure: "source/ with your implementation; presentation/ with your presentation files"); README.md is `source/README.md` | `package.py` |
| E3 | Submit by **5:00 PM ET, Thu 2026-10-15** | `package.py` warns under 24h |
| E4 | Watch the complete introduction video | human |
| E5 | Review the pre-read and all provided materials | human |
| E6 | Complete every dashboard checklist item (5 of 5) before upload unlocks | human |
| E8 | ZIP contains source code, a README, and the presentation **as a PDF** (briefing video, Stefan); `presentation/` holds that one PDF and nothing else | `package.py` |
| E7 | Same browser for the whole session: no incognito, no clearing cookies, no switching browsers, never forward the link | human |

## Build (the brief)

| # | Constraint | Source |
|---|---|---|
| B1 | Pipeline runs outside monday.com; results are pushed in through the GraphQL API or the monday MCP, and the choice can be defended | Technical Guidelines |
| B2 | Real backend code of my own: data model, API integration layer, core logic. 100% no-code fails | Technical Guidelines |
| B3 | Python or TypeScript; at least one AI model provider; runnable end to end, with error handling | Technical Guidelines |
| B4 | Inspectable distinct steps with explainable state; not one mega-prompt, not a black box | Technical Guidelines |
| B5 | Every answer cites section and page; numbers are verbatim; "not addressed in the RFP" instead of a guess | Nina |
| B6 | Amendments supersede base sections; never treated as a new RFP, never ignored | Doug |
| B7 | Uploading the same document twice creates nothing new | Doug |
| B8 | Indexing and retrieval run locally; every outbound model payload is known; few moving parts | Sam Ito |
| B9 | Out of scope: portal scraping, auto-submitting, drafting binding bid language, DMS integration | Doug, Nina, Sam Ito |
| B10 | A live, unseen question comes in during the demo through the path real users would use | Part 2 |
| B11 | At most 10 slides; about 15-20 min proposal plus 10-15 min demo | Presentation Format |
| B12 | Document AI use: prompts, iterations, where it helped and where it failed | AI-Assisted Development |
