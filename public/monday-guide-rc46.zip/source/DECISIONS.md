# Decisions

Each decision names the client words or measurement behind it, what was rejected, and how it gets revisited.

## D-600: Large documents (a real RFP runs 400-600 pages)

**Decision.** Keep retrieval-then-select: the parser chunks the RFP into clauses; each question sends only the
question plus ~8 retrieved clauses to the model. The model's context window is never the constraint.

**Why.** Sam Ito: only what is needed leaves RET's environment. Nina: figures verbatim; checking ~8 clauses is
tractable, checking a whole document per answer is not. Measured cost ~$0.0038/question with this path on 2026-10-10 (since re-measured; the deck shows the current figure)
(UNIT-ECONOMICS.md); sending the whole document is an estimated ~157x more.

**What changes at 600 pages, in order of risk.**
1. PDF extraction (tables, page breaks; KINTSUGI K1). Production path: Docling (MIT, runs locally).
2. Retrieval recall (vocabulary misses grow with size; K5, K25). Production path: add local embeddings as a
   second retriever and merge results; keep the glossary.
3. Bulk extraction of key facts from a new RFP: run offline through a batch API at reduced cost.

**Rejected.** Whole-document prompts as the answer path (cost, data leaving the environment, unverifiable
volume). A long-context model is kept as an optional offline auditor that asks "what did retrieval miss?".
Prompt caching: the repeated prefix (instructions) is below the size where it pays.

**Revisit when.** The PJM real-document test runs (HYPOTHESES H3, H4).

## D-K33: A refusal with no clauses gets a code floor, not a looser gate

**Decision.** When the model refuses and names no clause, ask once more; if it still names none, cite the retrieved
clause that covers the most question words, labelled "related text, does not answer".

**Why.** Measured (B): the follow-up call alone passed 3 of 3 manual runs, then failed inside the pre-commit gate, so a
second model call is still a coin flip. The code floor is deterministic: seam test `test_K33_bare_refusal_still_shows_related_text`
forces the worst case (model refuses bare on both calls) and all six refusal cases pass.

**Rejected.** Gate on 2 of 3 runs, disclosed. It hides the flake instead of removing it, and triples eval spend on every
commit. Rejected also: a stronger prompt rule; K27 measured that a prompt change for this case regressed wave 1 from 18/18 to 15/18.

**Revisit when.** The floor cites a wrong clause in any eval or live question (it is labelled, so a person sees it).

## D-K34: Rewrite history once more rather than ship without it

**Decision.** Scan the shipped history in the package gate, then rewrite it to remove internal and personal references,
with a backup bundle, remapped citations and a forced update of the private remote (Zach approved).

**Why.** The commit history is evidence the panel can verify: every hash cited in KINTSUGI, the snapshots and the flight log
resolves (184 checked, 0 stale). Shipping without it would turn those citations into claims nobody can check.

**Rejected.** Ship the ZIP without `history.bundle`. Cheaper and no force-push, but it removes the verifiable record that
every "measured" claim leans on.

**Revisit when.** Never for this repo; for the next one, decide what is internal before the first commit (K29, K34).

## D-LAYOUT: One reading column, not five side-by-side lanes

**Decision.** Stack every area in one column with a sticky jump bar and filters on top (Zach's choice, 2026-10-10).

**Why.** One order to read, print and present: the same sequence works on screen, as a US Letter PDF and in Present mode.
Five independent scroll areas cannot be printed as one document, and below about 1,000 px wide they stack anyway (D: inference,
not yet measured on this deck). The filters already on the Evals list make a long single column searchable.

**Rejected.** Five full-height lanes read left to right. Good for comparing areas side by side on a large screen, but
it gives each area a scroll position of its own, which makes "where am I" harder in a live demo.

**Revisit when.** A rehearsal shows the panel needs two areas side by side (for example a question next to its source text).

## D-DISCLAIM: One "Limits and disclaimers" section, plus tags; no separate legal, regulatory or disclosure columns

**Decision.** One section states the limits plainly; legal and compliance items carry a tag and a stakeholder filter
(Doug, Nina, Sam Ito, Elena) inside the areas where they already live.

**Why.** The legal content already sits in existing areas: prohibited contact (Q7), exceptions and waivers (W4, W5),
confidentiality (W6), never drafting bid language (T4), what data leaves (Sam Ito). The client set these rules (A: brief, discovery).
Moving them to new columns would group the same items two ways. Over-building once already cost us (K8).

**Rejected.** Separate Regulatory, Legal and Disclosure columns. Easy to scan by function, but they duplicate items that
belong to a job, and nothing in the brief asks for them (to be confirmed in the full brief reread).

**Revisit when.** The brief reread finds a regulatory requirement; it then becomes a tag plus test cases, not a column.

## D-SHOW: Every calculated figure and every decision shows its work

**Decision.** Derived figures come from the server as value, formula and sourced inputs, behind a "Show your work"
toggle (a footnote in the PDF). Decisions show the chosen option, the alternative and the evidence, as in this file.

**Why.** The provenance rule (every number measured, cited, client-provided, derived with inputs shown, or an explicit
placeholder) is enforced in the files but invisible to the panel. The briefing video grades how reasoning is communicated (A).

**Rejected.** A methods appendix at the end. One place to look, but the reader has to leave the number to check it,
and an appendix can fall out of step with the figure it explains. Working attached to the figure cannot drift.

**Revisit when.** The toggles clutter the deck in rehearsal; then show working on hover or in the PDF only.

## D-EVALMAP: Case-to-mistake links are declared data; "informed" files come from git

**Decision.** Each test case declares the logged mistakes it guards (`guards`); the code it touched comes from the
gate its latest run reported; the files its repairs changed come from commits that cite the mistake id.

**Why.** Only 1 of 30 cases named a mistake before (W10, K26), so the link could not be derived and had to be written down once,
where it can be reviewed. Code paths and changed files are measured, so they cannot drift from the code (B).

**Rejected.** Infer the mistake for each case from text similarity. Cheaper to maintain, but a wrong link would look
as authoritative as a right one. Gap disclosed: K2-K7 fixes predate commit-message ids, so Q4, T3 and W9 show "none recorded".

**Revisit when.** A new mistake is logged: its repair commit must cite the id, and its test case must list it in `guards`.

## D-DIAGRAM: Component teardown drawn as generated SVG; Mermaid text only for repo readers

**Decision.** The exploded 2.5D teardown (stacked, offset, skewed layer cards; components per layer; click a layer to
expand in HTML) is SVG emitted by `./rfp build` from the same records as every other figure. The same SVG goes into
the PDF (one full view plus one page per layer). `docs/architecture.mmd` is also emitted as plain text from the same data,
for engineers browsing the repo; nothing Mermaid-related runs in the deck or the PDF (Zach approved, 2026-10-10).

**Why.** The runtime stays standard-library only, which is the support and air-gap story Sam Ito's constraints point to (A).
An isometric layered view is outside Mermaid's automatic layout, so it would need custom drawing anyway (D: inference).
Generating from the records keeps the diagram as current as the numbers (K35).

**Rejected.** Mermaid as a dependency, loaded from a CDN or pre-rendered by a headless browser at build time
(size about 2 MB, D: estimate not measured). It adds a dependency and a network or toolchain step, and its auto-layout
cannot produce the stacked isometric view.

**Revisit when.** The diagram needs automatic layout of more than about 30 components, or RET's engineers ask for
Mermaid sources they can edit.

## D-SCOPE: Hybrid scope after the bar-raiser review (Zach, 2026-10-10)

**Decision.** Keep only the extra work that answers the brief's own pains with client data: the Deadlines board and the
Amendment Log (Doug's amendment incident; the real deposit-difference deadline), on a minimal trust layer. Cut the other
stakeholder dashboards, Playback and the review punchlists; fold the six commercial-terms items into one "open questions
for RET" line. Rehearsal comes first. Add risk allocation (cost cap §7.4, delay damages §7.5, proposal security §7.2) as
labelled key facts, one risk-table row and one test case (W13), without modelling or pricing anything.

**Why.** No line in the brief asks for per-stakeholder dashboards or commercial terms, and they had become the critical path
(bar-raiser BR2, BR3; D: reviewer judgement). Brief p7 rewards "a modest build that proves you listened" (A). The reviewer
estimated a 55% chance the panel calls the build over-built if that work ships and is shown, 30% if cut (D: logged as
BR-P3 for scoring). The kept boards use only grade-A RFP text.

**Rejected.** Cut everything (lowest over-built risk, but drops Doug's top ask, the deadlines, which the RFP itself puts on
the bidder, §4.3). Keep everything off-stage (most work; the dashboards would still sit on the critical path to submission).

**Revisit when.** A timed clean-database rehearsal passes twice with time to spare, or RET asks for a dashboard by name.

## D-BRAND: The deck uses monday.com's public design-system colours and type, not its logo (Zach, 2026-10-10)

**Decision.** Colours and fonts come from monday.com's open Vibe design system (github.com/mondaycom/vibe:
`packages/style/source/themes/light-theme.scss`, `typography.scss`; read 2026-10-10): primary #0073ea, positive #00854d,
text #323338 and #676879, borders #d0d4e4, grey background #f6f7fb; Figtree for text, Poppins for titles. No logo.

**Why.** The candidate presents as monday.com's forward deployed engineer to a monday.com customer, so the deck should look
at home next to monday.com's own product (C: primary source opened). Values were read from the source, not recalled.

**Rejected.** The candidate's personal dark palette (reads as a personal brand, prints poorly). monday.com's logo (would make
a candidate's deck look like an official monday.com document).

**Revisit when.** monday.com supplies a presentation template, or the fonts cannot load where the PDF is rendered.

**Correction (2026-10-12, brief trace).** No separate Deadlines board or Amendment Log was built. The deadlines are
rows on RET · Key Facts (the proposal due date and key dates, with the governing text), and each amendment's changes are
the "What it changes" column on RET · Solicitations. The record above described the intent; this is what shipped.

## D-SUBTRACT: Remove anything whose removal would not lower the panel's grade (Zach, 2026-10-10)

**Decision.** Removal only, after rehearsal. Cut from the queue: the exploded 2.5D component teardown and
docs/architecture.mmd (a plain pipeline diagram is enough); Present mode and the US Letter PDF conversion (the brief needs
a PDF, not a format; the current PDF stays); the remaining CI scanners (semgrep, CodeQL, bandit; nothing further is added).
Fold into one "What's next" line on the impact slide, with detail in the README: the learning loop, the "track X, unlocks
Y" ladder, the stakeholder acceptance rubric. Keep in the repo with at most one slide line plus prepared answers: the fault
matrix, the war game, the predictions log, trace spans. Internal only, shown if asked: the Evidence tab, Evals filters, deep
links, the status page. The story: amendment truth in code; select, do not generate, with the verbatim figure check and
refusal; monday-native landing; an A-E source grade beside every figure; the risk table and the capabilities split; one
plain mistakes-log example; the rehearsed demo. Pre-registered estimates stay on slides 1-2 as one small line each.

**Why.** The test for every item is whether removing it would lower the panel's grade. Brief p7 rewards a modest build that
proves you listened (A); the bar-raiser put over-built perception at 55% if extra work ships and is shown (D, BR-P3).

**Rejected.** Keep building the queued items and hide them behind clicks: still costs the days before Thursday that
rehearsal needs, and every extra surface is one more thing to defend line by line (brief p8).

**Revisit when.** Rehearsal passes twice with time to spare, or the panel asks for one of the cut items by name.

## D-MCP: Write to monday.com through the GraphQL API, not the MCP server (reviewed against monday.com's own repos, 2026-10-10)

**Decision.** The pipeline writes through the GraphQL API with its own small client. monday.com's official MCP server
(github.com/mondaycom/mcp, hosted at mcp.monday.com) is the right surface for the NEXT step: exposing "ask the RFP" as a
tool that monday.com's agents can call.

**Why.** Our writes must be deterministic and auditable: upserts keyed on the clause (no duplicates on re-run), every call's
complexity cost logged (B: flightlog/monday_calls.jsonl), and an allowlist of four boards (war game S7). The MCP server is
built for agents choosing actions; its beta `all_monday_api` tool runs any GraphQL an agent writes (C: repo README, read
2026-10-10), the opposite of a fixed allowlist. The official Python SDK (github.com/mondaycom/monday-api-python-sdk) would
add a dependency and drop the per-call cost logging and retry handling we measured.

**Rejected.** MCP for the sync (agent-chosen writes, harder to audit). The Python SDK (a dependency for little gain at
this size). monday.com's agent-evaluation engine Sensei (github.com/mondaycom/sensei; Node, AI judge) as our test runner:
our tests score citations and figures mechanically; exporting the 31 cases as a Sensei suite is a later step.

**Revisit when.** RET wants staff to query the RFP from inside monday.com's AI (then serve an MCP tool), or the sync grows
past a few boards (then the official SDK's types earn their keep).

## D-FREEZE: No new tasks until submission (Zach, 2026-10-10)

**Decision.** From now until the ZIP is submitted, nothing new enters the plan. The landing list: Zach's rehearsal;
the proof-of-one-answer object with `./rfp verify-proof` and the PDF no-JavaScript gate; the finance cost-model CSV; a
second blind cold read; the retrospective and T+N snapshot; the gauntlet (needs Zach's go); package and submit. Every other
open item moves to "next sprint" (with the monday.com app and the managed-agent exploration).

**Why.** Measured on the plan itself: in the last ~60 commits it grew from 18 to 45 tasks while done went from 6 to 15
(B: plan.json history), and more asks lived only in HANDOFF.md. Adding was outpacing landing.

**Rejected.** Fanning out to parallel writing sessions: everything left touches the same files, and two sessions
already collided once today; read-only workers run in parallel instead, one session writes.

**Revisit when.** The ZIP is submitted.

## D-REUSE: Reusable harness, disposable client surface (Zach, 2026-10-10)

**Decision.** The build has two layers, kept apart on purpose. The harness is reusable: the flight recorder (one
record per step and per commit), the evidence file and its generator, the gates (secrets, leak, provenance, security,
staleness, overflow, link check, proof verification), the canaries, the e2e runs against pre-registered expectations,
and the mistakes log. The client surface is one-off: the deck's wording, the front page's cards, and RET-specific copy.

**Why.** The harness exists so that any figure or change can be traced to its source and re-run: that is what makes
change control and audit cheap, and it carries to the next client unchanged. The surface is written for one audience,
kept thin, and generated from the harness's records, so even the disposable layer is reproducible and no hand-typed
figure can drift.

**Revisit when.** A second client build starts: whatever had to be rewritten for it was surface; whatever was copied
unchanged was harness. Anything that needed edits but should not have is a seam to fix.

## D-SETUPRUN: A run where no model replied is not a model result (2026-10-11)

**Decision.** In the every-run record on slide 6 (`E-eval-wave*-record`), a Claude run whose every failing case failed
before any model replied (the gate reads `provider: ...`, e.g. no API key set) is excluded and counted in the record's
working as "excluded, setup only". The run stays in `flightlog/eval_runs.jsonl`.

**Why.** The 2026-10-11 00:49 release-check run had no key in the shell; 14 of 18 questions came back "AI unavailable"
and the record's worst run became 4/18, which describes the shell, not the model. Every other failure, including
ones that make the record look worse, still counts. The rule is mechanical and stated in code, so it cannot be applied
selectively.

**Revisit when.** A run mixes setup failures with model failures: it then counts in full.

## D-SDK: Raw GraphQL, not the JavaScript SDK (2026-10-11)

**Decision.** The briefing lists the JavaScript SDK, `@mondaydotcomorg/api` (14.1.0 on npm, built on `graphql-request`,
Node 18+). We did not use it: the build is standard-library Python with no npm step, and our own client logs the cost
and complexity of every call and applies the retry rules we measured (`source/rfp/monday.py`), which the SDK would hide.

**Revisit when.** The sync grows past a few boards or moves to Node; then a typed SDK earns its place.

## D-ORCH: No agent-graph runtime (LangGraph) (2026-10-11)

**Decision.** LangGraph (listed in the briefing) was not adopted. The pipeline is a short fixed sequence (retrieve,
answer, check every figure and citation, write) and a graph runtime would add a dependency for no new behaviour. Its
resume-after-failure and human-review features map to what we already have: idempotent upsert keys (a re-run creates
nothing) and the refusal floor plus "Needs review" state.

**Revisit when.** The flow gains branches, long waits on people, or several agents; Claude Managed Agents is the
planned next step (`sprint2-agents`).

## D-PLAY: Queries checked in code and logs, not the API Playground (2026-10-11)

**Decision.** Every GraphQL call was checked by running it from code with its result and complexity logged
(`flightlog/monday_calls.jsonl`), not in the API Playground. The Playground (schema explorer, version switching,
query history) is the planned pre-test step for the mini app (`sprint2-app`) and a quick way to answer "does this
still work on the next API version".

## D-HELP: What the Academy, Knowledge Base and MCP Setup Guide changed (2026-10-11)

**Decision.** All three were read in a browser on 2026-10-11 (an automated fetch had been blocked). The Academy is a
training catalogue (lessons, learning paths, certifications) and shaped nothing in the build. The Knowledge Base's
board permissions guidance backs the slide 5 wording "under RET board permissions". The MCP Setup Guide
("Get started with monday MCP", modified 2026-09-22) confirms the D-MCP next step is cheap and safe to offer: monday
MCP is preinstalled on every account and plan at no extra cost, each user authorises it with OAuth and it sees only
what that user can see, an admin controls it under Admin, Permissions, AI Connectors, standard API limits apply, and
monday recommends reviewing AI-suggested changes before applying them. That per-user OAuth model is also the honest
answer to the token question: today the sync uses one personal token; MCP (or a service account) is the pilot step.

## D-RC14-GATE: the local release check is the gate for rc14 (2026-10-11)

GitHub Actions did not run on dccfc2e, 4354bb9 or a4af909 (runs 38129444604, 38129277066, 38129075636): each job
stopped in 2 s with "recent account payments have failed or your spending limit needs to be increased", a billing
block, not a code failure. Zach chose to gate rc14 on `scripts/release_check.sh` (exit 0) run locally, which runs
the same checks. rc13 is left as tagged. The history bundle is now packed with a deeper delta window (lossless,
every commit kept) to bring the ZIP back under the 8 MB warning.

## D-SIZE: rc14 ships at 8.56 MB (2026-10-11)

Zach accepted 8.56 MB: over the 8 MB warning, under the 10 MB cap. The full history bundle and the complete AI-call
log both stay in, so every cited commit still resolves. The phone present-mode overlay waits until after the dress
rehearsal (feature freeze).

## D-CLAIMS: Every sentence on the slides is checked, not only the figures (Zach, 2026-10-12)

A claims audit read all 65 claims on the 10 slides against the brief, the logs and the code: 43 held, 16 were
reworded, 4 were false as written (what leaves RET, who wrote the test questions, which boards RET already uses).
Zach approved the ledger's wording. The figure gates could not catch these, because the errors sat in the words
around the figures; `build.py --check` now refuses the false phrasings by name (KINTSUGI K54).

## D-UNFREEZE: Two items enter before the rehearsal (Zach, 2026-10-12)

D-FREEZE held new work out until submission. Zach judged that premature for two items the panel grades directly:
the claims fixes above, and a "How we decided" view that shows each key decision's options, choice and evidence.
Both land before rehearsal #1. Everything else held stays held until after it.

## D-NOTBUILT: What this pilot does not build, and why (2026-10-12)

**Not built:** watching the ISO portal for new amendments (staff add the file; the sync does the rest); a link to RET's
document-management system; submitting anything to the ISO; the ~50-row response tracker Doug keeps today; leadership
decks. **Why:** each is either outside what the brief asks the pilot to prove (Elena's three tests), or a decision that
belongs to RET's own teams (Sam Ito for integrations, Doug for the tracker). **Revisit when:** the pilot passes its exit
test and RET names one of these as the next pain.

## D-NOTIFY: No notifier in the pilot (2026-10-12)

**Decision.** Not pursued. A monday.com automation (notify Doug when a fact is amended) was considered and dropped: this
account is on the free plan, where automations are not included, and it reached past what the brief asks. The honest
line in the demo is enough: a person still downloads the amendment, as Doug asked, and the board shows what changed.

## D-PLAN: Everything here is measured on the free plan (2026-10-12)

**Decision.** The submission is built, tested and measured on a free monday.com trial account, as the brief asks. Every
monday.com figure (calls a day, complexity cost, timings) comes from that account. Three things a paid plan offers were
not used, and none is claimed: monday.com's own AI models (the `monday` provider exists but has never answered, 403 on
free), automations (D-NOTIFY), and API usage analytics.

**If a paid plan becomes available.** Test in a copy, against separate boards, with a separate token; never change the
submitted build. The order: the live-question path, then the eval set on `--provider monday`, then one automation for
amended facts. Use monday.com only where it does not bypass the figure check: no AI column or assistant answers RFP
questions directly, because their answers would skip the word-for-word check that every figure must pass.

## D-HISTORY: The ZIP carries a readable change history, not the git bundle (Zach, 2026-10-13)

**Decision.** `HISTORY.txt` (every commit: hash, date, release tag, full message, files changed) replaces
`history.bundle`, and every log ships whole. The ZIP falls from about 10.4 to about 3 MB.

**Why.** The bundle was 8.7 of the ZIP's 10.4 MB, mostly past versions of the PDF and the AI call log, and the ZIP was
over 10 MB on the stricter reading (10,000,000 bytes; K67). Every cited hash is still findable in `HISTORY.txt`; what is
lost from the ZIP is cloning and checking out an old commit, which the repository still allows.

**Rejected.** A slimmer clonable history without the old PDF versions: it changes every commit hash, so every cited
hash would need a translation table. Keeping the bundle and reading 10 MB as 10,485,760 bytes: no margin, and wrong if
the portal counts decimal bytes.

