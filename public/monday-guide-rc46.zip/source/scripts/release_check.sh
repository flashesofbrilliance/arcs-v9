#!/bin/sh
# CI-equivalent tier of DONE.md. Costs ~$0.10 of API calls. Run before tagging a submission candidate.
set -e
cd "$(dirname "$0")/.."
(cd source && python3 -m eval.check_golden && python3 -m eval.run_eval --provider claude && python3 -m sim.m1_fuzz --runs 30000 --seed 7 >/dev/null)
python3 -m flight.report --check
python3 -m flight.journey > JOURNEY.md
python3 scripts/freshness.py   # re-read the boards; flag stale videos (never fails the release)
python3 scripts/package.py
# Reached only if every step above passed (set -e): tag the next release candidate and keep its exact artifact.
n=$(git tag -l 'rc*-*' | sed 's/^rc\([0-9]*\)-.*/\1/' | sort -n | tail -1); n=$((${n:-0}+1))
tag="rc$n-$(date +%Y-%m-%d)"
git tag -a "$tag" -m "release_check exit 0" && git push -q origin "$tag" || true
cp dist/submission.zip "dist/submission-rc$n.zip"
shasum -a 256 "dist/submission-rc$n.zip" | tee "dist/submission-rc$n.zip.sha256"
echo "release candidate: $tag -> dist/submission-rc$n.zip"
