"""Dress rehearsal: the whole submission path as a graph of steps, run in loops, every run logged.

./rfp rehearse                 # one loop, free (mock model, fake monday.com)
./rfp rehearse --loops 3       # three loops; reports any step that is not green every time (flaky)
./rfp rehearse --plant         # self-test: plant a red step and prove its dependants are skipped, not passed
./rfp rehearse --live          # adds one live pass: Claude + real monday.com boards (~84 monday calls, cents of API)

Each step runs only when every step it depends on passed; a failed step marks its dependants "skipped", never
"passed". Results go to flightlog/rehearsal_runs.jsonl, one line per loop. Standard library only.
"""
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
import zipfile
from datetime import datetime, timezone

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PY = sys.executable
LOG = os.path.join(ROOT, "flightlog", "rehearsal_runs.jsonl")


def steps(live, unzip_dir, plant=False):
    s = lambda *a: [PY, os.path.join(ROOT, "scripts", a[0])] + list(a[1:])
    m = lambda *a: [PY, "-m"] + list(a)
    g = [  # (name, depends on, command, working dir)
        ("build", [], s("build.py"), ROOT),
        ("staleness", ["build"], s("build.py", "--check"), ROOT),
        ("provenance", ["build"], s("provenance_lint.py"), ROOT),
        ("security", ["build"], s("security_gate.py"), ROOT),
        ("overflow", ["build"], s("overflow_gate.py"), ROOT),
        ("proof", ["build"], s("proof.py", "--verify"), ROOT),
        ("front-page links", ["build"], s("home.py", "--check"), ROOT),
        ("seam tests", ["build"], m("unittest", "-q", "tests.test_seams"), os.path.join(ROOT, "source")),
        ("mutation check", ["seam tests"], m("tests.mutate"), os.path.join(ROOT, "source")),
        ("golden", ["build"], m("eval.check_golden"), os.path.join(ROOT, "source")),
        ("canaries", ["staleness", "provenance"], s("canaries.py"), ROOT),
        ("war game", ["mutation check"], m("sim.wargame", "--provider", "mock"), os.path.join(ROOT, "source")),
        ("package", ["staleness", "provenance", "security", "overflow", "proof", "front-page links", "canaries", "golden"], s("package.py"), ROOT),
        ("unzip", ["package"], None, ROOT),
        ("onboarding doc-test", ["unzip"], s("doc_test.py"), ROOT),
        ("e2e from ZIP", ["unzip"], m("sim.e2e", "--runs", "1", "--provider", "mock", "--monday", "fake", "--from-zip"), os.path.join(ROOT, "source")),
        ("e2e faults", ["build"], m("sim.e2e", "--runs", "1", "--provider", "mock", "--monday", "fake"), os.path.join(ROOT, "source")),
    ]
    if plant:  # self-test: force provenance red; package, unzip and e2e from ZIP must then show as skipped, never passed
        g = [(n, d, [PY, "-c", "raise SystemExit(1)"] if n == "provenance" else c, w) for n, d, c, w in g]
    if live:
        g.append(("e2e live", ["e2e from ZIP", "e2e faults"], m("sim.e2e", "--runs", "1", "--provider", "claude", "--monday", "live"), os.path.join(ROOT, "source")))
    return g


COLOR = sys.stdout.isatty() or bool(os.environ.get("FORCE_COLOR"))
MARK = {"pass": ("\u2713", "32"), "fail": ("\u2717", "31"), "skipped": ("-", "33")}


def row(name, state, detail):
    """One aligned line per step, cut to the terminal width; color only on a terminal or with FORCE_COLOR."""
    mark, code = MARK[state]
    width = shutil.get_terminal_size((100, 20)).columns
    detail = detail if len(detail) <= width - 34 else detail[:max(0, width - 35)] + "\u2026"
    tag = "%s %-7s" % (mark, state.upper())
    if COLOR:
        tag, detail = "\033[%sm%s\033[0m" % (code, tag), "\033[2m%s\033[0m" % detail
    return "  %-21s %s %s" % (name, tag, detail)


def unzip(dest):
    """Open the ZIP the way a reviewer would: every shipped page must be there and nothing from outside it."""
    with zipfile.ZipFile(os.path.join(ROOT, "dist", "submission.zip")) as z:
        z.extractall(dest)
    need = ["source/ONBOARDING.md", "source/docs/using-the-boards.md", "source/rfp", "source/glossary.json", "source/docs/site/index.html", "source/docs/site/deck.html", "presentation/RET-RFP-Intelligence.pdf",
            "source/docs/site/proof-of-one-answer.html", "source/docs/site/build-log.html", "source/README.md", "source/KINTSUGI.md"]
    missing = [n for n in need if not os.path.exists(os.path.join(dest, n))]
    return (1, "missing from the ZIP: " + ", ".join(missing)) if missing else (0, "%d required files present" % len(need))


HOME_DIR = re.compile(r"/(?:Users|home)/[^/\s]+/")   # any home folder, not only this machine's


def relative(line):
    """The log ships in the ZIP: a step's output keeps paths relative to the repository, never this machine's."""
    line = line.replace(ROOT + os.sep, "").replace(ROOT, ".").replace(tempfile.gettempdir(), "<tmp>")
    return HOME_DIR.sub("<home>/", line.replace(os.path.expanduser("~"), "<home>"))


def run_once(live, plant=False):
    tmp = tempfile.mkdtemp(prefix="rehearsal-")
    # Nothing carried over from an earlier run: no ZIP from before (a failed package step must not leave an old one to
    # unzip), and every step compiles Python fresh into this loop's own cache folder instead of reusing __pycache__.
    zip_path = os.path.join(ROOT, "dist", "submission.zip")
    if os.path.exists(zip_path):
        os.remove(zip_path)
    os.environ["PYTHONPYCACHEPREFIX"] = os.path.join(tmp, "pycache")
    status, results = {}, []
    try:
        for name, deps, cmd, cwd in steps(live, tmp, plant):
            if any(status.get(d) != "pass" for d in deps):
                status[name] = "skipped"
                results.append({"step": name, "status": "skipped", "after": [d for d in deps if status.get(d) != "pass"]})
                continue
            t = time.time()
            if cmd is None:
                code, out = unzip(tmp)
            else:
                p = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, timeout=1800)
                code, out = p.returncode, (p.stdout + p.stderr).strip().splitlines()[-1:] or [""]
                out = relative(out[0])[:200]
            status[name] = "pass" if code == 0 else "fail"
            results.append({"step": name, "status": status[name], "s": round(time.time() - t, 1), "last_line": out})
            print(row(name, status[name], "%5.1fs  %s" % (time.time() - t, out)), flush=True)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    for r in results:
        if r["status"] == "skipped":
            print(row(r["step"], "skipped", "after " + ", ".join(r["after"])))
    return results


def main(argv):
    loops = int(argv[argv.index("--loops") + 1]) if "--loops" in argv else 1
    live = "--live" in argv
    if "--plant" in argv:
        res = run_once(False, plant=True)
        st = {r["step"]: r["status"] for r in res}
        ok = st["provenance"] == "fail" and all(st[n] == "skipped" for n in ("canaries", "package", "unzip", "e2e from ZIP"))
        print("rehearsal --plant: %s (a red step %s its dependants)" % ("ok" if ok else "FAILED", "skips" if ok else "did NOT skip"))
        return 0 if ok else 1
    commit = subprocess.run(["git", "-C", ROOT, "rev-parse", "--short", "HEAD"], capture_output=True, text=True).stdout.strip()
    history = []
    for n in range(1, loops + 1):
        print("rehearsal loop %d of %d (commit %s%s)" % (n, loops, commit, ", live" if live else ""))
        t = time.time()
        res = run_once(live and n == loops)   # at most one paid pass, on the last loop
        green = all(r["status"] == "pass" for r in res)
        dirty = subprocess.run(["git", "-C", ROOT, "status", "--porcelain", "--untracked-files=no", "--", "source", "scripts", "presentation", "docs"], capture_output=True, text=True).stdout.strip() != ""
        rec = {"t": datetime.now(timezone.utc).isoformat(), "commit": commit, "uncommitted_code": dirty, "loop": n, "live": live and n == loops,
               "green": green, "seconds": round(time.time() - t, 1), "steps": res}
        os.makedirs(os.path.dirname(LOG), exist_ok=True)
        open(LOG, "a").write(json.dumps(rec) + "\n")
        history.append(rec)
        print("loop %d: %s in %.0fs" % (n, "GREEN" if green else "RED", rec["seconds"]))
    names = [r["step"] for r in history[0]["steps"]]
    flaky = [s for s in names if len({next(r["status"] for r in h["steps"] if r["step"] == s) for h in history if any(r["step"] == s for r in h["steps"])}) > 1]
    ok = all(h["green"] for h in history)
    print("rehearsal: %s; %d of %d loops green%s; logged to flightlog/rehearsal_runs.jsonl" % (
        "READY" if ok else "NOT READY", sum(h["green"] for h in history), loops, ("; flaky: " + ", ".join(flaky)) if flaky else ""))
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
