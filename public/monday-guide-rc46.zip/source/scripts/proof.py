"""Proof of one answer: "the proposal deadline is December 4, 2026, not November 13", as one self-contained object.

python3 scripts/proof.py           # write docs/site/proof-of-one-answer.json and .html
python3 scripts/proof.py --verify  # recompute everything; exit 1 on any mismatch (tamper, drift, or a missing test)

The JSON carries the premises quoted from the RFP, the conclusion, the code path the system took, what would make the
answer false, the tests that guard each failure, and SHA-256 hashes of both source documents and of the commit.
The HTML is the same object rendered with one probe script (a page policy blocks every request but the web fonts and a localhost check),
so it can be read offline and verified without trusting us. Standard library only.
Also checks the shipped PDF contains no JavaScript, auto-run or launch actions.
"""
import hashlib
import html
import json
import os
import re
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(ROOT, "source")
sys.path.insert(0, SRC)
os.environ.setdefault("MODEL_PROVIDER", "mock")
os.environ["MODEL_CALL_LOG"] = os.devnull
BASE = os.path.join(ROOT, "data", "rfp_maple_creek.txt")
AMEND = os.path.join(ROOT, "data", "rfp_maple_creek_amendment_1.txt")
OUT_JSON = os.path.join(ROOT, "docs", "site", "proof-of-one-answer.json")
OUT_HTML = os.path.join(ROOT, "docs", "site", "proof-of-one-answer.html")
PDF = os.path.join(ROOT, "presentation", "RET-RFP-Intelligence.pdf")
QUESTION = "When are proposals due?"


def sha(path):
    return hashlib.sha256(open(path, "rb").read()).hexdigest()


def line_with(path, needle):
    """The full line(s) of the source that contain the needle, joined; quoted exactly as written."""
    text = open(path).read()
    i = text.index(needle)
    start = text.rfind("\n", 0, i) + 1
    end = text.find("\n", i + len(needle))
    return re.sub(r"\s+", " ", text[start:end]).strip()


def clause(db, cid):
    """The whole clause as parsed (a single line can stop mid-sentence at a line break)."""
    row = db.execute("SELECT text FROM clauses WHERE clause_id=?", (cid,)).fetchone()
    return re.sub(r"\s+", " ", "%s %s" % (cid, row["text"])).strip()


def guard_exists(t, tests_src, golden, e2e):
    """Every guard named in the proof must exist in the repo; nothing is assumed present."""
    if t.startswith("seam test"):
        return ("def test_%s_" % t.split()[-1]) in tests_src
    if t.startswith("mutation check"):
        return ('"%s ' % t.split()[-1]) in open(os.path.join(SRC, "tests", "mutate.py")).read()
    if t.startswith("golden"):
        return t.split()[-1] in golden
    if t.startswith("e2e"):
        return t.split()[1] in e2e
    if t == "paraphrase canary":
        return "def paraphrase(" in open(os.path.join(ROOT, "scripts", "canaries.py")).read()
    if t == "Amendment 2 input on the test bench":
        return 'id="amend2"' in open(os.path.join(SRC, "harness", "ui.html")).read()
    return False  # an unknown guard is not counted as present


def build():
    from rfp import answer, store
    db = store.connect(":memory:")
    store.ingest(db, open(BASE).read(), "base")
    store.ingest(db, open(AMEND).read(), "amendment 1")
    r = answer.answer(db, QUESTION)
    effect = dict(db.execute("SELECT amendment_clause, op, target FROM effects WHERE amendment_clause='A1.1'").fetchone())
    tests_src = open(os.path.join(SRC, "tests", "test_seams.py")).read()
    golden = {c["id"] for g in ("golden.json", "golden_wave2.json") for c in json.load(open(os.path.join(SRC, "eval", g)))}
    e2e = {q["id"] for q in json.load(open(os.path.join(SRC, "eval", "e2e_expected.json")))["questions"]}
    obj = {
        "claim": "The proposal deadline for Maple Creek is DECEMBER 4, 2026, 5:00 PM CT, not November 13, 2026.",
        "premises": [
            {"id": "P1", "source": "RFP §3.2", "quote": line_with(BASE, "Proposal Submission Deadline")},
            {"id": "P2", "source": "Amendment No. 1, §A1.1", "quote": clause(db, "A1.1")},
            {"id": "P3", "source": "RFP §4.3", "quote": clause(db, "4.3")},
        ],
        "inference": "P2 revises the deadline set in P1, and P3 says the ISO may amend the RFP, so the amended date governs.",
        "conclusion": "DECEMBER 4, 2026" if "DECEMBER 4, 2026" in r["answer"] else "MISMATCH",
        "how_the_system_reached_it": {
            "resolver": "%s %s %s" % (effect["amendment_clause"], effect["op"], effect["target"]),
            "path": r.get("gate"), "status": r["status"], "cited": [c["clause_id"] for c in r.get("citations", [])],
            "note": "fast path: the governing text is read from the documents, no AI model call is made for this question"},
        "what_would_make_it_false": [
            {"risk": "A later amendment changes the date again", "guarded_by": ["e2e E1 (re-run on every push)", "Amendment 2 input on the test bench"]},
            {"risk": "Amendment wording the rules cannot read is treated as 'no change'", "guarded_by": ["seam test K17", "seam test K18", "mutation check K17"]},
            {"risk": "An answer about the deadline cites a neighbouring clause and omits the amendment", "guarded_by": ["seam test K19", "golden W1", "golden W11"]},
            {"risk": "A casual or misspelled question misses the deadline clause", "guarded_by": ["e2e E6", "paraphrase canary"]},
            {"risk": "The document was not read at all and the system says 'not addressed'", "guarded_by": ["seam test K42"]},
        ],
        "tests_exist": {t: (("test_%s_" % t.split()[-1]) in tests_src) if t.startswith("seam test") else
                        (t.split()[-1] in golden) if t.startswith("golden") else
                        (t.split()[1] in e2e) if t.startswith("e2e") else True
                        for row in [] for t in row},
        "integrity": {"base_rfp_sha256": sha(BASE), "amendment_1_sha256": sha(AMEND),
                      "commit": subprocess.run(["git", "-C", ROOT, "rev-parse", "HEAD"], capture_output=True, text=True).stdout.strip()},
    }
    names = [t for row in obj["what_would_make_it_false"] for t in row["guarded_by"]]
    obj["tests_exist"] = {t: guard_exists(t, tests_src, golden, e2e) for t in names}
    return obj


PROOF_STYLE = """main{max-width:760px}h2{margin-top:28px}
blockquote{margin:6px 0 0;padding:8px 12px;background:var(--soft);border:1px solid var(--line);border-radius:8px;font-family:ui-monospace,Menlo,monospace;font-size:14px}
td{font-size:15px}code{font-family:ui-monospace,Menlo,monospace;font-size:13px;word-break:break-all}pre,blockquote{white-space:pre-wrap;word-break:break-word}"""


PLAIN = {
    "seam test K17": "test: an amendment that revises a clause is never read as no change",
    "seam test K18": "test: wording the rules cannot read sends the answer to a person",
    "seam test K19": "test: the governing amendment is always cited",
    "seam test K42": "test: an unreadable document is refused, not stored as empty",
    "mutation check K17": "check: breaking the amendment reader makes a test fail",
    "paraphrase canary": "check: reworded questions still find the clause",
}


def render(obj):
    e = html.escape
    prem = "".join("<li><b>%s</b> %s<blockquote>%s</blockquote></li>" % (e(p["id"]), e(p["source"]), e(p["quote"])) for p in obj["premises"])
    # Each guard links to where a reviewer checks it, in this same folder (no network): a mistake row, or a test set.
    def cite(g):
        m = re.search(r"\b(K\d+)\b", g)
        if m:
            return '<a href="mistakes.html#%s">%s</a>' % (m.group(1), e(PLAIN.get(g, g)))
        m = re.search(r"\b([QTW])(\d+)\b", g)
        if m:
            f = "golden_wave2.json" if m.group(1) == "W" else "golden.json"
            return '%s (<a href="../../source/eval/%s">%s</a>)' % (e(g), f, f)
        return e(PLAIN.get(g, g))
    risks = "".join('<tr><td data-label="What would make it false">%s</td><td data-label="Guarded by">%s</td></tr>' % (e(r["risk"]), ", ".join(cite(g) for g in r["guarded_by"])) for r in obj["what_would_make_it_false"])
    h = obj["how_the_system_reached_it"]
    from home import STYLE, GNAV_STYLE, STACK_STYLE, gnav, GNAV_PROBE, CRUMB_STYLE, crumbs
    css = STYLE + GNAV_STYLE + STACK_STYLE + CRUMB_STYLE + PROOF_STYLE
    shell = ('<!doctype html><html lang="en"><head><meta charset="utf-8">'
             '<meta http-equiv="Content-Security-Policy" content="default-src \'none\'; script-src \'unsafe-inline\'; connect-src http://127.0.0.1:8765; style-src \'unsafe-inline\' https://fonts.googleapis.com; font-src https://fonts.gstatic.com">'
             '<meta name="viewport" content="width=device-width,initial-scale=1"><title>Proof Of One Answer</title>'
             '<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Figtree:wght@400;600&family=Poppins:wght@600&display=swap">'
             '<style>' + css.replace("%", "%%") + '</style></head><body>' + (gnav("wiki.html") + GNAV_PROBE + "<main>" + crumbs("Proof Of One Answer")).replace("%", "%%") + """
<h1>Proof of one answer</h1><p><b>%s</b></p>
<p class="m">This page runs one small script, a check for whether the local bench is up, and links only to files inside this submission, apart from the page bar's live link. It loads the web fonts and nothing else. Check it with <code>./rfp verify-proof</code>, which recomputes every hash and re-reads every quote from the RFP. The same proof as data is <a href="proof-of-one-answer.json"><code>proof-of-one-answer.json</code></a>, next to this page.</p>
<h2>Premises, quoted from the RFP</h2><ol>%s</ol>
<h2>Inference</h2><p>%s</p>
<h2>How the system reached it</h2><p>Resolver: §%s. Path: %s. Status: %s. Cited: %s. %s.</p>
<h2>What would make it false, and what guards each</h2><table class="stack">%s</table>
<h2>Integrity</h2><p class="m">Base RFP SHA-256 <code>%s</code><br>Amendment 1 SHA-256 <code>%s</code><br>Commit <code>%s</code></p>
</main></body></html>""")
    return shell % (e(obj["claim"]), prem, e(obj["inference"]), e(h["resolver"]), e(h["path"] or ""), e(h["status"]),
                           e(", ".join(h["cited"])), e(h["note"].capitalize()), risks, obj["integrity"]["base_rfp_sha256"],
                           obj["integrity"]["amendment_1_sha256"], obj["integrity"]["commit"])


def pdf_problems():
    data = open(PDF, "rb").read()
    return [k for k in (b"/JavaScript", b"/JS ", b"/JS(", b"/Launch", b"/OpenAction", b"/AA ") if k in data]


def verify():
    errors = []
    if not os.path.exists(OUT_JSON):
        return ["proof-of-one-answer.json is missing (run python3 scripts/proof.py)"]
    shipped = json.load(open(OUT_JSON))
    if shipped["integrity"]["base_rfp_sha256"] != sha(BASE): errors.append("base RFP hash does not match")
    if shipped["integrity"]["amendment_1_sha256"] != sha(AMEND): errors.append("Amendment 1 hash does not match")
    text = re.sub(r"\s+", " ", open(BASE).read() + " " + open(AMEND).read())
    for p in shipped["premises"]:
        q = re.sub(r"^(A?\d+\.\d+) ", "", p["quote"])
        if q not in text: errors.append("premise %s is no longer in the RFP text word for word" % p["id"])
    now = build()
    if now["conclusion"] != shipped["conclusion"] or now["conclusion"] == "MISMATCH": errors.append("the pipeline no longer reaches the same conclusion")
    if now["how_the_system_reached_it"]["cited"] != shipped["how_the_system_reached_it"]["cited"]: errors.append("the citations changed")
    errors += ["guard %r no longer exists" % t for t, ok in now["tests_exist"].items() if not ok]
    html_text = open(OUT_HTML).read() if os.path.exists(OUT_HTML) else ""
    # The shared page bar's live link and the two web-font links are the only network references allowed.
    scrubbed = re.sub(r'<link rel="stylesheet" href="https://fonts\.googleapis\.com/[^"]*">|href="http://127\.0\.0\.1:8765/[^"]*"|<meta http-equiv="Content-Security-Policy"[^>]*>|<!-- probe:start -->.*?<!-- probe:end -->', "", html_text, flags=re.S)
    if re.search(r"<script|https?://|<link|<img|<iframe", scrubbed, re.I): errors.append("the proof page contains script, a link or an external resource")
    errors += ["the PDF contains %s" % k.decode().strip() for k in pdf_problems()]
    return errors


def main(argv):
    if "--verify" in argv:
        errs = verify()
        for e in errs:
            print("verify-proof: " + e, file=sys.stderr)
        print("verify-proof: %s" % ("FAILED (%d)" % len(errs) if errs else "ok: hashes, quotes, conclusion, citations, guards, page and PDF all check"))
        return 1 if errs else 0
    obj = build()
    json.dump(obj, open(OUT_JSON, "w"), indent=1, ensure_ascii=False)
    open(OUT_HTML, "w").write(render(obj))
    print("proof: %s (conclusion %s; %d guards, all present: %s)" % (os.path.basename(OUT_JSON), obj["conclusion"], len(obj["tests_exist"]), all(obj["tests_exist"].values())))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
