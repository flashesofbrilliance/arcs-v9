"""Doc-as-test: run every keyless step of ONBOARDING.md from a freshly unzipped copy of the ZIP.

python3 scripts/doc_test.py     # exit 1 if any step fails or its output lacks an expected line

A step is a ```bash block placed right after a <!-- doc-test --> marker; each <!-- expect: text --> after it must
appear in the step's output. Commands run as split arguments, never through a shell. Runs with no keys in the environment and no .env, the way a reviewer opens it cold.
Standard library only.
"""
import os
import re
import shlex
import shutil
import subprocess
import sys
import tempfile
import zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def steps(text):
    out = []
    for m in re.finditer(r"<!-- doc-test -->\s*```bash\n(.*?)```((?:\s*<!-- expect: .*? -->)*)", text, re.S):
        out.append((m.group(1).strip(), re.findall(r"<!-- expect: (.*?) -->", m.group(2))))
    return out


def main():
    z = os.path.join(ROOT, "dist", "submission.zip")
    if not os.path.exists(z):
        print("doc-test: dist/submission.zip missing; run python3 scripts/package.py", file=sys.stderr)
        return 1
    tmp = tempfile.mkdtemp(prefix="doc-test-")
    try:
        with zipfile.ZipFile(z) as f:
            f.extractall(tmp)
        here = os.path.join(tmp, "source")   # the folder holding the rfp launcher, as ONBOARDING.md step 1 says
        os.chmod(os.path.join(here, "rfp"), 0o755)
        env = {k: v for k, v in os.environ.items() if k not in ("MONDAY_API_TOKEN", "ANTHROPIC_API_KEY", "PYTHONPATH")}
        doc = open(os.path.join(here, "ONBOARDING.md")).read()
        found, bad = steps(doc), 0
        if not found:
            print("doc-test: no <!-- doc-test --> steps found in ONBOARDING.md", file=sys.stderr)
            return 1
        for cmd, expects in found:
            p = subprocess.run(shlex.split(cmd), cwd=here, env=env, capture_output=True, text=True, timeout=600)
            out = p.stdout + p.stderr
            missing = [x for x in expects if x not in out]
            ok = p.returncode == 0 and not missing
            print("%-4s %s%s" % ("OK" if ok else "FAIL", cmd, "" if ok else "  (exit %d; missing: %s)" % (p.returncode, "; ".join(missing) or "none")))
            bad += not ok
        print("doc-test: %d of %d ONBOARDING.md steps pass from the unzipped ZIP" % (len(found) - bad, len(found)))
        return 1 if bad else 0
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    sys.exit(main())
