"""Generate the pinned status page (a static, theme-aware HTML snapshot) from the build's own records.

python3 scripts/status_page.py    -> status/build-status.html (gitignored), then republish it.
Reads the same sources as the local deck: plan.json, the flight logs, evals, scenarios, monday calls, git.
"""
import html
import json
import os
import subprocess
import sys
from datetime import datetime, timezone

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "source"))
sys.path.insert(0, os.path.join(ROOT, "scripts"))
os.chdir(os.path.join(ROOT, "source"))
from harness import server  # noqa: E402

REPO = "https://github.com/flashesofbrilliance/ret-rfp-intelligence"
e = lambda s: html.escape(str(s))


def plan_json(nodes, plan):
    """The plan board's data (ported from the read-only kanban): one slim record per node, dependencies resolved."""
    ids = {n["id"]: n for n in nodes}
    slim = [{"id": n["id"], "t": n.get("title", ""), "c": n.get("cluster") or "other", "s": n.get("status", ""),
             "o": n.get("owner", ""), "d": n.get("done_when", ""), "j": n.get("job", ""), "r": n.get("rank", 999),
             "n": [ids[x]["title"] if x in ids else x for x in n.get("needs", [])],
             "open": [ids[x]["title"] if x in ids else x for x in n.get("needs", []) if ids.get(x, {}).get("status") != "done"]} for n in nodes]
    return json.dumps({"nodes": slim, "deadline": plan.get("deadline", "")}).replace("</", "<\\/")


def main():
    o, ev, st = server.outcomes(), server.evidence(), server.state()
    plan = st["plan"]
    nodes = plan["nodes"]
    done = [n for n in nodes if n["status"] == "done"]
    deferred = [n for n in nodes if n["status"] == "deferred"]
    cut = [n for n in nodes if n["status"] == "cut"]
    open_ = [n for n in nodes if n["status"] not in ("done", "deferred", "cut")]
    scope = [n for n in nodes if n["status"] not in ("deferred", "cut")]
    hours = max(0, (datetime.fromisoformat(plan["deadline"]) - datetime.now(timezone.utc)).total_seconds() / 3600)
    log = subprocess.check_output(["git", "-C", ROOT, "log", "-8", "--format=%h|%ad|%s", "--date=format:%a %H:%M"]).decode().splitlines()
    sets = ev["eval_sets"]
    sc = ev["scenarios"] or {}

    def chip(ok, yes, no):
        return '<span class="chip %s">%s</span>' % ("ok" if ok else "bad", e(yes if ok else no))

    tiles = [
        ("Elena · same-day facts", "%d facts" % o["elena_facts"]["count"], "on the Key Facts board, verbatim with source; %d changed by an amendment (a clause an amendment adds is counted separately)" % o["elena_facts"]["amended"]),
        ("Elena · answers in minutes", "under ~1 min", "60 s polling + ~%s s AI (measured) + two writes; %s answerable test questions cited" % (o["elena_minutes"]["median_model_s"], o["elena_minutes"]["cited"])),
        ("Doug · amendment caught", "%d changes" % (o["doug_amendments"]["replaces"] + o["doug_amendments"]["adds"]), "unreadable wording is flagged, never guessed; re-sync creates 0 duplicates"),
        ("Nina · no guessing", "%d of %d" % (o["nina_refusals"]["correct"], o["nina_refusals"]["of"]), "unanswerable questions declined, incl. a request to draft bid language"),
        ("Sam Ito · what leaves", "%s chars" % format(o["sam_payload"]["avg_chars_sent"], ","), "per question to the AI provider. " + o["what_leaves"]["ai"] + " " + o["what_leaves"]["monday"]),
    ]
    eval_rows = "".join("<tr><td>%s</td><td class='n'>%d/%d</td><td>%s</td></tr>" % (
        e(k), v["passed"], v["total"], e(", ".join(c["id"] for c in v["cases"] if not c["pass"]) or "all pass")) for k, v in sets.items())
    plan_rows = "".join("<li><span class='st %s'>%s</span> %s<small>%s</small></li>" % (
        n["state"], {"done": "Done", "ready": "Ready", "blocked": "Waiting"}[n["state"]], e(n["title"]),
        e(n.get("moves_metric", "").split(" [E:")[0])) for n in open_)
    commits = "".join("<li><a href='%s/commit/%s'><code>%s</code></a> <span class='muted'>%s</span> %s</li>" % (
        REPO, c.split("|")[0], c.split("|")[0], e(c.split("|")[1]), e(c.split("|")[2][:90])) for c in log)
    page = TEMPLATE.format(
        updated=datetime.now().strftime("%a %b %d, %H:%M"), hours="%.0f" % hours,
        n_done=len(done), n_scope=len(scope), n_def=len(deferred), n_cut=len(cut),
        plan_json=plan_json(nodes, plan),
        crit=e(" → ".join(plan["critical_path"]) or "none"),
        tiles="".join("<div class='tile'><div class='who'>%s</div><div class='big'>%s</div><p>%s</p></div>" % (e(a), e(b), e(c)) for a, b, c in tiles),
        checks=chip(ev["seam_tests"]["ok"], "Every past bug stays fixed", "A past bug is back")
               + chip(ev["mutation"]["ok"], "Each fix has a test that catches it", "A fix has no test")
               + chip(ev["regression"]["ok"], "Nothing got worse since the last good run", "Something got worse"),
        eval_rows=eval_rows,
        scen="%s of %s combinations safe; %s with a real answer checked" % (format(sc.get("passed", 0), ","), format(sc.get("scenarios", 0), ","), format(sc.get("load_bearing_passed", 0), ",")),
        seams=len(st["kintsugi"]), monday="%d of %d" % (ev["monday"]["calls_today"], ev["monday"]["daily_cap"]),
        spend="$%.2f" % sum(m.get("usd") or 0 for m in ev["models"].values()),
        plan_rows=plan_rows or "<li>Nothing open</li>", commits=commits, repo=REPO)
    out = os.path.join(ROOT, "status", "build-status.html")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    open(out, "w").write(page)
    print(out)


TEMPLATE = """<title>Maple Creek Build Status</title>
<style>
/* Layout: a single instrument column; summary strip, then client outcomes, then proof, then the plan. */
:root{{--bg:#f6f8fb;--panel:#ffffff;--ink:#141a22;--muted:#5d6878;--line:#dfe5ee;--accent:#1b5fbf;--ok:#0d7a4c;--bad:#b3261e;--wait:#9a5b00;
  --display:"IBM Plex Sans Condensed","Arial Narrow",system-ui,sans-serif;--body:"IBM Plex Sans",system-ui,sans-serif;--mono:"IBM Plex Mono",ui-monospace,Menlo,monospace}}
@media (prefers-color-scheme: dark){{:root:not([data-theme="light"]){{--bg:#0c1118;--panel:#131a24;--ink:#e6ebf2;--muted:#9aa6b6;--line:#243142;--accent:#7fb2ff;--ok:#4cd39a;--bad:#ff8a80;--wait:#f0b45c;color-scheme:dark}}}}
:root[data-theme="dark"]{{--bg:#0c1118;--panel:#131a24;--ink:#e6ebf2;--muted:#9aa6b6;--line:#243142;--accent:#7fb2ff;--ok:#4cd39a;--bad:#ff8a80;--wait:#f0b45c;color-scheme:dark}}
body{{background:var(--bg);color:var(--ink);font:15px/1.5 var(--body);font-variant-numeric:tabular-nums}}
.wrap{{max-width:1080px;margin:0 auto;padding-inline:16px;padding-block:20px 48px;display:grid;gap:18px}}
h1{{font:600 28px/1.15 var(--display);letter-spacing:-.01em;margin:0;text-wrap:balance}}
h2{{font:600 13px/1 var(--body);text-transform:uppercase;letter-spacing:.08em;color:var(--muted);margin:0 0 10px}}
.muted{{color:var(--muted)}}
.strip{{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:1px;background:var(--line);border:1px solid var(--line);border-radius:10px;overflow:hidden}}
.strip div{{background:var(--panel);padding:12px 14px;min-width:0}}
.strip b{{display:block;font:600 22px/1.2 var(--display)}}.strip span{{font-size:12px;color:var(--muted)}}
.tiles{{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:12px}}
.tile{{background:var(--panel);border:1px solid var(--line);border-radius:10px;padding:14px 16px;min-width:0}}
.who{{font-size:12px;color:var(--muted)}}.big{{font:600 24px/1.2 var(--display);color:var(--accent);margin:4px 0}}
.tile p{{margin:0;font-size:13px;color:var(--muted)}}
.two{{display:grid;grid-template-columns:1fr 1fr;gap:18px}}@media (max-width:760px){{.two{{grid-template-columns:1fr}}}}
.card{{background:var(--panel);border:1px solid var(--line);border-radius:10px;padding:14px 16px;min-width:0}}
.chip{{display:inline-block;font-size:12px;font-weight:600;border-radius:99px;padding:2px 10px;margin:0 6px 6px 0;border:1px solid currentColor}}
.chip.ok{{color:var(--ok)}}.chip.bad{{color:var(--bad)}}
.tbl{{overflow-x:auto}}table{{width:100%;border-collapse:collapse;font-size:13px}}td{{padding:6px 4px;border-top:1px solid var(--line);vertical-align:top}}td.n{{font-family:var(--mono);white-space:nowrap}}
ul{{list-style:none;margin:0;padding:0;display:grid;gap:8px}}li{{font-size:14px}}li small{{display:block;color:var(--muted);font-size:12px}}
.st{{font-size:11px;font-weight:600;border-radius:99px;padding:1px 8px;margin-right:6px;border:1px solid currentColor}}
.st.ready{{color:var(--accent)}}.st.blocked{{color:var(--wait)}}.st.done{{color:var(--ok)}}
.views{{display:flex;gap:6px}}.view{{font:600 13px var(--body);border:1px solid var(--line);background:var(--panel);color:var(--ink);border-radius:8px;padding:6px 12px;cursor:pointer}}
.view[aria-selected="true"]{{border-color:var(--accent);box-shadow:inset 0 0 0 1px var(--accent)}}.view:focus-visible,.tab:focus-visible,.kcard:focus-visible{{outline:2px solid var(--accent);outline-offset:2px}}
#statusview{{display:grid;gap:18px}}#planview{{display:none}}body.plan #statusview{{display:none}}body.plan #planview{{display:grid;gap:14px}}
:root{{--ready:var(--accent);--blocked:var(--wait);--done:var(--ok);--deferred:#6b7585;--cut:#a7b0bd}}
.tabs{{display:flex;flex-wrap:wrap;gap:6px}}.tab{{font:500 13px var(--body);border:1px solid var(--line);background:var(--panel);color:var(--ink);border-radius:8px;padding:6px 11px;cursor:pointer;display:flex;gap:6px;align-items:center}}
.tab b{{font:500 11px var(--mono);color:var(--muted)}}.tab[aria-selected="true"]{{border-color:var(--accent);box-shadow:inset 0 0 0 1px var(--accent)}}
.kbar{{display:flex;height:8px;border-radius:99px;overflow:hidden;background:var(--line)}}.kbar i{{display:block}}
.lanes{{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:12px;align-items:start}}
@media (max-width:980px){{.lanes{{grid-template-columns:repeat(2,minmax(0,1fr))}}}}@media (max-width:560px){{.lanes{{grid-template-columns:minmax(0,1fr)}}}}
.lane{{display:grid;gap:8px;min-width:0}}.lane h2{{font:600 12px/1 var(--body);text-transform:uppercase;letter-spacing:.08em;margin:0;display:flex;justify-content:space-between;padding:6px 2px;border-bottom:2px solid var(--k)}}
.card.k,.lane article{{background:var(--panel);border:1px solid var(--line);border-left:3px solid var(--k);border-radius:8px;padding:10px 11px;display:grid;gap:5px;min-width:0}}
.lane article .t{{font-weight:600}}.meta{{display:flex;flex-wrap:wrap;gap:6px;font-size:12px;color:var(--muted)}}.pill{{font:500 11px var(--mono);border:1px solid var(--line);border-radius:99px;padding:0 7px}}
.dw{{font-size:12px;color:var(--muted)}}.dep{{font-size:12px;color:var(--wait)}}.empty{{color:var(--muted);font-size:12px;padding:6px 2px}}details summary{{cursor:pointer;font-size:12px;color:var(--accent)}}
code{{font-family:var(--mono);font-size:12px}}a{{color:var(--accent);text-underline-offset:3px}}
a:focus-visible{{outline:2px solid var(--accent);outline-offset:2px}}
</style>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=IBM+Plex+Mono&family=IBM+Plex+Sans+Condensed:wght@600&family=IBM+Plex+Sans:wght@400;600&display=swap">
<div class="wrap">
  <div><h1>Maple Creek build status</h1><div class="muted">Snapshot {updated} ET, generated from the build's own records. Not live: republished after each update.</div></div>
  <div class="views" role="tablist" aria-label="View"><button class="view" role="tab" aria-selected="true" data-v="status">Status</button><button class="view" role="tab" aria-selected="false" data-v="plan">Plan</button></div>
  <div id="statusview">
  <div class="strip">
    <div><b>{hours} h</b><span>due in · Thu Oct 15, 5:00 PM ET</span></div>
    <div><b>{n_done}/{n_scope} in scope</b><span>plan items done; {n_cut} cut and {n_def} deferred, counted apart</span></div>
    <div><b>{seams}</b><span>our mistakes, logged, each with its repair</span></div>
    <div><b>{spend}</b><span>AI spend so far (cash, measured)</span></div>
    <div><b>{monday}</b><span>monday.com API calls today</span></div>
  </div>
  <section><h2>What it does for Ridgeline</h2><div class="tiles">{tiles}</div></section>
  <div class="two">
    <section class="card"><h2>Proof</h2>{checks}
      <div class="tbl"><table>{eval_rows}</table></div>
      <p class="muted" style="margin:8px 0 0;font-size:13px">{scen}</p></section>
    <section class="card"><h2>Open work · critical path: {crit}</h2><ul>{plan_rows}</ul></section>
  </div>
  <section class="card"><h2>Latest commits</h2><ul>{commits}</ul><p class="muted" style="margin:10px 0 0;font-size:12px">Repository is private: <a href="{repo}">{repo}</a></p></section>
  </div>
  <div id="planview"><div class="muted">One card per plan item, generated from plan.json. Workstream tabs filter; lanes are Ready, Blocked, Done, Deferred, Cut. This is the only tracker.</div>
    <div class="tabs" role="tablist" id="tabs"></div><div class="kbar" id="kbar" aria-hidden="true"></div><div class="lanes" id="lanes"></div></div>
</div>
<script>
(function(){{var b=document.body;function set(v){{b.classList.toggle("plan",v==="plan");[].forEach.call(document.querySelectorAll(".view"),function(x){{x.setAttribute("aria-selected",x.dataset.v===v?"true":"false")}})}}
[].forEach.call(document.querySelectorAll(".view"),function(x){{x.onclick=function(){{set(x.dataset.v);try{{history.replaceState(null,"",x.dataset.v==="plan"?"#plan-All":"#")}}catch(e){{}}}}}});
if(location.hash.indexOf("#plan")===0)set("plan");}})();

var D={plan_json};
var LANES=[["ready","Ready","--ready"],["blocked","Blocked","--blocked"],["done","Done","--done"],["deferred","Deferred","--deferred"],["cut","Cut","--cut"]];
var tabsEl=document.getElementById("tabs"),lanesEl=document.getElementById("lanes"),barEl=document.getElementById("kbar");
var clusters={{}};D.nodes.forEach(function(n){{clusters[n.c]=(clusters[n.c]||0)+1}});
var order=["All"].concat(Object.keys(clusters).sort(function(a,b){{return clusters[b]-clusters[a]}}));
var cur="All";try{{var h=(location.hash.indexOf("#plan-")===0?location.hash.slice(6):"").replace(/_/g," ");if(order.indexOf(h)>=0)cur=h}}catch(e){{}}
function mk(tag,cls,txt){{var e=document.createElement(tag);if(cls)e.className=cls;if(txt!=null)e.textContent=txt;return e}}
function drawTabs(){{tabsEl.textContent="";order.forEach(function(c){{var b=mk("button","tab");b.setAttribute("role","tab");b.id="tab-"+c.replace(/\W+/g,"-");
  b.setAttribute("aria-selected",c===cur?"true":"false");b.appendChild(mk("span",null,c));b.appendChild(mk("b",null,String(c==="All"?D.nodes.length:clusters[c])));
  b.onclick=function(){{cur=c;try{{history.replaceState(null,"","#plan-"+c.replace(/ /g,"_"))}}catch(e){{}}draw()}};tabsEl.appendChild(b)}})}}
function draw(){{drawTabs();var items=D.nodes.filter(function(n){{return cur==="All"||n.c===cur}}).sort(function(a,b){{return a.r-b.r}});
  barEl.textContent="";LANES.forEach(function(L){{var k=items.filter(function(n){{return n.s===L[0]}}).length;if(!k)return;var i=mk("i");i.style.width=(100*k/items.length)+"%";i.style.background="var("+L[2]+")";i.title=L[1]+": "+k;barEl.appendChild(i)}});
  lanesEl.textContent="";LANES.forEach(function(L){{var lane=mk("section","lane");lane.style.setProperty("--k","var("+L[2]+")");
    var col=items.filter(function(n){{return n.s===L[0]}});var h=mk("h2");h.appendChild(mk("span",null,L[1]));h.appendChild(mk("span",null,String(col.length)));lane.appendChild(h);
    if(!col.length)lane.appendChild(mk("div","empty","Nothing here"));
    col.forEach(function(n){{var c=mk("article","kcard");c.tabIndex=0;c.appendChild(mk("div","t",n.t));
      var m=mk("div","meta");m.appendChild(mk("span","pill",n.o||"unassigned"));if(cur==="All")m.appendChild(mk("span","pill",n.c));c.appendChild(m);
      if(n.open.length&&n.s!=="done")c.appendChild(mk("div","dep","Waiting on: "+n.open.join(", ")));
      if(n.d)c.appendChild(mk("div","dw","Done when: "+n.d));
      if(n.j||n.n.length){{var det=mk("details");det.appendChild(mk("summary",null,"Job and dependencies"));
        if(n.j)det.appendChild(mk("div","dw","Job: "+n.j));if(n.n.length)det.appendChild(mk("div","dw","Needs: "+n.n.join("; ")));c.appendChild(det)}}
      lane.appendChild(c)}});lanesEl.appendChild(lane)}})}}
draw();
</script>"""

if __name__ == "__main__":
    main()
