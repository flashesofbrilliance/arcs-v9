"""Are our confidence numbers honest? Score every resolved prediction (Brier score) from one log.

python3 scripts/calibration.py                 # table + Brier score over resolved predictions
python3 scripts/calibration.py --add FILE      # append predictions from a JSONL file (skips ids already present)
python3 scripts/calibration.py --resolve ID 0|1 "evidence"   # record what actually happened

flightlog/predictions.jsonl, one row per prediction:
  {"id", "claim", "p" (0-1, stated BEFORE the outcome), "made_at", "resolves_by", "how_to_resolve", "source",
   "outcome" (null until resolved, then 0 or 1), "resolved_at", "evidence"}
Brier = mean of (p - outcome)^2 over resolved rows: 0 is perfect, 0.25 is what always saying 50% scores.
A prediction is never edited after it is made; only its outcome is filled in.
"""
import json
import os
import sys
from datetime import datetime, timezone

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LOG = os.path.join(ROOT, "flightlog", "predictions.jsonl")


def rows():
    return [json.loads(l) for l in open(LOG) if l.strip()] if os.path.exists(LOG) else []


def save(rs):
    with open(LOG, "w") as f:
        f.writelines(json.dumps(r, ensure_ascii=False) + "\n" for r in rs)


def now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def score(rs):
    done = [r for r in rs if r.get("outcome") in (0, 1)]
    if not done:
        return None, 0
    return sum((r["p"] - r["outcome"]) ** 2 for r in done) / len(done), len(done)


def main(a):
    rs = rows()
    if a[:1] == ["--add"]:
        have = {r["id"] for r in rs}
        added = 0
        for line in open(a[1]):
            if not line.strip():
                continue
            r = json.loads(line)
            if r["id"] in have:
                continue
            if not 0 <= float(r["p"]) <= 1:
                raise SystemExit("p must be between 0 and 1: %s" % r["id"])
            r.setdefault("made_at", now()); r.setdefault("source", os.path.basename(a[1]))
            r.update(outcome=None, resolved_at=None, evidence=None)
            rs.append(r); added += 1
        save(rs)
        print("calibration: added %d predictions (%d total)" % (added, len(rs)))
        return 0
    if a[:1] == ["--resolve"]:
        rid, out, ev = a[1], int(a[2]), a[3]
        for r in rs:
            if r["id"] == rid:
                if r.get("outcome") is not None:
                    raise SystemExit("%s is already resolved; outcomes are not rewritten" % rid)
                r.update(outcome=out, resolved_at=now(), evidence=ev)
                save(rs)
                print("calibration: %s resolved as %d" % (rid, out))
                return 0
        raise SystemExit("no prediction %s" % rid)
    for r in rs:
        state = "open" if r.get("outcome") is None else ("happened" if r["outcome"] else "did not happen")
        print("%-8s p=%.2f  %-15s %s" % (r["id"], r["p"], state, r["claim"][:80]))
    b, n = score(rs)
    print("Brier score: %s over %d resolved of %d (0 is perfect; always saying 50%% scores 0.25)" % (
        "%.3f" % b if b is not None else "n/a", n, len(rs)))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
