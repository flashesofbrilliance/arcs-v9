"""Read what the monday.com boards hold right now and save it for the review page (docs/site/boards.html).

python3 scripts/boards_snapshot.py     # read-only: one call per board plus one to find them; needs MONDAY_API_TOKEN

A reviewer cannot open the boards without an invitation, so the build shows what the integration actually wrote:
every item and column on the four RET boards, the time they were read, and the monday.com calls the read cost
(from the same call log as every other call). Writes evidence/boards-snapshot.json; scripts/home.py renders the page
from that file, so the page needs no network and cannot drift from the data. Standard library only.
"""
import json
import os
import sys
from datetime import datetime, timezone

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "source"))
from rfp import monday  # noqa: E402
from rfp.sink import ALLOWED_BOARDS  # noqa: E402

OUT = os.path.join(ROOT, "evidence", "boards-snapshot.json")
ORDER = ["RET · Solicitations", "RET · Key Facts", "RET · Questions", "RET · Pilot Scorecard"]
PURPOSE = "boards snapshot"


def main():
    started = datetime.now(timezone.utc).isoformat()
    found = monday.gql("query { boards(limit: 200) { id name columns { id title type } } }", purpose=PURPOSE)["boards"]
    boards = []
    for name in ORDER:
        b = next((x for x in found if x["name"] == name), None)
        if not b or name not in ALLOWED_BOARDS:
            continue
        cols = [c for c in b["columns"] if c["type"] not in ("name", "subtasks")]
        items = monday.all_items(b["id"], "id name column_values { id text }", purpose=PURPOSE)
        rows = [{"name": it["name"], "values": {c["id"]: (c["text"] or "") for c in it["column_values"]}} for it in items]
        boards.append({"name": name, "id": b["id"], "columns": [{"id": c["id"], "title": c["title"]} for c in cols], "items": rows})
    log = os.path.join(ROOT, "flightlog", "monday_calls.jsonl")
    calls = [json.loads(l) for l in open(log, encoding="utf-8") if l.strip()]
    calls = [{"t": c["t"], "purpose": c.get("purpose"), "complexity": (c.get("complexity") or {}).get("query"),
              "latency_s": c.get("latency_s"), "ok": c.get("ok"), "request_id": c.get("request_id")}
             for c in calls if c.get("purpose", "").startswith(PURPOSE) and c["t"] >= started]
    json.dump({"read_at": started, "api_version": monday.API_VERSION, "boards": boards, "calls": calls},
              open(OUT, "w", encoding="utf-8"), indent=1, ensure_ascii=False)
    print("boards snapshot: %d boards, %d items, %d calls -> %s" % (
        len(boards), sum(len(b["items"]) for b in boards), len(calls), os.path.relpath(OUT, ROOT)))
    return 0


if __name__ == "__main__":
    sys.exit(main())
