"""Release notes between snapshots, generated from git (never hand-written).

python3 scripts/release_notes.py [since-ref]   # default: the latest snapshot-* tag, else the first commit
Groups commits by conventional type and lists the seams (K-numbers) each one closed.
"""
import re
import subprocess
import sys

REPO = "https://github.com/flashesofbrilliance/ret-rfp-intelligence"  # private; in the ZIP, see HISTORY.txt
TITLES = {"feat": "New", "fix": "Fixed", "test": "Tests and gates", "docs": "Docs and evidence",
          "data": "Data", "chore": "Housekeeping"}


def git(*a):
    return subprocess.check_output(["git"] + list(a)).decode().strip()


def main():
    since = sys.argv[1] if len(sys.argv) > 1 else None
    if not since:
        tags = git("tag", "--list", "snapshot-*", "--sort=-creatordate").split()
        since = tags[0] if tags else git("rev-list", "--max-parents=0", "HEAD")
    rng = "%s..HEAD" % since if since != git("rev-list", "--max-parents=0", "HEAD") else "HEAD"
    lines = git("log", rng, "--reverse", "--format=%h|%ad|%s", "--date=format:%H:%M").splitlines()
    groups = {}
    for line in lines:
        sha, t, subj = line.split("|", 2)
        m = re.match(r"(\w+)(\(([^)]*)\))?: (.*)", subj)
        kind, text = (m.group(1), m.group(4)) if m else ("chore", subj)
        groups.setdefault(TITLES.get(kind, "Other"), []).append((t, sha, text))
    print("## Release notes since %s (%d commits)\n" % (since[:12], len(lines)))
    for title in list(TITLES.values()) + ["Other"]:
        if title in groups:
            print("### " + title)
            for t, sha, text in groups[title]:
                ks = set()
                for a, b in re.findall(r"K(\d+)(?:\s*[-–]\s*K?(\d+))?", text):
                    ks.update(range(int(a), int(b or a) + 1))  # "K19-K22" means K19, K20, K21, K22
                seams = ", ".join("K%d" % k for k in sorted(ks))
                print("- %s [`%s`](%s/commit/%s) %s%s" % (t, sha, REPO, sha, text, " (closes %s)" % seams if seams else ""))
            print()


if __name__ == "__main__":
    main()
