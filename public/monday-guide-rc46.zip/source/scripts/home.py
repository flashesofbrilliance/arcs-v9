"""The front door of the submission: one page (docs/site/index.html) with a GRID and a PRESENT view over its cards,
plus the build log, the find-anything page (docs/site/wiki.html) and the rest. Links are checked against the ZIP layout (source/, and presentation/ with the PDF).

python3 scripts/home.py            # write every page (build.py calls this)
python3 scripts/home.py --check    # exit 1 if any page differs from what the records produce

Every figure comes from evidence/evidence.jsonl or a flight log, never typed in. Output is deterministic (no clock,
no commit hash), so the staleness check only fails when the records change. Standard library only.
"""
import functools
import glob
import html
import json
import os
import subprocess
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SITE = os.path.join(ROOT, "docs", "site")   # ships as source/docs/site/
OUT = {n: os.path.join(SITE, n) for n in ("index.html", "build-log.html", "how-we-decided.html", "mistakes.html", "boards.html", "wiki.html")}
CATALOG = os.path.join(ROOT, "docs", "catalog.json")
e = html.escape


CARDS = [
    ("01", "The deck", "Ten slides: the situation, what we built, how it held up, and the ask. The place to start. Press F for full screen.", "deck.html", "The argument"),
    ("02", "How we got here", "How we worked the problem from discovery to handoff: what RET needs most, the choices we made, what tests proved wrong, and the checks that keep it honest. Read at the depth you choose.", "how-we-decided.html", "Our reasoning"),
    ("03", "What the boards hold", "What the integration actually wrote to monday.com, read back through the API: each fact with its governing text, each question with its answer and citations.", "boards.html", "The integration"),
    ("04", "Try it live", "In a terminal, from the unzipped folder: {CMD} This starts the test bench and the poller; this link then opens the bench: ask a question and see the answer with the clauses it cites.", "http://127.0.0.1:8765/#bench", "Live"),
    ("05", "Read", "Every page and file in one place: one answer proved end to end, every mistake and its guard, the build log, the controls, and the questions RET will ask.", "wiki.html", "Evidence and files"),
]
LIVE_CMD = "cd source && ./rfp start"
TILE_COPY_STYLE = """
.tile code{background:var(--soft);border:1px solid var(--line);padding:1px 6px;border-radius:4px;font:13px ui-monospace,Menlo,monospace;overflow-wrap:anywhere}
.tile-copy{min-height:40px;padding:0 12px;border:1px solid var(--line);border-radius:8px;background:var(--bg);color:var(--ink);font:600 13px Figtree,Roboto,system-ui,sans-serif;cursor:pointer}
.tile-copy:hover{color:var(--accent)}.tile-copy:focus-visible{outline:2px solid #0073ea;outline-offset:2px}"""
TILE_COPY_SCRIPT = ("<script>(function(){var b=document.querySelector('.tile-copy');if(!b)return;b.addEventListener('click',function(ev){"
                    "ev.preventDefault();ev.stopPropagation();var t=%s,done=function(){b.textContent='Copied'};"
                    "if(navigator.clipboard)navigator.clipboard.writeText(t).then(done,function(){});"
                    "else{var a=document.createElement('textarea');a.value=t;document.body.appendChild(a);a.select();"
                    "try{document.execCommand('copy');done()}catch(e){}a.remove()}})})()</script>" % json.dumps(LIVE_CMD))
# Evidence pages: one level down, listed first on the Read page, not top-level cards.
EVIDENCE = [
    ("Proof of one answer", "Why the deadline is December 4, not November 13: the clauses, the reasoning, what would make it false, and hashes. Reproduce it with ./rfp verify-proof.", "proof-of-one-answer.html"),
    ("The catch net", "Every mistake we made while building, what caught it, its repair, and what now guards it.", "mistakes.html"),
    ("The build log", "What it cost to build, how it was tested end to end, and our forecasts and how they scored.", "build-log.html"),
]
# Five cards, unfolding in a line: the argument sets the horizon, then how we worked it, what landed, the live system,
# then the evidence and every file. Stage 03 (design) comes before 02 (data) on purpose: the boards read better once the
# reasoning is known. The page bar (GNAV) and the read-me follow the same order.
READ_ME = [
    ("01 Review the brief and scenario", "The deck",
     "the problem in RET's own words and numbers (slides 1 to 3), and what we ask for and how it is judged (slides 1 and 7)"),
    ("02 Explore the sample data", "What the boards hold; Read (Proof of one answer)",
     "the {E-facts|14 key facts} the data yields as they landed in monday.com, and one answer traced clause by clause"),
    ("03 Design your solution", "How we got here; the deck, slides 4, 5, 8 and 9",
     "how we worked the problem from discovery to handoff: architecture, integration and AI choices, risks, trade-offs, each stakeholder's acceptance"),
    ("04 Build, test, and document", "Try it live; Read (the catch net, the build log); README",
     "the working system; every mistake with what caught it and what guards it now; tests, cost and forecasts"),
    ("05 Package your final submission", "Read",
     "every shipped file with one line on what it is, the change history (HISTORY.txt), and the controls"),
]

STYLE = """:root{--ink:#323338;--muted:#676879;--line:#d0d4e4;--accent:#0060b9;--fill:#0073ea;--soft:#f6f7fb;--bg:#fff;--measure:720px;
--sans:Figtree,Roboto,-apple-system,"Segoe UI",Helvetica,Arial,sans-serif;--title:Poppins,Figtree,Roboto,-apple-system,"Segoe UI",Arial,sans-serif}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:16px/1.5 var(--sans)}
a{color:var(--accent)}a:focus-visible,button:focus-visible{outline:2px solid var(--accent);outline-offset:2px}
main{max-width:1080px;margin:0 auto;padding:72px 16px 64px}h1{font:600 32px/40px var(--title);margin:0 0 12px}
h2{font:600 20px/1.3 var(--title);margin:32px 0 10px}.lede{color:var(--muted);font-size:18px;margin:0 0 28px}
table{width:100%;border-collapse:collapse}th,td{text-align:left;padding:8px 6px;border-top:1px solid var(--line);vertical-align:top}
.m{color:var(--muted);font-size:14px}.stat{display:inline-block;background:var(--soft);border:1px solid var(--line);border-radius:8px;padding:10px 14px;margin:0 8px 8px 0}
.stat b{display:block;font-size:22px}.stat>span{font-size:13px;color:var(--muted)}"""


def ev():
    return {r["id"]: r for r in (json.loads(l) for l in open(os.path.join(ROOT, "evidence", "evidence.jsonl")) if l.strip())}


GRADE_OF = {"RET": "A", "ret-derived": "A", "measured": "B", "derived": "B", "cited": "C", "estimate": "D"}


def fig(E, eid, key="show"):
    text = E[eid].get(key) or E[eid]["value"]
    return '<span data-e="%s" data-g="%s">%s</span>' % (eid, GRADE_OF.get(E[eid].get("class"), ""), e(text))


# Phones: a table wider than the screen becomes one card per row, each value under its column name, so nothing
# runs off the right edge. Cells get their column name from the header row (data-label); tables with no header row stay.
STACK_STYLE = """details.fold{border:1px solid var(--line);border-radius:12px;margin:0 0 12px;background:var(--bg)}
details.fold>summary{cursor:pointer;list-style:none;padding:14px 16px;font:600 16px/1.35 var(--title);display:flex;gap:10px;align-items:baseline}
details.fold>summary::-webkit-details-marker{display:none}details.fold>summary::before{content:"+";color:var(--accent);font-weight:700}
details.fold[open]>summary::before{content:"\\2212"}details.fold>summary small{font:400 13px var(--sans);color:var(--muted)}
details.fold>.body{padding:0 16px 14px}.verdict{font:600 20px/1.35 var(--title);margin:4px 0 14px;max-width:none}
@media(max-width:640px){table.kv,table.kv tbody,table.kv tr{display:block;width:auto}table.kv td{overflow-wrap:anywhere}table.kv th{display:block;width:auto!important;padding:6px 0 0}table.kv td{display:block;padding:2px 0 6px}table.stack,table.stack tbody,table.stack tr,table.stack td{display:block;width:auto}
table.stack tr:first-child:has(th){display:none}table.stack tr{border:1px solid var(--line);border-radius:10px;padding:8px 12px;margin:0 0 12px;background:var(--soft)}
table.stack td{border:0;padding:4px 0;white-space:normal!important;overflow-wrap:anywhere}table.stack code{overflow-wrap:anywhere;word-break:break-word}table.stack td[data-label]::before{content:attr(data-label);display:block;font:600 12px var(--sans);color:var(--muted);margin-bottom:2px}
.wrap,div[style*="overflow-x"]{overflow-x:visible!important}}"""


def stack_tables(html_):
    """Give every table with a header row the phone layout: class "stack" and data-label on each cell."""
    def one(m):
        t = m.group(0)
        heads = re.findall(r"<th[^>]*>(.*?)</th>", t, re.S)
        if not heads or 'class="kv"' in t[:40]:   # label/value tables already read as cards
            return t
        labels = [re.sub(r"<[^>]+>", "", h).strip() for h in heads]
        def row(r):
            i = iter(labels)
            return re.sub(r"<td(?![^>]*data-label)", lambda c: '<td data-label="%s"' % e(next(i, "")), r.group(0))
        t = re.sub(r"<tr[^>]*>(?:(?!</tr>).)*<td.*?</tr>", row, t, flags=re.S)
        return re.sub(r"<table(?![^>]*\bstack\b)( class=\"([^\"]*)\")?", lambda c: '<table class="%s"' % ("stack " + (c.group(2) or "")).strip(), t, count=1)
    return re.sub(r"<table.*?</table>", one, html_, flags=re.S)


# One shared bar on every reading page, so any page is one tap from any other. Phones get a Menu button (a native
# <details>, so it works without script); wider screens get the links in a row. The start page has its own header.
# Four places, the same on every page and on the bench: the start page, the deck, the reading room (every page
# and file), and the live system. Reading pages sit under Read, so the bar never grows with the content.
GNAV = [("index.html", "Start"), ("deck.html", "Deck"), ("wiki.html", "Read"), ("http://127.0.0.1:8765/#bench", "Try it live")]
GNAV_TITLE = {"RET RFP Intelligence": "index.html", "Build Log": "build-log.html", "How We Got Here": "how-we-decided.html", "Our Mistakes": "mistakes.html",
              "What the Boards Hold": "boards.html", "Read": "wiki.html"}
# The one nav style, for the pages, the deck and the bench alike (home.py writes it into deck.html and ui.html
# between "gnav:start" and "gnav:end" and --check fails if either drifts). Vibe light tokens; the deck's dark
# switch overrides the --gn-* values only.
GNAV_STYLE = """html{overflow-y:scroll}  /* the scrollbar always shows, so moving between pages never shifts the layout by its width */
.gnav{--gn-bg:#fff;--gn-line:#d0d4e4;--gn-ink:#323338;--gn-accent:#0060b9;--gn-soft:#f6f7fb;position:sticky;top:0;z-index:60;background:var(--gn-bg);border-bottom:1px solid var(--gn-line)}
.gnav .in{display:flex;gap:4px;align-items:center;max-width:1240px;margin:0 auto;padding:8px 16px}
.gnav a,.gnav .tools button{display:inline-flex;align-items:center;min-height:40px;padding:0 12px;border:0;border-radius:8px;background:transparent;color:var(--gn-ink);text-decoration:none;font:600 13px Figtree,Roboto,system-ui,sans-serif;white-space:nowrap;cursor:pointer}
.gnav a:hover,.gnav .tools button:hover{color:var(--gn-accent)}.gnav a[aria-current=page]{background:var(--gn-soft);color:var(--gn-accent)}
.gnav .tools{margin-left:auto;display:inline-flex;align-items:center;border:1px solid var(--gn-line);border-radius:8px}
.gnav a:focus-visible,.gnav button:focus-visible,summary:focus-visible{outline:2px solid #0073ea;outline-offset:2px}
.gnav .tools a,.gnav .tools button{min-height:34px;border-radius:0}.gnav .tools>*+*{border-left:1px solid var(--gn-line)}
@media(max-width:420px){.gnav .in{gap:0;padding:8px}.gnav a,.gnav .tools button{padding:0 9px}}
.gn-pop{--gn-bg:#fff;--gn-line:#d0d4e4;--gn-ink:#323338;--gn-accent:#0060b9;--gn-soft:#f6f7fb;position:fixed;top:60px;left:16px;right:16px;max-width:560px;margin:0 auto;z-index:70;display:flex;flex-wrap:wrap;gap:8px;align-items:center;padding:10px 12px;background:var(--gn-bg);color:var(--gn-ink);border:1px solid var(--gn-line);border-radius:8px;box-shadow:0 4px 16px rgba(0,0,0,.12);font:400 14px/1.4 Figtree,Roboto,system-ui,sans-serif}
.gn-pop[hidden]{display:none}.gn-pop code{background:var(--gn-soft);padding:1px 6px;border-radius:4px;font:13px ui-monospace,Menlo,monospace}
.gn-pop button{min-height:40px;padding:0 12px;border:1px solid var(--gn-line);border-radius:8px;background:var(--gn-soft);color:var(--gn-ink);font:600 13px Figtree,Roboto,system-ui,sans-serif;cursor:pointer}
.gn-pop button:hover{color:var(--gn-accent)}.gn-pop button:focus-visible{outline:2px solid #0073ea;outline-offset:2px}
@media print{.gn-pop{display:none!important}}"""
# "Try it live" needs the local bench. A short probe (localhost only, no-cors) lets the link work as usual when the bench is up
# and otherwise shows how to start it. It sits right after the nav so the nav itself stays identical on every page.
GNAV_PROBE = ("<!-- probe:start --><div class=\"gn-pop\" role=\"status\" hidden><span>Start the bench first: <code>./rfp serve</code> "
              "(from the unzipped source folder)</span><button type=\"button\" class=\"gn-copy\">Copy</button>"
              "<button type=\"button\" class=\"gn-x\" aria-label=\"Close\">Close</button></div><script>(function(){"
              "var l=document.querySelector('.gnav a[href^=\"http://127.0.0.1:8765\"]'),p=document.querySelector('.gn-pop');if(!l||!p)return;"
              "var up=false;function probe(){var c=new AbortController(),t=setTimeout(function(){c.abort()},1500);"
              "fetch('http://127.0.0.1:8765/',{mode:'no-cors',signal:c.signal}).then(function(){up=true}).catch(function(){up=false}).then(function(){clearTimeout(t)})}"
              "probe();l.addEventListener('click',function(ev){if(up)return;ev.preventDefault();p.hidden=false;probe()});"
              "p.querySelector('.gn-x').addEventListener('click',function(){p.hidden=true});"
              "p.querySelector('.gn-copy').addEventListener('click',function(ev){var b=ev.target,done=function(){b.textContent='Copied'};"
              "if(navigator.clipboard)navigator.clipboard.writeText('./rfp serve').then(done,function(){});"
              "else{var a=document.createElement('textarea');a.value='./rfp serve';document.body.appendChild(a);a.select();"
              "try{document.execCommand('copy');done()}catch(e){}a.remove()}})})()</script><!-- probe:end -->")
PROBE_MARK = ("<!-- probe:start -->", "<!-- probe:end -->")
GNAV_MARK = ("/* gnav:start */", "/* gnav:end */")
GNAV_PAGES = {os.path.join(ROOT, "docs", "site", "deck.html"): None, os.path.join(ROOT, "source", "harness", "ui.html"): None}


def with_gnav_style(text):
    """The shared nav style between the markers, or None when the markers are missing."""
    a, b = text.find(GNAV_MARK[0]), text.find(GNAV_MARK[1])
    if a < 0 or b < 0:
        return None
    text = text[:a + len(GNAV_MARK[0])] + "\n" + GNAV_STYLE + "\n" + text[b:]
    pa, pb = text.find(PROBE_MARK[0]), text.find(PROBE_MARK[1])
    if pa >= 0 and pb >= 0:
        text = text[:pa] + GNAV_PROBE + text[pb + len(PROBE_MARK[1]):]
    return text


# Light only on every page; the deck alone offers a dark switch (Zach, 2026-10-13).


def gnav(current):
    """Four links that fit a phone, so there is no menu to open; a reading page highlights Read."""
    current = current if current in dict(GNAV) else "wiki.html"
    a = lambda h, t: '<a href="%s"%s>%s</a>' % (h, ' aria-current="page"' if h == current else "", e(t))
    return '<nav class="gnav" aria-label="Pages"><div class="in">%s</div></nav>' % "".join(a(h, t) for h, t in GNAV)


FILE_TOKEN = re.compile(r"(?<![\w/.-])((?:[\w-]+/)*[\w-][\w.-]*\.(?:py|md|json|jsonl|sh|html|csv|txt|pdf))(?![\w/-]|\.\w)")
SITE_PAGES = {"index.html", "wiki.html", "deck.html", "how-we-decided.html", "mistakes.html", "boards.html", "build-log.html",
              "proof-of-one-answer.html", "proof-of-one-answer.json", "cost-model.csv"}


@functools.lru_cache(maxsize=None)
def catalog_paths():
    with open(CATALOG, encoding="utf-8") as f:
        return tuple(c["path"] for c in json.load(f))


def link_one(m):
    href = file_href(m.group(1))
    return '<a href="%s">%s</a>' % (e(href), m.group(1)) if href else m.group(1)


def file_href(p):
    """Where a file named in page text opens from source/docs/site/, or None. Accepts a repo path, a page name, the
    older presentation/<page> spelling, or a bare file name that only one shipped file has."""
    p = re.sub(r"^(presentation|docs/site)/(?=[\w.-]+$)", "", p) if os.path.basename(p) in SITE_PAGES else p
    if p in SITE_PAGES:
        return p
    if p in GENERATED:
        return "../../" + p
    found = shipped_path(p) or shipped_path("source/" + p)
    if found:
        return found
    if "/" not in p:
        hits = [path for path in catalog_paths() if os.path.basename(path) == p]
        if len(hits) == 1:
            return shipped_path(hits[0])
    return None


def link_files(body):
    """Every file a page names becomes a link to it (provenance you can open), except where it is already a link."""
    out, depth, skip = [], 0, 0
    for part in re.split(r"(<[^>]+>)", body):
        if part.startswith("<"):
            tag = re.match(r"</?\s*(\w+)", part)
            name = tag.group(1).lower() if tag else ""
            if name == "a":
                depth += -1 if part.startswith("</") else (0 if part.endswith("/>") else 1)
            elif name in ("script", "style", "title"):
                skip += -1 if part.startswith("</") else 1
            out.append(part)
        elif depth or skip:
            out.append(part)
        else:
            out.append(FILE_TOKEN.sub(link_one, part))
    return "".join(out)


# Start / Read / <page>, on every page reached from Read. One definition: page() and the proof page both call crumbs(),
# and --check fails if a page lacks it.
CRUMB_TITLE = {"Build Log": "The build log", "How We Got Here": "How we got here", "Our Mistakes": "Our mistakes", "What the Boards Hold": "What the boards hold",
               "Proof Of One Answer": "Proof of one answer"}
CRUMB_STYLE = """.crumbs{display:flex;flex-wrap:wrap;align-items:center;gap:0 6px;margin:0 0 8px;font:600 14px var(--sans)}
.crumbs a{display:inline-flex;align-items:center;min-height:40px;color:var(--accent);text-decoration:none}.crumbs a:hover{text-decoration:underline}
.crumbs a:focus-visible{outline:2px solid #0073ea;outline-offset:2px}.crumbs [aria-hidden]{color:var(--muted)}.crumbs [aria-current]{color:var(--ink)}"""


def crumbs(title):
    return ('<nav class="crumbs" aria-label="Breadcrumb"><a href="index.html">Start</a><span aria-hidden="true">/</span><a href="wiki.html">Read</a>'
            '<span aria-hidden="true">/</span><span aria-current="page">%s</span></nav>') % e(CRUMB_TITLE[title])


def page(title, body, extra_style="", script=""):
    if title in GNAV_TITLE:
        body = gnav(GNAV_TITLE[title]) + GNAV_PROBE + body.replace('<main><p class="m"><a href="index.html">← Start here</a></p>', "<main>" + (crumbs(title) if title in CRUMB_TITLE else ""), 1)
        extra_style = extra_style + GNAV_STYLE + (CRUMB_STYLE if title in CRUMB_TITLE else "")
    body = link_files(stack_tables(body))
    extra_style = extra_style + STACK_STYLE
    return ('<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
            '<title>%s</title><link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Figtree:wght@400;600&family=Poppins:wght@600&display=swap">'
            '<style>%s%s</style></head><body>%s%s</body></html>\n') % (e(title), STYLE, extra_style, body, script)


HOWTO_FOLD = """.howto-fold{margin:0 0 24px;border:1px solid var(--line);border-radius:8px;padding:4px 16px}.howto-fold>summary{min-height:44px;display:flex;align-items:center;font:600 15px var(--sans);cursor:pointer}"""
SHELL_STYLE = """
.readme{margin:8px 0 0;padding:0 0 16px}
.readme h2{font:600 20px/1.25 var(--title);margin:0 0 8px}.readme h3{font:600 16px/1.3 var(--title);margin:16px 0 6px}
.readme p{margin:0 0 8px;max-width:none}.readme table{width:100%;border-collapse:collapse;font-size:14px}
.readme th,.readme td{text-align:left;vertical-align:top;padding:8px 10px;border-top:1px solid var(--line)}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:16px}
.tile{display:flex;flex-direction:column;gap:8px;border:1px solid var(--line);border-radius:12px;padding:20px;background:var(--soft);color:var(--ink);text-decoration:none}
.tile:hover{border-color:var(--accent)}.tile h2{font:600 20px/1.25 var(--title);margin:0}.tile p{margin:0;color:var(--muted)}
.no{font:600 13px var(--sans);color:var(--accent);}.tag{margin-top:auto;font:600 12px var(--sans);color:var(--muted)}
"""




def readme():
    """The start page's read-me: a three-line summary, then where each part of the brief is answered and why the pages
    run in this order. Figures come from evidence.jsonl."""
    E = ev()
    rows = "".join("<tr><td>%s</td><td>%s</td><td>%s</td></tr>" % (e(a), e(w), fill(E, y)) for a, w, y in READ_ME)
    return ('<div class="readme">'
            '<p><b>In short.</b> RET\'s intake takes %s today. This pilot puts the key facts on a '
            'monday.com board the day an RFP or amendment lands, and answers staff questions on the board in minutes, every '
            'figure quoted word for word from the clause it cites or withheld. It was built and tested on the free plan, and '
            'is judged by Elena\'s three tests.</p>'
            '<p>Each of the assignment\'s five stages, and where it is answered. The design comes before the data on purpose: '
            'what landed on the boards reads better once the reasoning is known.</p>'
            '<div class="wrap"><table><tr><th>Assignment stage</th><th>Where to look</th><th>What you will find</th></tr>%s</table></div></div>'
            % (fill(E, "{E-intake-hours|~650 team hours per intake cycle}"), rows))


README = os.path.join(ROOT, "README.md")
README_MARK = ("<!-- how-to-review: generated by scripts/home.py from the start page's How-to-use data; do not edit -->",
               "<!-- /how-to-review -->")


def fill_md(E, text):
    """fill() for Markdown: {E-id|text} shows text, which must appear word for word in its evidence row."""
    def one(m):
        eid, shown = m.group(1), m.group(2)
        if shown is None:
            return E[eid].get("show") or E[eid]["value"]
        if shown not in E[eid]["value"]:
            raise SystemExit("home: %r is not in evidence row %s" % (shown, eid))
        return shown
    return re.sub(r"\{(E-[\w-]+)(?:\|([^}]+))?\}", one, text)


def readme_md():
    """The README's How to review section: the same rows as the start page's drawer, with ZIP-relative links."""
    E = ev()
    site = "docs/site/"
    links = " · ".join("[%s](%s%s)" % (n, site, f) for f, n in GNAV if not f.startswith("http")) + \
        " · " + " · ".join("[%s](%s%s)" % (t_, site, h) for t_, d_, h in EVIDENCE)
    rows = "".join("| %s | %s | %s |\n" % (a, w, fill_md(E, y)) for a, w, y in READ_ME)
    return ("%s\n**In short.** RET's intake takes %s today. This pilot puts the key facts on a monday.com board the day an RFP "
            "or amendment lands, and answers staff questions on the board in minutes, every figure quoted word for word from "
            "the clause it cites or withheld.\n\nEach of the assignment's five stages, and where it is answered:\n\n"
            "| Assignment stage | Where to look | What you will find |\n|---|---|---|\n%s\nThe pages: %s. They open from the "
            "unzipped folder; with `./rfp serve` running, open http://127.0.0.1:8765/source/docs/site/index.html and every code "
            "and document link opens as a readable page.\n%s"
            % (README_MARK[0], fill_md(E, "{E-intake-hours|~650 team hours per intake cycle}"), rows, links, README_MARK[1]))


def readme_file():
    """README.md with its generated section replaced, or None when the markers are missing."""
    text = open(README, encoding="utf-8").read()
    a, b = text.find(README_MARK[0]), text.find(README_MARK[1])
    if a < 0 or b < 0:
        return None
    return text[:a] + readme_md() + text[b + len(README_MARK[1]):]


def index():
    """Start: the shared bar, one line on what this is, the How-to-use fold, and the five cards."""
    snippet = ('<code>%s</code> <button type="button" class="tile-copy">Copy</button>' % e(LIVE_CMD))
    tiles = "".join('<a class="tile" href="%s"><h2>%s</h2><p>%s</p><span class="tag">%s · Open →</span></a>'
                    % (href, e(t), e(d).replace("{CMD}", snippet), tag) for no, t, d, href, tag in CARDS)
    body = ('<main id="grid"><h1>RET RFP Intelligence</h1><p class="verdict">Key facts on a monday.com board the day an RFP or amendment '
            'lands, and cited answers in minutes: a working pilot, judged by RET\'s own three tests.</p>'
            '<p class="lede">Start with the deck, then read left to right. Every figure comes from one evidence file, and every '
            'page opens offline from this folder. Prefer to watch? <a href="https://youtu.be/w7b-FVA3qSE">The walkthrough video</a> (online).</p>'
            '<details class="howto-fold"><summary>How to use this bundle</summary>%s</details><div class="grid">%s</div></main>') % (readme(), tiles)
    return page("RET RFP Intelligence", body, SHELL_STYLE + HOWTO_FOLD + TILE_COPY_STYLE, TILE_COPY_SCRIPT)

def jsonl(name):
    p = os.path.join(ROOT, "flightlog", name)
    return [json.loads(l) for l in open(p) if l.strip()] if os.path.exists(p) else []


def spark(vals, color, label):
    """A small inline SVG line: one point per record, scaled to its own range; first and last values printed."""
    w, h, pad = 320, 56, 4
    lo, hi = min(vals), max(vals)
    span = (hi - lo) or 1
    pts = " ".join("%.1f,%.1f" % (pad + i * (w - 2 * pad) / max(1, len(vals) - 1), h - pad - (v - lo) * (h - 2 * pad) / span) for i, v in enumerate(vals))
    return ('<svg viewBox="0 0 %d %d" width="%d" height="%d" role="img" aria-label="%s" style="display:block;max-width:100%%">'
            '<polyline points="%s" fill="none" stroke="%s" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"/></svg>') % (w, h, w, h, e(label), pts, color)


def hardening():
    """Risk going down, defence going up: three series straight from the flight logs (committed, so the page only changes when a log does)."""
    sc = jsonl("scenario_runs.jsonl")
    fail = [r["scenarios"] - r["passed"] for r in sc]
    wg = [r for r in jsonl("wargame_runs.jsonl")]
    held = ["%d of %d" % (r["passed"], r["total"]) for r in wg]
    sys.path.insert(0, os.path.join(ROOT, "scripts"))
    from dashboard import setup_only   # a run where no model replied is not a result (D-SETUPRUN)
    ev = [r for r in jsonl("eval_runs.jsonl") if r.get("provider") == "claude" and not setup_only(r)]
    miss = [r["total"] - r["passed"] for r in ev]
    rows = [
        ("Failing fault combinations, per full matrix run", spark(fail, "#d83a52", "failing combinations per run"),
         "%d runs: %d failing on the first, %d on the latest." % (len(fail), fail[0], fail[-1])),
        ("Stakeholder attacks held, per war-game run", spark([r["passed"] / r["total"] for r in wg], "#00854d", "attacks held per run"),
         "%d logged runs, from %s to %s. The first honest run, before this log existed, held 11 of 15." % (len(wg), held[0], held[-1])),
        ("Test questions Claude got wrong, per evaluation run", spark(miss, "#0073ea", "test questions missed per run"),
         "%d Claude runs across both question sets: %d missed on the first, %d on the latest. Each miss became a repair in the mistakes log and a test case." % (len(miss), miss[0], miss[-1])),
    ]
    return "".join('<h3 style="font:600 15px var(--sans);margin:18px 0 4px">%s</h3>%s<p class="m" style="margin:4px 0 0">%s</p>' % (a, b, e(c)) for a, b, c in rows)


BUILD_STYLE = """.hero{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px;margin:0 0 28px}
.hero .h{border:1px solid var(--line);border-radius:8px;padding:16px;background:var(--soft)}.hero .h b{display:block;font:600 32px/1.15 var(--title);color:var(--ink)}
.hero .h b.ok{color:#00854d}.hero .h b.no{color:#c0203a}.hero .h span{display:block;margin-top:6px;font-size:14px;color:var(--muted)}
.hero .h a{color:inherit}details.fold>summary{min-height:40px}
.chips{display:flex;flex-wrap:wrap;gap:8px;margin:0 0 12px}.chips .chip{display:inline-flex;align-items:center;gap:8px;min-height:40px;padding:0 14px;border:1px solid var(--line);border-radius:999px;background:var(--soft);font-size:14px;color:var(--muted)}
.chips .chip b{font:600 14px var(--sans);color:var(--accent)}"""


def fold(title, sub, inner):
    return '<details class="fold"><summary>%s <small>%s</small></summary><div class="body">%s</div></details>' % (e(title), e(sub), inner)


def plain(t):
    """Forecast wording as written in the log, minus the build's internal names."""
    for a, b in (("eval gates", "evaluation checks"), ("gate", "check"), ("canary", "paraphrase check")):
        t = t.replace(a, b)
    return t


def build_log():
    E = ev()
    preds = jsonl("predictions.jsonl")
    done = [p for p in preds if p.get("outcome") in (0, 1)]
    brier = sum((p["p"] - p["outcome"]) ** 2 for p in done) / len(done) if done else None
    e2e = [r for r in jsonl("e2e_runs.jsonl") if r.get("provider") == "claude" and r.get("monday") == "live"]
    last = e2e[-1] if e2e else None
    rehearsal = jsonl("rehearsal_runs.jsonl")
    green = bool(rehearsal and rehearsal[-1]["green"])
    rows = "".join("<tr><td><span data-assumption>%s</span></td><td>%s</td><td>%s</td></tr>" % (e(plain(p["claim"])), "%d in 100" % round(p["p"] * 100),
                   {1: "came true", 0: "did not"}.get(p.get("outcome"), "open")) for p in preds)
    hero = ('<div class="hero">'
            '<div class="h"><b>%s</b><span>Cash spent on the AI while building and testing. Measured from the call log; the free mock and local model cost nothing.</span></div>'
            '<div class="h"><b>%s</b><span>Live end-to-end runs passed on real monday.com boards. Every failed run stays in the log.</span></div>'
            '<div class="h"><b class="%s">%s</b><span>Latest full rehearsal: build, tests, security, packaging and a live run, start to finish.</span></div></div>'
            ) % (fig(E, "E-build-spend"), fig(E, "E-e2e-live"), "ok" if green else "no", fig(E, "E-rehearsal"))
    hk = re.search(r"~(\$[\d.]+)/question", E["E-haiku"]["value"])
    chips = [("Pipeline cash spend", fig(E, "E-build-spend")),
             ("Default model", fig(E, "E-cost-per-q")),
             ("Per response cycle", fig(E, "E-cycle-cost")),
             ("Small cloud model", '<span data-e="E-haiku" data-g="%s">%s per question</span>' % (GRADE_OF.get(E["E-haiku"].get("class"), ""), e(hk.group(1))) if hk else fig(E, "E-haiku", "value")),
             ("Local model", "nothing"), ("Mock and tests", "nothing")]
    cost = ('<div class="chips">%s</div>'
            '<p class="m">Cash spent on the AI while building and testing, and what each unit of the product costs to run, all from the call log. '
            'Key facts and amendment changes are read straight from the documents with no AI call; the local model and the free mock bill nothing.</p>'
            ) % "".join('<span class="chip"><span>%s</span><b>%s</b></span>' % (e(l), v) for l, v in chips)
    running = ('<table><tr><th>Mode</th><th>Cash cost</th><th>Measured quality and speed</th><th>When to use it</th></tr>'
               '<tr><td>No AI: rules read the documents</td><td>none</td><td>Key facts and amendment changes, quoted word for word (%s)</td><td>Always on. Dates, deposits and amendment changes never need a model.</td></tr>'
               '<tr><td>Local model, on RET hardware</td><td>none (RET\'s own machine)</td><td>%s</td><td>When text must not leave RET, or offline. Slower and less accurate; every answer still goes through the same figure check.</td></tr>'
               '<tr><td>Small cloud model</td><td>%s</td><td>A little less accurate; it missed some cases where it should have refused</td><td>High volume, low-stakes questions, once refusals are re-tested.</td></tr>'
               '<tr><td>Full cloud model (default)</td><td>%s; %s a cycle</td><td>Best accuracy and speed measured</td><td>Default: a wrong answer on a bid with a deposit at stake costs far more than the AI; the real cost is people reviewing, not the model.</td></tr></table>'
               '<p class="m">So the range per response cycle runs from nothing to %s of AI. Spend when accuracy saves reviewer time or a bid; do not spend when data residency or an offline setting rules it out.</p>'
               ) % (fig(E, "E-facts", "value"), fig(E, "E-local-eval", "value"), fig(E, "E-haiku", "value"), fig(E, "E-cost-per-q"), fig(E, "E-cycle-cost"), fig(E, "E-cycle-cost"))
    live = ("Latest live run on real monday.com boards with Claude, %s%s: %d of %d passed; median %s from pick-up to the answer on the board. "
            "%d live runs logged, %d passed; every failed run stays in the log."
            % (last["t"][:10], ", from the submitted ZIP" if last.get("from_zip") else "", last["passed"], last["runs"], fig(E, "E-e2e-answer"),
               len(e2e), sum(1 for r in e2e if r["passed"] == r["runs"]))) if last else "No live run recorded yet."
    fc = ('<p class="m">%d made, %d resolved so far%s. Open ones resolve at or after the pilot.</p>'
          '<table><tr><th>Forecast</th><th>Our confidence</th><th>Result</th></tr>%s</table>'
          ) % (len(preds), len(done), ("; Brier score %.3f (lower is better; 0.25 is a coin flip)" % brier) if brier is not None else "", rows)
    body = ('<main><p class="m"><a href="index.html">\u2190 Start here</a></p><h1>The build log</h1>'
            '<p class="verdict">The AI cost %s in cash to build and test; %s live end-to-end runs passed; the latest full rehearsal was %s.</p>'
            % (fig(E, "E-build-spend"), fig(E, "E-e2e-live"), fig(E, "E-rehearsal")) + hero +
            fold("Cost to build", "pipeline cash and the cost of each unit", cost) +
            fold("Running cost", "four ways to run it, and when to spend", running) +
            fold("Hardening over time", "risk down, defences up, one point per run", '<p class="m">Each line is one point per run or repair, read from the run logs.</p>' + hardening()) +
            fold("Live end-to-end runs", "the latest run and the record", "<p>%s</p>" % live) +
            fold("Our forecasts", "written down before the outcome, and how they scored", fc) + '</main>')
    return page("Build Log", body, BUILD_STYLE)


LEVELS = ["Executive", "Strategic", "Operational", "Tactical", "Surgical"]
LEVEL_NOTE = ["each choice and the business result it unlocks", "+ what was open and what we gave up", "+ who it serves, where it lives, and now, next, later with what moves each step",
              "+ what could go wrong and how sure we are", "+ the files that prove it"]

DECIDE_STYLE = """
.ctl{margin:0 0 8px}.ctl .lab{font:600 12px var(--sans);color:var(--muted);margin:0 0 6px}
.seg{display:flex;flex-wrap:wrap;border:1px solid var(--line);border-radius:12px;overflow:hidden;width:max-content;max-width:100%}
.seg button{border:0;border-right:1px solid var(--line);background:var(--bg);color:var(--ink);padding:0 14px;min-height:44px;font:600 13px var(--sans);cursor:pointer}
.seg button:last-child{border-right:0}.seg button[aria-pressed=true]{background:var(--fill);color:#fff}
.lvlnote{color:var(--muted);font-size:14px;margin:6px 0 24px}
.dec{border:1px solid var(--line);border-radius:8px;padding:24px;margin:0 0 16px;background:var(--bg)}
.dec h3.t{font:600 18px/1.25 var(--title);margin:0 0 6px}.dec .q{color:var(--muted);margin:8px 0 0}
.dec .chose{margin:0;font-weight:400}.dec .chose b{font:600 14px var(--sans);color:var(--accent);margin-right:8px}
.cells{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:12px;margin-top:14px}
.cell{border-top:1px solid var(--line);padding:12px 0 0}
.cell .ch{font:600 12px var(--sans);color:var(--muted);margin:0 0 8px}.cell p,.cell li{margin:0 0 6px}
.cell ul{margin:0;padding-left:18px}.gr{display:inline-block;font:600 12px var(--sans);border:1px solid var(--line);border-radius:4px;padding:0 5px;margin-right:6px}
.tags{display:flex;flex-wrap:wrap;gap:6px 16px;margin:8px 0 0;font-size:14px;color:var(--muted)}.tags b{font:600 12px var(--sans);margin-right:5px;color:var(--accent)}
.dec .chose .step{font:600 12px var(--sans);border:1px solid var(--line);border-radius:100px;padding:1px 8px;color:var(--muted);vertical-align:middle}.unl{margin:8px 0 0}.unl b{font:600 12px var(--sans);color:var(--accent);margin-right:6px}.unl .step{font:600 12px var(--sans);border:1px solid var(--line);border-radius:100px;padding:1px 8px;margin-right:6px;color:var(--muted)}\n/* One type role per depth: Executive = H3, Strategic = lede, Operational = body, Tactical = small body, Surgical = code. */\n.dec .chose,.dec h3.t{font:600 18px/1.35 var(--title)}.dec .unl{font:600 16px/1.45 var(--title)}\n.dec [data-lvl="2"],.dec [data-lvl="2"] li,.dec [data-lvl="2"] p{font:400 17px/1.55 var(--sans);color:var(--ink)}\n.dec [data-lvl="3"],.dec [data-lvl="3"] li,.dec [data-lvl="3"] p{font:400 16px/1.55 var(--sans)}\n.dec [data-lvl="4"],.dec [data-lvl="4"] li,.dec [data-lvl="4"] p{font:400 15px/1.5 var(--sans);color:var(--muted)}\n.dec [data-lvl="5"],.dec [data-lvl="5"] li,.dec [data-lvl="5"] a{font:400 13px/1.5 ui-monospace,SFMono-Regular,Menlo,Consolas,monospace}\n.cell h4{font:600 12px/1.3 var(--sans)}\n.ev{margin:12px 0 0;padding-left:18px}body[data-depth="1"] .dec{padding:10px 16px;margin:0 0 8px;border-radius:8px}body[data-depth="1"] .dec h3.t{font-size:16px;margin:0 0 2px}body[data-depth="1"] .sec{margin:24px 0 10px}.sec{font:600 24px/1.2 var(--title);margin:36px 0 14px}
""" + "".join('body[data-depth="%d"] [data-lvl="%d"]{display:none}' % (dp, lv) for dp in range(1, 5) for lv in range(dp + 1, 6)) + """
body[data-depth="1"] .cells:not(:has(.cell:not([data-lvl]))){display:none}"""

DECIDE_SCRIPT = """<script>
(function () {
  var bs = [].slice.call(document.querySelectorAll(".seg button")), note = document.getElementById("lvlnote"), notes = %s;
  function set(d) { document.body.setAttribute("data-depth", d);
    bs.forEach(function (b) { b.setAttribute("aria-pressed", b.dataset.d === String(d)); });
    note.textContent = notes[d - 1];
    try { localStorage.setItem("depth", d); } catch (e) {} }
  bs.forEach(function (b) { b.onclick = function () { set(+b.dataset.d); }; });
  var v = null; try { v = +localStorage.getItem("depth"); } catch (e) {}
  set(v >= 1 && v <= 5 ? v : 2);
})();
</script>""" % json.dumps(["Showing: " + n for n in LEVEL_NOTE])

GRADE_NAMES = {"A": "from your documents", "B": "measured in this build", "C": "cited from a published source", "D": "our estimate"}


def decisions_problems(rows):
    """Every row needs all five cells and at least one evidence file that exists; the build fails otherwise."""
    bad = []
    for r in rows:
        for k in ("title", "question", "who", "chose", "where", "options", "risk", "sure", "revisit", "unlocks", "horizon", "evidence"):
            if not r.get(k):
                bad.append("%s: missing %s" % (r.get("id"), k))
        for k in ("now", "next", "later", "trigger"):
            if not (r.get("horizon") or {}).get(k):
                bad.append("%s: horizon missing %s" % (r.get("id"), k))
        if not (r.get("unlocks") or {}).get("outcome"):
            bad.append("%s: unlocks missing outcome" % r.get("id"))
        if r.get("sure", {}).get("grade") not in GRADE_NAMES:
            bad.append("%s: grade must be one of A, B, C, D" % r.get("id"))
        for ev_ in r.get("evidence") or []:
            if not os.path.exists(os.path.join(ROOT, ev_["path"])):
                bad.append("%s: evidence %s does not exist" % (r.get("id"), ev_["path"]))
    return bad


def section_problems(d):
    """gaps, inputs, loops, held and checks: every field present, every evidence file exists (a directory counts)."""
    need = {"inputs": ("what", "detail", "grade", "evidence"), "loops": ("who", "where", "believed", "tested", "found", "changed", "evidence"),
            "checks": ("who", "where", "what", "how", "guards", "evidence"), "gaps": ("gap", "assumed", "why", "evidence"),
            "held": ("belief", "evidence_text", "evidence"), "principles": ("name", "means", "enforced", "guards", "tools", "evidence"),
            "outcomes": ("rank", "outcome", "goal_type", "evidence_text", "why", "serves", "status", "measure", "evidence")}
    bad = []
    for sec, keys in need.items():
        if not d.get(sec):
            bad.append("missing section %s" % sec)
        for n, r in enumerate(d.get(sec) or [], 1):
            for k in keys:
                if not r.get(k):
                    bad.append("%s %d: missing %s" % (sec, n, k))
            for x in r.get("evidence") or []:
                if not os.path.exists(os.path.join(ROOT, x["path"])):
                    bad.append("%s %d: evidence %s does not exist" % (sec, n, x["path"]))
            for t in r.get("tools") or []:
                if not os.path.exists(os.path.join(ROOT, t["tool"])):
                    bad.append("%s %d: tool %s does not exist" % (sec, n, t["tool"]))
    return bad


def tags(r):
    return '<p class="tags"><span><b>Who</b> %s</span><span><b>Where</b> %s</span></p>' % (e(r["who"]), e(r["where"]))


def evlinks(items):
    return "".join('<li><a href="%s">%s</a> <span class="m">%s</span></li>' % (e(shipped_path(x["path"]) or "../../" + x["path"]),
                   e(re.sub(r"\s*K\d+(?:,\s*K\d+)*$", "", x["label"])), e(x["path"])) for x in items)


def fill(E, text):
    """{E-id} placeholders take the figure from evidence.jsonl, so no number in this page is typed in."""
    out, last = [], 0
    for m in re.finditer(r"\{(E-[\w-]+)(?:\|([^}]+))?\}", text):
        out.append(e(text[last:m.start()]))
        eid, shown = m.group(1), m.group(2)
        if shown is None:
            out.append(fig(E, eid))
        elif shown in E[eid]["value"]:   # {E-id|text}: text must appear word for word in the evidence row
            out.append('<span data-e="%s" data-g="%s">%s</span>' % (eid, GRADE_OF.get(E[eid].get("class"), ""), e(shown)))
        else:
            raise SystemExit("home: %r is not in evidence row %s" % (shown, eid))
        last = m.end()
    out.append(e(text[last:]))
    return "".join(out)


def how_we_decided():
    """Five depths, each a superset of the one above: Executive, Strategic, Operational, Tactical, Surgical."""
    E = ev()
    data = json.load(open(os.path.join(ROOT, "evidence", "decisions.json")))
    rows = data["rows"]
    bad = decisions_problems(rows) + section_problems(data)
    if bad:
        raise SystemExit("home: evidence/decisions.json: " + "; ".join(bad))
    def lv(n, tag, inner, cls=""):
        return '<%s%s data-lvl="%d">%s</%s>' % (tag, (' class="%s"' % cls) if cls else "", n, inner, tag.split()[0])
    def cell(n, title, inner):
        return '<div class="cell" data-lvl="%d"><p class="ch">%s</p>%s</div>' % (n, e(title), inner)   # a label, not a heading level
    def evid(items):
        return lv(5, "ul", evlinks(items), "ev")
    gaps = "".join('<section class="dec"><p class="chose"><b>OPEN</b>%s</p>%s%s%s</section>'
                   % (e(x["gap"]), lv(1, "p", "We assumed: " + e(x["assumed"]), "q"), lv(2, "p", fill(E, x["why"]), "q"), evid(x["evidence"]))
                   for x in data["gaps"])
    inputs = "".join('<section class="dec"><h3 class="t">%s <span class="gr" title="%s">%s</span></h3>%s%s</section>'
                     % (e(x["what"]), e(GRADE_NAMES[x["grade"]]), x["grade"], lv(2, "p", fill(E, x["detail"]), "q"), evid(x["evidence"]))
                     for x in data["inputs"])
    loops = "".join('<section class="dec"><p class="chose"><b>LOOP %d</b>We believed: %s</p>%s%s%s<div class="cells">%s%s</div>%s</section>'
                    % (n, fill(E, x["believed"]), lv(1, "p", "So we changed: " + fill(E, x["changed"]), "q"),
                       lv(2, "p", "We found: " + fill(E, x["found"]), "q"), lv(3, "div", tags(x)),
                       cell(4, "We tested", "<p>%s</p>" % fill(E, x["tested"])), "", evid(x["evidence"]))
                    for n, x in enumerate(data["loops"], 1))
    held = "".join('<section class="dec"><p class="chose"><b>HELD</b>%s</p>%s%s</section>'
                   % (fill(E, x["belief"]), lv(2, "p", fill(E, x["evidence_text"]), "q"), evid(x["evidence"])) for x in data["held"])
    cards = []
    for r in rows:
        opts = "".join("<li><b>%s.</b> %s</li>" % (e(o["option"]), fill(E, o["gave_up"])) for o in r["options"])
        g = r["sure"]["grade"]
        h = r["horizon"]
        cards.append('<section class="dec" id="%s"><h3 class="t">%s</h3><p class="chose"><b>We chose</b>%s</p>'
                     '<p class="unl"><b>Unlocks</b><span class="step">%s</span> %s</p>%s'
                     '<div class="cells">%s%s%s%s</div>%s</section>'
                     % (e(r["id"].lower()), e(r["title"]), fill(E, r["chose"]), e(r["unlocks"]["step"]), fill(E, r["unlocks"]["outcome"]),
                        lv(2, "p", fill(E, r["question"]), "q"),
                        cell(2, "Options and what we gave up", "<ul>%s</ul>" % opts),
                        cell(3, "Now, next, later", tags(r) + "<ul><li><b>Now.</b> %s</li><li><b>Next.</b> %s</li><li><b>Later.</b> %s</li></ul><p><b>What moves it:</b> %s</p>"
                             % (fill(E, h["now"]), fill(E, h["next"]), fill(E, h["later"]), fill(E, h["trigger"]))),
                        cell(4, "What could go wrong", "<p>%s</p>" % fill(E, r["risk"])),
                        cell(4, "How sure, and why", '<p><span class="gr" title="%s">%s</span>%s</p>' % (e(GRADE_NAMES[g]), g, fill(E, r["sure"]["text"]))),
                        evid(r["evidence"])))
    checks = "".join('<section class="dec"><p class="chose">%s</p>%s<div class="cells">%s</div>%s</section>'
                     % (fill(E, x["what"]), lv(2, "p", "Guards against: " + e(x["guards"]), "q") + lv(3, "div", tags(x)), cell(4, "Proof it fails when it should", "<p>%s</p>" % fill(E, x["how"])), evid(x["evidence"]))
                     for x in data["checks"])
    cited = [r for r in E.values() if r.get("class") == "cited"]
    sources = lv(5, "div", '<table><tr><th>Claim</th><th>Published source, and when we read it</th></tr>%s</table>'
                 % "".join("<tr><td>%s</td><td>%s</td></tr>" % (fig(E, r["id"], "value"), e(r.get("source", ""))) for r in cited))
    def tools(x):   # Tactical: the tools that do the job, in the order they act
        return cell(4, "Tools for the job, in the order they act", "<ol>%s</ol>" % "".join(
            "<li><code>%s</code>: %s</li>" % (e(t["tool"]), e(t["does"])) for t in x["tools"]))
    titles = {r["id"]: r["title"] for r in rows}
    outcomes = "".join(
        '<section class="dec"><p class="chose"><b>%d</b>%s <span class="step">%s</span></p>%s%s<div class="cells">%s%s</div>%s</section>'
        % (x["rank"], e(x["outcome"]), e(x["goal_type"]), lv(2, "p", fill(E, x["evidence_text"]) + " " + e(x["why"]), "q"),
           lv(3, "p", "Built for it: " + ", ".join('<a href="#%s">%s</a>' % (e(i.lower()), e(titles[i])) for i in x["serves"]), "q"),
           cell(4, "Build status", "<p>%s</p>" % fill(E, x["status"])), cell(4, "How the pilot measures it", "<p>%s</p>" % fill(E, x["measure"])),
           evid(x["evidence"])) for x in sorted(data["outcomes"], key=lambda o: o["rank"]))
    principles = "".join('<section class="dec"><p class="chose"><b>%s</b>%s</p>%s%s<div class="cells">%s</div>%s</section>'
                         % (e(x["name"]), e(x["means"]), lv(2, "p", "Guards against: " + e(x["guards"]), "q"),
                            lv(3, "p", fill(E, x["enforced"]), "q"), tools(x), evid(x["evidence"])) for x in data["principles"])
    seg = "".join('<button type="button" data-d="%d" aria-pressed="false">%s</button>' % (n, e(name)) for n, name in enumerate(LEVELS, 1))
    body = ('<main><p class="m"><a href="index.html">← Start here</a></p><h1>How we got here</h1>'
            '<p class="lede">The principles we built to, the choices we made, how tests changed our approach, what held, what the brief left open, what we worked from, '
            'and the checks that keep it honest: most-used first, most specialized last. Choose how deep to read; each level adds to the one before.</p>'
            '<div class="ctl"><p class="lab" id="lvl-lab">DEPTH</p><div class="seg" role="group" aria-labelledby="lvl-lab">' + seg + '</div>'
            '<p class="lvlnote" id="lvlnote" aria-live="polite"></p></div>'
            '<h2 class="sec">1. What matters most to RET, ranked</h2><p class="m">Our ranking (D: our judgement from the brief and '
            'the briefing video); the figures are RET\'s own (A). Ranked this way, they were also our build goals, in order. '
            'Sam\'s rule on what leaves RET and Nina\'s rule on citations are gates, not outcomes: fail either and none of these count. '
            'Other goal types live below: technical goals in what we hold to and how we decided; platform goals in the monday.com '
            'decision (D-MCP) and <a href="boards.html">what the boards hold</a>.</p>' + outcomes +
            '<h2 class="sec">2. What we hold to</h2>' + principles +
            '<h2 class="sec">3. How we decided</h2>' + "".join(cards) +
            '<h2 class="sec">4. How it evolved: what we believed, found and changed</h2>' + loops +
            '<h2 class="sec">5. What held</h2>' + held +
            '<h2 class="sec">6. What the brief left open</h2>' + gaps +
            '<h2 class="sec">7. What we worked from</h2>' + inputs + sources +
            '<h2 class="sec">8. Why you can trust the checks</h2>' + checks +
            '<p class="m">Grades: A from your documents · B measured in this build · C cited from a published source · D our estimate. '
            'Every decision, including smaller ones, is in <a href="../../DECISIONS.md">DECISIONS.md</a>.</p></main>')
    # Mistake numbers (K17) mean nothing to a reader here; the mistakes page carries them, and each file is linked.
    body = re.sub(r"\s*\((?:<a [^>]*>)?K\d+(?:</a>)?(?:,\s*(?:<a [^>]*>)?K\d+(?:</a>)?)*\)", "", body)
    return page("How We Got Here", body, DECIDE_STYLE, DECIDE_SCRIPT)


def mistakes():
    """KINTSUGI.md as a readable page: a browser shows the .md as raw text, and ../../ links break outside the ZIP."""
    src = open(os.path.join(ROOT, "KINTSUGI.md")).read()
    rows = [l for l in src.splitlines() if re.match(r"^\| K\d+ \|", l)]
    md = lambda t: re.sub(r"`([^`]+)`", r"<code>\1</code>", re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", e(t)))
    # Each row carries its id as an anchor (mistakes.html#K17), so the proof page and the wiki can cite one row exactly,
    # and its links like a ticket's: what guards it, and what it relates to (dashboard.mistake_links).
    sys.path.insert(0, os.path.join(ROOT, "scripts"))
    import dashboard
    L = dashboard.mistake_links()
    def src(f):
        path, _, case = f.partition(" ")
        return '<a href="../../%s"><code>%s</code></a>%s' % (e(path), e(path), (" " + e(case)) if case else "")
    def guard(k):
        x = L[k]
        if x["guarded_by"]:
            return "<br>".join(src(f) for f in x["guarded_by"])
        return "<i>No automated guard:</i> " + e(x["process"] or "")
    def related(k):
        x = L[k]
        bits = ['<a href="#%s">%s</a>' % (r, r) for r in x["related"]]
        bits += ['<a href="../../DECISIONS.md">%s</a>' % e(d) for d in x["decisions"]]
        bits += [src(f) for f in x["fixed_in"]]
        return "<br>".join(bits) or "none"
    TOP = ["K55", "K56", "K57", "K58"]   # the four that mattered most (evidence/cases.json, "Simulation versus users")
    def card(r):
        c = [x.strip() for x in r.strip().strip("|").split(" | ")]
        k, what = c[0], c[1]
        head = re.split(r"(?<=[.!?])\s", re.sub(r"\*\*", "", what), 1)[0]
        g = L[k]
        gshort = ("guarded by " + ", ".join(sorted({os.path.basename(f.split(" ")[0]) for f in g["guarded_by"]}))) if g["guarded_by"] else "process lesson"
        rows = "".join('<tr><th scope="row">%s</th><td>%s</td></tr>' % (lbl, val) for lbl, val in (
            ("What went wrong", md(what)), ("Caught by", md(c[2])), ("Whose error", md(c[3])), ("Repair", md(c[4])),
            ("What it changed", md(c[5]) if len(c) > 5 else ""), ("Guarded by", guard(k)), ("Related", related(k))))
        return ('<details class="fold mk" id="%s"><summary><b>%s</b> %s <small>%s</small></summary><div class="body"><table class="kv">%s</table></div></details>'
                % (k, k, e(head), e(gshort), rows))
    cards = "".join(card(r) for r in rows)
    n_g = sum(1 for x in L.values() if x["guarded_by"])
    verdict = ('<p class="verdict">%d mistakes logged; %d guarded by a test, simulation, test-set case or release gate; '
               '%d are process lessons, each with its reason.</p><p>The four that mattered most were found by rehearsing like a real '
               'user, not by simulation: %s. Open any row for what caught it, the repair, and what guards it now.</p>'
               % (len(L), n_g, len(L) - n_g, ", ".join('<a href="#%s">%s</a>' % (k, k) for k in TOP)))
    body = ('<main><p class="m"><a href="index.html">← Start here</a></p><h1>Our mistakes, and their repairs</h1>' + verdict +
            '<p class="lede">Every time a failure turned out to be our own mistake (a wrong test, a bad assumption, a claim the code '
            'did not back), it was logged when it was found. Nothing was quietly edited to pass. ' + fig(ev(), "E-repairs") +
            ', generated from KINTSUGI.md.</p>' + cards + '</main>')
    script = "<script>(function(){function o(){var h=location.hash.slice(1),d=h&&document.getElementById(h);if(d&&d.tagName==='DETAILS'){d.open=true;d.scrollIntoView();}}addEventListener('hashchange',o);o();})();</script>"
    return page("Our Mistakes", body, "details.mk:target{outline:2px solid var(--accent)}details.mk{scroll-margin-top:70px}table.kv th{width:9rem;text-align:left;vertical-align:top;color:var(--muted);font-weight:600}", script)


def boards():
    """What the integration wrote to monday.com, read back by scripts/boards_snapshot.py (no login needed to view)."""
    d = json.load(open(os.path.join(ROOT, "evidence", "boards-snapshot.json"), encoding="utf-8"))
    parts = []
    def cell(v):   # monday.com file links need a signed-in member; name the file instead of showing a dead link
        if "/protected_static/" in v:
            return "file attached: %s (members only)" % e(v.rstrip("/").split("/")[-1].split("?")[0])
        return e(v).replace("\n", "<br>")
    def state(v):   # a question's stage at a glance: answered, flagged for a person, or not in the RFP
        tone = {"answered": "ok", "needs review": "warn", "not addressed in rfp": "none", "refused to guess": "refused"}.get(v.strip().lower(), "bad" if v else "")
        return '<span class="st %s">%s</span>' % (tone, e(v or "Waiting")) if v or tone else ""
    for b in d["boards"]:
        cols = [c for c in b["columns"] if c["title"] != "Key"]   # our internal upsert key, not for readers
        head = "<tr><th>Item</th>%s</tr>" % "".join("<th>%s</th>" % e(c["title"]) for c in cols)
        rows = "".join("<tr><td>%s</td>%s</tr>" % (e(it["name"]), "".join(
            "<td>%s</td>" % (state(it["values"].get(c["id"], "")) if c["title"] == "State" else cell(it["values"].get(c["id"], "")))
            for c in cols)) for it in b["items"])
        parts.append('<details class="fold"><summary>%s <small>%d items · board id %s</small></summary><div class="body"><div style="overflow-x:auto"><table>%s%s</table></div></div></details>'
                     % (e(b["name"]), len(b["items"]), e(b["id"]), head, rows))
    calls = "".join("<tr><td>%s</td><td>%s</td><td>%s</td><td>%s s</td><td>%s</td></tr>" % (
        e(c["t"][11:19]), e(c.get("purpose") or ""), c.get("complexity"), c.get("latency_s"), "ok" if c.get("ok") else "failed")
        for c in d["calls"])
    body = ('<main><p class="m"><a href="index.html">← Start here</a></p><h1>What the boards hold</h1>'
            '<p class="verdict">%d boards, %d items, read back from monday.com at %s UTC.</p>'
            '<p class="lede">The monday.com boards need an invitation to open, so this page shows what the integration actually '
            'wrote, read back through the GraphQL API (version %s) at %s UTC. Questions marked [sample] are RET\'s own 14 sample '
            'questions, asked and answered on the board through the path staff use (<code>./rfp samples</code>); [rehearsal] '
            'rows are from a dress rehearsal and <code>./rfp reset</code> archives them before a demo.</p>%s'
            '<details class="fold"><summary>What reading the boards cost <small>each call, its complexity points and time</small></summary><div class="body"><p class="m">Each call as logged in flightlog/monday_calls.jsonl.</p><table><tr><th>Time (UTC)</th><th>Purpose</th>'
            '<th>Complexity</th><th>Latency</th><th>Result</th></tr>%s</table></div></details>'
            '<p class="m">Refresh with <code>python3 scripts/boards_snapshot.py</code>, then <code>python3 scripts/build.py</code>.</p></main>'
            ) % (len(d["boards"]), sum(len(b["items"]) for b in d["boards"]), e(d["read_at"][:16].replace("T", " ")),
                 e(d["api_version"]), e(d["read_at"][:16].replace("T", " ")), "".join(parts), calls)
    # The same colors monday.com shows for each State label (rfp/sink.py STATE_HEX), so the page and the board agree.
    return page("What the Boards Hold", body, ".st{display:inline-block;padding:2px 10px;border-radius:4px;font:600 12px var(--sans);"
                "white-space:nowrap;color:#fff;background:#c4c4c4}.st.ok{background:#037f4c}.st.warn{background:#ffcb00;color:#323338}"
                ".st.none{background:#757575}.st.bad{background:#bb3354}.st.refused{background:#ff7575;color:#323338}")


SECTIONS = ["1 Product", "1.1 Run it", "2 Architecture", "2.1 Data model", "2.2 Integrations", "3 Evidence", "3.1 Evals",
            "4 Governance", "4.2 Change control", "6 Build history"]
GENERATED = {"evidence/repair-times.json", "evidence/turning-points-resolved.json", "HISTORY.txt"}  # written by package.py, not in git
TOP = set()   # nothing ships beside source/ and presentation/ (the portal's package structure)


def ignored_local(rel):
    """A local-only file (gitignored) never ships, so it is never linked."""
    return subprocess.run(["git", "-C", ROOT, "check-ignore", "-q", rel], capture_output=True).returncode == 0


def top_file(rel):
    """README.md or presentation/<x>: under the repo root, or one level above source/ in the unzipped ZIP."""
    return not ignored_local(rel) and any(os.path.isfile(os.path.join(ROOT, *up, rel)) for up in ((), ("..",)))


def shipped_files():
    """What package.py puts under source/: SOURCE_PARTS applied to the files git knows (tracked, or new and not ignored).
    None when there is no git checkout (the unzipped ZIP), where the manifest cannot be compared."""
    import subprocess
    sys.path.insert(0, os.path.join(ROOT, "scripts"))
    from package import SOURCE_PARTS
    r = subprocess.run(["git", "-C", ROOT, "ls-files", "--cached", "--others", "--exclude-standard"], capture_output=True, text=True)
    if r.returncode:
        return None
    # docs/site/ is the review pages themselves; the find-anything page lists them in its own table.
    return sorted(f for f in set(r.stdout.splitlines()) if f.split("/")[0] in SOURCE_PARTS and not f.endswith("history.bundle") and f != ".env"
                  and not f.startswith("docs/site/")
                  and os.path.isfile(os.path.join(ROOT, f)))


def manifest_problems():
    """docs/catalog.json must list every shipped file exactly once, with a known section and a purpose line."""
    if not os.path.exists(CATALOG):
        return ["docs/catalog.json is missing"]
    rows = json.load(open(CATALOG, encoding="utf-8"))
    bad, seen = [], {}
    for r in rows:
        if not (r.get("path") and r.get("purpose")) or r.get("section") not in SECTIONS:
            bad.append("catalog row needs path, purpose and a known section: %r" % (r.get("path"),))
        seen[r["path"]] = seen.get(r["path"], 0) + 1
    bad += ["docs/catalog.json lists %s %d times" % (p, n) for p, n in seen.items() if n > 1]
    shipped = shipped_files()
    if shipped is not None:
        bad += ["docs/catalog.json is missing shipped file %s" % f for f in shipped if f not in seen]
        bad += ["docs/catalog.json lists %s, which does not ship" % p for p in seen if p not in shipped and p not in GENERATED | TOP]
    return bad


AREAS = [("evidence", "Evidence", ["3 Evidence", "3.1 Evals"]), ("product", "Product", ["1 Product", "1.1 Run it"]),
         ("architecture", "Architecture", ["2 Architecture", "2.1 Data model", "2.2 Integrations"]), ("governance", "Governance", ["4 Governance", "4.2 Change control"]),
         ("presentation", "Presentation", []), ("history", "Build history", ["6 Build history"])]

WIKI_STYLE = """
/* File tables: the path column has one width on every section, so 'What it is' starts in the same place. */
table:has(td.p){table-layout:fixed}table:has(td.p) th:first-child{width:38%}td.p code{overflow-wrap:anywhere}
.toc{margin:0 0 24px;border:1px solid var(--line);border-radius:8px;padding:4px 16px}.toc summary{min-height:44px;display:flex;align-items:center;font:600 14px var(--sans);cursor:pointer}
.toc ol{list-style:none;margin:0 0 12px;padding:0}.toc ol ol{padding-left:14px}.toc a{display:block;padding:6px 0;color:var(--ink)}
@media(min-width:1100px){.toc{display:none}}
.fold{border-top:1px solid var(--line);padding:6px 0}.fold summary{cursor:pointer;min-height:40px;display:flex;align-items:center;gap:6px;font-weight:600}
html{scroll-behavior:smooth}.top{position:sticky;top:0;z-index:50;background:var(--bg);border-bottom:1px solid var(--line)}
.top .row{display:flex;gap:8px;align-items:center;padding:8px 16px;overflow-x:auto;max-width:1240px;margin:0 auto}
.pill{flex:none;display:inline-flex;align-items:center;min-height:40px;padding:0 14px;border:1px solid var(--line);border-radius:100px;background:var(--soft);color:var(--ink);font:600 13px var(--sans);text-decoration:none;cursor:pointer}
.pill:hover,.pill[aria-current=true]{border-color:var(--accent);color:var(--accent)}.pill.sm{min-height:34px;font-weight:400;letter-spacing:0}
.top .subs{padding-top:0}.js .subs[data-area]{display:none}.js .subs.on{display:flex}.sp{flex:1}
.shell{max-width:1240px;margin:0 auto;padding:16px 16px 64px}.rail{display:none}
@media(min-width:1100px){.shell{display:grid;grid-template-columns:15rem minmax(0,1fr);column-gap:40px;align-items:start}
.rail{display:block;position:sticky;top:72px;max-height:calc(100vh - 90px);overflow:auto;font-size:14px}}
.rail ol{list-style:none;margin:0;padding:0}.rail ol ol{padding-left:12px;border-left:1px solid var(--line);margin:2px 0 8px 2px}
.rail a{display:block;padding:4px 8px;color:var(--muted);text-decoration:none;line-height:1.35}.rail a:hover{color:var(--accent);text-decoration:underline}
.wiki main{max-width:none;padding:8px 0 0}.wiki h2{font:600 26px/1.2 var(--title);margin:40px 0 8px;scroll-margin-top:110px}
.wiki h3{font:600 18px/1.3 var(--title);margin:28px 0 6px;scroll-margin-top:110px}.wiki .intro{color:var(--muted);margin:0 0 10px;max-width:var(--measure)}
.wiki td.p{white-space:nowrap}.wiki .wrap{overflow-x:auto}.wiki code{font-size:14px}
.menu{display:none}.menu summary{list-style:none}.menu summary::-webkit-details-marker{display:none}
.menu nav{position:absolute;left:0;right:0;top:100%;max-height:70vh;overflow:auto;background:var(--bg);border-bottom:1px solid var(--line);padding:8px 16px 16px;font-size:15px}
.menu ol{list-style:none;margin:0;padding:0}.menu ol ol{padding-left:14px;border-left:1px solid var(--line);margin:2px 0 10px 4px}
.menu a{display:block;padding:9px 4px;color:var(--ink);text-decoration:none}.menu ol ol a{color:var(--muted);padding:7px 4px}
@media(max-width:719px){.top .areas .pill[data-area],.top .subs,.js .subs.on{display:none}.menu{display:block}.top{position:sticky}.top .row{overflow:visible}}"""

WIKI_SCRIPT = """<script>(function(){var m=document.querySelector(".toc");if(m)m.addEventListener("click",function(ev){if(ev.target.tagName==="A")m.open=false;});})();</script>"""


def slug(s):
    return re.sub(r"[^a-z0-9]+", "-", s.lower()).strip("-")


PATH_RE = re.compile(r"(?<![\w/.-])((?:[\w-]+/)*[\w.-]+\.(?:py|md|json|jsonl|sh|html))(?![\w/.-])")


def shipped_path(p):
    """Where a path cited in a wiki table lives: under source/ (repo root) or presentation/ (the PDF), or None."""
    if (p.startswith("presentation/") or p in TOP) and top_file(p):
        return "../../../" + p
    if os.path.exists(os.path.join(ROOT, p)) and not ignored_local(p):
        return "../../" + p
    return None


def KNOWN_K():
    return set(re.findall(r"^\| (K\d+) \|", open(os.path.join(ROOT, "KINTSUGI.md")).read(), re.M))


def linked(E, text):
    """fill(), then every cited file becomes a link that opens it (in the bench or the unzipped ZIP)."""
    html_ = fill(E, text)
    # A mistake id jumps to its row on the mistakes page, so a reviewer can cross-check the claim.
    known = KNOWN_K()
    html_ = re.sub(r"\b(K\d+)\b", lambda m: '<a href="mistakes.html#%s">%s</a>' % (m.group(1), m.group(1)) if m.group(1) in known else m.group(1), html_)
    return PATH_RE.sub(lambda m: '<a href="%s"><code>%s</code></a>' % (shipped_path(m.group(1)), m.group(1))
                       if shipped_path(m.group(1)) else m.group(1), html_)


def table(E, cols, rows):
    """Header plus body rows; every cell goes through fill() so {E-id} placeholders take their figure from evidence.jsonl,
    and every cited file becomes a link."""
    return '<div class="wrap"><table><tr>%s</tr>%s</table></div>' % ("".join("<th>%s</th>" % e(c) for c in cols),
        "".join("<tr>%s</tr>" % "".join("<td>%s</td>" % linked(E, c) for c in r) for r in rows))


def claim_problems():
    """The wiki's sourced tables: no unfinished cell, and every file they cite exists (a claim may not point at nothing).
    Every mistake has a guard or a stated reason it has none, and every declared guard exists."""
    out = []
    sys.path.insert(0, os.path.join(ROOT, "scripts"))
    import dashboard
    L = dashboard.mistake_links()
    declared = json.load(open(os.path.join(ROOT, "evidence", "mistake-guards.json")))
    for k, x in L.items():
        if not x["guarded_by"] and not x["process"]:
            out.append("%s has no guard and no stated reason (add one to evidence/mistake-guards.json)" % k)
    for k, d in declared.items():
        if k != "about" and k not in L:
            out.append("evidence/mistake-guards.json names %s, which is not in KINTSUGI.md" % k)
        for g in (d.get("guarded_by", []) if isinstance(d, dict) else []):
            if not os.path.exists(os.path.join(ROOT, g)):
                out.append("evidence/mistake-guards.json: %s guard %s does not exist" % (k, g))
    for n in ("controls.json", "acceptance.json", "faq.json", "cases.json"):
        text = open(os.path.join(ROOT, "evidence", n), encoding="utf-8").read()
        if "TODO-VERIFY" in text:
            out.append("evidence/%s has an unfinished TODO-VERIFY cell" % n)
        for p in sorted(set(PATH_RE.findall(text))):
            if not shipped_path(p):
                out.append("evidence/%s cites %s, which does not exist" % (n, p))
    return out


def wiki():
    """Find anything: the manifest (docs/catalog.json) by area, links that open in the bench and in the unzipped ZIP,
    and three tables read from evidence/controls.json, acceptance.json and faq.json."""
    E = ev()
    cat = json.load(open(CATALOG, encoding="utf-8"))
    rd = lambda n: json.load(open(os.path.join(ROOT, "evidence", n), encoding="utf-8"))
    controls, accept, faq, cases = rd("controls.json"), rd("acceptance.json"), rd("faq.json"), rd("cases.json")
    def files(sec):
        rows = "".join('<tr><td class="p"><a href="%s"><code>%s</code></a></td><td>%s</td></tr>' % (e(shipped_path(c["path"]) or "../../" + c["path"]), e(c["path"]), e(c["purpose"]))
                       for c in cat if c["section"] == sec)
        return '<div class="wrap"><table><tr><th>File</th><th>What it is</th></tr>%s</table></div>' % rows
    pages = "".join('<tr><td class="p"><a href="%s">%s</a></td><td>%s</td></tr>' % (e(h), e(t), e(d)) for _, t, d, h, _tag in CARDS if not h.startswith("http") and h != "wiki.html")
    pages += "".join('<tr><td class="p"><a href="%s">%s</a></td><td>%s</td></tr>' % (e(h), e(t), e(d)) for t, d, h in EVIDENCE)
    evidence_pages = ('<div class="wrap"><table><tr><th>Page</th><th>What it proves</th></tr>%s</table></div>'
                      % "".join('<tr><td class="p"><a href="%s">%s</a></td><td>%s</td></tr>' % (e(h), e(t), e(d)) for t, d, h in EVIDENCE))
    pages += '<tr><td class="p"><a href="../../../presentation/RET-RFP-Intelligence.pdf">RET-RFP-Intelligence.pdf</a></td><td>The deck as a PDF.</td></tr>'
    bench = ('<p class="intro">The bench needs <code>cd source &amp;&amp; ./rfp start</code> (or <code>./rfp serve</code>) running; the link does nothing until then.</p>'
             '<p><a href="http://127.0.0.1:8765/#bench">Open the test bench</a> (needs the bench running)</p>')
    extra = {
        "evidence": [("evidence-pages", "Evidence pages", "The three pages that prove the build: one answer end to end, every mistake and its guard, and the record.", evidence_pages)],
        "governance": [("controls-map", "Controls map", "Each control, what it guards, what checks it, and where it is shown.",
                        table(E, ["Control", "What it guards", "Checked by", "Shown in"], [[c["control"], c["guards"], c["checked_by"], c["shown_in"]] for c in controls])),
                       ("acceptance", "Each stakeholder's acceptance", "What each stakeholder will not accept, and how the build answers it.",
                        table(E, ["Stakeholder", "Non-negotiable in their words", "Guard in the build", "Acceptance test", "Definition of done", "Evidence"],
                              [[a["stakeholder"], a["nonnegotiable"], a["guard"], a["test"], a["done"], a["evidence"]] for a in accept]))],
        "history": [("cases", "Cases: what the evidence showed", "Where we expected one thing and the evidence showed another, what we did, and the control that exists now.",
                     table(E, ["Case", "We expected", "The evidence showed", "What we did", "The control now", "Record"],
                           [[c["case"], c["expected"], c["evidence"], c["did"], c["control"], c["record"]] for c in cases]))],
        "product": [("faq", "Questions RET will ask", "Likely questions, grouped by who asks, with the answer and where it is shown.",
                     "".join("<h4>%s</h4>%s" % (e(g), table(E, ["Question", "Answer"], [[q["question"], q["answer"]] for q in faq if q["group"] == g]))
                             for g in dict.fromkeys(q["group"] for q in faq)))]}
    sys.path.insert(0, os.path.join(ROOT, "scripts"))
    import dashboard
    plan = json.load(open(os.path.join(ROOT, "plan.json"), encoding="utf-8"))
    epics = "".join('<details class="fold"><summary>%s <span class="m">(%d items)</span></summary>%s</details>' % (
        e(ep["title"]), len(ns), table(E, ["Item", "Owner", "State", "Done when"], [[n["title"], n["owner"], n["status"], n.get("done_when", "")] for n in ns]))
        for ep in plan["epics"] for ns in [[n for n in plan["nodes"] if n.get("epic") == ep["id"]]] if ns)
    beliefs = table(E, ["Belief we tested", "What happened"], [[h, s] for _, h, s in dashboard.hypotheses()])
    run = dashboard.evals().get("claude", {})
    qs = {}
    for g in ("golden.json",):
        qs.update({c["id"]: c["q"] for c in json.load(open(os.path.join(ROOT, "source", "eval", g), encoding="utf-8"))})
    evals = ('<p>Latest run on Claude: {E-eval-wave1|test questions} ({E-eval-wave1-record}); follow-up set: {E-eval-wave2|second-order follow-up questions} ({E-eval-wave2-record}). '
             'Every run, including the ones that missed a case, is in flightlog/eval_runs.jsonl; the cases are in source/eval/golden.json.</p>')
    evals = fill(E, evals) + '<div class="wrap"><table><tr><th>Case</th><th>Question</th><th>Result</th><th>Cited</th></tr>%s</table></div>' % "".join(
        '<tr id="case-%s"><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>' % (e(r["id"]), e(r["id"]), e(qs.get(r["id"], "")), "pass" if r.get("pass") else "missed",
                                                                         e(", ".join(r.get("cited", [])))) for r in run.get("results", []))
    gl = json.load(open(os.path.join(ROOT, "glossary.json"), encoding="utf-8"))
    glossary = table(E, ["Term", "What it means here"], [[k, v] for k, v in gl["definitions"].items()])
    runrows = [("./rfp start", "Everything: checks first, then the test bench and the poller", "You want the full experience, including questions typed on the monday.com board getting answers. The one to use."),
               ("./rfp serve", "Only the test bench page", "You only want to ask questions on the bench page; questions on the monday.com board are not answered."),
               ("./rfp poll", "Only the poller", "The bench is already running and you also want board questions answered."),
               ("./rfp stop", "Stops both, wherever they were started", "You are done, or something is stuck."),
               ("./rfp status", "Nothing; reports what is running and monday.com calls left today", "Checking before a demo.")]
    runit = '<div class="wrap"><table><tr><th>Command</th><th>What it starts</th><th>Use it when</th></tr>%s</table></div>' % "".join(
        '<tr><td class="p"><code>%s</code></td><td>%s</td><td>%s</td></tr>' % (e(c), e(w), e(u)) for c, w, u in runrows)
    plain = lambda s: re.sub(r"^\d+(\.\d+)?\s+", "", s)
    groups = [
        ("pages", "The pages", [("pages-list", "Every page", "Start with these. Each one opens from the unzipped folder.",
                                 '<div class="wrap"><table><tr><th>Page</th><th>What it is</th></tr>%s</table></div>' % pages)]),
        ("ret", "What it does for RET", [("faq", "Questions RET will ask", "Grouped by who asks, with the answer and where it is shown.", extra["product"][0][3]),
                                         ("acceptance", "Each stakeholder's acceptance", "What each stakeholder will not accept, and how the build answers it.", extra["governance"][1][3])]),
        ("built", "How it was built", [("plan", "The plan", "Every planned item by area, with its owner and when it counts as done. Read from plan.json.", epics),
                                      ("beliefs", "Beliefs we tested", "What we believed going in and what the tests showed. Read from HYPOTHESES.md.", beliefs),
                                      ("cases", "Where the evidence surprised us", "What we expected, what the evidence showed, and the control that exists now.", extra["history"][0][3])]),
        ("proof", "How we know it works", [("evals", "Test questions and results", "", evals),
                                          ("controls", "Controls", "Each control, what it guards, what checks it, and where it is shown.", extra["governance"][0][3])]),
        ("glossary", "Glossary", [("terms", "Words used on these pages", "The definitions every page, the deck and search share. Read from glossary.json.", glossary)]),
        ("files", "Every file", [(slug(plain(s)), plain(s), "", files(s)) for _, _, secs in AREAS for s in secs]),
        ("live", "Try it live", [("bench", "The test bench", "", bench)]),
        ("run", "Run it", [("commands", "Commands", "The bench is the page where you ask questions yourself; the poller watches the monday.com Questions board and answers new items there. Run these from the source folder.", runit)]),
    ]
    rail, body = [], []
    for gid, name, items in groups:
        rail.append('<li><a href="#%s">%s</a><ol>%s</ol></li>' % (gid, e(name), "".join('<li><a href="#%s">%s</a></li>' % (i, e(tt)) for i, tt, _, _ in items)))
        body.append('<h2 id="%s">%s</h2>%s' % (gid, e(name), "".join(
            '<h3 id="%s">%s</h3>%s%s' % (i, e(tt), ('<p class="intro">%s</p>' % e(d)) if d else "", b) for i, tt, d, b in items)))
    toc = '<details class="toc"><summary>Contents</summary><nav aria-label="Contents"><ol>%s</ol></nav></details>' % "".join(rail)
    page_body = ('<div class="shell wiki"><nav class="rail" aria-label="Contents"><ol>%s</ol></nav><main>'
                 '<h1>Read</h1><p class="verdict">The pages, what the build does for RET, how it was built, how we know it works, and every shipped file.</p>%s%s</main></div>'
                 % ("".join(rail), toc, "".join(body)))
    return page("Read", page_body, WIKI_STYLE, WIKI_SCRIPT)


def render():
    return {"index.html": index(), "build-log.html": build_log(), "how-we-decided.html": how_we_decided(), "mistakes.html": mistakes(), "boards.html": boards(), "wiki.html": wiki()}


def broken_links(pages):
    """Every relative link must resolve in the ZIP. The pages sit in source/docs/site/: a sibling ships beside them;
    ../../<x> ships from the repo root when <x> sits under one of the packager's SOURCE_PARTS; ../../../presentation/<x>
    is the PDF folder at the top of the ZIP."""
    sys.path.insert(0, os.path.join(ROOT, "scripts"))
    from package import SOURCE_PARTS
    bad = []
    for name, text in pages.items():
        for href in re.findall(r'href="([^"#]+)', text):
            if re.match(r"[a-z]+:", href):
                continue
            if href.startswith("../../../"):
                rel = href[len("../../../"):]
                ok = (rel.startswith("presentation/") or rel in TOP) and top_file(rel)
            elif href.startswith("../../"):
                rel = href[len("../../"):]
                ok = rel in GENERATED or (rel.split("/")[0] in SOURCE_PARTS and os.path.exists(os.path.join(ROOT, rel)))
            else:
                ok = href in pages or os.path.exists(os.path.join(SITE, href))
            if not ok:
                bad.append("%s links to %s, which is not in the ZIP" % (name, href))
    return bad


def nav_problems():
    """Every page in docs/site/ (the proof page included) carries the shared page bar and the shared nav style."""
    bad = []
    for f in sorted(glob.glob(os.path.join(SITE, "*.html"))):
        name, text = os.path.basename(f), open(f, encoding="utf-8").read()
        m = re.search(r'<nav class="gnav".*?</nav>', text, re.S)
        if not m:
            bad.append("%s has no shared page bar" % name)
            continue
        cur = re.search(r'<a href="([^"]*)" aria-current="page"', m.group(0))
        inner = re.sub(r'<span class="tools">.*?</span>', "", m.group(0), flags=re.S)   # the deck adds its own tools
        if inner != gnav(cur.group(1) if cur else "wiki.html"):
            bad.append("%s page bar differs from the shared one" % name)
        if name != "deck.html" and GNAV_STYLE not in text:
            bad.append("%s lacks the shared nav style" % name)
        if GNAV_PROBE not in text and name != "deck.html":
            bad.append("%s lacks the Try it live probe" % name)
        if "fonts.googleapis.com/css2?family=Figtree" not in text:
            bad.append("%s does not load the shared fonts" % name)
        if name not in ("index.html", "wiki.html", "deck.html"):
            t = re.search(r"<title>(.*?)</title>", text)
            if not t or t.group(1) not in CRUMB_TITLE or crumbs(t.group(1)) not in text:
                bad.append("%s lacks the shared breadcrumb (Start / Read / page)" % name)
            elif CRUMB_STYLE not in text:
                bad.append("%s lacks the breadcrumb style" % name)
    return bad


def main(check):
    new = render()
    man = manifest_problems() + claim_problems()
    bad = man + broken_links(new)
    for b in man:
        print("home: MANIFEST " + b, file=sys.stderr)
    for b in bad[len(man):]:
        print("home: BROKEN LINK " + b, file=sys.stderr)
    if bad:
        return 1
    stale = [n for n, t in new.items() if not os.path.exists(OUT[n]) or open(OUT[n]).read() != t]
    shared = {f: with_gnav_style(open(f, encoding="utf-8").read()) for f in GNAV_PAGES if os.path.exists(f)}
    for f, s in shared.items():
        if s is None:
            print("home: %s lacks the gnav:start/gnav:end markers" % os.path.relpath(f, ROOT), file=sys.stderr)
            return 1
        rd = readme_file() if os.path.exists(README) else ""   # in the unzipped ZIP, README.md sits one level up
    if rd is None:
        print("home: README.md lacks the how-to-review markers", file=sys.stderr)
        return 1
    if check:
        nb = nav_problems()
        for b in nb:
            print("home --check: NAV " + b + "; regenerate: python3 scripts/proof.py && python3 scripts/home.py", file=sys.stderr)
        if nb:
            return 1
        drift = [os.path.relpath(f, ROOT) for f, s in shared.items() if s != open(f, encoding="utf-8").read()]
        if drift:
            print("home --check: STALE nav style in %s; regenerate: python3 scripts/home.py" % ", ".join(drift), file=sys.stderr)
            return 1
        if rd and rd != open(README, encoding="utf-8").read():
            print("home --check: STALE README.md how-to-review section; regenerate: python3 scripts/home.py", file=sys.stderr)
            return 1
        for n in stale:
            print("home --check: STALE docs/site/%s; regenerate: python3 scripts/home.py" % n, file=sys.stderr)
        return 1 if stale else 0
    for n, t in new.items():
        open(OUT[n], "w").write(t)
    if rd:
        open(README, "w", encoding="utf-8").write(rd)
    for f, s in shared.items():
        open(f, "w", encoding="utf-8").write(s)
    print("home: docs/site/index.html, build-log.html, how-we-decided.html, mistakes.html, boards.html, wiki.html; links resolve in the ZIP")
    return 0


if __name__ == "__main__":
    sys.exit(main("--check" in sys.argv))
