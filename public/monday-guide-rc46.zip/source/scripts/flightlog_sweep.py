"""Sweep every flight log for outliers, suspiciously clean results (inliers), false passes and headwinds.

python3 scripts/flightlog_sweep.py         # prints findings; writes nothing; exit 0 (it reports, it does not gate)

Mechanical only: each check is a rule over the logs, listed here so anyone can audit it. Judgement about what a
finding means is left to a person. Standard library only.
"""
import json
import os
import statistics as st
from collections import Counter, defaultdict
from datetime import date

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
F = []


def jl(name):
    p = os.path.join(ROOT, "flightlog", name)
    return [json.loads(l) for l in open(p) if l.strip()] if os.path.exists(p) else []


def find(kind, log, what):
    F.append((kind, log, what))


def outliers(xs, k=3.0):
    if len(xs) < 5:
        return []
    med = st.median(xs)
    mad = st.median([abs(x - med) for x in xs]) or 1e-9
    return [x for x in xs if abs(x - med) / mad > k * 1.4826]


def main():
    # model calls: errors, latency and token outliers, calls with no model name
    mc = jl("model_calls.jsonl")
    errs = [c for c in mc if not c.get("ok")]
    if errs:
        find("headwind", "model_calls", "%d of %d calls failed; reasons: %s" % (len(errs), len(mc), dict(Counter(str(c.get("error", "?"))[:50] for c in errs).most_common(3))))
    lat = [c["latency_s"] for c in mc if c.get("ok") and c.get("provider") == "claude" and c.get("latency_s")]
    o = outliers(lat)
    if o:
        find("outlier", "model_calls", "%d Claude calls far slower than the median %.2f s (max %.1f s)" % (len(o), st.median(lat), max(o)))
    tin = [c["usage"]["input_tokens"] for c in mc if c.get("usage")]
    o = outliers(tin)
    if o:
        find("outlier", "model_calls", "%d calls with unusual input size (median %d tokens; extremes %s)" % (len(o), st.median(tin), sorted(o)[-3:]))
    unnamed = sum(1 for c in mc if c.get("provider") == "claude" and not c.get("model"))
    if unnamed:
        find("false-positive risk", "model_calls", "%d Claude calls logged without a model name (cannot be attributed to a model)" % unnamed)

    # monday calls: errors by kind, retries
    mo = jl("monday_calls.jsonl")
    bad = [c for c in mo if not c.get("ok")]
    if bad:
        find("headwind", "monday_calls", "%d of %d calls failed: %s" % (len(bad), len(mo), dict(Counter("%s %s" % (c.get("http"), str(c.get("error", ""))[:40]) for c in bad).most_common(4))))
    per_day = Counter(c["t"][:10] for c in mo)
    for d, n in per_day.items():
        if n > 700:
            find("headwind", "monday_calls", "%s used %d of the 1,000 daily calls" % (d, n))

    # evals: cases that flip between runs of the same set (flaky), perfect-every-time sets (inliers)
    ev = jl("eval_runs.jsonl")
    by = defaultdict(lambda: defaultdict(list))
    for r in ev:
        key = "%s/%s" % (r.get("set") or "golden.json", r.get("model") or r.get("provider"))
        for x in r.get("results", []):
            by[key][x["id"]].append(x["pass"])
    for key, cases in by.items():
        flaky = sorted(c for c, v in cases.items() if len(set(v)) > 1)
        if flaky:
            find("flaky", "eval_runs", "%s: %d cases flipped between runs: %s" % (key, len(flaky), ", ".join(flaky[:8])))
        runs = max(len(v) for v in cases.values())
        if runs >= 5 and all(all(v) for v in cases.values()):
            find("inlier", "eval_runs", "%s: every case passed in all %d runs; check it is not too easy" % (key, runs))

    # scenarios: totals, regressions, a whole invariant failing in lockstep (structural, not random)
    sc = jl("scenario_runs.jsonl")
    for r in sc:
        if r.get("regressions"):
            find("regression", "scenario_runs", "%s (%s): %d case regressions" % (r["t"][:16], r.get("commit"), len(r["regressions"])))
    if sc:
        last = sc[-1]
        if last["passed"] == last["scenarios"]:
            find("inlier", "scenario_runs", "latest run %d of %d pass; %d of %d runs ever were all-pass" % (last["passed"], last["scenarios"], sum(r["passed"] == r["scenarios"] for r in sc), len(sc)))
        for r in sc:
            for inv, n in (r.get("violations_by_invariant") or {}).items():
                if n and n % 256 == 0:
                    find("structural", "scenario_runs", "%s: invariant %s failed in exactly %d cases (a whole factor level, not noise)" % (r["t"][:16], inv, n))

    # e2e: implausibly fast runs (a run that did nothing passes fast), failures by step
    for r in jl("e2e_runs.jsonl"):
        for x in r.get("results", []):
            if x.get("seconds") is not None and x["seconds"] < 0.05 and r.get("monday") == "fake" and x.get("fault") == "none":
                find("inlier", "e2e_runs", "%s %s finished in %.3f s; confirm it exercised every step" % (r["t"][:16], x.get("label"), x["seconds"]))
                break
        if r.get("passed", 0) < r.get("runs", 0):
            find("headwind", "e2e_runs", "%s %s/%s: %d of %d runs passed" % (r["t"][:16], r.get("provider"), r.get("monday"), r["passed"], r["runs"]))

    # war game: any attack that ever got through
    for r in jl("wargame_runs.jsonl"):
        lost = [x["id"] for x in r.get("results", []) if not x.get("pass")]
        if lost:
            find("headwind", "wargame_runs", "%s (%s, %s): attacks not held: %s" % (r["t"][:16], r.get("provider"), r.get("commit"), ", ".join(lost)))

    # predictions: overdue and unresolved
    today = date.today().isoformat()
    overdue = [p["id"] for p in jl("predictions.jsonl") if p.get("outcome") not in (0, 1) and p.get("resolves_by", "9999") < today]
    if overdue:
        find("stale", "predictions", "%d predictions past their resolve-by date and unresolved: %s" % (len(overdue), ", ".join(overdue[:8])))

    # rehearsals: steps that were ever red
    red = Counter(s["step"] for r in jl("rehearsal_runs.jsonl") for s in r["steps"] if s["status"] == "fail")
    if red:
        find("headwind", "rehearsal_runs", "steps that have failed at least once: %s" % dict(red))

    for kind, log, what in F:
        print("%-20s %-15s %s" % (kind.upper(), log, what))
    print("sweep: %d findings across %d logs" % (len(F), len({l for _, l, _ in F})))


if __name__ == "__main__":
    main()
