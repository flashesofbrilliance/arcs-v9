"""Build the submission ZIP and gate it against CONSTRAINTS.md E1-E3.

python3 scripts/package.py            # builds dist/submission.zip, exits 1 on any violation
"""
import json
import os
import re
import subprocess
import sys
import zipfile
from datetime import datetime, timedelta, timezone

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "dist", "submission.zip")
MAX_BYTES = 10_000_000   # the stricter reading of "10 MB": decimal bytes, as a phone or upload page counts it (K67)
DEADLINE = datetime(2026, 10, 15, 21, 0, tzinfo=timezone.utc)  # 5:00 PM EDT
SKIP_DIRS = {".git", "__pycache__", "dist", ".venv", "node_modules"}
SKIP_FILES = {".env", ".DS_Store"}
# The portal's package structure: "source/ with your implementation; presentation/ with your presentation files", and
# step 05: "Prepare source/, exactly one presentation PDF, and README.md inside one ZIP package." So the top level is
# exactly source/ and presentation/; README.md is source/README.md; presentation/ holds the PDF and nothing else.
SOURCE_PARTS = ("rfp", "install.sh", "requirements.txt", ".env.example", "glossary.json", "ONBOARDING.md", "eval_baseline.json", ".gitignore", "source", "flight", "flightlog", "scripts", "hooks", "data", "docs",
                "snapshots", "README.md", "plan.json", "HYPOTHESES.md", "DEMO.md", "DECISIONS.md", "TROUBLESHOOT.md", "CONSTRAINTS.md", "DONE.md", "KINTSUGI.md", "RCA.md", "JOURNEY.md", "UNIT-ECONOMICS.md", "TCO.md", "evidence")


def files_under(path):
    if os.path.isfile(path):
        yield path
        return
    for d, dirs, files in os.walk(path):
        dirs[:] = [x for x in dirs if x not in SKIP_DIRS]
        for f in files:
            if f not in SKIP_FILES:
                yield os.path.join(d, f)


# Split literals so this file does not match its own pattern.
LEAK = __import__("re").compile("|".join(["/" "Users/", r"\b" "AR" "CS" r"\b", "arcs" r"\.care", "arcs" "-v9",
                                          "zach" r"\.harris@", "sk" "-ant-", "eyJhbG" "ciOi"]))




def history_text():
    """Every commit as plain text: hash, date, refs (release tags), full message and the files it changed. It replaces
    the git bundle (D-HISTORY): readable anywhere with no tools, about 0.03 MB compressed against 8.7 MB, and every commit
    hash cited in the mistakes log and decisions can be found in it. The full repository keeps the clonable history."""
    import subprocess
    log = subprocess.run(["git", "-C", ROOT, "log", "main", "--date=iso-strict", "--name-status",
                          "--format=commit %H%nDate:   %ad%nRefs:   %D%n%n%w(0,4,4)%B"], capture_output=True, text=True, check=True).stdout
    head = ("Change history of this build, newest first: %d commits on main. Each entry is the commit hash, its date, any\n"
            "release tag, its full message and the files it added (A), modified (M), deleted (D) or renamed (R).\n"
            "Search for a hash cited elsewhere (for example 9ce0b26) to find its entry.\n\n") % len(re.findall(r"^commit [0-9a-f]{40}$", log, re.M))
    return head + log


def build():
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    counts = {"source": 0, "presentation": 0}
    with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED) as z:
        for part in SOURCE_PARTS:
            p = os.path.join(ROOT, part)
            if not os.path.exists(p):
                continue
            for f in files_under(p):
                rel = os.path.relpath(f, ROOT)
                z.write(f, os.path.join("source", rel))   # every log ships whole: nothing is trimmed
                counts["source"] += 1
        z.writestr("source/HISTORY.txt", history_text())
        # The ZIP has no git checkout: ship when each mistake was logged, for the bench's timeline (dashboard.repair_times).
        sys.path.insert(0, os.path.join(ROOT, "scripts"))
        import dashboard
        z.writestr("source/evidence/repair-times.json", json.dumps(dashboard.repair_times(), indent=1))
        z.writestr("source/evidence/turning-points-resolved.json", json.dumps(dashboard.turning_points(), indent=1))
        for f in files_under(os.path.join(ROOT, "presentation")):
            z.write(f, os.path.relpath(f, ROOT))
            counts["presentation"] += 1
    return counts


def main():
    errors = []
    # Regenerate first, then verify: the ZIP can never ship a stale figure or a PDF of an older deck (K35).
    # The proof of one answer is regenerated and verified before packaging (hashes, quotes, guards, script-free page, PDF).
    if subprocess.call([sys.executable, os.path.join(ROOT, "scripts", "proof.py")]) or \
            subprocess.call([sys.executable, os.path.join(ROOT, "scripts", "proof.py"), "--verify"]):
        errors.append("E10: the proof of one answer does not verify (python3 scripts/proof.py --verify)")
    if subprocess.call([sys.executable, os.path.join(ROOT, "scripts", "build.py")]) or \
            subprocess.call([sys.executable, os.path.join(ROOT, "scripts", "build.py"), "--check"]):
        errors.append("E9: generated files are stale and could not be rebuilt (python3 scripts/build.py)")
    counts = build()
    size = os.path.getsize(OUT)
    if size >= MAX_BYTES:
        errors.append("E1: ZIP is %d bytes, limit is %d (10 MB)" % (size, MAX_BYTES))
    with zipfile.ZipFile(OUT) as z:
        biggest = max(z.infolist(), key=lambda i: i.compress_size)
    print("headroom: %.2f / 10.00 MB (decimal); largest entry %s, %.2f MB" % (size / 1e6, biggest.filename, biggest.compress_size / 1e6))
    if 8_000_000 <= size < MAX_BYTES:
        print("WARN E1: over 8 MB (decimal).", file=sys.stderr)
    for folder, n in counts.items():
        if n == 0:
            errors.append("E2: %s/ is empty" % folder)
    with zipfile.ZipFile(OUT) as z:
        names = z.namelist()
    if "source/README.md" not in names:
        errors.append("E8: README.md missing from source/")
    top = sorted({n.split("/")[0] for n in names})
    if top != ["presentation", "source"]:
        errors.append("E2: the ZIP's top level must be exactly source/ and presentation/, found %s" % ", ".join(top))
    pres = [n for n in names if n.startswith("presentation/") and not n.endswith("/")]
    if len(pres) != 1 or not pres[0].lower().endswith(".pdf"):
        errors.append("E8: presentation/ must hold exactly one file, the PDF; found %s" % ", ".join(pres))
    if len([n for n in names if n.lower().endswith(".pdf")]) != 1:
        errors.append("E8: the ZIP must hold exactly one PDF")
    if not any(n.startswith("presentation/") and n.lower().endswith(".pdf") for n in names):
        errors.append("E8: no presentation PDF in presentation/")
    with zipfile.ZipFile(OUT) as z:
        for n in z.namelist():
            if n.endswith(".pdf"):
                continue
            hit = LEAK.search(z.read(n).decode("utf-8", "replace"))
            if hit:
                errors.append("LEAK %s contains %r (internal or personal reference)" % (n, hit.group(0)))
    # The bench must run from the unzipped layout, not just the repo's (K60): extract and build its two API answers.
    import tempfile
    with tempfile.TemporaryDirectory() as tmp:
        zipfile.ZipFile(OUT).extractall(tmp)
        r = subprocess.run([sys.executable, "-c", "import sys; sys.path.insert(0, '.'); from harness import server; "
                            "server.state(); server.outcomes()"], cwd=os.path.join(tmp, "source", "source"),
                           capture_output=True, text=True, env=dict(os.environ, MODEL_CALL_LOG=os.devnull))
        if r.returncode:
            errors.append("E11: the test bench fails from the unzipped ZIP: %s" % (r.stderr.strip().splitlines() or ["?"])[-1])
    # HISTORY.txt ships every commit message, and the repository keeps every diff: the gate reads all of it (K34).
    hist = subprocess.run(["git", "-C", ROOT, "log", "main", "--tags", "-p", "--format=%H%n%B"],
                          capture_output=True, text=True).stdout
    hits = [m.group(0) for m in LEAK.finditer(hist)]
    if hits:
        errors.append("LEAK commit history: %d internal or personal references in commit history (first: %r)" % (len(hits), hits[0]))
    left = DEADLINE - datetime.now(timezone.utc)
    if left < timedelta(0):
        errors.append("E3: deadline passed")
    elif left < timedelta(hours=24):
        print("E3 warning: %.1f hours to deadline" % (left.total_seconds() / 3600))
    for e in errors:
        print("FAIL " + e, file=sys.stderr)
    print("%s: %.2f MB, source %d files, presentation %d files" % (
        OUT, size / 1e6, counts["source"], counts["presentation"]))
    print("Human items still open: E4-E7 in CONSTRAINTS.md")
    return 1 if errors else 0


if __name__ == "__main__":
    sys.exit(main())
