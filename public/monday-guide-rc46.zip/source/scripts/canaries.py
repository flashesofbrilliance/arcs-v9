"""Canaries: checks on the checks. Each one looks for a way our own evidence could be green while wrong.

python3 scripts/canaries.py            # all canaries; exit 1 if any fails
python3 scripts/canaries.py --bless    # record today's eval code paths as the baseline (after a reviewed change)

1. Gate self-test: plant a known-bad input for each gate and require it to fail (a gate that cannot fail is blind).
2. Paraphrase: reword every test question that must cite a clause and check search still finds that clause
   (our test questions are written by us, often in the RFP's own words; this measures how much that flatters us).
3. Path drift: each test case must take the same code path as its blessed baseline (a case that silently starts
   using the fast path, or stops reaching the model, still passes but no longer tests what it was written for).
4. Premise: every quote on a slide appears word for word in the client's brief or the RFP text, and every section
   cited on a slide exists in the parsed RFP (a remembered quote or a phantom clause is a flawed premise).
5. Cherry-pick: wherever the deck shows a latest eval score it must also show the record across runs.
Standard library only. Checks that need a file this machine may not have (the private brief) report NOT RUN, never pass.
"""
import json
import os
import re
import subprocess
import sys
import tempfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(ROOT, "source")
sys.path[:0] = [SRC, os.path.join(ROOT, "scripts")]
os.environ.setdefault("MODEL_PROVIDER", "mock")
os.environ["MODEL_CALL_LOG"] = os.devnull
DECK = os.path.join(ROOT, "docs", "site", "deck.html")
BRIEF_PDF = os.environ.get("RFP_BRIEF_PDF", os.path.expanduser("~/Downloads/energy-rfp-take-home-v1.md.pdf"))
BASELINE = os.path.join(SRC, "eval", "path_baseline.json")
PARAPHRASE_MIN = 0.80  # pre-registered (prediction CAN-para, 60% confident); a measured rate below it fails

RESULTS = []


def report(name, status, detail):
    RESULTS.append((name, status, detail))
    print("%-34s %-8s %s" % (name, status, detail))


def py(*args, **kw):
    return subprocess.run([sys.executable] + list(args), cwd=ROOT, capture_output=True, text=True, **kw)


# ------------------------------------------------------------------ 1. gate self-test
def gate_selftest():
    from package import LEAK
    report("gate: leak pattern", "PASS" if LEAK.search("a non-" + "AR" "CS friend") and not LEAK.search("a careful friend") else "FAIL",
           "matches a planted internal word, ignores clean text")
    with tempfile.NamedTemporaryFile("w", suffix=".md", delete=False, dir=ROOT) as f:
        f.write("The pilot saves $1,000,000 a year.\n")
    r = py("scripts/provenance_lint.py", f.name)
    os.unlink(f.name)
    report("gate: provenance lint", "PASS" if r.returncode == 1 else "FAIL", "untagged planted figure %s" % ("rejected" if r.returncode == 1 else "ACCEPTED"))
    deck = open(DECK).read()
    planted = re.sub(r'(data-e="E-eval-wave1"[^>]*>)[^<]*', r"\g<1>99 of 18", deck, count=1)
    if planted == deck:  # a plant that changes nothing makes the check vacuous (it fooled this canary once)
        report("gate: staleness (build --check)", "FAIL", "the plant did not apply; the canary itself is blind")
        return
    try:
        open(DECK, "w").write(planted)
        r = py("scripts/build.py", "--check")
    finally:
        open(DECK, "w").write(deck)
    report("gate: staleness (build --check)", "PASS" if r.returncode == 1 else "FAIL", "planted stale score %s" % ("rejected" if r.returncode == 1 else "ACCEPTED"))
    probe = os.path.join(ROOT, "scripts", "_canary_probe.py")
    open(probe, "w").write('import subprocess\nsubprocess.run("ls", shell=' + 'True)\n')
    try:
        subprocess.run(["git", "-C", ROOT, "add", "-N", probe], capture_output=True)
        r = py("scripts/security_gate.py")
    finally:
        subprocess.run(["git", "-C", ROOT, "rm", "-q", "--cached", "-f", probe], capture_output=True)
        os.unlink(probe)
    report("gate: security patterns", "PASS" if r.returncode == 1 else "FAIL", "planted risky subprocess call %s" % ("rejected" if r.returncode == 1 else "ACCEPTED"))
    r = py("-m", "sim.wargame", "--no-log", cwd=None) if False else subprocess.run(
        [sys.executable, "-m", "tests.mutate"], cwd=SRC, capture_output=True, text=True)
    survived = [l for l in r.stdout.splitlines() if "SURVIVED" in l]
    report("gate: repairs guarded (mutation)", "PASS" if not survived and r.stdout.strip() else "FAIL",
           "%d repairs switched off, %d survived" % (len(r.stdout.splitlines()), len(survived)))


# ------------------------------------------------------------------ 2. paraphrase
SWAPS = [(r"\bWhen are\b", "By what date are"), (r"\bWhat is\b", "Tell me"), (r"\bWhat are\b", "List"),
         (r"\bproposals\b", "bids"), (r"\bdue\b", "required"), (r"\brequire\b", "need"), (r"\bbid deposit\b", "deposit"),
         (r"\bcan we\b", "are we allowed to"), (r"\bCan we\b", "Are we allowed to"), (r"\bhow\b", "in what way"),
         (r"\bwinner\b", "selected developer"), (r"\bannounced\b", "named"), (r"\bpenalties\b", "damages")]


def paraphrases(q):
    out = []
    for pat, rep in SWAPS:
        p = re.sub(pat, rep, q, count=1)
        if p != q:
            out.append(p)
    words = q.rstrip("?").split()
    if len(words) > 6:
        out.append("Quick question about the RFP: " + q[0].lower() + q[1:])
    return out[:3]


def paraphrase():
    from rfp import answer, store
    db = store.connect(":memory:")
    store.ingest(db, open(os.path.join(ROOT, "data", "rfp_maple_creek.txt")).read(), "base")
    store.ingest(db, open(os.path.join(ROOT, "data", "rfp_maple_creek_amendment_1.txt")).read(), "a1")
    clauses = store.all_clauses(db)
    tried = found = 0
    misses = []
    for g in ("golden.json", "golden_wave2.json"):
        for c in json.load(open(os.path.join(SRC, "eval", g))):
            if not c.get("must_cite"):
                continue
            for p in paraphrases(c["q"]):
                ids = {x["clause_id"] for x in answer.expand_with_amendments(db, answer.retrieve(clauses, p))}
                fast = answer.fast_path(db, p)
                if fast:
                    ids |= {x["clause_id"] for x in fast.get("citations", [])}
                tried += 1
                if all(m in ids for m in c["must_cite"]):
                    found += 1
                else:
                    misses.append("%s: %r" % (c["id"], p[:70]))
    rate = found / tried if tried else 0
    report("paraphrase: governing clause found", "PASS" if rate >= PARAPHRASE_MIN else "FAIL",
           "%d of %d rewordings (%.0f%%; floor %.0f%%)" % (found, tried, 100 * rate, 100 * PARAPHRASE_MIN))
    for m in misses[:8]:
        print("    missed  " + m)
    return rate


# ------------------------------------------------------------------ 3. path drift
def latest_paths():
    runs = [json.loads(l) for l in open(os.path.join(ROOT, "flightlog", "eval_runs.jsonl")) if l.strip()]
    paths = {}
    for r in runs:
        if r["provider"] != "claude" or r.get("model") != "claude-sonnet-5-5":
            continue
        bad = [x for x in r["results"] if not x["pass"]]
        if bad and all(str(x.get("gate", "")).startswith("provider:") for x in bad):
            continue   # no model replied (e.g. no API key): not a path the system took (D-SETUPRUN)
        for x in r["results"]:
            g = x.get("gate") or ""
            # Refusal routes (bare, with context, related-text floor) are one family: the model varies between them
            # run to run (K33). A refusal turning into an answer, or an answer moving to the fast path, still drifts.
            kind = ("fast path" if g.startswith("fast path") else "scope" if g.startswith("scope") else
                    "refusal" if ("related text" in g or "context verbatim" in g or g == "model") else
                    "answer, checked" if g.startswith("verbatim") else g or "unknown")
            paths["%s:%s" % (r.get("set") or "golden.json", x["id"])] = kind
    return paths


def path_drift(bless):
    now = latest_paths()
    if bless or not os.path.exists(BASELINE):
        json.dump(now, open(BASELINE, "w"), indent=1, sort_keys=True)
        report("path drift", "BLESSED", "%d case paths recorded as the baseline" % len(now))
        return
    base = json.load(open(BASELINE))
    drift = ["%s %s -> %s" % (k, base[k], now.get(k)) for k in base if now.get(k) != base[k]]
    new = [k for k in now if k not in base]
    report("path drift", "FAIL" if drift else "PASS", "%d cases, %d changed path, %d new (run --bless after review)" % (len(base), len(drift), len(new)))
    for d in drift[:8]:
        print("    drift   " + d)


# ------------------------------------------------------------------ 4. premise
def premise():
    deck = open(DECK).read()
    sources = open(os.path.join(ROOT, "data", "rfp_maple_creek.txt")).read() + open(os.path.join(ROOT, "data", "rfp_maple_creek_amendment_1.txt")).read()
    brief = ""
    if os.path.exists(BRIEF_PDF):
        r = subprocess.run(["pdftotext", "-layout", BRIEF_PDF, "-"], capture_output=True, text=True)
        brief = r.stdout
    norm = lambda t: re.sub(r"\s+", " ", t.replace("…", "...").replace("’", "'").replace("“", '"').replace("”", '"')).lower()
    quotes = [re.sub(r"<[^>]+>", "", q) for q in re.findall(r"<q>(.*?)</q>", deck, re.S)]
    if not brief:
        report("premise: quotes verbatim", "NOT RUN", "client brief not on this machine (%d quotes unchecked)" % len(quotes))
    else:
        hay = norm(brief + sources)
        bad = []
        for q in quotes:
            parts = [p for p in re.split(r"\.\.\.|…", norm(q)) if p.strip(" .")]
            if not all(p.strip(" .") in hay for p in parts):
                bad.append(q[:60])
        report("premise: quotes verbatim", "FAIL" if bad else "PASS", "%d quotes, %d not found word for word%s" % (len(quotes), len(bad), (": " + "; ".join(bad)) if bad else ""))
    from rfp import store
    db = store.connect(":memory:")
    store.ingest(db, open(os.path.join(ROOT, "data", "rfp_maple_creek.txt")).read(), "base")
    store.ingest(db, open(os.path.join(ROOT, "data", "rfp_maple_creek_amendment_1.txt")).read(), "a1")
    ids = {c["clause_id"] for c in store.all_clauses(db)}
    cited = set(re.findall(r"§\s?(\d+(?:\.\d+)?)", deck)) | set(re.findall(r"\b(A\d\.\d+)\b", deck))
    phantom = sorted(c for c in cited if c not in ids)
    apps = set(re.findall(r"Appendix ([A-Z])", deck))
    phantom_apps = sorted(a for a in apps if ("Appendix " + a) not in sources)
    report("premise: cited clauses exist", "FAIL" if phantom or phantom_apps else "PASS",
           "%d sections and %d appendices cited; missing: %s" % (len(cited), len(apps), ", ".join(phantom + ["Appendix " + a for a in phantom_apps]) or "none"))


# ------------------------------------------------------------------ 5. cherry-pick
def cherry_pick():
    deck = open(DECK).read()
    bad = []
    for wave in ("E-eval-wave1", "E-eval-wave2"):
        for m in re.finditer(r'data-e="%s"' % wave, deck):
            # The record must sit on the same slide as the score (the deck has had no cards since the slide redesign).
            slide = deck[deck.rfind('<section class="slide', 0, m.start()): deck.find("</section>", m.start())]
            if 'data-e="%s-record"' % wave not in slide:
                bad.append(wave)
    report("cherry-pick: run record shown", "FAIL" if bad else "PASS",
           "latest-run scores shown without their record across runs: %s" % (", ".join(bad) or "none"))


def main(argv):
    bless = "--bless" in argv
    gate_selftest()
    paraphrase()
    path_drift(bless)
    premise()
    cherry_pick()
    failed = [r for r in RESULTS if r[1] == "FAIL"]
    print("canaries: %d checks, %d failed, %d not run" % (len(RESULTS), len(failed), sum(r[1] == "NOT RUN" for r in RESULTS)))
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
