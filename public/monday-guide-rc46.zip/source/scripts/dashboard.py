"""Build status dashboard, generated from the repo's own records (never hand-edited).

python3 scripts/dashboard.py        # writes status/dashboard.html
Reads plan.json, flightlog/*.jsonl, KINTSUGI.md, HYPOTHESES.md. Costs are recomputed from logged
tokens x the cited price in source/rfp/provider.py (K14), not from stored dollar amounts.
"""
import html
import json
import os
import re
import sys
from collections import Counter
from datetime import datetime, timezone

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "source"))
from rfp.provider import PRICES  # noqa: E402


def jsonl(name):
    p = os.path.join(ROOT, "flightlog", name)
    return [json.loads(l) for l in open(p) if l.strip()] if os.path.exists(p) else []


def esc(s):
    return html.escape(str(s))


def plan_section():
    nodes = json.load(open(os.path.join(ROOT, "plan.json")))["nodes"]
    done = {n["id"] for n in nodes if n["status"] == "done"}
    rows = []
    for n in nodes:
        state = "done" if n["id"] in done else ("ready" if all(d in done for d in n["needs"]) else "blocked")
        rows.append('<tr class="%s"><td><span class="pill %s">%s</span></td><td>%s</td><td>%s</td><td>%s</td><td class="muted">%s</td></tr>' % (
            state, state, state, esc(n["id"]), esc(n["title"]),
            '<span class="owner %s">%s</span>' % (n["owner"], esc(n["owner"])),
            esc(", ".join(n["needs"]) or "none")))
    counts = Counter(r.split('"')[1] for r in rows)
    return nodes, counts, "\n".join(rows)


def setup_only(run):
    """A run where no model replied: every failure is a provider setup error (e.g. no API key). It says nothing
    about the system, so no "latest result" may be read from it (D-SETUPRUN; also eval/regress.py, canaries.py)."""
    bad = [x for x in run.get("results", []) if not x.get("pass")]
    return bool(bad) and all(str(x.get("gate", "")).startswith("provider:") for x in bad)


def evals():
    """The latest run of the main set (RET's sample questions plus our traps) per provider; a follow-up set's run
    must not stand in for it (the bench once showed "14 of 14", the third set's score)."""
    latest = {}
    for run in jsonl("eval_runs.jsonl"):
        if not setup_only(run) and run.get("set", "golden.json") == "golden.json":
            latest[run["provider"]] = run
    return latest


def costs():
    calls = [c for c in jsonl("model_calls.jsonl") if c.get("ok") and c["provider"] == "claude"]
    usd = 0.0
    for c in calls:
        pin, pout = PRICES.get(c.get("model"), (0, 0))
        usd += (c["usage"]["input_tokens"] * pin + c["usage"]["output_tokens"] * pout) / 1e6
    return len(calls), usd, (usd / len(calls) if calls else 0)


def kintsugi():
    rows = [l for l in open(os.path.join(ROOT, "KINTSUGI.md")) if re.match(r"\| K\d+ \|", l)]
    whose = Counter()
    for r in rows:
        cell = [c.strip() for c in r.split("|")][4].replace("*", "")
        for w in re.split(r"\s*\+\s*", cell):
            whose[w] += 1
    return len(rows), whose


GRADES = {"A": "from your documents", "B": "measured in this build", "C": "cited from a published source", "D": "our estimate"}


def glossary():
    """Every id the bench may show as a tooltip: {id: {title, link}}. Mistakes (K) from KINTSUGI.md, test cases from the
    source/eval/golden*.json sets, decisions (D-...) from the DECISIONS.md headings. Plain file reads, so it works in the ZIP."""
    out = {}
    for r in open(os.path.join(ROOT, "KINTSUGI.md"), encoding="utf-8"):
        if re.match(r"\| K\d+ \|", r):
            c = [x.strip() for x in r.split("|")]
            out[c[1]] = {"title": "%s (%s)" % (re.sub(r"\*\*(.+?)\*\*.*", r"\1", c[2]), c[4].replace("*", "")), "link": "/source/KINTSUGI.md"}
    edir = os.path.join(ROOT, "source", "eval")
    for name in sorted(os.listdir(edir)):
        if re.fullmatch(r"golden.*\.json", name):
            for c in json.load(open(os.path.join(edir, name), encoding="utf-8")):
                out[c["id"]] = {"title": c["q"], "link": "/source/source/eval/" + name}
    for m in re.finditer(r"^## (D-[A-Z0-9-]+):? (.+)$", open(os.path.join(ROOT, "DECISIONS.md"), encoding="utf-8").read(), re.M):
        out[m.group(1)] = {"title": m.group(2).strip(), "link": "/source/DECISIONS.md"}
    return out


def repair_times():
    """When each mistake was logged: the commit that first added its row to KINTSUGI.md (K61 follow-up: the trace
    stopped recording repairs at K33). Read from git in the repo; the ZIP has no checkout, so package.py writes the
    same list to evidence/repair-times.json. A row not yet committed has t None and says so."""
    shipped = os.path.join(ROOT, "evidence", "repair-times.json")
    if not os.path.isdir(os.path.join(ROOT, ".git")) and os.path.exists(shipped):
        return json.load(open(shipped))
    import subprocess
    rows = [l for l in open(os.path.join(ROOT, "KINTSUGI.md")) if re.match(r"\| K\d+ \|", l)]
    log = subprocess.run(["git", "-C", ROOT, "log", "--reverse", "--format=COMMIT %cI", "-p", "--", "KINTSUGI.md"],
                         capture_output=True, text=True).stdout
    first, when = {}, None
    for line in log.splitlines():
        if line.startswith("COMMIT "):   # UTC with a Z, the same form as every trace timestamp
            when = datetime.fromisoformat(line[7:]).astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        else:
            m = re.match(r"\+\| (K\d+) \|", line)
            if m and m.group(1) not in first:
                first[m.group(1)] = when
    out = []
    for r in rows:
        c = [x.strip() for x in r.split("|")]
        title = re.sub(r"\*\*(.+?)\*\*.*", r"\1", c[2])
        out.append({"id": c[1], "title": title, "whose": c[4].replace("*", ""), "t": first.get(c[1])})
    return out


def first_added(path, pattern):
    """{key: UTC time of the commit that first added a line matching pattern (group 1 is the key)} for one file."""
    import subprocess
    log = subprocess.run(["git", "-C", ROOT, "log", "--reverse", "--format=COMMIT %cI", "-p", "--", path],
                         capture_output=True, text=True).stdout
    first, when = {}, None
    for line in log.splitlines():
        if line.startswith("COMMIT "):
            when = datetime.fromisoformat(line[7:]).astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        else:
            m = re.match(pattern, line)
            if m and m.group(1) not in first:
                first[m.group(1)] = when
    return first


def turning_points():
    """The curated turning points (evidence/turning-points.json), each placed at the commit that recorded its row.
    The ZIP has no git, so package.py ships the resolved list as evidence/turning-points-resolved.json."""
    shipped = os.path.join(ROOT, "evidence", "turning-points-resolved.json")
    if not os.path.isdir(os.path.join(ROOT, ".git")) and os.path.exists(shipped):
        return json.load(open(shipped))
    pts = json.load(open(os.path.join(ROOT, "evidence", "turning-points.json")))["points"]
    k = {r["id"]: r["t"] for r in repair_times()}
    d = first_added("DECISIONS.md", r"\+## (D-[A-Z0-9-]+):")
    out = [dict(p, t=k.get(p["ref"]) or d.get(p["ref"]), file="KINTSUGI.md" if p["ref"].startswith("K") else "DECISIONS.md")
           for p in pts]
    out.sort(key=lambda p: p["t"] or "9999")   # in the order they happened; an uncommitted row goes last
    for i, p in enumerate(out, 1):
        p["n"] = i
    return out


GUARD_FILES = ("source/tests/", "source/sim/", "source/eval/regress.py", "scripts/canaries.py", "scripts/build.py",
               "scripts/package.py", "scripts/overflow_gate.py", "scripts/provenance_lint.py", "scripts/security_gate.py",
               "scripts/proof.py", "hooks/pre-commit")


def mistake_links():
    """The relational web for every mistake (K row), like linked issues: what guards it, where it was fixed, and what
    cites it. Found by scanning for the id; evidence/mistake-guards.json adds guards the scan cannot see and names the
    process-only lessons. Read-only; the build fails if a row has no guard and no stated reason (scripts/home.py)."""
    import glob
    rows = {}
    for l in open(os.path.join(ROOT, "KINTSUGI.md"), encoding="utf-8"):
        m = re.match(r"\| (K\d+) \|", l)
        if m:
            rows[m.group(1)] = l
    pat = lambda k: re.compile(r"(?<![0-9A-Za-z])%s(?![0-9])" % k)
    files = sorted(set(glob.glob(os.path.join(ROOT, "source", "**", "*.py"), recursive=True) + glob.glob(os.path.join(ROOT, "scripts", "*.py"))
                       + glob.glob(os.path.join(ROOT, "flight", "*.py")) + [os.path.join(ROOT, "hooks", "pre-commit")]))
    text = {os.path.relpath(f, ROOT): open(f, encoding="utf-8").read() for f in files if os.path.exists(f)}
    gold = {}
    for f in sorted(glob.glob(os.path.join(ROOT, "source", "eval", "golden*.json"))):
        for c in json.load(open(f)):
            for g in c.get("guards", []):
                gold.setdefault(g, []).append("%s %s" % (os.path.relpath(f, ROOT), c["id"]))
    decs = re.split(r"\n(?=## D-)", open(os.path.join(ROOT, "DECISIONS.md"), encoding="utf-8").read())
    declared = json.load(open(os.path.join(ROOT, "evidence", "mistake-guards.json")))
    out = {}
    for k, row in rows.items():
        hit = [f for f, t in text.items() if pat(k).search(t)]
        guards = [f for f in hit if f.startswith(GUARD_FILES)] + gold.get(k, [])
        d = declared.get(k, {})
        guards += [g for g in d.get("guarded_by", []) if g not in guards]
        out[k] = {"guarded_by": guards, "process": d.get("process"),
                  "fixed_in": [f for f in hit if not f.startswith(GUARD_FILES)],
                  "decisions": [re.match(r"## (D-[A-Z0-9-]+)", x).group(1) for x in decs if x.startswith("## D-") and pat(k).search(x)],
                  "related": sorted({m for m in re.findall(r"(?<![0-9A-Za-z])K\d+(?![0-9])", row) if m != k and m in rows}, key=lambda x: int(x[1:]))}
    return out


def hypotheses():
    out = []
    for l in open(os.path.join(ROOT, "HYPOTHESES.md")):
        m = re.match(r"\| (H\d) \| (.+?) \|.*\| ([^|]+) \|\s*$", l)
        if m:
            out.append((m.group(1), m.group(2), m.group(3).strip()))
    return out


def main():
    nodes, counts, plan_rows = plan_section()
    ev = evals()
    sims = jsonl("sim_runs.jsonl")
    ncalls, usd, per_q = costs()
    nk, whose = kintsugi()
    hyps = hypotheses()
    deadline = datetime(2026, 10, 15, 21, 0, tzinfo=timezone.utc)
    left = deadline - datetime.now(timezone.utc)
    hours_left = max(left.total_seconds() / 3600, 0)

    ev_cards = "".join(
        '<div class="stat"><div class="k">%s eval</div><div class="v">%d/%d</div><div class="muted">%s</div></div>' % (
            esc(p), r["passed"], r["total"], esc(r["t"][:16].replace("T", " ")))
        for p, r in sorted(ev.items()))
    last_sim = sims[-1] if sims else None
    sim_card = ('<div class="stat"><div class="k">M1 fuzz</div><div class="v">%d fail</div><div class="muted">%s runs, seed %s</div></div>' % (
        sum(last_sim["failures_by_invariant"].values()), "{:,}".format(last_sim["runs"]), last_sim["seed"])) if last_sim else ""
    hyp_rows = "".join('<tr><td>%s</td><td>%s</td><td><span class="pill %s">%s</span></td></tr>' % (
        h, esc(t), "done" if s.startswith("Survived") else "blocked" if s.startswith("Falsified") else "ready", esc(s))
        for h, t, s in hyps)
    whose_rows = "".join('<li><b>%d</b> %s</li>' % (n, esc(w)) for w, n in whose.most_common())
    zach = [n for n in nodes if n["owner"] == "zach" and n["status"] != "done"
            and all(d in {m["id"] for m in nodes if m["status"] == "done"} for d in n["needs"])]
    zach_rows = "".join("<li>%s</li>" % esc(n["title"]) for n in zach) or "<li>Nothing right now</li>"

    page = TEMPLATE.format(
        generated=datetime.now().strftime("%Y-%m-%d %H:%M"), hours_left="%.0f" % hours_left,
        done=counts.get("done", 0), ready=counts.get("ready", 0), blocked=counts.get("blocked", 0),
        total=len(nodes), pct=int(100 * counts.get("done", 0) / len(nodes)),
        ev_cards=ev_cards, sim_card=sim_card, ncalls=ncalls, usd="%.2f" % usd, per_q="%.4f" % per_q,
        plan_rows=plan_rows, hyp_rows=hyp_rows, nk=nk, whose_rows=whose_rows, zach_rows=zach_rows)
    os.makedirs(os.path.join(ROOT, "status"), exist_ok=True)
    out = os.path.join(ROOT, "status", "dashboard.html")
    open(out, "w").write(page)
    print(out)


TEMPLATE = """<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>Build Status</title>
<style>
:root{{--bg:#f7f7f5;--card:#fff;--ink:#1b1d21;--muted:#646b76;--line:#e3e4e8;--done:#1f7a4d;--ready:#2457c5;--blocked:#a3541a;--zach:#7a3fb0}}
@media (prefers-color-scheme:dark){{:root{{--bg:#0f1115;--card:#171a20;--ink:#e6e8ec;--muted:#9aa2ae;--line:#272b33;--done:#4cc38a;--ready:#7aa2ff;--blocked:#e39b5b;--zach:#c39bff}}}}
*{{box-sizing:border-box}}body{{margin:0;background:var(--bg);color:var(--ink);font:15px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}}
main{{max-width:1080px;margin:0 auto;padding:24px 16px 48px}}h1{{font-size:22px;margin:0 0 4px}}h2{{font-size:15px;margin:28px 0 10px;text-transform:uppercase;letter-spacing:.06em;color:var(--muted)}}
.muted{{color:var(--muted);font-size:13px}}.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px}}
.stat{{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:12px 14px}}.k{{font-size:12px;color:var(--muted);text-transform:uppercase;letter-spacing:.05em}}.v{{font-size:24px;font-weight:600}}
.bar{{height:10px;background:var(--line);border-radius:6px;overflow:hidden;margin:10px 0 4px}}.bar>div{{height:100%;background:var(--done)}}
.card{{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:4px 0;overflow-x:auto}}
table{{width:100%;border-collapse:collapse;font-size:14px}}td{{padding:8px 12px;border-top:1px solid var(--line);vertical-align:top}}tr:first-child td{{border-top:0}}
.pill{{display:inline-block;font-size:12px;font-weight:600;padding:1px 8px;border-radius:99px;border:1px solid currentColor}}
.pill.done{{color:var(--done)}}.pill.ready{{color:var(--ready)}}.pill.blocked{{color:var(--blocked)}}.owner.zach{{color:var(--zach);font-weight:600}}
.two{{display:grid;grid-template-columns:1fr 1fr;gap:12px}}@media (max-width:720px){{.two{{grid-template-columns:1fr}}}}
.panel{{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:12px 16px}}.panel ul{{margin:6px 0;padding-left:18px}}
.ask{{border-color:var(--zach)}}
</style></head><body><main>
<h1>Maple Creek POC: build status</h1>
<div class="muted">Generated {generated} from plan.json and the flight logs. Run <code>python3 scripts/dashboard.py</code> to refresh.</div>

<div class="grid" style="margin-top:16px">
<div class="stat"><div class="k">Plan</div><div class="v">{done}/{total} done</div><div class="bar"><div style="width:{pct}%"></div></div><div class="muted">{ready} ready, {blocked} blocked</div></div>
<div class="stat"><div class="k">Deadline</div><div class="v">{hours_left} h</div><div class="muted">Thu Oct 15, 5:00 PM ET</div></div>
{ev_cards}{sim_card}
<div class="stat"><div class="k">API spend</div><div class="v">${usd}</div><div class="muted">{ncalls} calls, ${per_q}/question</div></div>
<div class="stat"><div class="k">Seams repaired</div><div class="v">{nk}</div><div class="muted">see KINTSUGI.md</div></div>
</div>

<h2>Waiting on you</h2>
<div class="panel ask"><ul>{zach_rows}</ul></div>

<h2>Workstreams</h2>
<div class="card"><table>{plan_rows}</table></div>

<div class="two">
<div><h2>Hypotheses</h2><div class="card"><table>{hyp_rows}</table></div></div>
<div><h2>Whose error (seams)</h2><div class="panel"><ul>{whose_rows}</ul><div class="muted">Each repair is logged when found, with the heading change it caused.</div></div></div>
</div>
</main></body></html>"""

if __name__ == "__main__":
    main()
