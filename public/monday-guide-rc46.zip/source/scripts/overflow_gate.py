"""Nothing on a slide may be cut off: every element must sit inside its 1280x720 slide and inside its own box.

python3 scripts/overflow_gate.py [deck.html]    # exit 1 on any overflow; prints each offender

Renders a temporary copy of the deck in headless Chrome with the real web fonts (the PDF uses them too), measures
every element, and writes the result into the page, which is read back with --dump-dom. Standard library plus the
Chrome already used to print the PDF. If Chrome is missing it says so and exits 2 (never a silent pass).
"""
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DECK = os.path.join(ROOT, "docs", "site", "deck.html")
CHROMES = ["/Applications/Google Chrome.app/Contents/MacOS/Google Chrome", shutil.which("google-chrome") or "",
           shutil.which("google-chrome-stable") or "", shutil.which("chromium") or ""]
PROBE = """<script>
document.fonts.ready.then(function () {
  var out = [];
  document.querySelectorAll(".slide").forEach(function (sl, i) {
    var sr = sl.getBoundingClientRect();
    if (Math.abs(sr.width - 1280) > 1) out.push({slide: i + 1, tag: "SLIDE", text: "rendered at " + Math.round(sr.width) + "px wide, not 1280 (scaled)", right: 0, bottom: 0, clipped: false});
    var rail = sl.querySelector(".rail"), rr = rail ? rail.getBoundingClientRect() : null;
    /* The footer (source legend, page number) is reserved space: nothing else may overlap it (cold read 2 found
       slide 9's table running into the legend after the rail was removed). */
    var foot = [].slice.call(sl.querySelectorAll(".key, .num")).map(function (f) { return [f, f.getBoundingClientRect()]; });
    sl.querySelectorAll("*").forEach(function (n) {
      var r = n.getBoundingClientRect();
      if (!r.width || n.tagName === "SCRIPT") return;
      var outside = r.right > sr.right + 1 || r.bottom > sr.bottom + 1;
      var clipped = n.scrollWidth > n.clientWidth + 1 && getComputedStyle(n).display !== "inline";
      /* Any box (text or card) that overlaps the progress rail, other than the rail itself and its ancestors. */
      if (rr && !rail.contains(n) && !n.contains(rail) && r.bottom > rr.top + 1 && r.top < rr.bottom - 1 && r.right > rr.left && r.left < rr.right) outside = true;
      foot.forEach(function (fr) { var f = fr[0], b = fr[1];
        if (!f.contains(n) && !n.contains(f) && n.children.length === 0 && r.bottom > b.top + 1 && r.top < b.bottom - 1 && r.right > b.left && r.left < b.right) outside = true; });
      if (outside || clipped) out.push({slide: i + 1, tag: n.tagName, text: (n.textContent || "").trim().slice(0, 60),
        right: Math.round(r.right - sr.right), bottom: Math.round(r.bottom - sr.bottom), clipped: clipped});
    });
  });
  var fonts = []; document.fonts.forEach(function (f) { if (f.status === "loaded" && fonts.indexOf(f.family) < 0) fonts.push(f.family); });
  var pre = document.createElement("pre"); pre.id = "overflow-report";
  pre.textContent = JSON.stringify({slides: document.querySelectorAll(".slide").length, fonts: fonts, problems: out});
  document.body.appendChild(pre);
});
</script></body>"""


FONTS = {"Figtree", "Poppins"}
FONT_LINK = re.compile(r'<link[^>]+fonts\.(googleapis|gstatic)\.com[^>]*>')


def pdf_fonts(pdf):
    """Font names embedded in the shipped PDF (subset fonts appear as /ABCDEF+Figtree-Regular)."""
    data = open(pdf, "rb").read()
    return {f for f in FONTS if re.search(rb"/FontName\s*/[A-Z]{6}\+" + f.encode(), data) or f.encode() in data}


def print_is_unscaled(html):
    """The PDF is printed from the same page, so on-screen fit-to-window scaling must never reach print: the scale
    rule may only sit inside @media screen, and no script may set an inline transform (that broke the PDF once)."""
    errs = []
    if re.search(r"\.style\.transform\s*=", html):
        errs.append("a script sets an inline transform; it would also apply when printing")
    for m in re.finditer(r"scale\(var\(--k", html):
        if html.rfind("@media screen", 0, m.start()) < html.rfind("}", 0, m.start()) - 400 or html.rfind("@media screen", 0, m.start()) < 0:
            errs.append("the fit-to-window scale rule is not inside @media screen")
    return errs


REFLOW_PROBE = """<script>
window.addEventListener("load", function () { setTimeout(function () {
  var out = [], de = document.documentElement;
  if (de.scrollWidth > de.clientWidth + 1) out.push({slide: 0, text: "page scrolls sideways by " + (de.scrollWidth - de.clientWidth) + "px"});
  [].forEach.call(document.querySelectorAll(".slide"), function (s, i) {
    var sr = s.getBoundingClientRect();
    [].forEach.call(s.querySelectorAll("*"), function (n) {
      if (n.closest(".gt") || n.closest(".detail") || !n.getClientRects().length) return;
      var r = n.getBoundingClientRect();
      if (r.width && r.right > sr.right + 1) out.push({slide: i + 1, text: (n.textContent || n.tagName).trim().slice(0, 50) + " ends " + Math.round(r.right - sr.right) + "px past its card"});
    });
  });
  var pre = document.createElement("pre"); pre.id = "reflow-report"; pre.textContent = JSON.stringify(out); document.body.appendChild(pre);
}, 1500); });
</script></body>"""


def reflow(path, width):
    """Grid view below 900px turns slides into reading cards (screen only). Nothing may poke past its card, and the
    page must not scroll sideways. The 1280 render above cannot see this range (added after the lean rebuild broke it)."""
    chrome = next((c for c in CHROMES if c and os.path.exists(c)), None)
    if not chrome:
        return 2
    html = open(path).read().replace("</body>", REFLOW_PROBE, 1)
    with tempfile.NamedTemporaryFile("w", suffix=".html", delete=False, dir=os.path.dirname(path)) as f:
        f.write(html)
        tmp = f.name
    try:
        r = subprocess.run([chrome, "--headless=new", "--disable-gpu", "--window-size=%d,900" % width, "--virtual-time-budget=8000",
                            "--dump-dom", "file://" + tmp + "?view=grid"], capture_output=True, text=True, timeout=120)
    finally:
        os.unlink(tmp)
    m = re.search(r'<pre id="reflow-report">(.*?)</pre>', r.stdout, re.S)
    if not m:
        print("overflow-gate: no reflow report at %dpx (not a pass)" % width, file=sys.stderr)
        return 2
    probs = json.loads(m.group(1).replace("&quot;", '"').replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">"))
    for p in probs:
        print("overflow-gate [grid %dpx]: slide %d: %s" % (width, p["slide"], p["text"]), file=sys.stderr)
    print("overflow-gate [grid %dpx]: %d problems" % (width, len(probs)))
    return 1 if probs else 0


def main(path):
    """Two renders: with the web fonts (they must load), and with them blocked (the fallback layout must fit too,
    which is what a reader sees while fonts load or offline). Then the PDF must embed both fonts."""
    worst = 0
    html = open(path).read()
    for k, sl in enumerate(re.split(r'<section class="slide"', html)[1:], 1):
        sl = sl.split("</section>")[0]
        if sl.count('class="rail"') > 1 or sl.count('class="num"') != 1:
            print("overflow-gate: slide %d has %d progress rails and %d page numbers (expected at most 1 and exactly 1)" % (k, sl.count('class="rail"'), sl.count('class="num"')), file=sys.stderr)
            worst = 1
    for e in print_is_unscaled(html):
        print("overflow-gate: " + e, file=sys.stderr)
        worst = 1
    for mode in ("web fonts", "fallback fonts"):
        rc = measure(path, mode)
        worst = max(worst, rc)
    for width in (390, 820):
        worst = max(worst, reflow(path, width))
    pdf = os.path.join(ROOT, "presentation", "RET-RFP-Intelligence.pdf")
    if path == DECK and os.path.exists(pdf):
        missing = FONTS - pdf_fonts(pdf)
        print("overflow-gate: PDF embeds %s" % (", ".join(sorted(FONTS - missing)) or "neither web font"))
        if missing:
            print("overflow-gate: the PDF is missing %s; re-render it with network access (python3 scripts/build.py)" % ", ".join(sorted(missing)), file=sys.stderr)
            worst = max(worst, 1)
    return worst


def measure(path, mode):
    chrome = next((c for c in CHROMES if c and os.path.exists(c)), None)
    if not chrome:
        print("overflow-gate: Chrome not found; cannot measure (not a pass)", file=sys.stderr)
        return 2
    html = open(path).read()
    if mode == "fallback fonts":
        html = FONT_LINK.sub("", html)
    html = html.replace("</body>", PROBE, 1)
    with tempfile.NamedTemporaryFile("w", suffix=".html", delete=False, dir=os.path.dirname(path)) as f:
        f.write(html)
        tmp = f.name
    try:
        r = subprocess.run([chrome, "--headless=new", "--disable-gpu", "--window-size=1400,900", "--virtual-time-budget=8000",
                            "--dump-dom", "file://" + tmp + "?view=grid"], capture_output=True, text=True, timeout=120)
    finally:
        os.unlink(tmp)
    m = re.search(r'<pre id="overflow-report">(.*?)</pre>', r.stdout, re.S)
    if not m:
        print("overflow-gate: no report came back from Chrome (not a pass)", file=sys.stderr)
        return 2
    rep = json.loads(m.group(1).replace("&quot;", '"').replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">"))
    for p in rep["problems"]:
        print("overflow-gate: slide %d %s %s by %dpx right / %dpx down: %r" % (
            p["slide"], p["tag"], "clipped inside its box" if p["clipped"] else "outside the slide", p["right"], p["bottom"], p["text"]),
            file=sys.stderr)
    print("overflow-gate [%s]: %d slides, fonts loaded: %s, %d problems" % (mode, rep["slides"], ", ".join(rep["fonts"]) or "none (fallback)", len(rep["problems"])))
    if mode == "web fonts" and not FONTS <= set(rep["fonts"]):
        print("overflow-gate: web fonts did not load (%s missing); the deck would render in a fallback font" % ", ".join(sorted(FONTS - set(rep["fonts"]))), file=sys.stderr)
        return 1
    return 1 if rep["problems"] else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1] if len(sys.argv) > 1 else DECK))
