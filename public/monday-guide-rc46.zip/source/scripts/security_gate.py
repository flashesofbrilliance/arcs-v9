"""Standard-library security gate, run by pre-commit and CI (no tools to install).

python3 scripts/security_gate.py

1. Risky code patterns in tracked Python and shell files (shell=True, eval/exec, pickle, unsafe YAML, disabled TLS
   verification, binding to all interfaces, os.system). Tests are exempt because they plant attacks on purpose.
2. Secret-shaped strings anywhere in the shipped history (every commit diff and message on main and tags), the
   same history whose commit messages ship in HISTORY.txt (K34).
3. Every Python file compiles.
Patterns are assembled from pieces so this file does not match itself.
"""
import compileall
import os
import re
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RISKY = re.compile("|".join([
    r"shell\s*=\s*" "True", r"\bev" r"al\(", r"\bex" r"ec\(", r"\bpick" r"le\b", r"ya" r"ml\.load\(",
    r"verify\s*=\s*" "False", r"0\.0\.0" r"\.0", r"os\.sys" r"tem\("]))
SECRET = re.compile("|".join([r"sk" "-ant-[A-Za-z0-9_-]{10,}", r"eyJhbG" r"ciOi[A-Za-z0-9_-]{20,}",
                              r"gh" r"p_[A-Za-z0-9]{30,}", r"AK" r"IA[0-9A-Z]{16}"]))


def git(*args):
    return subprocess.run(["git", "-C", ROOT] + list(args), capture_output=True, text=True).stdout


def main():
    errors = []
    for f in git("ls-files", "*.py", "*.sh").split():
        if "/tests/" in f or f.endswith("security_gate.py"):
            continue
        for n, line in enumerate(open(os.path.join(ROOT, f), errors="replace"), 1):
            if RISKY.search(line) and "# security-gate: allow" not in line:
                errors.append("risky pattern %s:%d: %s" % (f, n, line.strip()[:100]))
    hist = git("log", "main", "--tags", "-p", "--format=%H%n%B")
    for m in SECRET.finditer(hist):
        errors.append("secret-shaped string in shipped history: %s..." % m.group(0)[:10])
    for d in ("source", "scripts", "flight"):
        if os.path.isdir(os.path.join(ROOT, d)) and not compileall.compile_dir(os.path.join(ROOT, d), quiet=1):
            errors.append("a Python file in %s/ does not compile" % d)
    for e in errors:
        print("security-gate: " + e, file=sys.stderr)
    print("security-gate: %s" % ("FAILED (%d)" % len(errors) if errors else "ok (patterns, history secrets, compile)"))
    return 1 if errors else 0


if __name__ == "__main__":
    sys.exit(main())
