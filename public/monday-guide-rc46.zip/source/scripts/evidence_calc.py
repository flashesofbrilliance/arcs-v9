"""Measured and derived evidence, recomputed from the build's own records. Never typed in.

Each calculator returns {"value", "show", "work": {"formula", "inputs": [{"name", "value", "source"}]}}.
"value" is the full statement kept in evidence/evidence.jsonl, "show" is the exact text the deck renders,
"work" is what a "Show your work" toggle opens. Client-provided (RET) and cited entries stay authored.

python3 scripts/evidence_calc.py      # print every calculation with its inputs
"""
import json
import os
import re
import statistics

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SONNET = "claude-sonnet-5-5"


def jsonl(name):
    path = os.path.join(ROOT, "flightlog", name)
    return [json.loads(l) for l in open(path) if l.strip()] if os.path.exists(path) else []


def authored():
    return {e["id"]: e for e in (json.loads(l) for l in open(os.path.join(ROOT, "evidence", "evidence.jsonl")) if l.strip())}


def price(ev, eid):
    """'$2.00 input / $10.00 output per million tokens' -> (2.0, 10.0)."""
    a, b = re.findall(r"\$([\d.]+)", ev[eid]["value"])[:2]
    return float(a), float(b)


def inp(name, value, source):
    return {"name": name, "value": value, "source": source}


def calc_all():
    ev = authored()
    calls = [c for c in jsonl("model_calls.jsonl") if c.get("ok") and c.get("provider") == "claude"]
    son = [c for c in calls if c.get("model") == SONNET]
    answers = [c for c in son if c.get("purpose") == "answer"]
    pin, pout = price(ev, "E-price-sonnet55")
    out = {}

    tin = statistics.mean(c["usage"]["input_tokens"] for c in answers)
    tout = statistics.mean(c["usage"]["output_tokens"] for c in answers)
    out["E-tokens-per-q"] = {
        "value": "mean %s input + %s output tokens per question (%d %s answer calls)" % (f"{tin:,.0f}", f"{tout:,.0f}", len(answers), SONNET),
        "show": "%s + %s tokens" % (f"{tin:,.0f}", f"{tout:,.0f}"),
        "work": {"formula": "mean of logged input and output tokens over successful answer calls",
                 "inputs": [inp("answer calls", len(answers), "flightlog/model_calls.jsonl")]}}

    spent = sum(c["usage"]["input_tokens"] * pin + c["usage"]["output_tokens"] * pout for c in son) / 1e6
    per_q = spent / len(answers)
    extra = len(son) - len(answers)
    out["E-cost-per-q"] = {
        "value": "$%.4f per question" % per_q, "show": "$%.4f per question" % per_q,
        "work": {"formula": "(all %s tokens x price, including %d follow-up calls) / answer calls" % (SONNET, extra),
                 "inputs": [inp("tokens spent, priced", "$%.4f" % spent, "flightlog/model_calls.jsonl x E-price-sonnet55"),
                            inp("answer calls", len(answers), "flightlog/model_calls.jsonl"),
                            inp("price", ev["E-price-sonnet55"]["value"], "E-price-sonnet55")]}}

    nq = int(re.search(r"(\d+)", ev["E-questions"]["value"]).group(1))
    cycle = nq * per_q
    out["E-cycle-cost"] = {
        "value": "$%.2f of AI per response cycle of ~%d questions" % (cycle, nq), "show": "about $%.2f" % cycle,
        "work": {"formula": "questions per cycle x cost per question",
                 "inputs": [inp("questions per cycle", nq, "E-questions (RET)"), inp("cost per question", "$%.4f" % per_q, "E-cost-per-q")]}}

    # The call log prices every call as it is made; the total is that log's own sum, recomputed on every build.
    logged = sum(c.get("usd") or 0 for c in calls)
    hk = [c for c in calls if c.get("model") == "claude-haiku-5-5"]
    total = logged
    out["E-build-spend"] = {
        "value": "$%.2f total API spend for the build to date" % total, "show": "$%.2f" % total,
        "work": {"formula": "sum of the priced cost the call log records for each successful Claude call",
                 "inputs": [inp("%s calls" % SONNET, len(son), "flightlog/model_calls.jsonl"),
                            inp("claude-haiku-5-5 calls", len(hk), "flightlog/model_calls.jsonl")]}}

    sess = float(re.search(r"\$([\d.]+)", ev["E-build-session-spend"]["value"]).group(1))
    out["E-build-total"] = {
        "value": "$%.2f combined, two different kinds of cost: $%.2f API-equivalent compute for the coding assistant, on a subscription (not a cash charge) (grade B, session cost readout) + $%.2f measured pipeline API spend (grade B, call log)" % (sess + total, sess, total),
        "show": "about $%.0f" % (sess + total),
        "work": {"formula": "API-equivalent coding-assistant compute (subscription, not cash) + measured pipeline API spend; shown separately wherever possible",
                 "inputs": [inp("session cost", "$%.2f" % sess, "E-build-session-spend"), inp("API spend", "$%.2f" % total, "E-build-spend")]}}

    from dashboard import setup_only   # one rule for "no model replied" runs (D-SETUPRUN)
    runs = [r for r in jsonl("eval_runs.jsonl") if r["provider"] == "claude" and r.get("model") == SONNET and not setup_only(r)]
    for eid, s, what in (("E-eval-wave1", "golden.json", "test questions"), ("E-eval-wave2", "golden_wave2.json", "second-order follow-up questions")):
        r = [x for x in runs if (x.get("set") or "golden.json") == s][-1]
        out[eid] = {"value": "%d/%d %s on %s (latest run)" % (r["passed"], r["total"], what, SONNET),
                    "show": "%d of %d" % (r["passed"], r["total"]),
                    "work": {"formula": "latest %s run of %s" % (SONNET, s), "inputs": [inp("run", r["t"], "flightlog/eval_runs.jsonl")]}}

    # Every Claude run of the set, every version of the set, including runs logged before the model name was recorded
    # (those were Sonnet, HANDOFF item 7). Filtering any of them out would be cherry-picking (canary 5).
    allruns = [r for r in jsonl("eval_runs.jsonl") if r["provider"] == "claude" and r.get("model") in (None, "claude", SONNET)]
    for eid, sname in (("E-eval-wave1-record", "golden.json"), ("E-eval-wave2-record", "golden_wave2.json")):
        full = {"golden.json": 18, "golden_wave2.json": 12}[sname]   # smallest size the whole set ever had
        partial = [x for x in allruns if (x.get("set") or "golden.json") == sname and x["total"] < full]
        # A setup failure is not a model result: a run whose every failing case failed before any model replied
        # (e.g. "provider: ANTHROPIC_API_KEY is not set") is excluded and counted below; it stays in the log (K50).
        def setup_only(x):
            bad = [c for c in x["results"] if not c["pass"]]
            return bool(bad) and all(str(c.get("gate", "")).startswith("provider:") for c in bad)
        nosetup = [x for x in allruns if (x.get("set") or "golden.json") == sname and x["total"] >= full and setup_only(x)]
        rs = [x for x in allruns if (x.get("set") or "golden.json") == sname and x["total"] >= full and not setup_only(x)]
        green = sum(1 for x in rs if x["passed"] == x["total"])
        worst = min(rs, key=lambda x: x["passed"] / x["total"])
        out[eid] = {"value": "%d of %d Sonnet runs of this set were fully green, all versions of the set and all runs kept; worst run %d/%d" % (green, len(rs), worst["passed"], worst["total"]),
                    "show": "%d of %d runs fully green (worst %d/%d)%s" % (green, len(rs), worst["passed"], worst["total"],
                                                                            "; %d run with no API key set excluded" % len(nosetup) if len(nosetup) == 1 else ("; %d runs with no API key set excluded" % len(nosetup) if nosetup else "")),
                    "work": {"formula": "runs where every case passed / every run of this set (no run dropped)",
                             "inputs": [inp("runs", len(rs), "flightlog/eval_runs.jsonl"), inp("fully green", green, "flightlog/eval_runs.jsonl"),
                                        inp("worst run", "%d/%d at %s" % (worst["passed"], worst["total"], worst["t"][:16]), "flightlog/eval_runs.jsonl"),
                                        inp("excluded", "%d single-case debugging runs (fewer than %d questions)" % (len(partial), full), "flightlog/eval_runs.jsonl"),
                                        inp("excluded, setup only", "%d runs where no model replied (every failure a provider setup error, e.g. no API key)" % len(nosetup), "flightlog/eval_runs.jsonl")]}}

    # Blind sets: questions written by separate AI sessions that saw only the RFP and brief, never our tests, scored once before any fix (K43, K44).
    blind = []
    bdir = os.path.join(ROOT, "evidence", "blind")
    for f in sorted(os.listdir(bdir)):
        if f.endswith(".json"):
            b = json.load(open(os.path.join(bdir, f)))
            blind.append((f, sum(1 for r in b["results"] if r["pass"]), len(b["results"])))
    if blind:
        out["E-blind"] = {"value": "blind question sets, scored before fixes: " + "; ".join("%s %d of %d" % (f, p_, n) for f, p_, n in blind),
                          "show": " and ".join("%d of %d" % (p_, n) for _, p_, n in blind),
                          "work": {"formula": "passing cases / cases, per blind set, first scoring only",
                                   "inputs": [inp(f, "%d of %d" % (p_, n), "evidence/blind/" + f) for f, p_, n in blind]}}

    sc = jsonl("scenario_runs.jsonl")[-1]
    out["E-scenarios"] = {
        "value": "%s of %s fault combinations behaved safely; %s of them answered and checked" % (f"{sc['passed']:,}", f"{sc['scenarios']:,}", f"{sc['load_bearing_passed']:,}"),
        "show": "%s of %s" % (f"{sc['passed']:,}", f"{sc['scenarios']:,}"),
        "work": {"formula": "latest full-factorial matrix run", "inputs": [inp("run", sc["t"], "flightlog/scenario_runs.jsonl")]}}

    wg = jsonl("wargame_runs.jsonl")[-1]
    out["E-wargame"] = {
        "value": "%d of %d war-game attacks held in the latest run (%s model, %s)" % (wg["passed"], wg["total"], wg["provider"], wg["t"][:10]),
        "show": "%d of %d" % (wg["passed"], wg["total"]),
        "work": {"formula": "passing attacks / attacks, latest war-game run",
                 "inputs": [inp("run", wg["t"], "flightlog/wargame_runs.jsonl")]}}

    out["E-scenarios-checked"] = {
        "value": "%s of the %s combinations produced an answer that the checks then verified; the rest were safe refusals or flags" % (f"{sc['load_bearing_passed']:,}", f"{sc['scenarios']:,}"),
        "show": f"{sc['load_bearing_passed']:,}",
        "work": {"formula": "load-bearing passes in the latest matrix run (an answer was given and checked, K21)",
                 "inputs": [inp("run", sc["t"], "flightlog/scenario_runs.jsonl")]}}

    hours = [int(x) for x in re.findall(r"(\d+)", ev["E-intake-hours"]["value"])[:2]]
    saved = hours[0] - hours[1]
    cycles = int(re.search(r"(\d+)", ev["E-solicitations"]["value"]).group(1)) if re.search(r"\d+", ev["E-solicitations"]["value"]) else 12
    cost = ev["E-manual-cost"]["value"]
    m = float(re.search(r"\$([\d.]+)M", cost).group(1)); pct = int(re.search(r"(\d+)%", cost).group(1))
    out["E-ex-hours-cycle"] = {"value": "Illustrative: at least %d team hours saved per intake cycle (RET: ~%d h today, target <=%d h)" % (saved, hours[0], hours[1]),
                               "show": "at least %d hours" % saved,
                               "work": {"formula": "today's hours per cycle - RET's target", "inputs": [inp("today", "%d h" % hours[0], "E-intake-hours (RET)"), inp("target", "%d h" % hours[1], "E-intake-hours (RET)")]}}
    out["E-ex-hours-year"] = {"value": "Illustrative: about %s team hours a year (%d h x ~%d solicitations)" % (f"{saved * cycles:,}", saved, cycles),
                              "show": "about %s hours" % f"{saved * cycles:,}",
                              "work": {"formula": "hours saved per cycle x solicitations a year", "inputs": [inp("per cycle", "%d h" % saved, "E-ex-hours-cycle"), inp("solicitations", cycles, "E-solicitations (RET)")]}}
    out["E-ex-target-value"] = {"value": "Illustrative: about $%dK a year if RET reaches its %d%% recovery target on ~$%.1fM" % (round(m * pct / 100 * 1000), pct, m),
                                "show": "about $%dK" % round(m * pct / 100 * 1000),
                                "work": {"formula": "RET's annual manual cost x RET's recovery target", "inputs": [inp("annual cost", "$%.1fM" % m, "E-manual-cost (RET)"), inp("target", "%d%%" % pct, "E-manual-cost (RET)")]}}

    e2e = [json.loads(l) for l in open(os.path.join(ROOT, "flightlog", "e2e_runs.jsonl")) if l.strip()] if os.path.exists(os.path.join(ROOT, "flightlog", "e2e_runs.jsonl")) else []
    live = [r for run in e2e if run.get("provider") == "claude" and run.get("monday") == "live" for r in run["results"]
            if r.get("seconds_per_question") and r.get("pass")]
    if live:
        per = statistics.median(r["seconds_per_question"] for r in live)
        out["E-e2e-answer"] = {"value": "Median %.1f s from pick-up to the answer on the board, over %d passing live runs (Claude, real monday.com boards)" % (per, len(live)),
                               "show": "about %d s" % max(1, round(per)),
                               "work": {"formula": "median over passing live e2e runs of (poll step seconds / questions answered)",
                                        "inputs": [inp("runs", len(live), "flightlog/e2e_runs.jsonl")]}}
    liveruns = [run for run in e2e if run.get("provider") == "claude" and run.get("monday") == "live"]
    if liveruns:
        ok = sum(1 for run in liveruns if run["passed"] == run["runs"])
        out["E-e2e-live"] = {"value": "%d of %d live end-to-end runs passed (Claude, real monday.com boards); every failed run stays in the log" % (ok, len(liveruns)),
                             "show": "%d of %d" % (ok, len(liveruns)),
                             "work": {"formula": "live runs where every run passed / live runs logged",
                                      "inputs": [inp("live runs", len(liveruns), "flightlog/e2e_runs.jsonl"), inp("passed", ok, "flightlog/e2e_runs.jsonl")]}}
    rehearsals = jsonl("rehearsal_runs.jsonl")
    if rehearsals:
        last = rehearsals[-1]
        bad = [s_["step"] for s_ in last["steps"] if s_["status"] != "pass"]
        day = last["t"][:10]
        out["E-rehearsal"] = {"value": "Latest full rehearsal %s: %s (%d of %d steps passed%s)" % (day, "green" if last["green"] else "red", len(last["steps"]) - len(bad), len(last["steps"]), "; failed: " + ", ".join(bad) if bad else ""),
                              "show": "%s, %s" % ("green" if last["green"] else "red", day),
                              "work": {"formula": "newest entry in the rehearsal log",
                                       "inputs": [inp("run", last["t"], "flightlog/rehearsal_runs.jsonl"), inp("steps", len(last["steps"]), "flightlog/rehearsal_runs.jsonl"),
                                                  inp("live", "yes" if last.get("live") else "no", "flightlog/rehearsal_runs.jsonl")]}}
    seats = ev["E-arr-seats"]["value"]
    nseat = int(re.search(r"([\d,]+) seats", seats).group(1).replace(",", ""))
    arr = float(re.search(r"\$([\d.]+)K ARR", seats).group(1)) * 1000
    exp = int(re.search(r"~([\d,]+)-seat", seats).group(1).replace(",", ""))
    out["E-elg"] = {"value": "Engineering-led growth for monday.com: RET's ~%d-seat expansion at its current ~$%d per seat a year is about $%dK of new ARR" % (exp, round(arr / nseat), round(exp * arr / nseat / 1000)),
                    "show": "about $%dK" % round(exp * arr / nseat / 1000),
                    "work": {"formula": "expansion seats x (current ARR / current seats)",
                             "inputs": [inp("seats", nseat, "E-arr-seats (RET)"), inp("ARR", "$%dK" % (arr / 1000), "E-arr-seats (RET)"), inp("expansion", exp, "E-arr-seats (RET)")]}}

    lat = statistics.median(c["latency_s"] for c in calls)
    out["E-latency"] = {"value": "Median AI time ~%.1f s per question" % lat, "show": "~%.1f s" % lat,
                        "work": {"formula": "median latency over successful Claude calls",
                                 "inputs": [inp("calls", len(calls), "flightlog/model_calls.jsonl")]}}

    interval = int(re.search(r'"--interval", type=int, default=(\d+)', open(os.path.join(ROOT, "source", "live_questions.py")).read()).group(1))
    out["E-poll"] = {"value": "End-to-end live answer under ~1 minute: %d s polling interval + ~%.1f s AI time + two monday writes" % (interval, lat),
                     "show": "about a minute" if interval + lat < 90 else "about %d s" % round(interval + lat),
                     "work": {"formula": "worst-case wait = polling interval + median AI time (+ two writes, not timed)",
                              "inputs": [inp("polling interval", "%d s" % interval, "source/live_questions.py --interval default"),
                                         inp("median AI time", "%.1f s" % lat, "E-latency")]}}

    k = re.findall(r"^\| (K\d+) \|", open(os.path.join(ROOT, "KINTSUGI.md")).read(), re.M)
    out["E-repairs"] = {"value": "%d own errors logged, each with its repair" % len(k), "show": "%d errors logged" % len(k),
                        "work": {"formula": "rows in the mistakes log", "inputs": [inp("rows", len(k), "KINTSUGI.md")]}}

    pl = [c["payload"] for c in calls if c.get("payload")]
    user = statistics.mean(len(x["user"]) for x in pl)
    system = statistics.mean(len(x.get("system") or "") for x in pl)
    sent = user + system
    out["E-payload"] = {"value": "~%s characters sent to the AI per call (fixed instructions ~%s + question and clauses ~%s; mean %s)" % (f"{round(sent, -2):,.0f}", f"{round(system, -2):,.0f}", f"{round(user, -2):,.0f}", f"{sent:,.0f}"),
                        "show": "~%s characters" % f"{round(sent, -2):,.0f}",
                        "work": {"formula": "mean (system + user message) length over logged Claude calls, rounded to 100",
                                 "inputs": [inp("instructions", "%s chars" % f"{system:,.0f}", "flightlog/model_calls.jsonl"),
                                            inp("question and clauses", "%s chars" % f"{user:,.0f}", "flightlog/model_calls.jsonl")]}}
    for v in out.values():
        v["class"] = "derived" if "x" in v["work"]["formula"] or "+" in v["work"]["formula"] else "measured"
    out["E-elg"]["class"] = "ret-derived"   # every input is RET's own figure; nothing was measured (claims ledger #60)
    return out


if __name__ == "__main__":
    ev = authored()
    for eid, v in calc_all().items():
        old = ev.get(eid, {}).get("value", "(new)")
        print("%-15s %-36s %s" % (eid, v["show"], "" if old == v["value"] else "was: " + old[:70]))
