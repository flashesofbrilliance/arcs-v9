"""Provenance gate for business claims (K13/K14): no figure without evidence.

In each checked file, every line that states a dollar amount, percentage, or hour count must carry a
tag: [E:<id>] pointing at evidence/evidence.jsonl, or [ASSUMPTION]. In a file that contains any
[ASSUMPTION], a ratio (e.g. "7.5x") must itself be tagged [ASSUMPTION]: guesses cannot be laundered
into a headline. Exit 1 on any violation.
python3 scripts/provenance_lint.py [files...]
"""
import json
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DEFAULT = ["UNIT-ECONOMICS.md", "TCO.md", "docs/site/deck.html", "docs/site/index.html", "docs/site/build-log.html", "docs/site/how-we-decided.html"]
FIGURE = re.compile(r"\$\s?\d|\d\s?%|\b\d[\d,.]*\s?(?:h|hours?|hrs?)\b", re.I)
RATIO = re.compile(r"\b\d+(?:\.\d+)?x\b")
TAG = re.compile(r"\[E:([A-Za-z0-9-]+)\]")


def check_html(path, ids):
    """Slides: every figure in visible text must sit inside an element with data-e="<known id>" or
    data-assumption. Style and script blocks are ignored."""
    from html.parser import HTMLParser
    errors = []

    class P(HTMLParser):
        def __init__(self):
            super().__init__()
            self.stack, self.skip = [], 0

        def handle_starttag(self, tag, attrs):
            if tag in ("style", "script"):
                self.skip += 1
            if tag in ("br", "img", "meta", "path", "line", "rect"):
                return
            self.stack.append(dict(attrs))

        def handle_endtag(self, tag):
            if tag in ("style", "script"):
                self.skip -= 1
            if tag in ("br", "img", "meta", "path", "line", "rect"):
                return
            if self.stack:
                self.stack.pop()

        def handle_data(self, data):
            if self.skip or not FIGURE.search(data):
                return
            tagged = [a.get("data-e") for a in self.stack if a.get("data-e")]
            if any("data-assumption" in a for a in self.stack):
                return
            if not tagged:
                errors.append("%s:%d untagged figure: %s" % (path, self.getpos()[0], data.strip()[:80]))
            for i in tagged:
                if i not in ids:
                    errors.append("%s:%d unknown evidence id %s" % (path, self.getpos()[0], i))
    P().feed(open(os.path.join(ROOT, path)).read())
    return errors


def main(files):
    ids = {json.loads(l)["id"] for l in open(os.path.join(ROOT, "evidence", "evidence.jsonl")) if l.strip()}
    errors = []
    for f in files:
        if f.endswith(".html"):
            errors += check_html(f, ids)
            continue
        lines = open(os.path.join(ROOT, f)).read().splitlines()
        has_assumption = any("[ASSUMPTION]" in l for l in lines)
        for n, line in enumerate(lines, 1):
            if line.lstrip().startswith("#") and not FIGURE.search(line):
                continue
            tags = TAG.findall(line)
            errors += ["%s:%d unknown evidence id %s" % (f, n, t) for t in tags if t not in ids]
            if FIGURE.search(line) and not tags and "[ASSUMPTION]" not in line:
                errors.append("%s:%d figure with no evidence tag: %s" % (f, n, line.strip()[:90]))
            if has_assumption and RATIO.search(line) and "[ASSUMPTION]" not in line:
                errors.append("%s:%d ratio in a file with assumptions must be tagged [ASSUMPTION]" % (f, n))
    for e in errors:
        print("PROVENANCE " + e)
    print("provenance: %d issues in %d files" % (len(errors), len(files)))
    return 1 if errors else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:] or DEFAULT))
