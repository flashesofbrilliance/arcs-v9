"""One command regenerates every generated artifact from the build's records, so nothing shown can go stale.

python3 scripts/build.py           # evidence -> deck figures -> deck PDF -> status page
python3 scripts/build.py --check   # no writes: exit 1 if anything is stale, with the command that fixes it

Generated: evidence/evidence.jsonl (measured and derived rows only; RET and cited rows stay authored),
the figures inside docs/site/deck.html (prose stays authored), presentation/RET-RFP-Intelligence.pdf,
status/build-status.html. Every tagged figure in the deck must match its evidence row (K35 gate).
"""
import hashlib
import html
import json
import os
import re
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "scripts"))
import evidence_calc  # noqa: E402

EVIDENCE = os.path.join(ROOT, "evidence", "evidence.jsonl")
DECK = os.path.join(ROOT, "docs", "site", "deck.html")
PDF = os.path.join(ROOT, "presentation", "RET-RFP-Intelligence.pdf")
PDF_STAMP = os.path.join(ROOT, "docs", "site", ".pdf-source.sha256")  # hash of the deck the PDF was printed from
CHROME = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
TAG = re.compile(r'(<(\w+)[^>]*\bdata-e="([^"]+)"[^>]*>)([^<]*)(</\2>)')
FIG = re.compile(r"\$?\d[\d,]*(?:\.\d+)?%?")
REGEN = "python3 scripts/build.py"


def evidence_text(calc):
    rows = []
    for line in open(EVIDENCE):
        if not line.strip():
            continue
        e = json.loads(line)
        if e["id"] in calc:
            c = calc[e["id"]]
            e = {"id": e["id"], "class": c["class"], "value": c["value"], "source": c["work"]["inputs"][0]["source"],
                 "show": c["show"], "work": c["work"]}
        rows.append(e)
    have = {e["id"] for e in rows}
    for eid, c in calc.items():
        if eid not in have:
            rows.append({"id": eid, "class": c["class"], "value": c["value"], "source": c["work"]["inputs"][0]["source"],
                         "show": c["show"], "work": c["work"]})
    return "".join(json.dumps(e, ensure_ascii=False) + "\n" for e in rows)


GRADE = {"RET": "A", "ret-derived": "A", "measured": "B", "derived": "B", "cited": "C", "estimate": "D"}


def with_grade(open_tag, grade):
    """Keep the evidence grade on the figure itself (data-g; the cherry-pick canary greps it). Idempotent."""
    open_tag = re.sub(r'\sdata-g="[^"]*"', "", open_tag)
    return open_tag[:-1] + ' data-g="%s">' % grade if grade else open_tag


GRADE_WORDS = {"A": "from your documents", "B": "measured in this build", "C": "cited", "D": "our estimate"}
MARK = re.compile(r'<abbr class="g"[^>]*>[^<]*</abbr><span class="gt"[^>]*>[^<]*</span>|<tspan class="g"[^>]*>.*?</tspan>', re.S)


def grade_tip(row, grade):
    """Tooltip text for a grade letter, read from the figure's own evidence row (never typed in)."""
    cls = row.get("class")
    if cls == "derived":
        ins = (row.get("work") or {}).get("inputs") or []
        parts = ["%s (%s)" % (i.get("name", ""), i.get("source", "")) if i.get("source") else i.get("name", "") for i in ins]
        tip = "calculated from measurements: " + "; ".join(p for p in parts if p) if parts else "calculated from: " + row.get("source", "")
    elif cls == "ret-derived":
        tip = "calculated from your documents: " + (row.get("work") or {}).get("formula", "")
    elif cls == "measured":
        tip = "measured in this build: " + row.get("value", "")
    elif cls == "estimate":
        m = re.search(r"(\d+)% confident", row.get("value", ""))
        tip = "our estimate, %s%% confident" % m.group(1) if m else "our estimate"
    else:
        tip = "%s: %s" % (GRADE_WORDS.get(grade, ""), row.get("source", ""))
    tip = "%s · %s" % (grade, tip)
    return tip if len(tip) <= 200 else tip[:197].rstrip() + "..."


def esc(t):
    return t.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")


def grade_mark(tag, grade, tip, n):
    """The visible letter as a real element: hoverable, focusable, described by its tooltip. SVG text gets a tspan + title."""
    if tag in ("text", "tspan"):
        return '<tspan class="g" data-g="%s"><title>%s</title> %s</tspan>' % (grade, esc(tip), grade)
    return ('<abbr class="g" data-g="%s" tabindex="0" aria-label="grade %s" aria-describedby="gt%d">%s</abbr>'
            '<span class="gt" role="tooltip" id="gt%d">%s</span>' % (grade, grade, n, grade, n, esc(tip)))


def deck_text(calc, ev):
    """Computed figures are rewritten from their row; authored figures must appear in their row's value.
    Every tagged figure carries its A-E source grade from its evidence row."""
    problems = []

    count = [0]

    def sub(m):
        open_tag, tag, eid, text, close = m.groups()
        if eid not in ev:
            problems.append("deck tag %s has no evidence row" % eid)
            return m.group(0)
        grade = GRADE.get(ev[eid].get("class"), "")
        open_tag = with_grade(open_tag, grade)
        mark = ""
        if grade:
            count[0] += 1
            mark = grade_mark(tag, grade, grade_tip(ev[eid], grade), count[0])
        if eid in calc:
            return open_tag + calc[eid]["show"] + mark + close
        allowed = {x.rstrip(",") for x in FIG.findall(ev[eid]["value"].replace("≤", "").replace("≥", ""))}   # compare like with like
        for f in FIG.findall(text):
            if f.rstrip(",") not in allowed:
                problems.append("deck figure %r (tag %s) is not in its evidence row: %s" % (f, eid, ev[eid]["value"][:80]))
        return open_tag + text + mark + close
    return slide_keys(TAG.sub(sub, MARK.sub("", open(DECK).read()))), problems


KEY_WORDS = {"A": "your documents", "B": "measured in this build, or calculated from measurements", "C": "cited from a published source",
             "D": "our estimate"}


def slide_keys(deck):
    """Each slide's footer names the source grades used on that slide, inside the slide's own edge, so the key survives
    present mode and the PDF (slide citation convention: the key sits with the figures it explains). Idempotent."""
    deck = re.sub(r'\n  <div class="key">[^<]*</div>', "", deck)

    def one(m):
        used = sorted(set(re.findall(r'<abbr class="g" data-g="([A-Z])"', m.group(0))))
        if not used:
            return m.group(0)
        unknown = [g for g in used if g not in KEY_WORDS]
        if unknown or '\n  <div class="num">' not in m.group(0):
            raise SystemExit("build: slide grade footer cannot be placed (grades %s; every slide needs a <div class=\"num\">)" % unknown)
        key = "Source grades: " + " · ".join("%s %s" % (g, KEY_WORDS[g]) for g in used)
        return m.group(0).replace('\n  <div class="num">', '\n  <div class="key">%s</div>\n  <div class="num">' % key, 1)
    return re.sub(r'<section class="slide.*?</section>', one, deck, flags=re.S)


COST_CSV = os.path.join(ROOT, "docs", "site", "cost-model.csv")


def cost_csv(ev, calc):
    """A portable cost model for RET's finance team: variable costs from the evidence rows, fixed costs as blank input
    cells, blended with live spreadsheet formulas. Opens in Excel, Numbers or Google Sheets. Grade column = source."""
    num = lambda s: float(re.search(r"[\d,]*\.?\d+", s.replace(",", "")).group(0))
    per_q = num(calc["E-cost-per-q"]["show"])
    seats = ev["E-arr-seats"]["value"]
    seat_price = round(float(re.search(r"\$([\d.]+)K ARR", seats).group(1)) * 1000 / int(re.search(r"([\d,]+) seats", seats).group(1).replace(",", "")))
    rows = [
        ("Item", "Value", "Unit", "Source", "How it is used"),
        ("AI cost per question", "%.4f" % per_q, "USD", "B measured (E-cost-per-q)", "logged tokens x published list price"),
        ("Questions per response cycle", "180", "questions", "A your Q2 2026 review (E-questions)", ""),
        ("Response cycles per year", "12", "cycles", "A your discovery call (E-solicitations, 'roughly a dozen')", ""),
        ("AI cost per year", "=B2*B3*B4", "USD", "derived", "questions x cycles x cost per question"),
        ("monday.com seats added for the pilot", "", "seats", "INPUT", "0 if the pilot uses existing seats"),
        ("monday.com price per seat per year", str(seat_price), "USD", "A derived from your ARR and seats (E-arr-seats)", "replace with your contract price"),
        ("monday.com cost per year", "=B6*B7", "USD", "derived", ""),
        ("Engineer hours to stand up the pilot", "", "hours", "INPUT", "one-time"),
        ("Engineer hours per month to run it", "", "hours", "INPUT", "support after handover"),
        ("Engineer loaded rate", "", "USD per hour", "INPUT", ""),
        ("Engineer cost, first year", "=B9*B11+B10*B11*12", "USD", "derived", "set-up + 12 months of support"),
        ("Review minutes per answer", "", "minutes", "INPUT", "measured in the pilot (Verified by)"),
        ("Staff loaded rate", "", "USD per hour", "INPUT", ""),
        ("Review cost per year", "=B3*B4*B13/60*B14", "USD", "derived", "every answer reviewed by a person"),
        ("Blended cost, first year", "=B5+B8+B12+B15", "USD", "derived", "variable + fixed"),
        ("Blended cost per response cycle", "=B16/B4", "USD", "derived", ""),
        ("Manual RFP operations cost today", "1600000", "USD per year", "A your Q2 2026 review (E-manual-cost)", ""),
        ("Your recovery target", "0.5", "share", "A your Q2 2026 review (E-manual-cost)", ""),
        ("Value at target, per year", "=B18*B19", "USD", "derived", "arithmetic on your figures, not a forecast"),
        ("Net at target, first year", "=B20-B16", "USD", "derived", "fill the INPUT cells first"),
        ("Coding-assistant compute to build (floor, three sessions read by 2026-10-12)", "%.2f" % num(ev["E-build-session-spend"]["value"]), "USD API-equivalent", "B session cost readout (E-build-session-spend)", "on a subscription, not a cash charge; as of %s; not part of the totals above" % ev["E-build-session-spend"]["as_of"].split(" (")[0]),
        ("Pipeline API spend to build (reference)", "%.2f" % num(calc["E-build-spend"]["value"]), "USD", "B measured, call log (E-build-spend)", "cash; optional: key facts need no AI call, answers can run on a local model (E-local-eval), tests run on the free mock"),
    ]
    import csv, io
    buf = io.StringIO()
    csv.writer(buf, lineterminator="\n").writerows(rows)
    return buf.getvalue()


def sha(text):
    """The PDF's source: the deck's HTML and every image it shows, so a swapped screenshot re-renders the PDF too."""
    h = hashlib.sha256(text.encode())
    for name in sorted(set(re.findall(r'src="([\w.-]+\.(?:jpg|jpeg|png|webp))"', text))):
        f = os.path.join(os.path.dirname(DECK), name)
        if os.path.exists(f):
            h.update(open(f, "rb").read())
    return h.hexdigest()


def render_pdf():
    if not os.path.exists(CHROME):
        raise SystemExit("build: Google Chrome not found; the PDF cannot be rendered on this machine")
    subprocess.run([CHROME, "--headless=new", "--disable-gpu", "--no-pdf-header-footer", "--print-to-pdf=" + PDF,
                    "file://" + DECK], check=True, capture_output=True)
    open(PDF_STAMP, "w").write(sha(open(DECK).read()) + "\n")


def main(check):
    calc = evidence_calc.calc_all()
    new_ev = evidence_text(calc)
    ev = {e["id"]: e for e in (json.loads(l) for l in new_ev.splitlines())}
    new_deck, problems = deck_text(calc, ev)
    stale = []
    if new_ev != open(EVIDENCE).read():
        stale.append("evidence/evidence.jsonl differs from the records")
    new_cost = cost_csv(ev, calc)
    if not os.path.exists(COST_CSV) or new_cost != open(COST_CSV).read():
        stale.append("docs/site/cost-model.csv differs from the records")
    if new_deck != open(DECK).read():
        stale.append("docs/site/deck.html shows a figure that differs from its evidence")
    stamp = open(PDF_STAMP).read().strip() if os.path.exists(PDF_STAMP) else ""
    if stamp != sha(new_deck):
        stale.append("presentation/RET-RFP-Intelligence.pdf was printed from a different deck")
    if subprocess.run([sys.executable, os.path.join(ROOT, "scripts", "home.py"), "--check"], capture_output=True).returncode:
        stale.append("docs/site/index.html or build-log.html differs from the records, or links a file the ZIP lacks")
    # Each slide's source-grade line lists exactly the grades that slide uses, in A-D order.
    for n, sl in enumerate(re.findall(r'<section class="slide.*?</section>', new_deck, re.S), 1):
        used = sorted(set(re.findall(r'<abbr class="g" data-g="([A-D])"', sl)))
        key = re.findall(r'<div class="key">Source grades: ([^<]*)<', sl)
        listed = re.findall(r"(?:^|· )([A-D]) ", key[0]) if key else []
        if listed != used:
            stale.append("deck slide %d source-grade line lists %s but the slide uses %s" % (n, "".join(listed), "".join(used)))
    # One source for "what leaves RET" (glossary.json); no surface may claim less leaves than does.
    wl = json.load(open(os.path.join(ROOT, "glossary.json")))["what_leaves"]
    for line in (wl["ai"], wl["monday"]):
        if line not in new_deck:
            stale.append("deck does not state %r from glossary.json what_leaves" % line)
    # Every current document a reader opens, not a fixed list: a doc missed by the list said less leaves than does.
    # Logs, snapshots and the mistakes log are history and may quote the old wording.
    current = [f for f in subprocess.run(["git", "-C", ROOT, "ls-files", "*.md", "docs/site/*.html", "source/harness/ui.html", "scripts/status_page.py"],
                                         capture_output=True, text=True).stdout.split()
               if not f.startswith(("snapshots/", "flightlog/")) and f not in ("KINTSUGI.md", "JOURNEY.md", "HANDOFF.md", "DECISIONS.md")]
    for f in current or ["README.md"]:
        txt = html.unescape(open(os.path.join(ROOT, f)).read()).lower()
        for bad in ("only final answers", "nothing else leaves", "nothing leaves ret", "not the full documents", "nothing else goes to the ai", "only the question and a few clauses", "only your question", "full document stays on the pipeline", "reviewers who never saw"):
            # A phrase in quotation marks is quoted (the mistakes log, the guard's own description), not claimed.
            if re.search(r"(?<![\'\"‘“])" + re.escape(bad), txt):
                stale.append("%s claims %r; what leaves RET is stated once, in glossary.json what_leaves" % (f, bad))
    if check:
        for p in problems:
            print("build --check: " + p, file=sys.stderr)
        for s in stale:
            print("build --check: STALE " + s + "; regenerate: " + REGEN, file=sys.stderr)
        return 1 if problems or stale else 0
    if problems:
        for p in problems:
            print("build: " + p, file=sys.stderr)
        return 1
    open(EVIDENCE, "w").write(new_ev)
    open(DECK, "w").write(new_deck)
    open(COST_CSV, "w").write(new_cost)
    if stamp != sha(new_deck):
        render_pdf()
    subprocess.run([sys.executable, os.path.join(ROOT, "scripts", "status_page.py")], check=True, capture_output=True)
    subprocess.run([sys.executable, os.path.join(ROOT, "scripts", "home.py")], check=True, capture_output=True)
    print("build: evidence %d rows (%d computed), deck figures current, PDF %s, status page regenerated" % (
        len(ev), len(calc), "re-rendered" if stamp != sha(new_deck) else "unchanged"))
    return 0


if __name__ == "__main__":
    sys.exit(main("--check" in sys.argv))
