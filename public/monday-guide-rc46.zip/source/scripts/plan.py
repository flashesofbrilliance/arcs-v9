"""Read plan.json: what can run now, what blocks the deadline, and who is blocking.

python3 scripts/plan.py
A node is runnable when every node it needs is done; nodes owned by "zach" are human steps.
"""
import json
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def main():
    nodes = {n["id"]: n for n in json.load(open(os.path.join(ROOT, "plan.json")))["nodes"]}
    done = {i for i, n in nodes.items() if n["status"] == "done"}
    deferred = {i for i, n in nodes.items() if n["status"] in ("deferred", "cut")}
    done |= deferred  # deferred (postponed) and cut (removed by a decision) work no longer blocks anything
    ready = [n for i, n in nodes.items() if i not in done and all(d in done for d in n["needs"])]

    depth = {}

    def chain(i):
        if i not in depth:
            depth[i] = 1 + max([chain(d) for d in nodes[i]["needs"] if d not in done] or [0])
        return depth[i]

    path, cur = [], max((i for i in nodes if i not in done), key=chain)
    while cur:
        path.append(cur)
        pend = [d for d in nodes[cur]["needs"] if d not in done]
        cur = max(pend, key=chain) if pend else None
    path.reverse()

    # Reach: pending nodes this one unblocks at 1st, 2nd and 3rd order, plus stakeholder gaps it closes
    # (QUESTIONS.json). Ties go to the smaller effort (1 small, 2 medium, 3 large; 2 if unset).
    down = {i: [j for j, m in nodes.items() if i in m["needs"] and j not in done] for i in nodes}
    def reach(i):
        seen, frontier, orders = set(), [i], []
        for _ in range(3):
            frontier = [j for f in frontier for j in down[f] if j not in seen]
            seen |= set(frontier); orders.append(len(set(frontier)))
        return orders, len(nodes[i].get("answers", []))
    def score(n):
        orders, gaps = reach(n["id"])
        return sum(orders) + gaps, -n.get("effort", 2)
    print("READY NOW, ranked by reach (unblocks 1st/2nd/3rd order + stakeholder gaps closed), then smaller effort:")
    for n in sorted(ready, key=score, reverse=True):
        (o1, o2, o3), gaps = reach(n["id"])
        print("  [%s] %-11s reach %d (%d/%d/%d + %d gaps) effort %s  %s · %s" % (
            n["owner"], n["id"], o1 + o2 + o3 + gaps, o1, o2, o3, gaps, n.get("effort", 2), n.get("cluster", "?"), n["title"][:70]))
    clusters = {}
    for n in nodes.values():
        if n["id"] not in done:
            clusters.setdefault(n.get("cluster", "unclustered"), []).append(n["id"])
    print("\nOPEN WORK BY JOB CLUSTER:")
    for c, ids in clusters.items():
        print("  %-16s %s" % (c, ", ".join(ids)))
    print("\nCRITICAL PATH (%d steps): %s" % (len(path), " -> ".join(path)))
    print("BLOCKED ON ZACH: %s" % ", ".join(n["id"] for n in ready if n["owner"] == "zach"))


if __name__ == "__main__":
    main()
