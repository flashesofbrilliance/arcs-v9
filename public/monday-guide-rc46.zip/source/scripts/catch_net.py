"""The catch net: which layer of checking caught each mistake we made, generated from KINTSUGI.md (never typed in).

python3 scripts/catch_net.py      # writes status/catch-net.html and dist/atlas-bundle.json (both local, not shipped)

Each mistake's "Detected by" text is classified into one layer by plain keyword rules (first match wins, listed
below), so anyone can audit the classification. A mistake caught by a person reading carefully is its own layer:
that is a real part of the net, not a failure of it.
"""
import html
import json
import os
import re
import subprocess
from datetime import datetime, timezone

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
def _golden_cases():
    import glob
    return sum(len(json.load(open(f))) for f in glob.glob(os.path.join(ROOT, "source", "eval", "golden*.json")))


def _wargame_cases():
    return len(re.findall(r'^    \("[A-Z]\d+", "[a-z]+", "', open(os.path.join(ROOT, "source", "sim", "wargame.py")).read(), re.M))


LAYERS = [  # (layer, what it is, keywords in "Detected by"), in the order checks run
    ("Golden test questions", "%d questions with exact expected citations and figures" % _golden_cases(), ["golden eval", "wave 2 eval", "both eval", "eval gate", "smoke test"]),
    ("Fault harness and scenario matrix", "Every combination of broken inputs and a misbehaving model", ["harness", "mock fault", "matrix", "test bench", "same run"]),
    ("Ingest fuzz", "30,000 randomised document sequences", ["failing sequence"]),
    ("Seam tests and mutation check", "One test per repaired mistake; each repair switched off to prove a test catches it", ["mutation", "seam tests"]),
    ("Automated gates", "Provenance, leak, staleness and security gates in pre-commit and CI", ["gate", "packager", "provenance"]),
    ("War game", "%d stakeholder attacks on a model that obeys the attacker" % _wargame_cases(), ["wargame"]),
    ("Blind passes", "Questions and readers who never saw our tests", ["blind pass"]),
    ("Real document", "A public 265-page federal RFP package", ["large-document"]),
    ("End-to-end dry run", "The whole demo path, from a cold start, against pre-registered outputs", ["e2e"]),
    ("Logs and traces", "The build's own records, read back", ["flightlog", "timeline", "journey", "per-call", "stored item", "ingest test", "clause list"]),
    ("People reading carefully", "Zach, a reviewer, or me re-reading output before trusting it", ["zach", "review", "reading", "by eye", "self-audit", "asked", "writing", "looked too clean", "research", "building"]),
]


def mistakes():
    rows = []
    for line in open(os.path.join(ROOT, "KINTSUGI.md")):
        if re.match(r"^\| K\d+ \|", line):
            c = [x.strip() for x in line.split("|")]
            rows.append({"id": c[1], "what": re.sub(r"\*\*", "", c[2]), "found_by": c[3], "whose": c[4], "repair": c[5], "lesson": c[6] if len(c) > 6 else ""})
    return rows


def layer_of(found):
    f = found.lower()
    if f.startswith(("peer review", "peer security review", "zach")):  # the reviewer, not the thing reviewed (K34)
        return "People reading carefully"
    for name, _, keys in LAYERS:
        if any(k in f for k in keys):
            return name
    return "People reading carefully"


def short(text, n=120):
    text = re.sub(r"\s+", " ", text)
    return text if len(text) <= n else text[: n - 1].rsplit(" ", 1)[0] + "…"


def main():
    ms = mistakes()
    for m in ms:
        m["layer"] = layer_of(m["found_by"])
    by = {name: [m for m in ms if m["layer"] == name] for name, _, _ in LAYERS}
    preds = [json.loads(l) for l in open(os.path.join(ROOT, "flightlog", "predictions.jsonl")) if l.strip()]
    done = [p for p in preds if p.get("outcome") in (0, 1)]
    brier = sum((p["p"] - p["outcome"]) ** 2 for p in done) / len(done) if done else None
    e2e = [json.loads(l) for l in open(os.path.join(ROOT, "flightlog", "e2e_runs.jsonl"))] if os.path.exists(os.path.join(ROOT, "flightlog", "e2e_runs.jsonl")) else []
    commit = subprocess.run(["git", "-C", ROOT, "rev-parse", "--short", "HEAD"], capture_output=True, text=True).stdout.strip()
    now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")

    rows_html = []
    for name, what, _ in LAYERS:
        chips = "".join('<li><a href="#%s" class="chip">%s</a></li>' % (m["id"], m["id"]) for m in by[name]) or '<li class="none">none yet</li>'
        rows_html.append('<tr><th scope="row"><span class="ln">%s</span><span class="lw">%s</span></th><td class="n">%d</td><td><ul class="chips">%s</ul></td></tr>'
                         % (html.escape(name), html.escape(what), len(by[name]), chips))
    detail = "".join('<tr id="%s"><td><b>%s</b> %s</td><td>%s<span class="tag">%s</span></td><td>%s<p class="m">%s</p></td></tr>'
                     % (m["id"], m["id"], html.escape(short(m["what"], 300)), html.escape(short(m["found_by"], 140)), html.escape(m["layer"]),
                        html.escape(short(m["repair"], 240)), html.escape(short(m["lesson"], 160)))
                     for m in ms)
    last_e2e = e2e[-1] if e2e else None
    page = """<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Catch Net</title><style>
:root{--bg:#ffffff;--ink:#323338;--muted:#5f6070;--line:#d0d4e4;--soft:#f6f7fb;--accent:#0060b9;--measure:760px}
@media (prefers-color-scheme: dark){:root:not([data-theme="light"]){--bg:#181b25;--ink:#eceef6;--muted:#aab0c3;--line:#3a3f52;--soft:#222636;--accent:#7fb2ff}}
:root[data-theme="dark"]{--bg:#181b25;--ink:#eceef6;--muted:#aab0c3;--line:#3a3f52;--soft:#222636;--accent:#7fb2ff}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:16px/1.5 -apple-system,Segoe UI,Roboto,sans-serif}
main{max-width:1080px;margin:0 auto;padding:24px 16px 64px}h1{font-size:28px;line-height:1.2;margin:0 0 8px}h2{font-size:18px;margin:32px 0 10px}
.lede{color:var(--muted);margin:0 0 20px}.strip{display:flex;flex-wrap:wrap;gap:10px;margin:0 0 8px}
.stat{background:var(--soft);border:1px solid var(--line);border-radius:8px;padding:10px 14px}.stat b{display:block;font-size:22px}.stat span{font-size:13px;color:var(--muted)}
table{width:100%%;border-collapse:collapse}th,td{text-align:left;vertical-align:top;padding:10px 8px;border-top:1px solid var(--line)}
th .ln{display:block;font-weight:600}th .lw{display:block;font-size:13px;color:var(--muted);font-weight:400}td.n{font-size:20px;font-weight:600;width:48px}
.chips{list-style:none;margin:0;padding:0;display:flex;flex-wrap:wrap;gap:6px}.chip{display:inline-block;font:600 13px ui-monospace,Menlo,monospace;padding:3px 8px;border-radius:6px;border:1px solid var(--line);color:var(--accent);text-decoration:none;background:var(--soft)}
.chip:focus-visible,a:focus-visible{outline:2px solid var(--accent);outline-offset:2px}.none{color:var(--muted);font-size:13px}
ol.detail{list-style:none;padding:0;margin:0}ol.detail li{border-top:1px solid var(--line);padding:12px 0;max-width:var(--measure)}ol.detail p{margin:4px 0}
table.all td{font-size:14px;width:33%%}table.all td p{margin:4px 0 0}.tag{display:inline-block;margin-top:4px;font-size:12px;color:var(--muted);border:1px solid var(--line);border-radius:99px;padding:1px 8px;margin-left:6px}.m{font-size:14px;color:var(--muted)}
@media (max-width:640px){th .lw{display:none}td.n{width:32px}}
</style></head><body><main>
<h1>Catch net: what caught each of our mistakes</h1>
<p class="lede">Every mistake made while building the Maple Creek RFP pipeline, grouped by the layer of checking that caught it. Generated from the mistakes log at commit %s, %s. Layers are listed in the order they run; a mistake is filed under the first layer whose keywords match its "detected by" note.</p>
<div class="strip"><div class="stat"><b>%d</b><span>mistakes logged, each with its repair</span></div><div class="stat"><b>%d</b><span>caught by automated layers</span></div><div class="stat"><b>%d</b><span>caught by people reading carefully</span></div><div class="stat"><b>%s</b><span>calibration (Brier, %d resolved; 0.25 = coin flip)</span></div><div class="stat"><b>%s</b><span>latest end-to-end dry run</span></div></div>
<h2>The net, layer by layer</h2>
<table><thead><tr><th scope="col">Layer</th><th scope="col">Caught</th><th scope="col">Mistakes (select one for detail)</th></tr></thead><tbody>%s</tbody></table>
<h2>Every mistake (K1 to K%d)</h2><table class="all"><thead><tr><th scope="col">What went wrong</th><th scope="col">What caught it</th><th scope="col">Repair, and the lesson</th></tr></thead><tbody>%s</tbody></table>
</main></body></html>""" % (commit, now, len(ms), sum(len(v) for k, v in by.items() if k != "People reading carefully"), len(by["People reading carefully"]),
                         "%.3f" % brier if brier is not None else "n/a", len(done),
                         ("%d of %d (%s)" % (last_e2e["passed"], last_e2e["runs"], last_e2e["provider"])) if last_e2e else "n/a",
                         "".join(rows_html), len(ms), detail)
    os.makedirs(os.path.join(ROOT, "status"), exist_ok=True)
    open(os.path.join(ROOT, "status", "catch-net.html"), "w").write(page)
    bundle = {"generated": now, "commit": commit, "layers": [{"name": n, "what": w} for n, w, _ in LAYERS], "mistakes": ms,
              "plan": json.load(open(os.path.join(ROOT, "plan.json")))["nodes"], "predictions": preds, "e2e": e2e[-3:]}
    os.makedirs(os.path.join(ROOT, "dist"), exist_ok=True)
    json.dump(bundle, open(os.path.join(ROOT, "dist", "atlas-bundle.json"), "w"), indent=1, ensure_ascii=False)
    for n, _, _ in LAYERS:
        print("%-36s %2d  %s" % (n, len(by[n]), " ".join(m["id"] for m in by[n])))
    print("catch-net: status/catch-net.html, dist/atlas-bundle.json")


if __name__ == "__main__":
    main()
