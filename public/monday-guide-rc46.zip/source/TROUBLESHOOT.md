# Troubleshooting: what kills a good answer, and what to check first

Stack-ranked by how likely each failure is in a live session times how badly it hurts the outcome. Every
row comes from a failure this build actually hit (KINTSUGI K-number) or a measured platform limit. Work
top-down: each check takes under a minute.

## Symptom → first check

| Rank | What the user sees | Most likely cause (seen as) | Check first | Fix |
|---|---|---|---|---|
| 1 | A question on the board never gets an answer | Poller not running, or the item's State is not empty/"New" | Is `live_questions.py` running? Open the item: what does State say? | Start the poller; set State back to "New" |
| 2 | "Not addressed in the RFP" for something the RFP does say | Retrieval missed the clause on wording (K5, K25, W6): staff words differ from RFP words | Test bench → same question → "How this answer was made" → step 3: is the clause listed? | Add the word pair to the glossary in `rfp/answer.py`; add the question to a golden set; re-run evals |
| 3 | "A person should check this" on a deadline or deposit | An amendment worded in a way no rule recognises (K17, K18). This is the system working as designed | Evidence of the amendment clause in the note | A person reads the amendment; if the wording is common, add a rule in `rfp/resolve.py` plus a seam test |
| 4 | The answer quotes the old deadline or deposit | The amendment was not ingested, or arrived as a different document number (K19) | RET · Solicitations board: is Amendment No. N listed? | Ingest it; re-run `sync_boards.py` |
| 5 | "The AI did not respond" | Model API down, rate-limited, or key missing (K15) | `flightlog/model_calls.jsonl` last line: `error` field | Wait and retry; check `ANTHROPIC_API_KEY`; switch to `MODEL_PROVIDER=local` if it is an outage |
| 6 | Board writes stop; poller logs a monday error | Daily call cap (1,000 on free) or complexity budget (1M/min; each write costs 30,000) (K22, K23) | Evidence tab → monday usage: calls today, points by call type | Slow the poll interval; batch fewer writes; resume after the reset |
| 7 | "Refused to guess" on a normal question | The model cited a clause that is not in the documents (K20) or returned unparseable text | Test bench provenance → step 5: the raw model reply | Re-ask; if repeatable, add as a golden case and inspect the prompt |
| 8 | Two items for the same thing on a board | Something wrote without the Key column (K30 class) | Board: do both items have the same Key? | Archive the extra; check which script wrote it |
| 9 | Figures on the Key Facts board look wrong | Source text was extracted badly (K1) | Compare the board text with the PDF page | Re-extract; never hand-edit the board |
| 10 | Page or test bench blank | Harness server not running, or a page script error | Terminal running `python3 -m harness.server`; browser console | Restart the server |

## Before a demo or a live cycle (two minutes)

```bash
./rfp check                                  # repairs hold, mutations caught, nothing regressed, figures current (run from the folder with the rfp launcher)
cd source
python3 live_questions.py --once             # board reachable, nothing stuck
```
