# Bar raiser review: RET RFP Intelligence (read-only, 2026-10-10 ~15:30 ET)

Sources: brief PDF pp1-8; HANDOFF.md; plan.json (38 nodes: 11 done, 15 ready, 6 blocked, 6 deferred by my count incl. done-adjacent); presentation/deck.html; snapshots/reflection-brief-reread.md; `git log` = 77 commits. Brief p1 says "Estimated Preparation Time: 6-8 hours". Labels: [M] measured in repo, [C] client figure from brief, [I] my inference.

## Findings

| id | target | finding | why it matters | p | pre-mortem: "Thu 5 PM, this failed because..." | cheapest test |
|---|---|---|---|---|---|---|
| BR1 | scope | Build is far past a 6-8 h brief (77 commits, 38 own-error log, 3,072-case fault matrix, status page, flight log) [M]. | Brief p7: impressive-but-deaf scores worse than modest-and-listening; volume invites "who is this for?" | 60% | the panel spent Q&A on the harness, not on Doug's amendment. | Ask someone outside the build to skim README for 2 min and name the 3 client asks. If they name tooling instead, cut. |
| BR2 | plan | The 5 dash-* nodes are now the critical path, but no brief line asks for per-stakeholder dashboards [I]. | Critical path is pointing at the least load-bearing work 5 days out. | 75% | dash-ui half-shipped, demo boards drifted, rehearse never ran. | grep the brief for "dashboard": zero hits means it is optional. |
| BR3 | plan | 6 terms-* nodes write commercial/legal terms the brief never asks for (Part 1 items 1-5, pp6-7). | Reads as scope creep into sales/legal; Nina could ask "who authorized you to make promises?". | 70% | a panelist asked why an FDE drafted SLAs. | Map each terms-* node to a brief page; any with no page is cut. |
| BR4 | plan | `rehearse` is blocked on Zach while 15 nodes are "ready" for Claude [M]. | The only node that de-risks the live fresh question (p7) is the one not moving. | 65% | first clean-DB rehearsal happened Thursday morning and found a bug. | Run rehearsal once today from a clean DB, time it. |
| BR5 | deck | Slide 6 title "bugs ... are fixed for good" overclaims; a regression test detects return, it does not prevent it [M deck line 143]. | Nina's register is "no confident guess"; this is one. | 80% | Nina quoted the title back at the candidate. | Retitle to "each fix has a test that fails if the bug returns". |
| BR6 | deck | "18 of 18" and "12 of 12" are pass rates on 18 and 12 author-written cases [M]; terms-nina itself says "never guesses" rests on 6 test questions. | Small-n, self-graded; panel will ask "who wrote the questions?". | 70% | a fresh panel phrasing missed retrieval and the 18/18 looked hollow. | State n and authorship on the slide; run 5 unseen paraphrases written by someone else. |
| BR7 | deck | "3,072 of 3,072" is combinatorial toggle count; HANDOFF says 1,024 load-bearing [M]. | Inflated-looking denominator invites a credibility hit. | 55% | panel asked how many were distinct and the answer was "a third". | Quote 1,024 or explain the grid in one clause. |
| BR8 | deck | "$0.0038 per question" and "$0.68 a cycle" are inferred from token counts x list price, not billed spend [I, check evidence.jsonl]. | Sam asks what leaves; finance asks where it was measured. | 50% | "measured" turned out to be computed. | Check evidence.jsonl tag for that figure: measured vs computed. |
| BR9 | deck | "within about a minute" is a 60 s poll interval, not a measured answer latency on the panel's path [M DEMO.md]. | Demo dead air of up to 60 s with a panel watching. | 55% | silence for 50 s felt like a crash. | Time 5 board-submitted questions end to end; report p50/max. |
| BR10 | deck | Missing explicit risk table (likelihood x mitigation), self-identified in reflection-brief-reread.md [M]. | Brief p7 names "risk analysis" outright; a gap a grader can tick. | 70% | rubric line scored zero while dashboards shipped. | Add a 5-row risk table to slide 8; 30 min. |
| BR11 | deck | Slide 2 "~650 h / ~$1.6M" are client figures [C] correctly labeled; low risk. | Shows "use their numbers" (p6). | 15% | n/a, this is a strength. | none needed. |
| BR12 | build | Free-tier monday Models API 403 [M]; AI path depends on external provider live. | Live demo has a single external failure point. | 30% | provider key/rate limit failed on stage. | Pull network once in rehearsal; confirm graceful "needs review" output. |
| BR13 | scope | 38-entry KINTSUGI and the private status page are internal process artifacts [I]. | Good in the repo, noise if shown; costs minutes of 20. | 40% | demo time went to the process story. | Keep in repo, zero slide time. |

## Inverted questions

**Single fact that would cut scope now:** if a timed clean-DB rehearsal (ingest, amendment question, fresh board question) takes more than 15 minutes or fails once, stop all new nodes until it passes twice.

**Skeptic deletes outright:**
- dash-trust, dash-boards, dash-risks, dash-ui, dash-posterior: no brief ask; monday boards already exist (p7 asks for "whatever boards your design requires").
- terms-nina, terms-sam, terms-facts, terms-speed, terms-doug, pilot-terms: commercial terms are not in Part 1 items 1-5; convert to one "open questions for RET" line on slide 8.
- playback: duplicates slide 3 (stakeholder asks already verbatim).
- punchlists, otel, ports, pjm, doctor-ci: production-hardening or polish; mention as roadmap only.

**Truly load-bearing:** rehearse and live-q (p7 fresh question live); submit (p9 ZIP/PDF); core + eval-a2 (amendment supersedes, p5 Doug); datamodel (p8 "defend your schema"); verbose (p8 "walk through code line by line", shows clauses/scores); a risk table (p7). gauntlet is optional but cheap.

## Probabilities (basis)
- On-time submission with all gates green: 85%. package.py already passes at 1.79 MB [M]; risk is late churn from new nodes breaking the eval gate.
- Live demo survives a fresh panel question: 70%. Golden + wave-2 pass and refusal path exists [M], but keyword search "misses unusual wording" (deck slide 9) and the 60 s poll.
- Panel perceives the build as over-built: 55% if dashboards and terms ship and are shown; 30% if cut and kept out of the deck. Stated figure: 45% blended.
- Deck read as clear in 20 minutes: 70%. STAR framing and client-number tables are clean; slides are text-dense (slide 9-10 lists) [I].

## CUT (ranked)
1. dash-* (5 nodes): largest effort, no brief anchor.
2. terms-* + pilot-terms (6): out of FDE scope; one line of open questions instead.
3. playback: duplicate of slide 3.
4. punchlists: internal review artifact.
5. Any on-stage time for KINTSUGI/flight log/status page: link it, do not present it.

## KEEP (ranked)
1. rehearse (twice, clean DB, timed) - p7.
2. Risk table on slide 8 - p7.
3. Fix slide 6 overclaims (BR5-BR7) - Nina's register, p4.
4. verbose + datamodel - p8 line-by-line and schema defense.
5. eval-a2 - amendment supersession, the origin incident (p3, p5).

## Steelman for the current scope
An FDE's job is landing in the client's operating system, and Elena's third criterion is Doug's team spending time on strategy; per-stakeholder dashboards are literally where that shows up in monday, and the panel "plays the client... including the awkward ones" (p8), so terms answering Nina's liability question and Sam's data question pre-empt the hardest in-character challenges. The test volume is the honest answer to "how do you know it never guesses". If the extra nodes stay out of the 20-minute talk track and live only in the repo, depth costs little and wins Q&A. The weakness of this case: it only holds if rehearsal and the risk table land first.
