# Cold read: RET RFP Intelligence

## 1. What I understood
The candidate built a pipeline that reads RFPs and amendments, works out which text governs, and posts cited key facts and question answers to monday.com boards for Ridgeline. The AI sees only a question plus a few clauses, and code checks every figure against the source. The ask is to fund a phase 1 pilot on one solicitation (Maple Creek) and, if it meets Elena's three criteria, fund the rollout. It is a clear enough ask, but the "three criteria" are only implied on slide 1.

## 2. Per slide
1. Title/problem. Landed: the headline promise is concrete and the 3 stat cards frame it well. Confused: "Elena's three success criteria" is never listed; the A/B/C/D superscripts and S-T-A-R-I nav chips are unexplained noise. Dense: no.
2. Situation. Landed: today / target / estimate / confidence table is honest and unusual. Confused: "(50%)" and "(85%)" confidence figures have no stated meaning. "needs your staff rate" cells look unfinished. Dense: yes, 6 rows by 4 columns.
3. Task. Landed: four stakeholders mapped to design decisions, quoted. Confused: Sam Ito's row is jargon-heavy; "in RET's environment" is vague. Dense: no. Lots of empty space.
4. Action (boards). Landed: the live deadline example (Dec 4 over Nov 13) is the best proof on the deck. Confused: "polling interval", "ISO portal", "Appendix F", "$25,000 deposit difference" arrive with no setup. Dense: yes, three cards plus three bullets of RFP trivia.
5. Action (architecture). Landed: what stays local vs what leaves is easy to see. Confused: arrows are ambiguous; the dashed return arrow is not explained; "figure check" is unexplained. Dense: no.
6. Result. Landed: the admitted mistake (reading "extended" as "no change") is credible. Confused: "16 of 22 runs fully green (worst 15/18)" means the system is not deterministic; the headline hides that. "3,072 combinations" is hard to parse. Dense: moderate, no.
7. Impact (numbers). Landed: "what we will not guess" and the not-measured table are candid. Confused: $800K and 6,000 hours versus ">=200 h saved" on slide 2 versus "500 hours" here; the figures do not obviously reconcile. Dense: yes.
8. Impact (phases). Landed: each phase tied to a person's criterion and an exit test. Confused: the paragraphs below the table are tiny and cover production path, next steps and six open questions. Dense: yes, the densest slide.
9. Honest risks. Landed: does / will not / not yet is a good frame. Confused: the "Act when" column is cryptic. Dense: yes.
10. monday.com product feedback. Landed: concrete API findings. Confused: it is not the client's problem; it addresses monday, not Ridgeline. Dense: no.

## 3. Five claims I doubt most
1. "18 of 18" and "13 of 13": the candidate wrote the questions and follow-ups, including the traps, so they are the author's own tests. Slide 7 admits none are real staff questions. Passing your own exam is weak evidence.
2. The 16/22 runs fully green figure: roughly 27% of runs had at least one failure, and the worst was 15/18. A single "latest run" green is cherry-picked framing.
3. "3,072 of 3,072 behaved safely": a generated combinatorial grid of mutations the author devised; only 1,024 produced answers. Safe refusal is counted as success, which inflates the rate.
4. Savings: ">=200 h saved (50%)" versus "at least 500 hours" versus "$800K a year". Estimates by the candidate, confidence numbers with no method, and the $800K depends on the client's $1.6M figure and a 50% recovery assumption. It is also unclear whether the facts come to 500 h or 200 h.
5. "$0.0038 per question" and "$0.68 a cycle": this is list-price token cost only. It leaves out review time, monday seats, hosting, the coordinator's daily portal check, and the 1-minute "not yet timed end to end" latency. Calling the AI "under a dollar" is true but beside the point.

## 4. Five questions
1. Who wrote the 14 sample facts' ground truth, and did anyone at RET check them before you tested against them?
2. Why do 6 of 22 runs fail, and which test fails most often? Is that model variance or a flaky checker?
3. You flag unreadable amendment wording for a person. How often did that fire in testing, and could a human reviewer keep up across ~12 solicitations?
4. Why a local pipeline plus a daily human portal check rather than a native monday.com automation? What breaks if the one named coordinator is out sick?
5. What is the minimum evidence on Maple Creek that would make you say the pilot failed?

## 5. Grades
- Structuring ambiguity: B. Good STAR frame, stakeholder-to-design mapping, and explicit not-yet list. Docked because Elena's three criteria are never stated and open questions are crammed into slide 8.
- Trade-offs: B-. Local versus cloud AI, code versus AI for figures, flagging versus guessing are all weighed. Missing: why not simply use monday's own AI, and what it costs to maintain.
- Use of the client's data: B+. Uses RET's numbers, amendment, section numbers and quotes well. Docked for self-authored tests and the unreconciled savings math.
- Clarity: C+. The narrative works, but slides 2, 4, 7, 8, 9 are too dense for 2 minutes each and have unexplained jargon.

## 6. Cut one slide
Slide 10 (monday.com product changes). It is advice to the platform vendor, not to the client, and it uses time the panel needs on slides 6 to 8. Move a single line into the appendix.
