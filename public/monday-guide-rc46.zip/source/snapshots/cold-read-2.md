# Cold read 2: RET RFP Intelligence

## 1. What I understood (3 sentences)
The candidate built a pipeline that ingests RFP documents and amendments, resolves which text governs, extracts 14 key facts, and answers staff questions with clause citations, writing everything to monday.com boards. It is pitched against four named people's stated criteria (Doug, Nina, Sam, Elena), with a code-first design where the AI only picks clauses and code checks every figure. The ask: run a phase 1 pilot on "Maple Creek", and if it meets Elena's three criteria, fund a rollout.

## 2. Per slide
1. Landed: opens with the client's own three criteria and a today vs. estimate row. Confused: the A/B/C/D letter badges and "(85%)" confidence are unexplained until the tiny footer. Dense: no.
2. Landed: baseline table with an honest "needs real staff questions" and "needs your staff rate" instead of invented numbers. Confused: five columns of mixed sources; $1.6M and 650 h appear with no derivation. Dense: yes.
3. Landed: mapping each stakeholder quote to a design decision is the strongest slide. Confused: "Resolves amendments in code" is jargon to a non-engineer. Dense: no.
4. Landed: the live example (Dec 4 from Amendment 1, Nov 13 superseded) is concrete and checkable. Confused: three card paragraphs plus three bullets; deposit, Appendix F and Q&A deadline all land at once. Dense: yes.
5. Landed: the "what the AI sees" diagram answers Sam's data question visually. Confused: the arrows between boxes are unclear; "~2,400 characters" means little. Dense: no.
6. Landed: the one admitted mistake (extended read as "no change") is the most credible moment in the deck. Confused: 18/18, 13/13 and 3,072/3,072 sit beside "20 of 26 runs fully green". That undercuts the headline. Dense: yes.
7. Landed: separates known from unknown, and the "not measured yet" list is honest. Confused: the arithmetic ($800K, 6,000 h) sits next to a smaller 200 h estimate; which number do I take away? Dense: yes.
8. Landed: phases each tied to a named person's criterion with an exit test. Confused: the production path paragraph and the open questions are crammed into small text. Dense: yes.
9. Landed: Does / Will not / Not yet is a clean frame. Confused: the risk table runs into the footer and is cut off; it competes with the three boxes above. Dense: yes.
10. Landed: concrete API findings from actually building. Confused: it is off-topic for the client and reads as a pitch to monday.com staff. Dense: no.

## 3. Five claims I doubt
1. "Facts in 1 business day (85%)": the deck admits the real-release timing was never measured, so 85% rests on a sync test.
2. "Under 5 minutes (80%)" for answers: the 3 s answer time was on sample questions the candidate wrote.
3. "0 missed bids from an unnoticed amendment (70%)": the control is a human checking a portal daily, which is the status quo process.
4. "3,072 of 3,072 behaved safely": 2,048 were refusals, so this mostly proves it declines. The count is generated, so it is a big number with little information.
5. "$0.0039 per question": at ~2,400 characters and one call that is plausible, but it ignores review time. Also the ~$800K is the client's own target recovery, not a forecast.

## 4. Five questions
1. 20 of 26 runs were fully green. What failed in the other 6, and why is "latest run 18/18" the headline?
2. Your accuracy test uses questions you wrote. How would you design the first week so a miss on a real question is caught?
3. The base RFP is 400-600 pages but the parser is for known formats and refused a federal PDF. What breaks first at Maple Creek?
4. Why code-based amendment rules over letting the model read amendments? What is the cost of "flag for a person" at 12 solicitations a year?
5. If the sponsor says drop one of the three criteria for the pilot, which, and why?

## 5. Grades
- Structuring ambiguity: A-. Quotes turned into requirements, an explicit not-measured list, and out-of-scope items.
- Trade-offs: B. Local vs. AI call and code vs. model are clear. Cost, review burden and build vs. buy against monday-native AI are barely weighed.
- Use of client's data: B+. Real quotes, real dates and clause numbers. But testing is on self-written questions and no real release was run.
- Clarity: C+. The ideas are clear but slides 2, 4, 6, 7, 8 and 9 are dense, the badge system needs explaining, and slide 9 is clipped.

## 6. Cut one slide
Slide 10. It is for monday.com, not RET. Move one line into the ask, and spend the time on slide 6 or 9 where the panel will probe.
