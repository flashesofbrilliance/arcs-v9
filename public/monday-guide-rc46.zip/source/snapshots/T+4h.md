# Pulse check draft at T+~4h (read 2026-10-10 14:06 ET; HEAD 216b026; T0 = 10:07)

Re-grade of snapshots/T+2h.md using the same rows. Grades are judgement tied to evidence; ties go to the lower grade.
Source quality (SQ) per claim: **A** client's own documents (brief, data/*.txt, discovery transcript, docs/briefing-video.md) · **B** measured in this build (flightlog, eval runs, git timestamps, test output) · **C** third-party primary page actually opened (docs/monday-*.md rows with a URL) · **D** search summary or inference · **E** unverifiable recollection. Anything below B is labelled in the row.

## Measured state (read from the records, not memory)

| | T+2h | Now | Source | SQ |
|---|---|---|---|---|
| Commits | 25 (note counts 31) | 69 | `git rev-list --count HEAD` | B |
| Wave 1 eval, Claude | 18/18 | 18/18 (latest 17:48:57Z) | flightlog/eval_runs.jsonl | B |
| Wave 2, Claude | 12/12 | 12/12 (latest 17:49:19Z) | same | B |
| Eval flakiness | not noted | the same code scored 9 to 12 of 12 across 15:49 to 16:23Z before K33 and 16/18 to 18/18 on wave 1; since 62ccec4 the last runs are green | same | B |
| Haiku 5.5 benchmark | none | 16/18, 12/12, ~$0.00023 per question | E-haiku in evidence/evidence.jsonl | B |
| Local model (Qwen 2.5 7B) wave 1 | 14/18 | **still 14/18, run 14:35Z, before K17-K36. Not re-run.** | eval_runs.jsonl | B |
| Scenario matrix | 3,072/3,072, 1,024 load-bearing | 3,072/3,072, 1,024 load-bearing, last run 17:51Z at db84180 (not re-run after the 216b026 server fix) | scenario_runs.jsonl | B |
| Ingest fuzz | 0 failures, 30,000 | same (one prior row only; 2 rows in sim_runs) | sim_runs.jsonl | B |
| Tests | 12 seam, 6/6 mutations | `unittest tests.test_seams tests.test_server_security`: **23 tests, OK** (run now). Mutation check: lists K18, K19, K25, K33 each caught by 1-2 tests (run now via `python3 -m tests.mutate`; I saw only the last 4 lines, so the full count is not read) | test output | B |
| Seams repaired | 28 | **36** (KINTSUGI.md rows K1-K36) | KINTSUGI.md, E-repairs | B |
| Claude API spend | $1.13 over 304 calls | evidence says **$2.01** (E-build-spend); the raw log has 709 calls (576 Claude, 69 mock, 64 local), 2 failed, and its `usd` fields sum to $2.16. Reconciled after this draft: the gap is K14. Early calls logged `usd` with a mistyped price; the generator reprices every call's tokens at the cited price, so $2.01 is the figure. | model_calls.jsonl, evidence.jsonl | B |
| monday API | 193 calls, steady sync 906 points | 267 calls, 2 not ok; steady re-sync still 906 points | monday_calls.jsonl, E-monday-sync-steady | B |
| Build generator check | n/a | `python3 scripts/build.py --check` exit 0 (nothing stale) | run now | B |
| Open plan nodes | 12 threads | critical path 5 steps: wargame, onecol, present, gauntlet, submit; blocked on Zach: rehearse | `python3 scripts/plan.py` | B |
| ZIP | 0.1 MB | dist/submission.zip 2.86 MB (limit 10 MB), 75 files, contains presentation/RET-RFP-Intelligence.pdf and deck.html | `ls -la dist`, `unzip -l` | B |
| Elapsed | 2h 03m | ~4h 00m | `date` vs 10:07 | B |

## Part 1: Strategic proposal

| # | Previous | New | Evidence for new grade | SQ | Gap / next |
|---|---|---|---|---|---|
| 1.1 Exec summary slide | ⬜ | ✅ | presentation/deck.html slide 1 title: key facts the day it lands, answers in minutes, each with its clause; 10 slides; b41aa7c, 30f0e20 | B (client outcomes are A: brief) | Not yet rehearsed or panel-tested |
| 1.2 Pain points and business case in RET's numbers | 🟡 | 🟡 (stronger) | Evidence ledger holds RET figures tagged class RET (~180 questions, ~$1.6M, ~650 hours, 15 days, 3 missed bids) from the brief; deck slides Situation and Impact; $0.67 per ~180-question cycle derived (E-cycle-cost) | A for RET figures, B for cost derivations | ROI still deliberately withheld (K13). The deck text has zero hits for "ROI". Honest, but a panel may want a number. |
| 1.3 Technical architecture | 🟡 | 🟡 (stronger) | Deck slide "the AI sees a question and a few clauses; everything else stays put"; payload ~2,300 chars measured (E-payload); provider payload log; docs/monday-platform.md | B; monday platform claims C | **Diagram not done**: D-DIAGRAM is decided (546bba5) but the generated SVG teardown is a queued wave 3 item. Prose only plus slide. |
| 1.4 Scalable rollout, metrics per stakeholder, risk, non-goals | 🟡 | 🟡 | Deck slide "prove it on Maple Creek, then every cycle, then the teams next door"; slide "what it does not do yet, and what we chose not to build"; plan.json moves_metric | B | Deck has one "pilot" phase mention, no best/base/worst scenarios, no phase table. Pilot-terms checklist is a plan node, not done. |
| 1.5 Product recommendations for monday.com | 🟡 | ✅ (weak) | Deck slide "five product changes this build points to" (30f0e20); evidence: analytics Enterprise-gated (E-monday-analytics-gate), 30K-point write cost (E-monday-write-cost), Models API 403 on free tier (E-monday-models-api) | B for measurements; the analytics gate claim is C only if the Developer Center page was opened (source field says it is this account's own screen, so B) | Recommendations are inference from the measurements (D). |
| 1.6 Concise, exec-ready, ≤10 slides | ⬜ | 🟡 | 10 slides, PDF 723 KB in ZIP (b41aa7c); STAR-I titles carry the story | B | Never read by someone outside the build. Layout audit and "single reading column" are open (wave 3). Dense for an exec audience until the gauntlet runs. |

## Part 2: Technical proof of concept

| # | Previous | New | Evidence | SQ | Gap / next |
|---|---|---|---|---|---|
| 2.1 Uses the provided package | ✅ | ✅ | data/ verbatim (7e3382a), golden provenance gate | A, B | |
| 2.2 Results land in monday.com | ✅ (answers not on board) | ✅ | 4 boards incl. Questions and RET Pilot Scorecard (2ab1aea); 32b4a6f idempotent upserts; E-facts: 14 key facts posted, 2 amended; 28 create-item and 30 update-item calls logged | B | Scorecard "native monday dashboard" is a board built for one, not a dashboard I have seen built; label it a board. |
| 2.3 Panel submits an unseen question live, handled end to end | ⚠️ ⬜ | 🟡 (up from ⬜; not ✅ until rehearsed) | 12bf04d "monday Questions board answered end to end with citations"; source/live_questions.py; 2 "rehearsal question" calls in monday_calls.jsonl; poller stops after 30 idle min (fc8e5e9); template-row cleanup cannot archive staff questions (K30) | B | **Zero full rehearsals from a clean database.** Plan shows `rehearse` blocked on Zach. The demo depends on a 60 s poll (E-poll, derived). One path, one run seen in logs: ✅ would overclaim. |
| 2.4 Build outside monday, push in via GraphQL or MCP, defend the choice | 🟡 | 🟡 | GraphQL client pinned to 2026-07, 200-errors handled, budget logged (0b128ce); docs/monday-platform.md section 7 on MCP; docs/monday-native.md (21 pages opened, 3 errored) | C for platform docs. **monday-platform.md says it did not open the MCP pages or github.com/mondaycom/mcp, so the MCP side of the defence is D.** | The "why not MCP" defence is still not written in DECISIONS.md or the deck (deck text has 0 hits for "MCP"). Unchanged since T+2h. |
| 2.5 Inspectable distinct steps | ✅ | ✅ | ingest, resolve, retrieve, select, verify, sink in source/rfp/*; provenance chain per answer (914323a); Evals tab maps each case to code path (f59325d) | B | |
| 2.6 Real backend code of my own | ✅ | ✅ | source/rfp/{parse,resolve,answer,store,sink,monday,provider,faults}.py, stdlib only | B | |
| 2.7 Python, ≥1 AI provider, runnable end to end, error handling | 🟡 | ✅ | `./rfp` CLI (fc8e5e9: ask, sync, scorecard, poll, reset, eval, scenarios, check, serve); README "Setup and run" section (92d325b); faults degrade (K15, K20); mock provider runs with no keys | B | README line 46 still says "12 seam tests"; truth is 23 tests across two modules. HANDOFF says "14 seam tests" and "33 own errors"; truth is 36. **Stale numbers in two shipped docs.** |
| 2.8 Panel tests in character | ✅ Doug/Nina · 🟡 Sam · 🟡 Elena | ✅ Doug/Nina · 🟡 Sam · 🟡 Elena | Doug: wave 1+2 A1.x cases, V5/V6. Nina: T1-T4 refusals, "not addressed" cases W9/W10/W12. Elena: key facts answered with no model call (75682d8) plus the board. Sam: payload ~2,300 chars logged (E-payload); 216b026 hardens the local server (foreign Host, cross-site POST, paid calls refused by default; 9 attack tests). | B; persona concerns A (discovery transcript) | **Sam's offline switch still not built** (local model 14/18, not re-run, K-fixes since). Persona attack layer (war game) not run. Elena "landed the same day" is a claim about a flow nobody has timed on a real new RFP; Maple Creek only. |

## Prepared to defend

| # | Previous | New | Evidence | SQ | Gap |
|---|---|---|---|---|---|
| 3.1 Walk any file line by line | 🟡 | 🟡 | HANDOFF maps panel questions to evidence (eval case, seam test, doc) | B | No rehearsal with Zach (plan node `rehearse`). |
| 3.2 Why built, why not built | ✅ | ✅ | ee67e33 DECISIONS (alternative rejected, evidence grade, revisit trigger); BACKLOG out-of-scope; deck "what we chose not to build" | B | |
| 3.3 Document processing | ✅ | 🟡 (worse) | Deterministic parse; K1/K17/K18; **PJM real-document test deferred** (742061d) | B | The only large real RFP test was cut by value/effort. 600-page behavior is untested (D-600 decision logged, not measured). A real-document claim would be D. |
| 3.4 Schema and data model | 🟡 | 🟡 | SQLite schema in source/rfp/store.py, board columns | B | **DATA-MODEL.md does not exist** (`ls` confirms). Plan node `datamodel` open. |
| 3.5 Query/API construction, pagination, limits, batching | 🟡 | 🟡 | Measured costs (E-monday-write-cost 30,000 per write; reads 1-40), steady re-sync 906 points, pacing, diff-before-write | B (limits table in monday-platform.md is C) | No pagination, no batching (find item is the top call type at 104 of 267). Unchanged. |
| 3.6 Prompt engineering and iteration | ✅ | ✅ | K27 (reverted prompt that regressed), K33 (refusal follow-up call plus deterministic floor, 62ccec4), K25 stemming; mutation check guards K25 and K33 | B | |
| 3.7 Production hardening, AI limitations | 🟡 | 🟡 (stronger) | 216b026 server security + 9 attack tests; K34 leak gate; limits-and-disclaimers section queued in HANDOFF | B | Still not one page in the shipped docs. `scripts/security_gate.py` is untracked in the working tree, so not yet evidence. |

## AI-assisted development

| # | Previous | New | Evidence | SQ | Gap |
|---|---|---|---|---|---|
| 4.1 Notes on AI use with prompts and iterations | 🟡 | 🟡 | JOURNEY.md (generated), KINTSUGI.md, flightlog/trace.jsonl, snapshots, eval history | B | Still no short "how I directed the AI" page. |
| 4.2 Where AI worked and failed | ✅ | ✅ | 36 own errors with repair and heading change; deck slide "bugs we found are fixed for good"; Evals tab links each case to the mistake it guards | B | The 30K fuzz and 3,072 matrix are not "AI failed" evidence; keep the framing to the K rows. |

## Submission

| # | Previous | New | Evidence | SQ |
|---|---|---|---|---|
| E1 ZIP under 10 MB | 🟡 | ✅ | dist/submission.zip 2,856,187 bytes; packager fails on stale generated figures (934122f) | B vs A (limit from email) |
| E2 Non-empty source/ and presentation/ | ⚠️ | ✅ | presentation/ holds RET-RFP-Intelligence.pdf and deck.html; both in the ZIP listing | B |
| E3 By Thu 10-15 5:00 PM ET | 🟡 | 🟡 | ~123 h left (`date` now to 2026-10-15 17:00 ET). Not submitted. | B (deadline A) |
| E4 Watch the full intro video | ✅ | ✅ | docs/briefing-video.md captions in full | A. Captions are not the same as having watched it; label as captions. |
| E5 Review pre-read and materials | ✅ | ✅ | data/*.txt used by the golden gate | A, B |
| E6 Checklist 5/5 on the dashboard | ⬜ | ⬜ | Zach's action; nothing in the repo can show it | E (not verifiable from here) |
| E7 Same browser throughout | ✅ | ✅ | Per T+2h note, Comet only | E (recollection carried from T+2h) |
| E8 ZIP contains source, README and a presentation PDF | ⚠️ | ✅ | `unzip -l` shows presentation/RET-RFP-Intelligence.pdf (723,349 bytes); README present; source present | B |

## Assumptions in force (re-checked)

1. Panel question arrives via a monday Questions item. Now built (12bf04d). Still an assumption about the panel's path. Not rehearsed.
2. 60 s polling acceptable. Unchanged. Daily call cap 1,000 on free (C: monday-platform.md table); 267 calls used in the whole build so far (B).
3. Free account fine. **New fact:** monday Models API returned 403 insufficient_credits on the free tier (B); the tier upgrade request to Sam Turner is pending (per HANDOFF, E: Zach reported it).
4. Lexical retrieval enough at sample size. Still untested at 600 pages (PJM cut).
5. Rule-based amendment resolver covers real wording or flags it. Still only synthetic wording tested; Amendment 2 revising Amendment 1 is plan node `eval-a2`, open.
6. Claude primary, local the data-residency fallback. Local not re-measured since K17-K36.

## Rubric rows that got WORSE

- **3.3 Document processing: ✅ to 🟡.** The PJM real-document test was deferred in 742061d. The T+2h grade assumed it was pending; it is now dropped.
- **Local-model fallback (inside 2.8, Sam):** not a row change, but the 14/18 figure is now older relative to 18 further seam repairs (K19-K36). Still not re-run.
- **Documentation accuracy (inside 2.7):** README says 12 seam tests, HANDOFF says 14 seam tests and 33 errors; current truth is 23 tests and 36 errors. Shipped docs now disagree with the records.
- **Spend figure:** $1.13 (T+2h) to $2.01 (evidence) with the raw log at $2.16. The T+2h number was not wrong when written, but the two current figures disagree.

## Rows with no evidence or weak evidence

- E6 (checklist) and E7 (same browser): nothing in the repo; SQ E.
- 2.3: one successful path in logs, zero clean-database rehearsals.
- 2.4: MCP side of the defence is D (pages not opened) and the defence text is not written.
- 3.1: no walk-through with Zach.
- 3.4: DATA-MODEL.md missing.
- Sam's offline switch: not built.
- Diagram in 1.3: decided, not generated.
- Tier upgrade from Sam Turner: pending, source is Zach's report (E).

## Verdict at T+~4h

The two zero rows at T+2h (deck, live question path) moved: 10-slide deck and PDF are in the ZIP, and the monday Questions board answers end to end. Three things still gate a strong submission: no rehearsal, no MCP/GraphQL defence in writing, and no architecture diagram. Fix the stale test and error counts in README and HANDOFF before packaging.
