# Retrospective and re-grade at T+~6h (read 2026-10-10 16:18 ET; HEAD a8c1ba1; start 10:07 ET)

> Taken at commit a8c1ba1 (16:18 ET). Landed after it: K47 (footer gate, density cuts from blind cold read 2), the proof of one answer with `./rfp verify-proof`, the finance cost model (presentation/cost-model.csv). Those are graded in the next snapshot, not this one.

All numbers were read from the repo records on this pass. Source quality (SQ): A client documents, B measured in this build, C cited third-party page opened, D inference, E recollection. Ties go to the lower grade.

## Part 1: Retrospective, five layers

The build is 108 commits and 46 logged mistakes in about 6 hours (B: git log, mistakes log row count). Most commits came in the first four layers; most of the surprises came in the last one.

| Layer | Time | Commits | What it added | Mistakes surfaced |
|---|---|---|---|---|
| 1. Core engine | 10:07 to 10:32 | 3 | Ingest, amendment resolver, cited answers, 18 golden questions | K1 to K8: PDF lines dropped at page breaks, amendment never detected, a test that wanted the wrong date format |
| 2. Proof machinery | 10:37 to 11:33 | 15 | 30,000-run fuzz, provenance and evidence gates, cost write-ups, plan graph, fault injection, 3,072-case scenario matrix | K9 to K22: mostly my own harness and my own cost guesses (K10, K13, K14), then the matrix found real holes (K19 to K21) |
| 3. monday landing | 11:41 to 12:34 | 18 | GraphQL client, live boards, idempotent writes, Questions board answered end to end | K23 to K31: write cost 30,000 points each (K23), sync would have archived staff questions (K30), deck claims beyond what was measured (K31) |
| 4. Deck, generator, hardening | 12:36 to 14:11 | 37 | 10-slide deck and PDF, one generator for every shown figure, local server security, CI, plan clusters | K32 to K37: a fast path that made three tests vacuous (K32), hand-typed figures that drifted (K35), a hole where any web page could trigger paid calls (K36) |
| 5. Outside evidence, cuts, freeze | 14:11 to 16:17 | 35 | War game, bar-raiser review, scope cuts, real federal RFP, two blind question sets, cold read, e2e dry run, design pass | K38 to K46 (9 of the 46 in the last 2 hours) |

Layer boundaries are by commit time, so work overlaps at the edges. About 1 mistake per 2.3 commits overall.

### Turning points where outside evidence changed direction

1. **Real RFP (K42, 15:08, dd1b52e).** A public Army Corps package (89-page base RFP plus 7 amendments, about 265 pages) parsed to 0 clauses and was stored silently as 8 base RFPs. Before this, "600 pages" was a deferred test. After it, the parser refuses documents it cannot read (dd1b52e) and, later, documents with swallowed text (K46, f5171f0). Direction change: from "handles real documents" to "says so when it cannot".
2. **Blind sets (K43 and K44, 15:15 and 15:22).** Our own 31 questions scored 31 of 31. A reviewer who never saw our tests scored us 16 of 20, a second one 17 of 20. All first-set misses were wrongful "not addressed" answers. Direction change: synonyms, a shared glossary, typo tolerance and a lead-in stripper (5cc2535, 2c6b60e, c6a3928). Both sets are now marked as tuned on after scoring, so they cannot be reused as clean evidence.
3. **Cold read, clarity C+ (15:19, ece799e).** An outside reader flagged unexplained jargon, unreconciled savings figures (200 h, 500 h, $800K), and slides 2, 4, 7, 8, 9 as too dense. Direction change: the design pass (6596568, 16:14).
4. **Bar-raiser review (14:27) and the scope decision (14:32).** It said the build was far past a 6 to 8 hour brief and the critical path pointed at dashboards no one asked for. Direction change: D-SCOPE cut 12 plan items (fd0a170 separates "cut" from "deferred").
5. **War game (K38, 14:18).** 4 of 15 attacks got through a fooled model before code, not the model, enforced scope. Now 15 of 15 (wargame_runs).
6. **e2e dry run (K45, 15:35).** First live run failed on a board state and my own case-sensitive check; then 3 of 3 passed, median 3.2 s from pick-up to the answer on the board (E-e2e-answer, B).

### What grew faster than it closed

Plan nodes, from `git show <hash>:plan.json` across 24 commits that touched it:

| Moment | Nodes | Done |
|---|---|---|
| 11:02 plan created | 16 | 2 |
| 12:42 deck done | 18 | 6 |
| 13:53 job clusters added | 25 | 9 |
| 14:11 dashboard spec | 38 | 10 |
| 14:32 scope cut | 39 | 12 |
| 16:06 now | 49 (today's file) | 16 (14 deferred, 12 cut, 5 ready, 2 blocked) |

Nodes tripled (16 to 49) while done went from 2 to 16. Between 12:42 and 14:11 the plan gained 20 nodes and closed 4. The freeze (D-FREEZE, a8c1ba1) cites the same pattern: 18 to 45 tasks while done went 6 to 15. Other things that grew faster than they were checked: prose in shipped docs (README still says "12 seam tests", HANDOFF "14" and "33 errors"; truth is 26 tests and 46 errors), and the generated pages (status, journey, catch-net, decks), which outnumber the human-read ones. What closed well: the mistakes log (every row has a repair and a heading change), the figure generator (`build.py --check` exit 0), and the evals (13 of 13 and 18 of 18 on the latest Claude run, 20:07Z).

## Part 2: Re-grade against snapshots/T+4h.md

Measured state first.

| | T+4h | Now | Source | SQ |
|---|---|---|---|---|
| Commits | 69 | 108 | `git rev-list --count HEAD` | B |
| Mistakes logged | 36 | 46 | rows in the mistakes log, E-repairs | B |
| Tests | 23 | 26, OK (`unittest discover` in source/) | run now | B |
| Wave 1 / wave 2, Claude | 18/18, 12/12 | 18/18, 13/13 (20:07Z). Records: 20 of 26 and 17 of 25 runs fully green, worst 15/18 and 9/12 | eval_runs, E-eval-wave*-record | B |
| Blind sets | none | 16/20 and 17/20, before fixes, both tuned on after | evidence/blind | B |
| War game | not run | 15/15 (second run; first run 14/15) | wargame_runs | B |
| Local model | 14/18 | still 14/18 from 14:35Z, not re-run | eval_runs | B |
| Spend | $2.01 | $2.94 | E-build-spend | B |
| Calls | 709 model, 267 monday | 945 model (812 Claude), 603 monday | flightlog | B |
| Plan | 12 threads, 5-step path | 49 nodes, 16 done; path design-pass, gauntlet, submit; blocked on Zach: rehearse | `scripts/plan.py` | B |
| Zip | 2.86 MB, 75 files | 4.9 MB, 95 files, **built 15:29 to 15:39, before the 16:14 deck redesign: stale** | `ls dist`, `unzip -l` | B |
| Deck | 10 slides | 10 sections, PDF built 16:14; 0 hits for "MCP" and "ROI" in the deck | grep deck.html | B |
| Time left | about 123 h | about 120 h to Thu 17:00 | `date` | B |

### Calibration

`python3 scripts/calibration.py`: **Brier score 0.242 over 10 resolved of 39 predictions** (0 is perfect; always saying 50% scores 0.25). I count 6 of the 10 in the log with a recorded outcome visible by id (M1-p1, M1-p3, W2-p1, H4-p1, CAN-para, BLIND2-16 all happened); the rest of the 10 were read by the script, not listed by me. Reading: no better than a coin so far. Misses that cost the most were overconfidence on real-document predictions (H3-p1 0.75 and H3-p2 0.85, both did not happen) and the second blind set (BLIND2-18 at 0.40 did not happen, correct to doubt). 29 predictions are still open, including the rehearsal, pilot estimates and panel questions; those can only resolve on the day.

### Rubric rows (same rows as T+4h)

Part 1: Strategic proposal

| # | Previous | New | Evidence | SQ | Gap |
|---|---|---|---|---|---|
| 1.1 Exec summary slide | ✅ | ✅ | deck slide 1; 6596568 | B, A | Cold read said "Elena's three criteria" never listed. Not fixed by design pass as far as I verified. |
| 1.2 Pain points, business case | 🟡 stronger | 🟡 | RET figures in the ledger (E-questions, E-manual-cost, E-intake-hours, E-missed-bids); illustrative savings marked | A, B | Cold read found 200 h vs 500 h vs $800K does not reconcile. Deck has 0 hits for "ROI" while prediction BC1 (0.50) says a panelist asks. |
| 1.3 Technical architecture | 🟡 stronger | 🟡 | deck has an `<svg>` (1 hit); payload figure E-payload "about 2,400 characters" (evidence) vs 2,300 in the earlier snapshot | B | Cold read: arrows ambiguous. D-DIAGRAM decided at T+4h; I did not verify the generated teardown exists. |
| 1.4 Rollout, metrics, risk, non-goals | 🟡 | 🟡 | D-SCOPE risk rows (§7.2, 7.4, 7.5 as key facts); deck "risk" 3 hits | B | BR-P8 (explicit risk table with likelihood) is open. Slide 8 densest per cold read. |
| 1.5 Product recommendations for monday | ✅ weak | 🟡 (worse) | Same measurements (E-monday-write-cost, E-monday-analytics-gate) | B, D | Cold read: slide 10 speaks to monday, not to the client; suggested cutting it. Kept grade at 🟡. |
| 1.6 Concise, exec-ready, ≤10 slides | 🟡 | 🟡 | 10 slides; one 6-step type scale (6596568) | B | Cold read C+ on clarity was before the design pass. cold-read-2 not yet run. |

Part 2: Technical proof of concept

| # | Previous | New | Evidence | SQ | Gap |
|---|---|---|---|---|---|
| 2.1 Provided package used | ✅ | ✅ | data/ verbatim 7e3382a | A, B | |
| 2.2 Results land in monday | ✅ | ✅ | idempotent upserts 32b4a6f; scorecard board 2ab1aea | B | "Dashboard" is a board. |
| 2.3 Unseen live question end to end | 🟡 | 🟡 (stronger) | `./rfp e2e`: 3 of 3 live runs passed, median 3.2 s pick-up to answer (E-e2e-answer, 19:34Z, 38137a4). First attempt failed (K45) | B | Zach's clean-DB rehearsal still not done (plan node, blocked on Zach); poll interval is 60 s, so wait time is not 3.2 s. BR-P6 open. |
| 2.4 GraphQL vs MCP, defended | 🟡 | 🟡 (stronger) | D-MCP written (13810ac), reviewed against monday's own repos per its heading | C claimed by the file, **not re-opened by me**; D for MCP side | Deck still has 0 hits for "MCP". |
| 2.5 Inspectable distinct steps | ✅ | ✅ | source/rfp/*; Evals tab | B | |
| 2.6 Real backend code | ✅ | ✅ | stdlib Python | B | |
| 2.7 Runnable end to end, errors handled | ✅ | 🟡 (worse) | `./rfp` CLI; refusal of unreadable documents (dd1b52e, f5171f0) | B | README line 46 says 12 seam tests, truth 26. HANDOFF line 23 says 14 and 33; truth 26 and 46. Gate did not catch stale prose. |
| 2.8 Panel tests in character | ✅ Doug/Nina · 🟡 Sam · 🟡 Elena | ✅ Doug/Nina · 🟡 Sam · 🟡 Elena | War game 15/15 (S-prefixed Sam attacks pass); deposit-difference tile | B, A | Sam's offline switch not built; local model 14/18 not re-run since 36 fixes (K17 to K36 and later). |

Prepared to defend

| # | Previous | New | Evidence | SQ | Gap |
|---|---|---|---|---|---|
| 3.1 Walk any file | 🟡 | 🟡 | HANDOFF question-to-evidence map | B | No walk-through with Zach. |
| 3.2 Why built, why not built | ✅ | ✅ | 13 headed decisions in DECISIONS.md incl. D-SCOPE, D-SUBTRACT, D-FREEZE | B | |
| 3.3 Document processing | 🟡 (worse) | 🟡 (honest) | Real federal package tested (K42): parser failed, then refused instead of storing empty; K46 swallowed-text guard | B | Still cannot parse that layout. The claim is "flags what it cannot read", not "reads real RFPs". |
| 3.4 Schema and data model | 🟡 | 🟡 | source/rfp/store.py | B | DATA-MODEL.md still does not exist (find confirms). |
| 3.5 Query, pagination, limits, batching | 🟡 | 🟡 | steady re-sync 906 points (E-monday-sync-steady) | B, C | No pagination or batching. Unchanged. |
| 3.6 Prompt engineering and iteration | ✅ | ✅ | K27, K33, K25; blind-set fixes | B | |
| 3.7 Hardening, AI limits | 🟡 stronger | 🟡 stronger | 216b026, 405f2cd, CI 059ad70 proven red by plant (c9fe180); war game 15/15 | B | Limits and disclaimers still not a page in shipped docs as far as I checked. |

AI-assisted development

| # | Previous | New | Evidence | SQ | Gap |
|---|---|---|---|---|---|
| 4.1 Notes on AI use | 🟡 | 🟡 | JOURNEY.md, the mistakes log, snapshots, this retrospective | B | Still no short "how I directed the AI" page. |
| 4.2 Where AI worked and failed | ✅ | ✅ | 46 rows; catch-net (00a4d51) shows which layer caught each | B | 12 of 46 are "me" or "premise" errors, not model errors; say so. |

Submission

| # | Previous | New | Evidence | SQ |
|---|---|---|---|---|
| E1 ZIP under 10 MB | ✅ | ✅ (stale build) | 4.9 MB, but built before the last deck changes | B |
| E2 source/ and presentation/ non-empty | ✅ | ✅ | `ls presentation`: PDF 575,691 bytes, deck.html | B |
| E3 By Thu 17:00 ET | 🟡 | 🟡 | not submitted; about 120 h left | B (deadline A) |
| E4 Watch intro video | ✅ | ✅ (captions) | docs/briefing-video.md | A |
| E5 Review pre-read | ✅ | ✅ | data/*.txt used by golden gate | A, B |
| E6 Checklist 5/5 | ⬜ | ⬜ | nothing in repo shows it | E |
| E7 Same browser | ✅ | ✅ | carried from T+2h | E |
| E8 ZIP has source, README, PDF | ✅ | 🟡 (stale) | the ZIP predates the current PDF (16:14); needs rebuild | B |

### Rows that got worse

- 1.5 product recommendations (✅ weak to 🟡): an outside reader said the slide serves the vendor, not the client.
- 2.7 runnable and documented (✅ to 🟡): shipped docs disagree with the records on tests (12 or 14 vs 26) and errors (33 vs 46).
- E8 (✅ to 🟡): the package is older than the deck inside it.
- Evidence strength of all "18 of 18" style claims: down, not a row. Blind sets scored 16 and 17 of 20 against 100% on our own questions; wave 1 and 2 records show 20 of 26 and 17 of 25 fully green runs.
- Local model figure: now 36+ fixes old.

### Rows still without evidence or with weak evidence

- E6, E7: nothing verifiable from the repo (SQ E).
- 2.3: no clean-database rehearsal by Zach; dry run is scripted.
- 2.4: MCP side not re-opened this pass; deck never mentions it.
- 3.1: no walk-through with Zach.
- 3.4: DATA-MODEL.md missing.
- Sam's offline switch: not built.
- 1.3: diagram existence not verified by me.
- Pilot estimates (EST-* in predictions): all open, class D by design.
- Tier upgrade from monday: pending, Zach's report only (E).

## What I would do next (inside the freeze)

Rebuild the ZIP after the last content change; fix the two stale prose figures in README and HANDOFF; run Zach's rehearsal from a clean database; run the second cold read on the redesigned deck; then the gauntlet.
