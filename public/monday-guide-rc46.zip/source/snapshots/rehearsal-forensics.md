# Dress rehearsal: forensic reconstruction, 0 to 1 to Done (2026-10-10)

Reconstructed from `flightlog/rehearsal_runs.jsonl` (11 runs), `flightlog/e2e_runs.jsonl`, the war-game and scenario
logs, and git. Times are UTC. Every claim below points at a log line or a commit.

## 0: before the runner existed
- Gates ran one by one by hand and in pre-commit; nothing exercised the whole submission path end to end, and the
  "e2e from the ZIP" check was a false pass (it imported the repo, not the ZIP: K48, found later at 22:09).

## The runner is built (21:59 to 22:01, commit 737084a)
- `./rfp rehearse` chains 17 steps as a dependency graph (build, staleness, provenance, security, overflow, proof,
  front-page links, seam tests, mutation check, golden, canaries, war game, package, unzip, onboarding doc-test,
  e2e from the ZIP, e2e faults; plus e2e live with `--live`).
- Runs 1 to 3: GREEN, 16.5 to 18.6 s each. Self-test (`--plant`): forcing provenance red skips canaries, package,
  unzip and e2e from the ZIP; never reported as passed.
- Finding at once: the step labelled "seam + mutation" ran only the seam tests; split, and the mutation check added.

## Onboarding joins the graph (22:08 to 22:10, commits 1463d64, a8248a5)
- Writing ONBOARDING.md exposed K48: the ZIP lacked `glossary.json` and the `rfp` launcher; the from-ZIP e2e had
  tested the repo's code all along. Fixed; the from-ZIP test now fails if it imports any other copy (proved by plant).
- Runs 4 and 5: GREEN, with the new "onboarding doc-test" step (3 of 3 keyless steps from the unzipped ZIP).

## The one red run (22:18:08, recorded against bbd3602)
- Overflow gate failed on slide 5 (the new "what leaves RET" line ran off the slide); package, unzip, doc-test and
  e2e from the ZIP were skipped, as designed. Fixed by splitting the line; run 7 at 22:18:35 GREEN.
- Caveat: the run records HEAD, but the slide edit was uncommitted at the time (same class as K49). Rehearsal runs
  now also record `uncommitted_code`.

## Live rehearsal 1 (22:25:18, commit ac7c9ae)
- GREEN in 82.9 s; the live step ran Claude against the real monday.com boards in 64 s.

## Gauntlet fixes, then live rehearsal 2 from a clean board (23:52:15, commit 44c393a)
- Between: war-game S9 (hostile board question) added; N4 tightened (K49); slide 5 names monday.com as the second
  destination; `./rfp doctor` shows calls left.
- `./rfp reset` archived 0 items (the board was already clean). Rehearsal GREEN in 79.0 s. Live step: ingest 0.0 s,
  sync 1 12.1 s, sync 2 (must create nothing) 13.0 s, questions board 0.8 s, poll once 20.7 s.
- Persona acceptance checklists all passed: Doug (amendment governs, no duplicates, every change recorded), Nina
  (drafting refused, "Not addressed" not a guess, no unsupported figure under any fault), Sam Ito (allowlisted
  boards only, payload under the cap, no secret-shaped string), Elena (no bid verdict, within time, every question
  lands with a state, an answer and citations). These are the fictional stakeholders' checklists, run by code; no
  real RET user has validated anything.

## Done (release check)
- First attempt reported green in a commit message but had failed (K50: an untraced commit, `c92dbf7`; exit code
  hidden by a pipe). Fixed with a span marked RECONSTRUCTED; a second attempt failed for a missing API key in the
  shell (logged as is, not deleted); third attempt exit 0: 18 of 18 Claude, fuzz, flight report, journey, package.
- Still open, by design: Zach's own hands-on rehearsal with a question in his words, and the upload (his click).
