# Brief reread: reflection (2026-10-10)

Sources read in full: the brief PDF (17 pages, `pdfinfo`), `docs/briefing-video.md`, README, DECISIONS, KINTSUGI, CONSTRAINTS, deck text (10 sections), git log (69 commits). Page numbers below are PDF pages.

## 1. Requirements nailed

| Requirement (brief, page) | Evidence |
|---|---|
| "every answer cites its source" (p4) | Eval cases Q/T/W with `must_cite`; K20 (zero valid citations is an error); `source/eval/golden.json` |
| Dates and dollars "exactly as written" (p4) | Verbatim figure gate (K4, K11); K7 made the test assert "DECEMBER 4, 2026" as written; 18/18 and 12/12 in `flightlog/eval_runs.jsonl` |
| "not addressed in the RFP" over a guess (p4) | K6, K26, K33 (code floor); seam test `test_K33_bare_refusal_still_shows_related_text`; deck slide 6 |
| Catch the amendment, say "where it says so" (p5) | Resolver in `source/rfp/resolve.py`; K17-K19; deck slide 4 shows Dec 4 live, Nov 13 superseded |
| "uploads the same document twice" creates nothing (p5) | Deck slide 4 and seam tests; sync diff-before-write (K23, 906 points steady state) |
| Indexing and retrieval in "our own environment" (p4) | Local store and search; payload ~2,300 chars (E-payload); slide 5 |
| Out of scope: scraping, auto-submit, drafting bids, DMS (p5) | CONSTRAINTS B9; slide 9; refusal test T4 |
| Build outside, push into monday via API/MCP, "be ready to defend the choice" (p8) | `source/rfp/monday.py` GraphQL client, complexity logged; K22-K24; `docs/monday-native.md` |
| Real backend code, inspectable steps, error handling (p8) | `source/rfp/*`, K15 (timeouts degrade, never crash); K36 server hardening |
| Fresh panel question, live (p7-8) | `source/live_questions.py` poller, DEMO.md rows 4-7 (60 s poll) |
| Max 10 slides, PDF (p9; video) | Deck is 10 slides; `presentation/RET-RFP-Intelligence.pdf`; `dist/submission.zip` |
| Exec summary, pain points with "their numbers", architecture, rollout, product recs (p6-7) | Slides 1, 2, 5, 8, 10; slide 2 reproduces the p5-6 metrics table |
| Document AI use (p9) | JOURNEY.md, flightlog, KINTSUGI (36 seams) |

## 2. Drifted, under-served, or over-built

**Under-served**
- **Risk analysis.** Rollout must include "success metrics ... risk analysis, and explicit scope discipline" (p7). Slide 8 has phases and exit tests; slide 9 has limits. There is no risk table with likelihood or mitigation. This is the clearest missing ask.
- **Pagination and query defence.** The panel will probe "query construction, pagination, rate/complexity handling, batching" (p8). The code handles complexity and retries (monday.py lines 6-8, 57); I found no pagination story in README or DECISIONS. Unverified whether the code paginates; check before the demo.
- **Prompt iteration** is required talking (p8). K27 holds one good story; the deck does not surface it.
- **Elena's 3 criteria** need a real solicitation. Slide 7 admits "same day" was not measured. Honest, but the headline metric is open.
- **Ambiguity not flagged.** Brief p1 says "Estimated Preparation Time: 6-8 hours"; the build is far larger (69 commits). Not a requirement, but see over-built.
- **Amendment count.** Brief p10 gives one amendment ("one Amendment"); p5 Doug says "three or four." Resolver handles N (K9 fuzz uses A2); nothing to fix.

**Over-built (the brief never asks)**
- Local Qwen/Ollama provider (K8; `provider.py` line 18). Sam says to know "what's in" a model call (p4), not to run local. Slide 5 still mentions it as optional.
- Monday Models gateway adapter (commit 62ccec4) and `docs/monday-native.md`: brief offers "monday's native AI agents" only as tooling choice (p8).
- Flight recorder, rubrics, belief trail, OpenTelemetry-shaped spans: p9 asks for notes on AI use, not a telemetry system.
- 3,072-scenario matrix, mutation tests, 1,024 "load-bearing" passes: strong, but p7 says "a modest build that proves you listened" scores well. Risk is the panel asking to read code line by line (p8) and finding too much surface.
- Server hardening (K36), history rewrites (K29, K34), TCO/UNIT-ECONOMICS: outside the ask.
- Scorecard board (`scorecard_sync.py`) and 14-fact key board are reasonable, but "~50 rows of milestones, deliverables, and owners" the tracker (p3-4) is what Doug builds by hand; I found no tracker board of that kind. Check: if absent, that is a mismatch against the stated pain.

**Inconsistency found:** JOURNEY.md line 33 says $0.0057/question; deck and DECISIONS say $0.0037/$0.0038. K14 and K35 explain price correction; JOURNEY keeps the old figure. Fix or footnote.

## 3. Panel lens, graded against the deck

Video (A): "how you structure ambiguity, evaluate trade-offs, use the available data, and communicate your reasoning clearly"; not "a perfect answer."

| Lens | Grade | Why |
|---|---|---|
| Ambiguity | B | Slide 7 names what is not measured; slide 9 lists limits. Weak: the brief's own ambiguities (one vs several amendments; "pages" per clause that the RFP does not number, slide 9) are not framed as decisions made. |
| Trade-offs | B- | Slides 5, 8, 9 hold retrieval-vs-whole-document and refuse-vs-predict. Real alternatives and costs live in DECISIONS.md, not on slides; the deck shows choices without the rejected option. |
| Use of data | A- | Slides 2, 3, 7 quote RET's own numbers and four named people; every figure regenerates from records (K35). Gap: p6 benchmark column (3-5 days) is unused. |
| Clarity | B | STAR-I titles carry the story; 10 slides. Risk: dense tables on 2, 3, 8; no visible evidence grade on any slide (deck has `data-e` ids only, not A-E labels). |

**Claim source grades (deck slides):**
- 1: ~15 business days, 1-2 days, Elena's 3 criteria: **A** (p5-6).
- 2: ~650 h, <=150 h, ~180 q, 3 missed, $1.6M: **A** (p6). $0.0037/question: **B** (flightlog/model_calls.jsonl).
- 3: stakeholder quotes: **A** (p4-5).
- 4: Dec 4 vs Nov 13, ~1 minute answer: **A** (amendment p16); minute is **B** (poll interval, DEMO.md).
- 5: ~2,300 characters sent: **B** (E-payload).
- 6: 18/18, 12/12: **B** (eval_runs.jsonl). 3,072/3,072: **B** (scenario_runs.jsonl). "Fixed for good": **D**, an inference, since tests prove only listed cases.
- 7: $0.67 per cycle: derived from **B** x **A** (~180 questions). Whole-document "~157x": **D** (estimate, DECISIONS D-600).
- 8: phases and exit tests: **D** (design judgement). "Free account refused, measured": **B**.
- 9: "documentation shows no way to cite sources" for AI columns: **C** only if the page was opened (docs/monday-native.md cites URLs; confirm they were opened, not summarised from search). Otherwise **D**.
- 10: 30,000 points per write, 1,000,000 per minute: **B** (monday_calls.jsonl) and **C** (docs/monday-platform.md). "API analytics needs Enterprise": **C** if opened, else **D**.

No claim relies on grade E. K31 shows past slips from memory (grade E leaking in as fact); the gate now blocks that.

## 4. Top 3 changes, ranked by expected grade effect

1. **Add a risk table to slide 8 (or fold into 9): five risks, owner, mitigation, trigger.**
   Evidence: brief p7 names "risk analysis" explicitly; the deck has none (slide 8 and 9 text read above). Source material exists: D-600 (extraction, recall, batch), K22 (rate caps), K36, wrong-figure fault.
   Alternative: link DECISIONS.md from the deck. Weaker: the panel reads slides for 15-20 min, and a link is a claim the requirement is met somewhere else.

2. **Print an evidence grade (A-E) beside each number on slides 2, 5, 6, 7, 10.**
   Evidence: video (A) grades "use the available data" and "communicate reasoning"; `data-e` ids exist already, so this is a render change. It converts the strongest asset (provenance) into something visible in a PDF.
   Alternative: a methods appendix. Weaker: D-SHOW already rejected it, since the reader must leave the number to check it.

3. **Cut or demote over-built items from the live path: Qwen, monday gateway, scorecard.** Prepare one-line answers for pagination, prompt iteration (K27), and "why GraphQL not MCP".
   Evidence: p8 says the panel picks repo sections for line-by-line explanation; p7 says a modest listened-to build beats a showy one; K8 already records one over-claim; JOURNEY/deck cost inconsistency shows surface-area drift.
   Alternative: keep everything and rehearse. Weaker: rehearsal cannot reduce the number of files to defend, and K8, K29, K31, K34 show the pattern of unrequested surface producing integrity seams.

Unresolved before submit: (a) is there a pagination answer in code; (b) was the tracker (~50 rows) expected, and did the build skip it; (c) fix JOURNEY.md $0.0057.
