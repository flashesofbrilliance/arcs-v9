# Plan hardening: the RET proposal (deck), not the harness

Read-only, 2026-10-10. Sources: brief pp1-7 (A), data/*.txt (A), deck.html text (B), QUESTIONS.json, reflection-brief-reread.md, bar-raiser.md (BR1-BR13, not repeated). Page numbers are brief PDF pages; RFP lines are data/rfp_maple_creek.txt (R), amendment (AM).

## 1. Grid and pruning

Full grid: 5 altitudes x 8 value-chain stages x 6 supply-chain links = 240 cells. Filled: 16 cells. Pruned: 224, because no client document touches them. Main prune reasons: protest window (R 238-241) touches no stakeholder and no deck claim; ISO portal is out of scope by Doug's request (p5) except where it caused the incident; model provider and parser are already covered by BR8/BR12 and the deck's slide 5; estimators and the "engineer" altitude only appear through Sam's support line (p4). Cells kept are the ones where a client sentence or an RFP line names both the person and the stage.

## 2. Findings (only cells the deck leaves thin or missing)

| id | cell (altitude / stage / link) | finding | why it matters | p hurt | pre-mortem: "Thu 5 PM, this failed because..." | cheapest fix | grade |
|---|---|---|---|---|---|---|---|
| PH1 | exec / RFP published / ISO portal + people | The deck never says who notices a new amendment; the incident was an amendment that "sat unnoticed in a portal" (p4), and the pipeline only acts once someone uploads the file. | Elena tells the incident in every meeting (p3). If the plan still depends on a person noticing, criterion one is unproven at its root. | 60% (the gap is visible to anyone who knows the origin story, which is every panelist) | Elena asked "so who checks the portal on day two?" and the answer was "someone on Doug's team, like before." | One line on slide 4: named owner checks each tracked portal daily, logs "checked, nothing new" as a board item; a missed check turns the item red. Scraping stays out. | A |
| PH2 | operator / intake / monday platform | No tracker board: Doug rebuilds ~50 rows of milestones, deliverables and owners every cycle (p3-4), and the deck shows key facts and questions only. | The 650 hours are "extraction + tracker + decks" (p6); the deck addresses one of three, so the &le;150 h target has no path. | 55% (Doug is the trust gate, p5; the panel plays him) | Doug said "nice, but my fifty rows still get built by hand." | Slide 4: add "RET · Response Tracker" seeded from RFP key dates and Volume I-IV requirements (R 47-54, 214-229), owners left blank for Doug. Say it, do not build it. | A |
| PH3 | surgical / intake / amendment | Amendment 1 creates two actions with their own clocks: remit the $25,000 difference within 15 calendar days of Oct 2, so by Oct 17 (AM 10-13), and an officer-signed cybersecurity attestation per Appendix F, which is not in the package (AM 14-17). | This is exactly Doug's test (deadline moved and deposit changed, p5); showing the consequence, not just the new value, is what "noticing" means. | 45% | the demo showed $100,000 but nobody asked "and what do we owe by when?", and a panelist did. | Slide 4 line: "Amendment 1 also creates two tasks: pay $25,000 by Oct 17; get Appendix F (not in the package) signed by an officer." | A |
| PH4 | manager / internal Q&A / people | Questions the system answers "not addressed in the RFP" have nowhere to go; the ISO Q&A window closes Oct 16, 5 PM CT (R 50) and the ISO portal is the only channel (R 64-67; Q7 tests direct contact). | Nina wants refusals (p4); a refusal with no next step after Oct 16 is a lost clarification. | 35% | Nina asked "and then what?" and the answer was "ask Doug," which is the old process. | One sentence: unanswered items get a "Send to ISO Q&A" status with the window close date shown. | A |
| PH5 | exec / intake / monday platform | Elena's target "brief &le;3 days" (p5) has no artifact in the plan; slide 2 lists it, nothing produces it. Industry benchmark 3-5 days (p5) is unused. | Use their numbers (p6) and their success criteria; this is the one target with a benchmark to beat. | 40% | Elena asked "where is my bid/no-bid page?" | Slide 4: the Key Facts board grouped as the one-page view leadership already wants ("a dozen fields ... on one page", p3); cite benchmark 3-5 days. | A |
| PH6 | exec / next cycle / people | Funding moment not stated: Elena will "fund the rollout myself out of the BD budget" if one real solicitation shows the three criteria (p5); the deck has phases but no ask, cost or decision date. | Audience is Elena and leadership (p6); a proposal without a decision ask is a status report. | 45% | the meeting ended with "interesting, send us something." | Slide 8 footer: "Decision for Elena after Maple Creek submission (Dec 4): fund phase 2 from BD budget, yes or no, against the three criteria." | A |
| PH7 | manager / next cycle / people | Handover owner is listed only as an open question; Sam says his two-person team supports it (p4). | "Countable moving parts" is Sam's condition; naming the count makes it checkable. | 30% | Sam asked "how many things do we run?" and the answer took a minute. | Slide 5 caption: "You run: one Python program, one local database file, one scheduled job, one API key." | A (ask) / B (count) |
| PH8 | exec / next cycle / monday platform | Expansion economics are missing for the monday side: 900 seats, $310K ARR, ~250 seats if the pilot succeeds (p2). | The panel is monday.com; slide 10 talks product, never account value. | 30% | a panelist asked "what does this mean for the account?" | One line on slide 9 or 10: "Pilot success opens ~250 seats in BD, Proposals, Regulatory (account brief)." | A |
| PH9 | engineer / compliance matrix / parser | Volume page limits and the "unstated exceptions are waived" rule (R 225-230) are compliance-matrix facts the plan never mentions; nothing maps requirements to volumes. | This is where a wrong reading becomes a rejected proposal (R 229-230), Nina's world. | 20% | low; only if a panelist pushes on "compliance matrix". | Do not build. One phase-2 line: "requirements list by volume, from section 11." | A |

Covered adequately already (no finding): amendment supersession and dates (slide 4), cost cap and delay damages (slide 9), what leaves RET (slide 5), Nina's verbatim and refusal rules (slide 3), scope exclusions (slides 3, 9).

## 3. Top 7 fixes, by grade effect per minute

1. PH1 portal-noticing owner line (5 min). Ties the plan to the origin incident.
2. PH3 amendment consequences line (5 min). Turns Doug's demo into "it noticed what we owe."
3. PH6 decision ask with date (5 min). Makes it a proposal.
4. PH2 tracker board, named not built (10 min). Closes the biggest share of the 650 h.
5. Worked business-case example (section 4) (15 min).
6. PH5 one-page brief plus 3-5 day benchmark (5 min).
7. PH4 "Send to ISO Q&A" status with Oct 16 (5 min).

Over-building to avoid: actually building the tracker board, a portal watcher, a compliance-matrix extractor (PH9), or an ROI calculator. Each is a slide line, not code (brief p7, "a modest build that proves you listened").

## 4. Business case: refuse to state a return, or show a worked example?

For refusing (current deck): staff cost, seat price and pilot cost are unknown; inventing them invites Nina's "a guess is a liability" (p4); honest about evidence.

For a worked example: the brief asks to "connect them to business outcomes and quantified value. Use their numbers" (p6), and RET already gave the numbers. Using only RET's figures is arithmetic, not a guess: ~$1.6M a year, &ge;50% target, so ~$800K a year is RET's own target value; intake 650 h to &le;150 h saves &ge;500 h a cycle, x ~12 cycles = &ge;6,000 h a year; ~180 questions x 1-2 days wait. Elena also says the real cost is bids, not hours (p4): one more competitive bid kept is worth more than any hours line. Refusing reads as dodging the one slide the brief names.

Recommendation: show the worked example on slide 7, labelled "Illustrative, RET's own figures (Q2 2026 review), not a forecast", with three lines (500 h/cycle, 6,000 h/yr, $800K at RET's 50% target) and keep "return needs your costs: staff rate, seats, pilot cost" as the open line. Lead with Elena's framing: hours are the floor, bids kept are the point.

Grades: findings PH1-PH9 rest on A sources; the probability estimates are D (my judgement, calibrated against the bar-raiser's 55-80% band for visible gaps).
