# Pulse check at T+2h (2026-10-10 12:10 ET; T0 = brief read at 10:07)

Line-by-line grade against the brief, Sam Turner's email, and the briefing video. Grades are my
judgement, each tied to evidence in the repo; a grade with no evidence is "Not started". The panel will
grade harder than this, so ties go to the lower grade.

**Scale:** ✅ Met (evidence exists and was run) · 🟡 Partial · ⬜ Not started · ⚠️ At risk

## Measured state

| | Value | Source |
|---|---|---|
| Elapsed | 2 h 03 min, 25 commits | git log |
| Wave 1 eval (Claude) | 18/18 | flightlog/eval_runs.jsonl |
| Wave 2, second-order questions (Claude) | 12/12 | same |
| Local model (Qwen 2.5 7B), wave 1 | 14/18, last run before K17-K28 | same |
| Scenario matrix (all fault combinations) | 3,072/3,072, of which 1,024 load-bearing | flightlog/scenario_runs.jsonl |
| Ingest fuzz | 0 failures in 30,000 runs | flightlog/sim_runs.jsonl |
| Seam tests / mutation check | 12/12 pass; 6/6 repairs caught when removed | tests/ |
| Seams repaired (our own errors) | 28 | KINTSUGI.md |
| Claude API spend | $1.13 over 304 calls (tokens x cited price) | flightlog/model_calls.jsonl |
| monday API | 193 calls; steady-state sync 906 complexity points | flightlog/monday_calls.jsonl |

## Part 1: Strategic proposal (15-20 min, ≤10 slides, Elena + leadership)

| # | Requirement (brief) | Grade | Evidence | Gap / next |
|---|---|---|---|---|
| 1.1 | Executive summary in one slide: problem, approach, outcome | ⬜ | none | Deck not started |
| 1.2 | Pain points and business case in RET's numbers and language | 🟡 | UNIT-ECONOMICS.md, TCO.md, evidence ledger (RET-sourced, provenance-gated) | No slide; ROI deliberately withheld until RET inputs (K13) |
| 1.3 | Technical architecture: where it runs, where documents live, what reaches external AI, each constraint honored, AI approach and why | 🟡 | README, DONE.md, provider payload log, monday-platform.md | No diagram; the "what leaves the building" story exists only in prose |
| 1.4 | Scalable rollout: pilot → all cycles → adjacent teams; metrics per stakeholder; risk; explicit non-goals | 🟡 | plan.json (moves_metric), BACKLOG.md "out of scope", TCO backlog | No phased plan written; best/base/worst scenarios discussed, not written |
| 1.5 | Product recommendations for monday.com | 🟡 | Evidence: API analytics gated to Enterprise; 30K-point flat write cost; AI columns lack citations; agents need public URLs | Not yet a list |
| 1.6 | Concise for an executive audience; ≤10 slides | ⬜ | none | Highest-weight missing item |

## Part 2: Technical proof of concept (10-15 min live, code on screen)

| # | Requirement | Grade | Evidence | Gap / next |
|---|---|---|---|---|
| 2.1 | Uses the provided package (base RFP, Amendment 1, sample questions) | ✅ | data/ verbatim (K1 repaired), golden provenance gate | |
| 2.2 | Results land in a monday.com account with boards the design requires | ✅ | 3 live boards; rerun creates 0 items | Answers not yet written to the Questions board |
| 2.3 | **Panel submits an unseen question live through the path real users use; handled end to end** | ⚠️ ⬜ | Answer engine ready; Questions board exists | **Live question path not built: the single most important demo item** |
| 2.4 | Build outside monday, push in via GraphQL API or MCP, defend the choice | 🟡 | GraphQL client, pinned version, platform doc | Defence not written (why not MCP: same call budget, less inspectable) |
| 2.5 | Inspectable distinct steps with explainable state; not a mega-prompt, not a black box | ✅ | ingest → resolve → retrieve → select → verify → sink; provenance chain per answer | |
| 2.6 | Real backend code of my own: data model, API layer, core logic | ✅ | source/rfp/*, stdlib only | |
| 2.7 | Python/TS; ≥1 AI provider; runnable end to end; error handling | 🟡 | Claude + local; errors degrade (K15, K20) | No single "run everything" command or setup section in README |
| 2.8 | Panel tests in character against stated concerns (Doug's amendment, Nina's citations, Sam's data, Elena's same-day facts) | ✅ for Doug/Nina · 🟡 Sam · 🟡 Elena | Wave 1+2, matrix V5/V6, needs-review flags | Sam: offline switch not built. Elena: key facts exist but no "landed the same day" flow |

## Prepared to defend (panel Q&A)

| # | Topic | Grade | Notes |
|---|---|---|---|
| 3.1 | Walk any file line by line | 🟡 | Code is short and commented; I have not rehearsed it with Zach |
| 3.2 | Why each thing was built, and what was deliberately not built | ✅ | KINTSUGI, BACKLOG out-of-scope, plan moves_metric |
| 3.3 | Document processing: choices, trade-offs, failure modes | ✅ | Deterministic parse; K1/K17/K18; PJM real-document test still pending |
| 3.4 | Schema and data model | 🟡 | SQLite schema + board columns exist; DATA-MODEL.md not written |
| 3.5 | Query/API: construction, pagination, rate and complexity limits, batching, data flow | 🟡 | Measured costs (K23), pacing, upserts | No pagination yet (boards are small); batching not used |
| 3.6 | Prompt engineering approach and iteration | ✅ | select-not-generate; K27 (a prompt change that regressed, reverted) is the best story |
| 3.7 | Production hardening; limitations and failure modes of the AI integration | 🟡 | Known; not written as one page |

## AI-assisted development (brief: document prompts, iterations, where AI helped or failed)

| # | Requirement | Grade | Evidence | Gap |
|---|---|---|---|---|
| 4.1 | Notes on how AI was used, with prompts and iterations | 🟡 | JOURNEY.md, KINTSUGI.md, flight log | No short "how I directed the AI" page for the ZIP |
| 4.2 | Where AI was most and least effective; where I intervened | ✅ | K8, K10, K13, K14, K27 are AI (my) errors caught by Zach or gates | Needs to be framed as such in the deck |

## Submission (Sam Turner's email + briefing video)

| # | Constraint | Grade | Evidence |
|---|---|---|---|
| E1 | One ZIP under 10 MB | 🟡 | package.py builds it (0.1 MB today) |
| E2 | Non-empty source/ and presentation/ | ⚠️ | presentation/ empty |
| E3 | By Thu 10-15 5:00 PM ET | 🟡 | ~101 h left |
| E4 | Watch the full intro video | ✅ | Captions captured in full |
| E5 | Review the pre-read and materials | ✅ | |
| E6 | Checklist 5/5 on the dashboard | ⬜ | Zach: tick 01-02 now; 03-05 later |
| E7 | Same browser throughout | ✅ | Comet only |
| E8 | ZIP contains source, README and a presentation PDF | ⚠️ | No PDF yet |

## Assumptions in force (each is a place we could be wrong)

1. The panel's unseen question arrives through monday (a new Questions item), not typed into our local page. Brief: "through whatever path your design gives real users".
2. Polling at 60 s+ during the demo is acceptable latency. Budget: 1,000 calls/day on free.
3. A free account is acceptable for the demo; a tier upgrade from Sam is pending and not required by the brief.
4. Lexical retrieval + glossary + stemming is enough at the sample's size; a 600-page package is untested (H4).
5. The rule-based amendment resolver covers real-world wording or flags it (H3: partly falsified on synthetic wording, fixed; PJM real-document test pending).
6. Claude stays the primary model; local is the data-residency fallback (H2 falsified as primary).

## Risks (ranked)

| Risk | Likelihood | Impact | Mitigation |
|---|---|---|---|
| Live question path not done or flaky on demo day | Medium | Critical | Build next; rehearse twice from a clean database; keep the local test bench as a fallback path |
| Deck under-built because the build kept expanding | **High** (12 open threads at T+2h) | High | Freeze new scope after the live path; deck next |
| A panel question exposes an untested real-world amendment wording | Medium | High | It degrades to "needs review", never a wrong answer (K17/K18), and that is the demo line |
| API budget or rate limit hit during rehearsal + demo | Low | High | Measured costs, pacing, diff-before-write; rehearse with mock first |
| Over-engineering perceived ("too clever") | Medium | Medium | Lead with the client's three outcomes; keep the rigor apparatus for Q&A only |
| Internal-platform vocabulary leaks into shipped files | Low | Medium | Plain-language rule in DONE.md; sweep before packaging |

## Known issues and limitations

- No live question path yet; the Questions board is empty.
- Page citations are section page ranges, not per-clause pages (the RFP gives only ranges); stated, not hidden.
- Retrieval is lexical; vocabulary misses are patched one at a time (K5, K25) and will recur on new phrasing until semantic retrieval is added.
- The local model last measured 14/18 before twelve later fixes; needs a re-run before quoting.
- A local editor config outside this repo was modified to run the harness; revert when done.

## Verdict at T+2h

The engine is ahead of where a 6-8 hour plan would be, and it is well defended. **The submission is behind**: the two highest-weight deliverables, the live unseen-question path (Part 2) and the ≤10-slide deck (Part 1), are both at zero, and presentation/ is empty, which fails E2 and E8 today. Next block, in order: live question path → key-facts fast path → deck draft → first full rehearsal. Everything else becomes a named slide item, not a build item.

## Release notes since 90402118f6cf (31 commits)

### New
- 10:31 [`94f6429`](https://github.com/flashesofbrilliance/ret-rfp-intelligence/commit/94f6429) ingest, amendment resolver, cited answers, golden eval 18/18
- 10:43 [`d7cd920`](https://github.com/flashesofbrilliance/ret-rfp-intelligence/commit/d7cd920) golden provenance gate, pre-commit, release check; RCA + DoD; K10-K11 (closes K10, K11)
- 10:46 [`45e2618`](https://github.com/flashesofbrilliance/ret-rfp-intelligence/commit/45e2618) generated JOURNEY.md time-to-discovery map; discovered_at (K12) (closes K12)
- 10:57 [`644eb1c`](https://github.com/flashesofbrilliance/ret-rfp-intelligence/commit/644eb1c) evidence ledger + provenance lint; TCO honest rewrite; cited price fix (K13, K14) (closes K13, K14)
- 11:02 [`f869827`](https://github.com/flashesofbrilliance/ret-rfp-intelligence/commit/f869827) plan.json dependency graph + scheduler; HYPOTHESES.md with H3-H5 pre-registered
- 11:04 [`d975927`](https://github.com/flashesofbrilliance/ret-rfp-intelligence/commit/d975927) generated build dashboard from plan.json and flight logs
- 11:06 [`a639a70`](https://github.com/flashesofbrilliance/ret-rfp-intelligence/commit/a639a70) fault injection + mock provider; degrade on provider error (K15, K16) (closes K15, K16)
- 11:24 [`914808b`](https://github.com/flashesofbrilliance/ret-rfp-intelligence/commit/914808b) full-factorial scenario matrix with load-bearing vs vacuous passes; K19-K22; monday platform doc (closes K19, K20, K21, K22)
- 11:32 [`914323a`](https://github.com/flashesofbrilliance/ret-rfp-intelligence/commit/914323a) provenance chain per answer; first-visit walkthrough; one-click sample sets
- 11:33 [`3222c2c`](https://github.com/flashesofbrilliance/ret-rfp-intelligence/commit/3222c2c) moves_metric on every node; shown in the deck's ticket detail
- 11:41 [`0b128ce`](https://github.com/flashesofbrilliance/ret-rfp-intelligence/commit/0b128ce) GraphQL client (pinned version, 200-errors, budget logging); first live call; token node done
- 11:47 [`32b4a6f`](https://github.com/flashesofbrilliance/ret-rfp-intelligence/commit/32b4a6f) live monday boards, idempotent upserts, diff-before-write, template-row cleanup (K23, K24) (closes K23, K24)

### Fixed
- 11:16 [`938089b`](https://github.com/flashesofbrilliance/ret-rfp-intelligence/commit/938089b) no silent no-change on revisions; unresolved amendments flag answers (K17, K18); H3 scored (closes K17, K18)
- 12:05 [`0426b55`](https://github.com/flashesofbrilliance/ret-rfp-intelligence/commit/0426b55) stemming, keep verified context on refusals, revert hedging prompt (K25-K27); wave 2 12/12; deck auto-refresh (closes K25, K26, K27)
- 12:11 [`3ed5e35`](https://github.com/flashesofbrilliance/ret-rfp-intelligence/commit/3ed5e35) expand K-ranges in release notes; regenerate T+2h
- 12:18 [`c8dfc23`](https://github.com/flashesofbrilliance/ret-rfp-intelligence/commit/c8dfc23) ship snapshots/ (pulse checks + release notes were missing from the ZIP)

### Tests and gates
- 10:40 [`c7150b1`](https://github.com/flashesofbrilliance/ret-rfp-intelligence/commit/c7150b1) M1 30K deterministic fuzz, 0 failures after K9 harness fix; ex-ante scored (closes K9)
- 12:09 [`fbe8360`](https://github.com/flashesofbrilliance/ret-rfp-intelligence/commit/fbe8360) seam regression tests + mutation check + per-case baseline; path-triggered eval gate (K28) (closes K28)

### Docs and evidence
- 10:32 [`267a9f4`](https://github.com/flashesofbrilliance/ret-rfp-intelligence/commit/267a9f4) seam ledger K1-K8, own errors logged with repair and heading change (closes K1, K2, K3, K4, K5, K6, K7, K8)
- 10:37 [`407f1f2`](https://github.com/flashesofbrilliance/ret-rfp-intelligence/commit/407f1f2) planning notes: Monte Carlo split by cost, OSS conventions
- 10:51 [`e1492e0`](https://github.com/flashesofbrilliance/ret-rfp-intelligence/commit/e1492e0) briefing video (E8 PDF constraint gated), unit economics per stage
- 10:54 [`904c7db`](https://github.com/flashesofbrilliance/ret-rfp-intelligence/commit/904c7db) year-one TCO with labeled assumptions, sensitivity, loop backlog
- 10:58 [`f095ef6`](https://github.com/flashesofbrilliance/ret-rfp-intelligence/commit/f095ef6) market and resources water line (public sources, verification marked per row)
- 11:42 [`3f4effc`](https://github.com/flashesofbrilliance/ret-rfp-intelligence/commit/3f4effc) monday API analytics is Enterprise-gated; own call log is the meter
- 12:11 [`750fefa`](https://github.com/flashesofbrilliance/ret-rfp-intelligence/commit/750fefa) T+2h pulse check with line-by-line rubric and generated release notes

### Data
- 10:24 [`7e3382a`](https://github.com/flashesofbrilliance/ret-rfp-intelligence/commit/7e3382a) Maple Creek RFP package, verbatim from the brief

### Housekeeping
- 10:11 [`9040211`](https://github.com/flashesofbrilliance/ret-rfp-intelligence/commit/9040211) scaffold glass-box flight recorder, rubrics, constraints gate
- 10:37 [`1b0a17a`](https://github.com/flashesofbrilliance/ret-rfp-intelligence/commit/1b0a17a) pre-register M1 predictions before building it
- 12:16 [`22e3dca`](https://github.com/flashesofbrilliance/ret-rfp-intelligence/commit/22e3dca) log updates before history cleanup
- 12:16 [`c92dbf7`](https://github.com/flashesofbrilliance/ret-rfp-intelligence/commit/c92dbf7) log updates before history cleanup (hooks off for this one commit)
- 12:18 [`92d325b`](https://github.com/flashesofbrilliance/ret-rfp-intelligence/commit/92d325b) verifiable history bundle in the ZIP, leak gate, README setup; history cleaned and disclosed (K29) (closes K29)

