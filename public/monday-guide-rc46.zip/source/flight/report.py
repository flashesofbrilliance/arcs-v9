"""Derive the T0 -> TDone audit from the flight log: unit economics per stage, belief trail, grades.

python3 -m flight.report            # markdown to stdout
python3 -m flight.report --check    # exit 1 if any commit since T0 has no span (audit != build log)
"""
import subprocess
import sys
from collections import OrderedDict

from flight.recorder import COST_KEYS, ROOT, STAGES, read_log


def commits():
    out = subprocess.check_output(["git", "-C", ROOT, "log", "--format=%h %s", "--reverse"]).decode()
    return [line.split(" ", 1) for line in out.splitlines() if line]


def economics(spans):
    rows = OrderedDict((s, {k: 0.0 for k in COST_KEYS}) for s in STAGES)
    basis = {s: set() for s in STAGES}
    for sp in spans:
        for k in COST_KEYS:
            v = (sp.get("cost") or {}).get(k)
            if v is not None:
                rows[sp["stage"]][k] += v
        basis[sp["stage"]].add(sp.get("cost_basis", "unknown"))
    return rows, basis


def render(spans):
    out = ["# Flight report: T0 -> now", "", "## Unit economics by stage", "",
           "| stage | spans | in tok | out tok | USD | wall min | human min | basis |",
           "|---|---|---|---|---|---|---|---|"]
    rows, basis = economics(spans)
    for st, r in rows.items():
        n = sum(1 for sp in spans if sp["stage"] == st)
        if not n:
            continue
        out.append("| %s | %d | %d | %d | %.2f | %.1f | %.1f | %s |" % (
            st, n, r["input_tokens"], r["output_tokens"], r["usd"], r["wall_min"], r["human_min"],
            "/".join(sorted(basis[st]))))
    out += ["", "## Belief trail", ""]
    for sp in spans:
        if sp.get("belief_after") or sp.get("belief_before"):
            out.append("- **%s** (%s, %s): %s -> %s" % (
                sp["name"], sp["stage"], sp.get("commit") or "no commit",
                sp.get("belief_before") or "(no prior)", sp.get("belief_after") or "(open)"))
    out += ["", "## Grades", ""]
    for sp in spans:
        g = sp.get("grade")
        if g:
            got = sum(s["score"] for s in g["scores"])
            out.append("- **%s**: %s rubric, %d points" % (sp["name"], g["rubric"], got))
    return "\n".join(out)


def check(spans):
    covered = {sp.get("commit") for sp in spans}
    missing = [(h, s) for h, s in commits() if h not in covered]
    for h, s in missing:
        print("UNTRACED commit %s %s" % (h, s), file=sys.stderr)
    return 1 if missing else 0


if __name__ == "__main__":
    spans = read_log()
    sys.exit(check(spans) if "--check" in sys.argv else print(render(spans)) or 0)
