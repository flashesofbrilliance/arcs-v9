"""Flight recorder: spans modelled on OpenTelemetry's trace, span and parent structure (not OpenTelemetry-compliant), in an append-only JSONL log.

Every unit of build work is a span. A span carries:
  - stage:      analyze | assess | evaluate | synthesize | recapitulate | build
  - belief:     before / after (what changed my mind, and why)
  - evidence:   where it says so (file, page, section, commit)
  - grade:      rubric scores from flight/rubrics.json, each with a reason
  - cost:       unit economics (model tokens, dollars, wall minutes, human minutes)
  - commit:     the git SHA the span produced, so the audit log is 1-1 with the build log

Stdlib only. The log is the source of truth; reports are derived from it, never hand-edited.
"""
import json
import os
import subprocess
import sys
import time
import uuid
from datetime import datetime, timezone

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LOG = os.environ.get("FLIGHT_LOG", os.path.join(ROOT, "flightlog", "trace.jsonl"))
RUBRICS = os.path.join(ROOT, "flight", "rubrics.json")
TRACE_ID = "ret-maple-creek-takehome"
STAGES = ("analyze", "assess", "evaluate", "synthesize", "recapitulate", "build")
COST_KEYS = ("input_tokens", "output_tokens", "usd", "wall_min", "human_min")


def now():
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def read_log():
    if not os.path.exists(LOG):
        return []
    with open(LOG) as f:
        return [json.loads(line) for line in f if line.strip()]


def append(span):
    os.makedirs(os.path.dirname(LOG), exist_ok=True)
    with open(LOG, "a") as f:
        f.write(json.dumps(span, sort_keys=True) + "\n")
    return span


def head_sha():
    try:
        return subprocess.check_output(
            ["git", "-C", ROOT, "rev-parse", "--short", "HEAD"], stderr=subprocess.DEVNULL
        ).decode().strip()
    except subprocess.CalledProcessError:
        return None


def validate_grade(grade):
    """Every score must name a rubric criterion that exists and carry a reason."""
    if not grade:
        return
    with open(RUBRICS) as f:
        rubrics = json.load(f)
    rubric = rubrics.get(grade.get("rubric"))
    if rubric is None:
        raise ValueError("unknown rubric: %r" % grade.get("rubric"))
    known = {c["id"]: c for c in rubric["criteria"]}
    for s in grade.get("scores", []):
        crit = known.get(s.get("criterion"))
        if crit is None:
            raise ValueError("unknown criterion %r in rubric %r" % (s.get("criterion"), grade["rubric"]))
        if not (0 <= s.get("score", -1) <= crit["max"]):
            raise ValueError("score out of range for %r" % s["criterion"])
        if not s.get("reason"):
            raise ValueError("score for %r has no reason; ungrounded grades are not allowed" % s["criterion"])


def record(name, stage, belief_before=None, belief_after=None, evidence=None,
           grade=None, cost=None, parent=None, kind="span", started=None, cost_basis=None,
           discovered_at=None):
    if stage not in STAGES:
        raise ValueError("stage must be one of %s" % (STAGES,))
    validate_grade(grade)
    cost = {k: (cost or {}).get(k) for k in COST_KEYS}
    span = {
        "trace_id": TRACE_ID,
        "span_id": uuid.uuid4().hex[:8],
        "parent": parent,
        "name": name,
        "kind": kind,
        "stage": stage,
        "start": started or now(),
        "end": now(),
        "belief_before": belief_before,
        "belief_after": belief_after,
        "evidence": evidence or [],
        "grade": grade,
        "cost": cost,
        # measured | estimated | unknown: never present an estimate as a measurement
        "cost_basis": cost_basis or ("unknown" if all(v is None for v in cost.values()) else "estimated"),
        "commit": head_sha(),
        # when the finding happened, if logged later (K12); None means logged as it happened
        "discovered_at": discovered_at,
    }
    return append(span)


class span:
    """Context manager that times wall minutes for a block of work."""

    def __init__(self, name, stage, **kw):
        self.name, self.stage, self.kw = name, stage, kw

    def __enter__(self):
        self.t0, self.started = time.time(), now()
        return self

    def __exit__(self, *exc):
        cost = dict(self.kw.pop("cost", {}) or {})
        cost.setdefault("wall_min", round((time.time() - self.t0) / 60, 2))
        record(self.name, self.stage, cost=cost, started=self.started, **self.kw)
        return False


def main(argv):
    """CLI: python3 -m flight.recorder add '<json>'   (one span as a JSON object)"""
    if len(argv) == 2 and argv[0] == "add":
        kw = json.loads(argv[1])
        print(json.dumps(record(**kw)))
        return 0
    print(main.__doc__)
    return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
