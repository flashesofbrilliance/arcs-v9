# Definition of done (deliberately stricter than the brief)

## Tiers

| Tier | Must be true | Enforced by |
|---|---|---|
| **Staged** (before `git commit`) | Every figure in a business claim carries evidence (`[E:<id>]` or `[ASSUMPTION]`; no ratio built on assumptions) (`provenance_lint.py`). Deterministic tests pass: parser coverage, M1 fuzz (1,000 runs, fixed seed), golden provenance check. No secrets in the diff. | `hooks/pre-commit` |
| **Committed** | One flight span per commit; `flight.report --check` passes; any own-error found is in `KINTSUGI.md` in the same commit | `hooks/post-commit`, `flight.report --check` |
| **CI-equivalent** (before tagging a candidate; this repo has no remote CI, so run by hand) | Full golden eval on Claude 18/18; M1 at 30,000 runs; `package.py` passes E1-E3 | `scripts/release_check.sh` |
| **UAT** (the panel's bar, as the client voiced it) | Doug: the amendment is caught, with where it says so. Nina: every answer cited, figures verbatim, "not addressed" when absent, no bid drafting. Sam Ito: payloads logged, no duplicates, parts countable. Elena: key facts on the board the same day. Plus one unseen question answered live through monday.com | Demo rehearsal script, run twice from a clean database |
| **Submitted** | E1-E7 in `CONSTRAINTS.md`, including the human items | `package.py` + Zach's checklist |

## What goes in a commit

| | Always | Sometimes | Never |
|---|---|---|---|
| Commit | Code with its test; the flight span (auto); a KINTSUGI entry if a seam was found | Golden cases added after a miss; glossary entries (each tied to a KINTSUGI row) | Secrets or `.env`; `rfp.db`; edits to `data/` (source files are frozen); a test edited to green without a KINTSUGI entry; generated reports |
| Submission ZIP | `source/` (code, data, flight log, ledgers), `presentation/` | `BACKLOG.md` stays out; `RCA.md` and `KINTSUGI.md` go in | internal tool or personal-platform vocabulary in anything the panel reads; anything from other private repositories; personal data |
| Deploy | Not applicable: this POC runs locally by design (Sam Ito). The only outbound writes are to monday.com and the model API | | Public hosting of the client materials |
