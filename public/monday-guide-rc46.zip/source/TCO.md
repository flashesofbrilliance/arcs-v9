# Total cost of ownership: what we know, and what RET must tell us

Every figure is tagged: `[E:<id>]` is evidence in `evidence/evidence.jsonl` (RET's own numbers, our
measurements, or a cited source); `[ASSUMPTION]` is a placeholder until RET confirms it.
`scripts/provenance_lint.py` blocks any untagged figure, and blocks any ratio built on assumptions
unless the ratio is tagged too. Earlier versions presented guesses as a headline ratio (KINTSUGI K13).

## Known, from evidence

| Line | Value |
|---|---|
| Model calls per year | ~$8 [E:E-cost-per-q] at 180 questions [E:E-questions] x ~12 cycles [E:E-solicitations] |
| Current monday.com relationship | 900 seats, $310K ARR, ~250-seat expansion if the pilot succeeds [E:E-arr-seats] |
| What RET spends today on manual RFP operations | ~$1.6M/yr, target >=50% recovery [E:E-manual-cost] |
| Intake effort today vs target | 650 h vs 150 h per cycle [E:E-intake-hours] |
| Missed or near-missed bid windows | 3 in 24 months [E:E-missed-bids]; value per project not given |

## Unknown: inputs to collect in discovery (the calculator, not a forecast)

| Input | Who knows it | Placeholder until confirmed |
|---|---|---|
| Price per expansion seat | monday.com account team | none; do not average from ARR, tier and discounts differ |
| Fully loaded staff cost per hour | RET finance | $150/h [ASSUMPTION] |
| Review time per AI answer | Doug, Nina (measure it in the pilot) | 2 min [ASSUMPTION] |
| Support effort for Sam Ito's team | Sam Ito | 4 h/month [ASSUMPTION] |
| Hosting | Sam Ito | existing machine, $0 [ASSUMPTION] |
| Value of one competitive project | Elena | none; likely the largest number on the page |

**Formula:** annual cost = seats x seat price + model calls + (review hours + support hours) x staff rate +
hosting. Annual value = intake hours freed x staff rate + Q&A cycle time + avoided missed bids.

**Illustration only:** with the placeholders above and seats excluded, the human lines come to about
136 h/yr, ~$20K at $150/h [ASSUMPTION]. That is a shape, not a finding; no ROI ratio is stated until RET
supplies the inputs.

## Predictive bid/no-bid

~12 bids a year [E:E-solicitations] give ~12 outcome labels a year. A credible model needs n>=30, roughly
2.5 years of labels [ASSUMPTION: the n>=30 bar is our rule, not a law]. Year one is label collection only:
the "Verified by" column on the board. Elena keeps the decision.

## Prioritized backlog for running the loop

| P | Item | Why now |
|---|---|---|
| P0 | Verification column on the board ("Verified by" + verdict) | Every click is a label; nothing downstream can be measured without it |
| P0 | Queue for amendments the rules could not classify, owned by Nina | The one path where the system says "a human must decide" |
| P1 | Key-facts fast path (no model call) | Fewer calls, and the most common questions never leave RET |
| P1 | Eval rerun on every model or API version change | Catches silent regressions before RET does |
| P2 | Glossary growth from misses | Retrieval learns RET's vocabulary |
| P3 | Predictive bid/no-bid signal | Data collection only until the sample is large enough |
