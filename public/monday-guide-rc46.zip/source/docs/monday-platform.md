# monday.com platform constraints (GraphQL API) for the RFP pipeline

## Method and limits

- **Date:** 2026-10-10. Sources are pages on developer.monday.com, fetched as raw `.md` starting from the index at https://developer.monday.com/api-reference/llms.txt. Most pages show `updatedAt` 2026-09-06; the auth, sandbox and MCP pages show 2026-10-06 to 2026-10-08.
- **Pages read:** 39 fetches: the index, 37 doc and reference pages, and one re-fetch. That is over the budget of about 30, because confirming the exact `ColumnType` enum and the cursor lifetime each took an extra page.
- **No API calls were made.** Nothing here was tested against a live account. Every number comes from the docs.
- **What I could not verify (marked UNVERIFIED below):**
  - https://monday.com/w/mcp and the support.monday.com MCP articles. I did not open them.
  - Whether a local or self-hosted MCP server exists. The docs link `github.com/mondaycom/mcp`, which I did not open.
  - Whether the developer account has its own daily call limit.
  - Whether the `2026-10` version changed from release candidate to current on 2026-10-01. The versioning page still shows `2026-07` as current, but its own schedule says `2026-10` becomes current on Oct 1, 2026.
  - Whether a webhook URL must be publicly reachable. The docs never say "public". It follows from monday's servers POSTing to the URL, so I mark it *derived*.
- Abbreviations used below: **RC** (release candidate, the unstable preview API version), **MCP** (Model Context Protocol, a standard way for AI agents to call tools), **UTC** (Coordinated Universal Time).

---

## 1. Auth and versioning

| Fact | Value | Source |
|---|---|---|
| Endpoint | `POST https://api.monday.com/v2` with a JSON body `{"query": ...}` | https://developer.monday.com/api-reference/docs/authentication.md |
| Token header | `Authorization: <personal V2 token>`. The raw token, **no `Bearer` prefix** in the docs example. | same |
| Token permissions | A personal token mirrors the user's UI permissions and has all scopes. App tokens have explicit scopes. | same |
| Token regeneration | Regenerating a token invalidates the old one immediately. | same |
| Version header | `API-Version: 2026-07` (example in the docs). Every response echoes the `API-Version` header. You can also query `version { kind value }`. | https://developer.monday.com/api-reference/docs/api-versioning.md |
| Default version | If you send no header, you get the **Current** version, which can change under you each quarter. Production apps are told to pin a version. | same |
| Versions as shown on the page | `2026-04` Maintenance · `2026-07` Current · `2026-10` RC | same |
| Schedule from the same page | `2026-10`: RC Jul 1 2026 → Current **Oct 1 2026** → Maintenance Jan 15 2027. `2026-07`: Current Jul 1 2026 → Maintenance Oct 1 2026. `2027-01` is RC from Oct 1 2026. UNVERIFIED which label applies today; check with `query { versions { ... } }` at runtime. | same |
| Stability | RC is unstable and not for production. Current and Maintenance are stable. Each stable version holds for at least 6 months. Deprecation is announced at least 6 months ahead. | same |

```bash
curl -X POST https://api.monday.com/v2 \
-H "Authorization: xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx" \
-H "Content-Type: application/json" \
-d '{"query": "query { me { id name } }"}'
```

## 2. Rate limits

Source for every row except the error rows: https://developer.monday.com/api-reference/docs/rate-limits.md

| Limit | Value |
|---|---|
| Complexity per single query | 5,000,000 points |
| Complexity per minute, personal token | 10M points combined for reads and writes. **1M for trial, NGO and free accounts.** |
| Complexity per minute, app token | 5M for reads and 5M for writes |
| Complexity window | Sliding window. It resets 60 s after the first call. |
| Daily calls (reset at midnight UTC) | Free/Standard/Basic **1,000** · Pro 10,000 · Enterprise 25,000. Hosted MCP calls count toward this. |
| Daily-call accounting | A call that hits a rate limit costs 0.1 call. A `complexity`-only query costs 0.1. A high-complexity query can cost more than 1 call. |
| Requests per minute | Enterprise 5,000 · Pro 2,500 · Other 1,000 |
| Endpoint-specific limits | `create_board` 40/min · duplicate board 40/min · duplicate group 40/min · `items` query 100 items · `display_value` on formula columns 10,000/min |
| Concurrency | Enterprise 250 · Pro 100 · Other 40 concurrent requests |
| IP limit | 5,000 requests per 10 seconds per IP |
| Developer account complexity | "API complexity: 10M" (https://developer.monday.com/api-reference/docs/developer-sandbox.md). Its daily call tier is UNVERIFIED. |
| Failed requests | Failed requests still count toward the limits. |

**How to read your remaining budget**

1. Add the `complexity` field to the query itself. Its fields are `before`, `query`, `after` and `reset_in_x_seconds` (https://developer.monday.com/api-reference/reference/complexity.md):
   ```graphql
   mutation {
     complexity { query before after }
     create_item(board_id:1234567890, item_name:"test item") { id }
   }
   ```
2. Read the response headers. Every response carries `RateLimit-Policy` and `RateLimit` in the IETF structured format, with policies `minuteRate`, `concurrency` and `complexityMinute`. `r` is the remaining quota and `t` is seconds until reset.
   ```
   RateLimit: "minuteRate";r=0;t=38, "concurrency";r=249, "complexityMinute";r=4950000;t=45
   ```

**Retry behaviour**

- Every rate-limit error returns a `retry_in_seconds` field. Wait that long before retrying (rate-limits.md).
- Errors also carry a `Retry-After` header (https://developer.monday.com/api-reference/docs/error-handling.md).
- The official SDK retries automatically.

**Error codes when you hit a limit** (error-handling.md and rate-limits.md):

| Code | HTTP status | Meaning |
|---|---|---|
| `ComplexityException` | (status not shown on the page I read) | Hit the complexity limit (rate-limits.md) |
| `COMPLEXITY_BUDGET_EXHAUSTED` | 429 | Per-minute complexity budget used up |
| `DAILY_LIMIT_EXCEEDED` | not shown | Daily call cap reached |
| `Rate Limit Exceeded` (rate-limits.md calls it "Minute limit rate exceeded") | 429 | Too many requests this minute |
| `maxConcurrencyExceeded` | 429 | Too many concurrent requests |
| `IP_RATE_LIMIT_EXCEEDED` | 429 | IP limit |
| `Resource is currently locked, please try again later` | 423 | Board locked by a concurrent update |
| `API_TEMPORARILY_BLOCKED` | 200 | Platform issue |

**Idempotency** (https://developer.monday.com/api-reference/docs/idempotency.md)

- Send an `Idempotency-Key` header on mutations (POST only).
- The response is cached for **30 minutes**. A replay comes back with `Idempotency-Replayed: true`.
- A concurrent duplicate gets `409 IDEMPOTENCY_CONFLICT` plus `Retry-After`.
- Responses over 1 MB are not cached.
- Each user and app pair has a memory budget. Past it, responses run but are not cached.
- Do not use it for 429 retries, because the original request was never processed.

## 3. Pagination

| Fact | Value | Source |
|---|---|---|
| `items_page` | Nested under `boards` or `groups`. `limit` defaults to 25, **max 500**. Returns `cursor` and `items`. A `null` cursor means the end. | https://developer.monday.com/api-reference/reference/items-page.md |
| Cursor vs filters | You cannot send `query_params` and `cursor` in the same request. Filter on the first call, then page with the cursor. | same |
| `next_items_page(cursor, limit)` | Root query. Avoids the cost of nesting under `boards`. | same and https://developer.monday.com/api-reference/reference/items-page-by-column-values.md |
| **Cursor lifetime** | Cached for 60 minutes and "expire[s] 60 minutes after the first request" | https://developer.monday.com/api-reference/reference/next-items-page.md |
| Archived and deleted items | `items_page` returns active items only. For other states, use root `items(ids, state)`, up to 100 IDs. | items-page.md |
| Filter operators | `any_of`, `not_any_of`, `is_empty`, `is_not_empty`, `greater_than(_or_equals)`, `lower_than(_or_equal)`, `between`, `contains_text`, `not_contains_text`, `contains_terms`, `starts_with`, `ends_with`, `within_the_next`, `within_the_last` | https://developer.monday.com/api-reference/reference/items-page-other-types.md |
| Sort by time | `order_by` accepts `column_id: "__creation_log__"` or `"__last_updated__"` | same |
| Board size | `ItemsLimitationException`: "limit of 10,000 items per board" | error-handling.md |

```graphql
query {
  next_items_page(
    cursor: "MSw5NzI4MDA5MDAsaV9YcmxJb0p1VEdYc1VWeGlxeF9kLDg4MiwzNXw0MTQ1NzU1MTE5"
    limit: 50
  ) { cursor items { id name } }
}
```

## 4. The mutations and queries we need

| Operation | Exact signature or arguments from the docs | Notes | Source |
|---|---|---|---|
| `create_board` | `board_name: String!`, `board_kind: BoardKind!` (`private` \| `public` \| `share`), plus optional `board_owner_ids`, `board_owner_team_ids`, `board_subscriber_ids`, `item_nickname`, … | **40 per minute.** The creator is added as owner automatically. | https://developer.monday.com/api-reference/reference/boards.md |
| `create_group` | `board_id: ID!`, `group_name`, plus optional `group_color` (hex), `relative_to`, `position_relative_method` | | https://developer.monday.com/api-reference/reference/groups.md |
| `create_column` | `board_id: ID!`, `column_type: ColumnType!`, `title`, plus optional `description`, `after_column_id`, `defaults: JSON` (checked against `get_column_type_schema`), `capabilities` | The `ColumnType` enum includes `status`, `text`, `long_text`, `numbers`, `date`, `dropdown`, `link`, `dependency` and `people`. | https://developer.monday.com/api-reference/reference/columns.md, https://developer.monday.com/api-reference/reference/columns-other-types.md |
| `create_item` | `board_id: ID!`, `item_name`, plus optional `group_id: String`, `column_values: JSON`, `create_labels_if_missing: Boolean` | Item names must be 1–255 characters (`ItemNameTooLongException`). | https://developer.monday.com/api-reference/reference/items.md, error-handling.md |
| `change_multiple_column_values` | `board_id: ID!`, `item_id: ID`, `column_values: JSON!`, `create_labels_if_missing: Boolean` | Accepts simple string values, JSON values, or a mix. **Required** for dependency and connect-boards columns. | columns.md |
| `create_update` (comment) | `body: String!`, plus optional `item_id: ID`, `parent_id: ID` (for a reply), `mentions_list`, `original_creation_date` (DD-MM-YYYY) | | https://developer.monday.com/api-reference/reference/updates.md |
| `items_page_by_column_values` | Root query. `board_id: ID!`, `columns: [{column_id, column_values}]`, `limit` (max 500), `cursor` | **Text matches the entire value, case-insensitive.** Supported column types include text, long text (exact match), numbers, status (label text), date (one `YYYY-MM-DD`), dropdown, link and people. **Not supported:** item ID, auto number, formula, creation log, last updated, tags, mirror, connect boards, and others. | items-page-by-column-values.md |

**Column value formats.** The value passed in `column_values` is a JSON string. These are the docs' own examples, copied from each column page (https://developer.monday.com/api-reference/reference/{status,text,long-text,number,date,dropdown,link,people,dependency}.md):

| Column type | Write format |
|---|---|
| status | `{"status": {"label": "Done"}}` or `{"status": {"index": 1}}`. The simple form `{"status": "Done"}` also works in `change_multiple_column_values` (columns.md). |
| text | `{"text": "Sample text"}` |
| long_text | `{"long_text": {"text": "This is a detailed description.\nWith a second line."}}` |
| numbers | `{"numbers": "42.5"}` (the number is sent as a string) |
| date | `{"date": {"date": "2026-06-15", "time": "09:00:00"}}`. The simple form is `"YYYY-MM-DD"` with an optional `" HH:MM:SS"`. **Times are UTC.** The API's `time` and `text` fields come back in the caller's time zone. |
| dropdown | `{"dropdown": {"labels": ["Marketing", "Design"]}}` or `{"dropdown": {"ids": [1, 2]}}` |
| link | `{"link": {"url": "https://monday.com", "text": "Go to monday!"}}` |
| people | `{"people": {"personsAndTeams": [{"id": 48202303, "kind": "person"}]}}` |
| dependency | `{"dependent_on": {"item_ids": ["9876543210"]}}` (the key is the column ID) |
| clear any column | `{"<col>": null}` |

```graphql
mutation {
  change_multiple_column_values(
    item_id: 1234567890
    board_id: 9876543210
    column_values: "{\"status\":{\"index\":1},\"date4\":{\"date\":\"2021-01-01\"},\"person\":{\"personsAndTeams\":[{\"id\":9603417,\"kind\":\"person\"}]}}"
  ) { id }
}
```

**Dependency column** (https://developer.monday.com/api-reference/docs/working-with-dependency-column.md, https://developer.monday.com/api-reference/reference/dependency.md):

- Dependencies link items on the **same board**.
- They can only be set with `change_multiple_column_values`. `change_simple_column_value` is not supported.
- Column settings include `boardIds` and `dependency_mode` (`flexible` or `strict`). The mode only matters if the board also has a Date or Timeline column.

## 5. Webhooks

Source for every row: https://developer.monday.com/api-reference/reference/webhooks.md

| Fact | Value |
|---|---|
| Subscribe | `create_webhook(board_id: ID!, url: String! (max 255 chars), event: WebhookEventType!, config: JSON)`. Requires the `webhooks:write` scope. |
| Events | `change_column_value`, `change_status_column_value`, `change_specific_column_value`, `change_name`, `create_item`, `item_archived`, `item_deleted`, `item_moved_to_any_group`, `item_moved_to_specific_group`, `item_restored`, `create_update`, `edit_update`, `delete_update`, `create_column`, and subitem variants |
| Challenge handshake | monday POSTs `{"challenge": "<token>"}` to the URL. You must echo the same JSON back. |
| Retry | Once a minute for 30 minutes |
| Authentication | A signed JWT in the `Authorization` header is sent only when the webhook was created with an integration **app** OAuth token. |
| Public URL needed? | *Derived:* yes. monday's servers must reach the URL to send the challenge and the events. The page does not use the word "public". |

```graphql
mutation {
  create_webhook (board_id: 1234567890, url: "https://www.webhooks.my-webhook/test/", event: change_status_column_value, config: "{\"columnId\":\"status\", \"columnValue\":{\"$any$\":true}}") {
    id
    board_id
  }
}
```

**Alternatives for a local-only app that does not use webhooks**

| Approach | What the docs give you | Source |
|---|---|---|
| `items_page` filtered on `__last_updated__` | Values are `TODAY`, `YESTERDAY`, `THIS_WEEK` or `LAST_WEEK` with `compare_attribute: "UPDATED_AT"`. **Day-level granularity, not a timestamp.** Results depend on the calling user's time zone and week settings. | https://developer.monday.com/api-reference/reference/last-updated.md |
| `items_page` filtered on `creation_log` | `between` on `["YYYY-MM-DD","YYYY-MM-DD"]` with `CREATED_AT`. Also day-level. | https://developer.monday.com/api-reference/reference/creation-log.md |
| Board `activity_logs(from, to, column_ids, group_ids, item_ids, user_ids, limit, page)` | Takes **ISO8601 timestamps**. Returns results newest first, up to 10,000 logs. `limit` defaults to 25. The page points to the `2026-07` version requirement for user-level logs. | https://developer.monday.com/api-reference/reference/activity-logs.md |
| Sort by `__creation_log__` descending and stop at the last item ID you saw | Sort is supported. Using item IDs as a watermark is my own *derived* idea, not a documented pattern. | items-page-other-types.md |

## 6. Developer account (sandbox)

Source for every row: https://developer.monday.com/api-reference/docs/developer-sandbox.md

| Fact | Value |
|---|---|
| Cost and separation | Free. Separate from production data. For "development and testing only", not production. |
| Seats | Up to 10 |
| **Items** | **Up to 1,000 items per product** |
| Boards, dashboards, docs | Unlimited |
| Automations and integrations | 25,000 actions per month each |
| API complexity | 10M |
| Products and columns | All products and all column types. Activity log included. |
| More capacity | Request through the partner extensions form. Reviewed within 5 business days. |
| Expiry | Not stated on the page. UNVERIFIED. |
| Daily call limit | Not stated. The Free tier gets 1,000 per day (rate-limits.md). Whether that applies here is UNVERIFIED. |
| Separate test environment | No separate API host is documented. It is a separate account on the same `api.monday.com/v2` (derived from authentication.md). |

## 7. monday MCP server

| Fact | Value | Source |
|---|---|---|
| What it is | The "Platform MCP": a hosted MCP server run by the monday AI team. It wraps the GraphQL API. Each tool call runs as a GraphQL request with the user's permissions. | https://developer.monday.com/api-reference/docs/mondaycom-mcp.md |
| Hosted URL and transport | `https://mcp.monday.com/mcp`, Streamable HTTP only. The SSE (Server-Sent Events) transport and the `/sse` path are deprecated and unsupported. | https://developer.monday.com/api-reference/docs/integrate-with-monday-mcp.md |
| Local option | "No local setup is required." The page links `github.com/mondaycom/mcp`, which I did not open. Whether a local or self-hosted mode exists is UNVERIFIED. | mondaycom-mcp.md |
| Auth | A personal API token as a Bearer token (personal use and testing, no admin approval), your own OAuth app, pre-approved clients, or dynamic client registration with admin approval | integrate-with-monday-mcp.md |
| Version pin | Send an `Api-Version` header in the MCP client config | same |
| Tools | More than 60 tools. Examples: `create_board`, `get_board_info`, `get_board_items`, `get_board_activity`, `create_group`, `create_column`, `create_item`, `change_item_column_values`, `create_update`, `get_updates`, `all_monday_api` (runs any GraphQL), `get_graphql_schema`. Call `tools/list` for the current set. | https://developer.monday.com/api-reference/docs/platform-mcp-tools.md |
| Limits | MCP calls count toward the **daily API call limit** | mondaycom-mcp.md, rate-limits.md |
| https://monday.com/w/mcp and the support articles | Not opened. UNVERIFIED. | |

## 8. Errors

Source: https://developer.monday.com/api-reference/docs/error-handling.md

**Response shape**

- Application errors come back as **HTTP 200** with an `errors[]` array. Each entry has `message`, `locations`, `path` and `extensions.code`, and may include `extensions.status_code` and `error_data`.
- Partial `data` can come back alongside the errors.
- Each response includes a `request_id` in `extensions`. The response also carries `account_id`.
- Transport errors use 4xx and 5xx codes.

**So the client must check `errors` on every 200 response.**

| Code | HTTP | Meaning and what to do |
|---|---|---|
| `ColumnValueException` | 200 | Bad column value format. Check the column's data structure. Use `change_multiple_column_values` for connect-boards columns. |
| `CorrectedValueException` | 200 | Wrong value type for the column |
| `InvalidArgumentException` | 200 | Bad argument, or you hit a pagination limit |
| `InvalidBoardIdException` / `InvalidColumnIdException` / `InvalidUserIdException` | 200 | The ID does not exist or you lack access |
| `InvalidVersionException` | 200 | Bad `API-Version` value |
| `ItemNameTooLongException` | 200 | Item name must be 1–255 characters |
| `ItemsLimitationException` | 200 | More than 10,000 items on one board |
| `ResourceNotFoundException` | 200 or 404 | The ID does not exist, or a column was deleted |
| `Parse error on...` | 200 | Malformed query |
| `JsonParseException` | 400 | Invalid JSON |
| `Unauthorized` | 401 | Bad or missing token |
| `UserUnauthorizedException` | 403 | The user lacks permission |
| `USER_ACCESS_DENIED` | 403 | The user is inactive, view-only, or has an unconfirmed email |
| `IDEMPOTENCY_CONFLICT` | 409 | A duplicate request is still in flight |
| Locked resource | 423 | Retry after a short delay |
| Rate and complexity limits | 429 | See section 2 |
| `Internal Server Error` | 500 | Often caused by bad IDs or malformed column JSON. Retry. |

## 9. Implications for our build

Every bullet below is *derived* from the cited rows above.

1. **Pin `API-Version` explicitly** (§1). Pin `2026-07`, which the docs list as Current and every example uses. Check `query { version { kind value } }` at startup and log it. Plan to move to `2026-10` before `2026-07` reaches end of life. Never send an RC version from production.
2. **Expect a free or dev account to allow only 1,000 calls per day, and treat that as the binding limit** (§2, §6). It binds well before complexity does. A 30 s poll alone is 2,880 calls a day. So poll at 60–120 s or slower, combine reads and writes into multi-operation GraphQL documents, and track daily usage locally.
3. **Plan within a 1M complexity budget per minute on free or trial accounts** (§2). Include `complexity { before after reset_in_x_seconds }` in every request. Read the `RateLimit` header and throttle when `r` gets low. On a 429, sleep for `retry_in_seconds` or `Retry-After`; never use a fixed backoff.
4. **Make upserts idempotent with a key column** (§4). Use a **text** column holding a stable external key, such as an RFP question hash. `items_page_by_column_values` matches the entire text value case-insensitively, so it works as a key lookup. Item ID and auto-number columns are not searchable this way. Also send an `Idempotency-Key` header derived from the record key on each `create_item` and `create_update`. It protects for 30 minutes only, so the key-column lookup is the lasting guard.
5. **Write answers in one call per item** (§4). Use `change_multiple_column_values` to set status, link and long_text together, then one `create_update` for the cited answer body. Do not use `create_labels_if_missing`. Create status and dropdown labels once at board setup so a typo fails loudly as a `ColumnValueException`.
6. **Treat every HTTP 200 as possibly failed** (§8). Parse `errors[]` and log `extensions.code` and `request_id`. Retry only on 429, 423, 5xx and network timeouts. Never retry on `ColumnValueException` or `Invalid*Exception`.
7. **Use a polling watermark, not the `__last_updated__` filter** (§5). That filter only works by day. For a timestamp watermark, use board `activity_logs(from: <last_seen_ts>)`. Or filter a "New" status or group and flip the status once an item is picked up, which also stops double-processing.
8. **Page with at most 500 items per page and re-filter on each poll** (§3). Cursors expire 60 minutes after the first request, so do not store them between poll cycles.
9. **Respect the board limits** (§2, §3, §6): 40 `create_board` calls per minute, 10,000 items per board, and only **1,000 items per product on a dev account**. Create boards once at bootstrap, not per run. Archive or rotate boards if the question volume could approach 1,000 on the sandbox.
10. **Keep dependency links on one board** (§4). Dependencies only link items on the same board and can only be set with `change_multiple_column_values`. Questions and the items they depend on must live on the same board.

---

## 10. monday AI and labs features

**Method and limits.** Researched 2026-10-10 in about 19 page reads.

- **What I could read:**
  - developer.monday.com: the API docs and the apps-framework docs
  - monday.com product pages: `/pricing`, `/w/ai`, `/w/sidekick`, `/w/agents`
- **What blocked me:** **Every support.monday.com page returned HTTP 403** to both curl and WebFetch, so nothing below comes from the help center. The support articles are only linked from the dev docs, never opened.
- **Product pages are marketing copy.** I quote them as claims, not as specifications.
- **Probed and not found (404):** `monday.com/labs`, `/w/labs`, `/w/workflows`, `/w/ai-credits`.

### 10.1 AI columns (AI blocks on boards)

| Fact | Value | Source |
|---|---|---|
| API availability | **Only API version `2026-10` and later.** If we pin `2026-07` (§9 bullet 1), the API cannot configure AI columns. | https://developer.monday.com/api-reference/reference/ai-column.md |
| Configure mutations | `configure_categorize_ai_column`, `configure_summarize_ai_column`, `configure_translate_ai_column`, `configure_improve_text_ai_column`, `configure_extract_ai_column`, `configure_open_block_ai_column`, `configure_write_me_ai_column`. Requires the `boards:write` scope. | same |
| What the AI can read (`source_type`) | `item_name`, `thread` (the item's updates), `column`. Categorize also accepts `emails_and_activities`. **No file or PDF source type is listed.** The open-block and write-me mutations reference columns through `{pulse.column_id}` instead. | same |
| Extract targets | Writes into a `text`, `long_text`, `date`, `email`, `phone` or `link` column. Supports `entity_type: custom` with `custom_instructions` (max 5,000 characters). | same |
| Categorize | Picks only from the target column's existing labels | same |
| Plan tier | The pricing page lists "AI columns" on **Standard** and above, inside the AI credits bundle. Free has "No AI credits", with AI "Available from Basic". | https://monday.com/pricing (marketing) |
| Extract from uploaded files | UNVERIFIED. The support article on AI-powered columns returned 403, and the API docs list no file source. | https://support.monday.com/hc/en-us/articles/18640208769682-AI-powered-columns (403) |

### 10.2 Agents, the agent builder, and the workflow builder

| Fact | Value | Source |
|---|---|---|
| Built-in agents | User-built "work orchestrators" with a profile, a goal and a markdown plan. Lifecycle actions: create, update, activate, run, delete. Created agents start `INACTIVE`. The API is the **dev (preview) schema only**: "There is no stable public GraphQL equivalent yet". | https://developer.monday.com/api-reference/docs/manage-agent.md |
| Early access | Agents require an account with "**Agents enabled** (early-access feature)". Every agent API call must send `API-Version: dev`. | https://developer.monday.com/api-reference/docs/build-an-external-agent.md |
| External (bring-your-own) agent | Two modes. A managed provider ("e.g. a Claude-managed agent"; monday orchestrates the calls). Or a custom webhook agent: monday POSTs a signed event, waits about 30 s for the HTTP reply, and the agent acts through GraphQL with its own `api_token`. **Requires a public HTTPS endpoint.** Triggers: `chat`, `mention`, `assigned`. | same |
| Agent token | Starts with **no** board access. Access must be granted with `add_agent_resource_access`, or the agent must create the board itself. Supports create_item, change_multiple_column_values, items_page_by_column_values and create_update. | https://developer.monday.com/api-reference/docs/agent-api-key-capabilities.md |
| Credits | Connected agents "consume AI credits tracked under the account's usage dashboard" | https://developer.monday.com/api-reference/docs/build-on-monday-with-ai.md |
| Product page claims | Agents "use the docs, PDFs, and boards you define as context". Ready-made agents are listed. The page gives no plan tier, credits or trigger list. "Agent Factory" **does not appear** on the page. | https://monday.com/w/agents (marketing) |
| Pricing | "AI agent workforce" is "Limited" on Basic. The "AI workflow builder" is listed on **Pro**. | https://monday.com/pricing (marketing) |
| Workflow builder (apps side) | monday workflows is a visual builder that combines trigger and action blocks. Custom blocks are app features with **public endpoints the monday apps server calls**. | https://developer.monday.com/apps/docs/monday-workflows.md |
| "Agent Factory" by that name | UNVERIFIED. It is not found on any page I opened. | |

### 10.3 Sidekick and "Dev Sidekick"

| Fact | Value | Source |
|---|---|---|
| What it is | monday's AI assistant or "digital worker". It writes and summarizes, answers questions from board context, **searches the web**, and acts through connected apps. | https://developer.monday.com/apps/docs/sidekick-tool.md |
| Extending it | A "Sidekick tool" app feature: when Sidekick picks the tool, monday calls your block's **Run URL**, which must be a reachable endpoint | same |
| Availability | "available on all monday.com workspaces". The pricing page lists Sidekick in the Basic+ credit bundle. | https://monday.com/w/sidekick, https://monday.com/pricing (marketing) |
| Citations and file reading | Not stated on the product page | https://monday.com/w/sidekick |
| "Dev Sidekick" | UNVERIFIED. The term did not appear on any page I opened. | |

### 10.4 Labs, beta, or early-access program

| Fact | Value | Source |
|---|---|---|
| A "monday Labs" program | **Not found.** `monday.com/labs` and `/w/labs` return 404. UNVERIFIED either way. | probed URLs |
| What *is* documented | Agents are an "early-access feature", and the agent APIs run on `API-Version: dev`. The RC API version gives "early access to the latest features". How to enrol in agents early access is UNVERIFIED (not stated on the pages I read). | build-an-external-agent.md; https://developer.monday.com/api-reference/docs/api-versioning.md |

### 10.5 Apps framework: views, recipes, and hosting

| Fact | Value | Source |
|---|---|---|
| Client-side views (board, item, column and other views) | Built with `mapps`. During development, "The CLI will also create a temporary secure tunnel, so your local app can be accessed by monday.com." | https://developer.monday.com/apps/docs/quickstart-view.md |
| Production view hosting | Uploaded views go on monday's apps CDN, which "does not have authentication". Views are publicly reachable at a random URL. | same |
| Integration recipes and automation blocks | Need public endpoints that monday's server calls | https://developer.monday.com/apps/docs/monday-workflows.md |
| monday code hosting | Regions are US, EU, AU and IL. **Multi-region is for public apps only.** Private apps deploy to the account's region. Apps deployed before August 2024 are on US servers. | https://developer.monday.com/apps/docs/multi-region-feature.md |
| Apps MCP (local) | `npx @mondaydotcomorg/monday-api-mcp -t <token> --mode apps`. It manages apps and is **not** for board data. *Correction to §7:* a local npx package exists. Whether it has a local *data* mode is still UNVERIFIED. | https://developer.monday.com/api-reference/docs/build-on-monday-with-ai.md |
| Can a purely local app use views or recipes without hosting? | *Derived:* **no**, except for development through the `mapps` tunnel. Every documented path (view CDN, block Run URL, webhook) needs a monday-reachable endpoint. | rows above |

### 10.6 Files column and uploading the RFP PDF

| Fact | Value | Source |
|---|---|---|
| Upload mutation | `add_file_to_column(item_id, column_id, file: File!)` sent as **multipart/form-data** to `https://api.monday.com/v2/file`, not to `/v2` | https://developer.monday.com/api-reference/reference/files-1.md |
| Size limit | "files up to 500 MB" | https://developer.monday.com/api-reference/reference/assets-1.md |
| Behaviour | **Appends**; it does not replace. To replace, clear the column first. The JSON column mutations only support `clear_all` on file columns. | files-1.md |
| Reading files back | `asset.public_url` is valid for **1 hour**. Files can be read but **not filtered** with `items_page`. | same |
| `add_file_to_update` | Not checked. UNVERIFIED. | |

```graphql
mutation ($file: File!) { add_file_to_column(item_id: 1234567890, column_id: "files", file: $file) { id } }
```

### 10.7 Are AI features metered separately (AI credits)?

| Fact | Value | Source |
|---|---|---|
| Credits per plan | Free: none. Basic: 1,000/month. Standard: 2,000/month. Pro: 3,000/month. Enterprise: custom. "Need more? Add credits anytime". The plan breakdown prices credits at "1,000 credits = $10". | https://monday.com/pricing (marketing; read through WebFetch summarisation, so check the exact wording) |
| Agents | Consume AI credits | build-on-monday-with-ai.md |
| Developer account | The sandbox page lists "Free plan" features plus extras and **does not mention AI credits**. UNVERIFIED. | https://developer.monday.com/api-reference/docs/developer-sandbox.md |
| Trial account | UNVERIFIED (support pages 403) | |
| API calls vs AI credits | Separate meters. The pricing page lists API calls per day separately from AI credits (Standard 1,000/day; Pro 10,000; Enterprise 25,000). That **contradicts rate-limits.md**, which puts Standard at 1,000 together with Free and Basic. They agree on 1,000/day for Standard. For Basic the pricing page lists no limit. | https://monday.com/pricing; rate-limits.md |

### 10.8 Verdict

How the native AI features conflict with two stakeholder rules:

- **Nina's verbatim-citation rule:**
  - Native AI columns summarize, categorize, extract and write.
  - **No page I read documents source citations or verbatim quoting.**
  - Extract runs on columns and threads only, not on the PDF.
  - Their output is model text written into a cell. It cannot be traced back to a clause.
- **Sam Ito's data-residency preference:**
  - Every native AI feature, agent and Sidekick runs inside monday's cloud through unnamed "leading AI models". Sidekick also **searches the web**.
  - Uploading the RFP PDF puts the document in monday's storage.
  - The only region control documented is monday code multi-region, and it applies to public apps only.

| Feature | Stakeholder need it fits | Risk | Recommend |
|---|---|---|---|
| API writes from our local pipeline (§4: column values, `create_update` with verbatim quote and page) | Nina (citations, no guessing), Elena (same-day facts), Sam (only the final answers leave the environment) | Answers still end up stored in monday | **Use in POC** |
| `add_file_to_column` for the RFP PDF | Nina (a reviewer can open the source next to the answer) | **The full document leaves RET's environment** (Sam). Public URLs last 1 hour. | **Avoid by default.** Store a link or document hash instead. Upload only if Sam signs off. |
| AI column, extract or summarize | Elena (quick facts on the board) | No citations (conflicts with Nina). Needs API `2026-10`. Standard tier or higher. Uses AI credits. Data processed by monday's AI (conflicts with Sam). | **Mention as rollout path** for non-citable triage only, never for the answer |
| AI column, categorize (e.g. question type or urgency) | Doug (routing, possibly flagging amendment items) | Can only pick existing labels. Output can't be verified. Credits and tier. | **Mention as rollout path** |
| monday agents or external agent | Elena (automatic run on a new item) | Early access, `API-Version: dev`, no stable API. Needs a public HTTPS endpoint (conflicts with a local-only setup). Uses credits. | **Avoid in POC.** Mention as a rollout path once there is a hosted endpoint. |
| Sidekick or a Sidekick tool | Elena (ask questions about the board) | Web search mixes in outside sources (conflicts with Nina). A tool needs a public Run URL. | **Avoid**, or mention only as a user-side convenience |
| Workflow builder or automation blocks | Doug (detect a new or amended item and route it) | Custom blocks need public endpoints. Workflow builder is Pro tier. | **Mention as rollout path.** Native no-code automations (status change → notify) are fine to show. |
| Board, item or column views (apps framework) | Nina (a side-by-side citation viewer) | Production views are served from an unauthenticated CDN. Local use needs the `mapps` tunnel. | **Mention as rollout path** |
| "Labs" program, Agent Factory, Dev Sidekick | none confirmed | Could not verify that they exist | **Do not mention** until confirmed |
