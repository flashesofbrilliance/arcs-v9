# Large RFP test-document candidates (SAM.gov)

Researched 2026-10-10. Report only: no file was downloaded. Facts come from SAM.gov's public JSON endpoints (the SAM.gov web UI is JavaScript-rendered and was not used). Individual points of contact are deliberately omitted.

Source URLs actually opened:
- [S1] Search: https://sam.gov/api/prod/sgs/v1/search/?index=opp&q=W912P525RA001&page=0&sort=-modifiedDate&mode=search&is_active=false
- [S2] Notice record: https://sam.gov/api/prod/opps/v2/opportunities/4d6854dea66341debd33166188c6dab6
- [S3] Attachment list: https://sam.gov/api/prod/opps/v3/opportunities/4d6854dea66341debd33166188c6dab6/resources?excludeDeleted=false&withScanResult=false
- Human-facing page (not opened, derived from the notice id): https://sam.gov/opp/4d6854dea66341debd33166188c6dab6/view

## Candidate 1 (TOP PICK): W912P525RA001, Chickamauga Lock Replacement Approach Wall and Decommissioning

- Agency: DoD > Dept of the Army > USACE > LRD > W072 ENDIST Nashville [S1]
- Type / NAICS: Solicitation (RFP), unrestricted; NAICS 237990 Other Heavy and Civil Engineering Construction; estimated value $250M to $500M; single FFP contract, base plus 3 options [S2]
- Related notices: Special Notice posted 2025-01-06; Presolicitation posted 2025-01-17 [S1]
- Base RFP posted: 2025-02-05 (attachment date) [S3]. The notice record's postedDate shows 2025-07-15, which is the date of the latest amendment (0007) [S2]
- Response deadline: 2025-08-01 11:00 AM Central (final, per A0006; A0007 confirms no further extension) [S2]. Status: closed (is_active=false search) [S1]
- Seven SF-30 amendments, two of which extend the proposal due date [S2]

### Base RFP files (posted 2025-02-05) [S3]
| Filename | Bytes | Access |
|---|---|---|
| W912P525RA001_final_04Feb2025.pdf | 1,110,090 | public |
| Instructions to Offerors and Procedures for Submission of Offerors and Proposal Evaluation Approach.pdf | 440,867 | public |
| CKL Approach Wall and Decommissioning.xlsx (price schedule) | 197,494 | public |
| DBA WD TN20250145 03Jan2025 (Hamilton County TN Heavy Construction).pdf | 55,415 | public |
| JA for Brand Name CKL AWD_signed ssw_Redacted.pdf | 2,020,572 | public |
| Watts Bar Map.pdf | 5,340,878 | public |
| US Citizens Security Access Form.pdf / Foregin National Contractor Security Access Form.pdf | 135,206 / 91,318 | public |
| W912P5-25-R-A001_TSpecs_AWD_RTA_01FEB2025.pdf (technical specs) | 38,125,869 | CONTROLLED |
| W912P5-25-R-A001_TPlans_AWD_Folio-1..5_RTA_29JAN2025.pdf (plans, 5 files) | 24.9M / 22.2M / 8.0M / 22.1M / 5.4M | CONTROLLED |

Page counts: not shown for any file (the API exposes size only).

### Amendments (SF-30 file, change summary file, what changed) [S2][S3]
| Amd | Posted | SF-30 filename (bytes) | Other public files | What it changes [S2] |
|---|---|---|---|---|
| 0001 | 2025-02-20 | W912P525RA001 A0001 SF 30_final 20 Feb 25.pdf (3,442,257) | W912P525RA001 Amendment 0001 Changes_20Feb2025.pdf; Instructions ..._REV1.pdf; CKL Approach Wall and Decommissioning_2025-02-13.xlsx | Adds FIO drawings to DFARS 252.236-7001, removes PLA requirement (Class Deviation 2025-O0002), moves site visit to 04 Mar 2025, virtual pre-proposal 20 Feb |
| 0002 | 2025-03-20 | W912P525RA001 A0002 SF30_final 20 Mar 25.pdf (3,449,341) | Chickamauga Lock AWD RFP Amendment 0002 Letter_signed ssw.pdf (posted 2025-03-12) | **Extends proposals 07 Apr 2025 2:00PM CT -> 08 Jul 2025 11:00AM CT**; question deadline 16 May; second site visit 02 Apr |
| 0003 | 2025-04-01 | W912P525RA001 A0003 SF30_final 01Apr2025.pdf (3,483,019) | W912P525RA001 Amendment 0003 Changes_Updated 28MAR2025.pdf; CKL Approach Wall and Decommissioning_ 03282025.xlsx | Revised plans/specs and price schedule (adds line item 03-AH35), FAR clause updates per Class Deviations 2025-O0003/O0004 |
| 0004 | 2025-05-13 | W912P525RA001 A0004 SF30_final 13May2025.pdf (3,422,365) | W912P525RA001 Amendment 0004 Changes_29Apr2025.pdf; CKL Approach Wall and Decommissioning_ 04292025.xlsx | Revised plans/specs/price schedule, government Q&A answers |
| 0005 | 2025-05-16 | W912P525RA001 A0005 SF 30_Final_16May2025.pdf (3,407,788) | none | Extends question deadline 16 May -> 06 Jun 2025 |
| 0006 | 2025-06-17 | W912P525RA001 A0006 SF 30_Final_17June2025.pdf (3,437,836) | W912P525RA001 Amendment 0006 Changes_11Jun2025.pdf; Instructions ..._REV2.pdf; CKL Approach Wall and Decommissioning Price Schedule_11JUNE2025.xlsx | **Extends proposals 08 Jul -> 01 Aug 2025 11:00AM CT**; reinstates PLA (new Factor V); questions to 30 Jun; adds GFP item to Section 00 73 00 |
| 0007 | 2025-07-15 | W912P525RA001 A0007 SF 30_Final_15July2025.pdf (3,318,678) | W912P525RA001 Amendment 0007 Changes_10JUL2025.pdf; CKL Approach Wall and Decommissioning Price Schedule_11JULY2025.xlsx | Revised specs/plans/price schedule, Q&A; confirms due date unchanged |

Each amendment also carries CONTROLLED "Contract Specifications" and "Consolidated Sheet Changes" PDFs (e.g. W912P5-25-R-A001_Am6_Consolidated Sheet Changes_11JUN2025.pdf, 15,636,395 bytes) [S3].

### Fit / caveats
- Strengths: real amendment chain (7 SF-30s), two due-date extensions, a clause removed then reinstated (PLA: A0001 vs A0006), revised Instructions to Offerors (REV1, REV2), versioned price schedules. Excellent for testing amendment diffing and "current effective due date" logic.
- Size gap: the PUBLIC base RFP PDF is only ~1.1 MB; page count not shown (UNVERIFIED, likely well under 300 pages). Each SF-30 is ~3.4 MB, suggesting each may reissue substantial content (UNVERIFIED). The 300-600 page bulk (technical specs ~38 MB, plans, FIO drawings) is marked accessLevel=private / "controlled" and requires SAM.gov sign-in plus an approved access request; do not count on it.
- Downloadability: the 2025 notice is archived/inactive, but the API still lists fileExists=1 for all 74 attachments [S3]. Actual download of public files: UNVERIFIED (not attempted, by instruction).
- License: US federal government work, generally public domain under 17 U.S.C. 105. Markings: controlled files are access-restricted (likely CUI/export-controlled; exact marking UNVERIFIED). "The Chickamauga Report (1942).pdf" and FIO files from prior contracts (shop drawings, AACF plans) may include contractor-prepared material: third-party status UNVERIFIED. Public files: no third-party marking seen in metadata (content not inspected, UNVERIFIED).

## Candidate 2: none qualified within budget

Checked W912BV26RA016 (Child Development Center, Tinker AFB, USACE Tulsa; notice id 3beb8482f9eb4abe8b1c5585789972f7, response 2026-10-30): its SAM.gov resources list holds only a site-visit sign-in sheet and PIEE links; the RFP itself is hosted in the PIEE Solicitation Module, not SAM.gov. Not usable. Source: https://sam.gov/api/prod/opps/v3/opportunities/3beb8482f9eb4abe8b1c5585789972f7/resources?excludeDeleted=false&withScanResult=false

Lesson for the next search: many recent DoD construction RFPs (2025-2026) publish the package in PIEE, not as SAM.gov attachments. Civilian agencies (GSA PBS, VA, DOE, Bureau of Reclamation) are more likely to post full public PDFs on SAM.gov. To find one, query the search API above with an agency filter and then check the `/resources` endpoint for large public PDFs and A000N SF-30s.
