# monday.com-native options for RFP intake + cited Q&A

Researched 2026-10-10 from primary sources only (developer.monday.com and monday.com). 21 pages opened; 3 more returned an error (listed at the end). No monday API was called. Quotes are taken from the pages as fetched. **UNVERIFIED** means the source did not confirm the claim.

Stakeholder constraints used to judge fit:
- (C1) every answer cites its source word for word
- (C2) data stays in the client's environment, except final answers
- (C3) few moving parts
- (C4) no portal scraping, no auto-submit, no drafting of bid language

Already established, not researched again: the build is a local stdlib Python pipeline using GraphQL API 2026-07, on a free account. API analytics needs Enterprise. Each write costs 30,000 complexity points. A local poller is used because webhooks need a reachable URL. On the free account the Models API returned 403 insufficient_credits.

---

## 1. Models API in depth

- **Base URL:** "https://api.monday.com/platform-ai-gateway/openai/v1". Authentication is `Bearer <MONDAY_API_TOKEN>`. An app token needs the "`ai:consume`" scope. Source: https://developer.monday.com/api-reference/docs/getting-started-with-the-models-api.md
- **Plan:** "A monday.com **Pro** or **Enterprise** workspace with AI features available for your use case." (same page). The overview page also says "The Models API itself has no separate subscription fee". Source: https://developer.monday.com/api-reference/docs/models-api-overview.md
- **Metering:** usage "draws down monday AI tokens, which are intended to approximate the cost of the underlying model". The `x-monday-credits-used` response header reports usage per call. Sources: overview page and getting-started page.
  - Pricing page credit amounts: Basic "1,000 AI credits / month", Standard "2,000", Pro "3,000", Enterprise "Custom AI credits". Free: AI is "Available from Basic". Source: https://monday.com/pricing
- **Aliases** (source: https://developer.monday.com/api-reference/docs/models-api-supported-models.md):

  | Alias | Model it maps to | Description on the page |
  |---|---|---|
  | `monday-fast` | `claude-haiku-4-5` | "Fast, cost efficient tier" |
  | `monday-standard` | `claude-sonnet-4-6` | the "Default when you omit `model`" |
  | `monday-powerful` | `claude-opus-4-6` | "Highest capability tier" |

  monday "can change which underlying model powers each tier", and the page advises setting `model` explicitly in production.
- **Spend and budget controls:** the overview lists "Set budgets on users and agents" and "Budget and rate limits" as capabilities. It gives no mechanism or values, so the actual controls are **UNVERIFIED**.
- **Fallbacks:** "Clients are not impacted even during an outage" (overview page). How the failover works is **UNVERIFIED**.
- **Data handling, retention and model training:** none of the three Models API pages, nor the changelog, say anything on these topics. Two guessed trust-page URLs (monday.com/w/ai-data-policy and monday.com/trustcenter/privacy/ai) returned 404. All of these points are **UNVERIFIED**.
- **"No new AI vendor review":** the changelog says monday handles "routing to upstream providers (OpenAI and Anthropic)" and that there are "no separate vendor accounts, API keys, or procurement cycles". Source: https://developer.monday.com/api-reference/changelog/consume-ai-models-through-monday.md
  - This removes a *procurement* step. It does not remove the *data-flow* review: RFP text still goes to OpenAI or Anthropic through monday.
  - **Fit:**
    - C1: neutral. The gateway gives no citations, so the local pipeline still has to enforce them.
    - C2: weak. Prompt content leaves the client's environment and goes to an upstream LLM vendor.
    - C3: good. It reuses the monday token and needs no new vendor key.
  - **Risk:** the retention and training terms are not documented on the pages I read. An Enterprise security team would still ask for them. Credible as a "no new contract" path; **not proven** as a "no new review" path.

## 2. run_prompt and other AI GraphQL operations (2026-10)

- **`run_prompt` mutation.** Source: https://developer.monday.com/api-reference/reference/ai.md
  - Availability: "Only available in API versions 2026-10 and later"
  - Scope: "Required scope (apps): AI:Consume"
  - Arguments: `prompt: String!` and optional `config` (`model` such as `MONDAY_STANDARD`, `system_prompt`, `temperature`, `max_tokens`)
  - Returns: only `content: String`. **There are no citation, source or grounding fields.** It is single-turn only. Multi-turn, streaming and tool calling need the Models API.
  - It requires the account's External AI gateway access permission to be enabled.
- **Changes from 2026-07 to 2026-10** (source: https://developer.monday.com/api-reference/docs/release-notes.md):
  - **Breaking changes:**
    - The User migration finishes. Legacy user photo, role and status fields are removed. `Query.users` takes `user_kind`, `sort` and `status` in place of `kind`, `newest_first` and `non_active`.
    - `update_form_tag` is removed.
    - The page lists **no breaking changes for boards, items, updates, files or assets, columns, or docs**.
  - **Additions:**
    - Boards: `change_board_kind`; board automation listing and deletion; duplicating and restoring board views; CSV export (Enterprise).
    - Items: root-level `items_page`; `aggregate_history` and `items_history`.
    - Updates: `search.updates`, which searches updates by body, board, creator and date.
    - Columns: AI column mutations; a `sub_type` field on mirror and lookup inputs.
    - Docs: `search.docs` accepts an `ids` filter.
    - AI: `run_prompt`.
  - Carried over from 2026-07: `Query.users` without `limit` returns only 200 users.
- **Fit:** pinning to 2026-07 loses nothing the pipeline needs. Moving to 2026-10 is low-risk for boards, items, updates and files, and would add `search.updates`, which a reviewer could use to look up past answers. `run_prompt` fails C1 because it has no citation fields. Use it only behind the local citation check, and only on Pro or above.

## 3. Dashboards and widgets via the API

- Available operations (source: https://developer.monday.com/api-reference/reference/dashboards-and-widgets.md):
  - `create_dashboard`, `update_dashboard`, `update_overview_hierarchy`, `delete_dashboard`
  - `create_widget`, `delete_widget`
  - **There is no `update_widget`**: to change a widget you delete it and create it again.
  - No API version is stated (**UNVERIFIED**).
- Widget kinds: `APP_FEATURE`, `BATTERY`, `CALENDAR`, `CHART`, `GANTT`, `LISTVIEW`, `NUMBER`. The `settings` shape depends on the kind; query `all_widgets_schema` first. Source: https://developer.monday.com/api-reference/docs/all-widgets-schema.md
- **Best scorecard set:**
  - `NUMBER` for counts such as answered, cited, and needs SME
  - `BATTERY` for the share of status values (answer status)
  - `CHART` for a breakdown by section
  - `LISTVIEW` for the open-question queue
- **Fit:** good for C3. A dashboard is a one-time setup step, created once by the pipeline or by hand.
- **Risk:** whether multi-board dashboards and dashboard limits work on the free plan is **UNVERIFIED**. The pricing page gives boards-per-dashboard figures only for monday dev and service.

## 4. Native automations and workflows to replace parts of the poller

- **No public GraphQL API for creating automations.** "there is no direct public GraphQL equivalent". Automations are managed in the UI or through the MCP. The example trigger is "When a new item is created"; example actions are "Send a notification" and move to group. Source: https://developer.monday.com/api-reference/docs/create-automation.md
- 2026-10 adds the ability to *list and delete* board automations through GraphQL (release notes, above).
- **Workflows** (cross-board) are created with the MCP `create_workflow` tool, against the "dev (preview) API schema", with "no stable public GraphQL equivalent yet". Source: https://developer.monday.com/api-reference/docs/create-workflow.md
- **"Call a URL" / webhook action:** not documented on these pages, so **UNVERIFIED**. Even if it exists, it needs a reachable endpoint, which the local setup does not have.
- **Tier gates** (source: https://monday.com/pricing):

  | Plan | Automation actions | Integration actions |
  |---|---|---|
  | Standard | "250 actions / month" | "250 actions / month" |
  | Pro | "25,000 actions / month" | "25,000 actions / month" |
  | Enterprise | "Up to 250,000 automation and integration actions per month" | (combined figure) |

  Free and Basic: no automation quota is listed, so **UNVERIFIED**. The support article on automations returned 403.
- **Fit:** a UI-built "when status changes to Needs SME, notify the owner" rule is a good *human-routing* layer. It adds no moving part to the pipeline (C3). It cannot replace the poller's job of pulling RFP text into the local pipeline.

## 5. monday Docs (WorkDocs) as the home for the cited answer

- Mutations (source: https://developer.monday.com/api-reference/reference/docs.md):
  - `create_doc` creates a doc "in a document column or workspace".
  - `add_content_to_doc_from_markdown` takes `docId` and `markdown`, converts the markdown into blocks, and returns `block_ids`.
  - `import_doc_from_html`
  - All three need the `docs:write` scope.
  - The doc-history queries (`doc_version_history`, `doc_version_diff`) need 2026-04 or later.
- Blocks (source: https://developer.monday.com/api-reference/reference/blocks.md):
  - `create_doc_block` types include `quote`, `notice_box`, `table` and `normal_text`.
  - `create_doc_blocks` creates up to 25 blocks at once and needs 2026-07 or later.
  - Table limits conflict on the same page: "up to 25 rows and 10 columns" on create, and a maximum of 5 on update. Treat both as **UNVERIFIED**.
- **Fit:** a `quote` block for the source passage plus `normal_text` for the answer is a strong fit for C1. Doc version history also gives an audit trail.
- **Risk:**
  - Doc writes add an extra object per item, which adds moving parts.
  - The 30,000-point write cost applies per block mutation unless markdown is written in bulk.
  - How to attach a doc to an item's doc column is not documented step by step (**UNVERIFIED**).
- **Recommendation:** keep the per-question cited answer in an item update. Use one doc per RFP as a compiled answer-pack, written with a single `add_content_to_doc_from_markdown` call.

## 6. Update formatting and file columns

- **`create_update`.** Source: https://developer.monday.com/api-reference/docs/create-update.md
  - "The `body` field supports HTML tags for formatting (e.g. `<b>`, `<i>`, `<br>`); do not use Markdown."
  - Mentions go through `mentionsList`, never `@` in the body.
  - Length limits are not stated (**UNVERIFIED**).
  - Whether `<blockquote>` or `<a>` are allowed is **UNVERIFIED**. Test before relying on them; fall back to `<b>Source:</b>` followed by the quoted text.
- **`add_file_to_column`.** Source: https://developer.monday.com/api-reference/reference/files-1.md
  - Uses `https://api.monday.com/v2/file` and "requires a multipart form request".
  - No size limit is stated (**UNVERIFIED**).
  - `add_file_to_update` was not on that page (**UNVERIFIED**).
- **Attaching the source RFP:**
  - It is sensible on the RFP-level item (one file per RFP). It gives reviewers the original document next to the citations.
  - Multipart upload is possible with the Python stdlib (`urllib` plus a hand-built multipart body).
  - **Risk to C2:** this puts the whole RFP inside monday. Do it only if the client's monday tenant counts as "their environment". Otherwise store a path or hash, not the file.

## 7. Apps framework views for the provenance chain

- Feature types include `BOARD_VIEW`, `ITEM_VIEW`, `DASHBOARD_WIDGET`, `AI_ITEM_UPDATE_ACTIONS` and `MCP_SERVER`. Deployment kinds: "CLIENT_SIDE_CODE", "EXTERNAL_HOSTING", "SERVER_SIDE_CODE". Source: https://developer.monday.com/api-reference/reference/features-other-types.md
- Example: `type: ITEM_VIEW` with `deployment kind: CLIENT_SIDE_CODE`. Source: https://developer.monday.com/api-reference/reference/app-features.md
- The Apps MCP scaffolds app features and manages deployments, but "does not interact with boards or items". Source: https://developer.monday.com/api-reference/docs/apps-mcp.md
- **Hosting:** a `CLIENT_SIDE_CODE` item view (a static bundle hosted by monday) could read the item's updates and columns and render the chain: question → source passage → answer → reviewer. It needs no client server. That monday code is the host behind `CLIENT_SIDE_CODE` is **UNVERIFIED**; the name does not appear on these pages.
- **Fit:** strong for reviewer experience. But it is an extra build and an extra app review, which weighs against C3.

## 8. Official monday MCP (Claude)

- What it is: "monday.com's hosted MCP (Model Context Protocol) server", at `https://mcp.monday.com/mcp`. It works with "Claude, ChatGPT, Cursor, Copilot, Gemini". It offers 60+ tools. Source: https://developer.monday.com/api-reference/docs/mondaycom-mcp.md
- Security (source: https://developer.monday.com/api-reference/docs/monday-mcp-security-overview.md):
  - It acts "on behalf of the authenticated user and respect[s] that user's monday.com permissions".
  - "The MCP Server does not store or log customer OAuth tokens."
  - Admins approve connectors under "monday administration → Connectors → Dynamic Connectors".
  - Revoking a connector can take up to 24 hours to take effect.
- Tools: read-type tools include `get_board_items_page`, `get_updates`, `search`, `read_docs` and `board_insights`. `all_monday_api` can run any query or mutation, so it is **not read-only**. No read-only mode or plan gate is documented. Source: https://developer.monday.com/api-reference/docs/platform-mcp-tools.md
- **Is it "inside monday"?** No. It lets a reviewer ask questions *from Claude about monday*, not from inside the monday UI. An in-monday assistant would be an `AI` or `AI_AGENT` app feature (section 7), or monday's own agent tools (`manage_agent*`). Their behaviour was not researched here (**UNVERIFIED**).
- **Fit:** a reviewer using Claude with the monday MCP connector could ask "show me unanswered questions in section 4 and their cited sources". That adds zero code (C3).
- **Risk:** board content goes into the Claude conversation (C2). Also, `all_monday_api` exposes write access, which is a hazard for C4 unless the reviewer's token is scoped narrowly.

---

## Decision table

| Capability | Native option | Tier gate | Verdict | One-line reason |
|---|---|---|---|---|
| LLM calls | Models API gateway (`monday-standard` = Sonnet 4.6) | Pro/Enterprise (doc) | Rollout path | No new vendor contract, but retention terms are undocumented and there are no citations |
| LLM calls (GraphQL) | `run_prompt` | API 2026-10, Pro+, gateway permission | Avoid in POC | Single-turn and returns only `content`, so it can't carry citations |
| Cited answer per question | `create_update` with HTML body | All plans (no gate stated) | **Adopt** | Already wired; HTML gives bold source labels; one write per answer |
| Compiled answer pack | Doc plus `add_content_to_doc_from_markdown` | `docs:write`; plan gate UNVERIFIED | Rollout path | One bulk write per RFP; `quote` blocks and version history help the audit |
| Source RFP file | `add_file_to_column` via `/v2/file` multipart | Size and plan limits UNVERIFIED | Rollout path | Useful context, but it moves the full RFP into monday (C2) |
| Scorecard | `create_dashboard` + `create_widget` (NUMBER, BATTERY, CHART, LISTVIEW) | Free-plan dashboard limits UNVERIFIED | **Adopt** (one-time) | Native view of progress with nothing new to run; no `update_widget`, so recreate to change |
| Human routing | UI automation, e.g. "item created/status → notify" | Standard 250, Pro 25,000 actions/mo | Adopt if plan allows | No code; does not replace the poller's ingest |
| Webhook / call-URL trigger | Webhooks / integration recipes | Needs a reachable URL | Avoid | Breaks local-only and adds a public endpoint |
| Cross-board workflows | MCP `create_workflow` (preview schema) | Not stated | Avoid | Preview schema, no stable GraphQL |
| Provenance viewer | App `ITEM_VIEW` with `CLIENT_SIDE_CODE` | App build plus install | Rollout path | Best reviewer experience; adds an app to maintain |
| Reviewer Q&A | Platform MCP at mcp.monday.com in Claude | Admin connector approval | Mention as rollout path | Zero code, permission-scoped; data goes to the LLM client and writes are exposed |
| Past-answer search | `search.updates` (2026-10) | API 2026-10 | Rollout path | Native reuse lookup when the pipeline moves to 2026-10 |

## Pages that returned an error (claims depending on them are UNVERIFIED)
- https://support.monday.com/hc/en-us/articles/360001222900-monday-com-Automations: 403
- https://monday.com/w/ai-data-policy: 404
- https://monday.com/trustcenter/privacy/ai: 404
