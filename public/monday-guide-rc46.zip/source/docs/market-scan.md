# Market and resources scan: the "water line" for an RFP-intelligence POC

## Method and limits

- **Date:** 2026-10-10. **Lookups:** 25 (16 web searches, 9 page fetches). Bounded scan of public sources only, about 25 minutes. No individuals researched or listed.
- **"verified" column:** `yes` means I opened that URL (fetched the page) and it confirmed the claim. `search` means the claim came from a search-engine summary of that URL. I did not open the page itself, so treat it as unverified. `no` means I could not confirm the claim.
- **Could not verify:**
  - MISO's Competitive Transmission Administration RFP list. Two MISO pages I fetched did not render the RFP list.
  - The FERC Order 1000 page returned HTTP 403.
  - Responsive and AutoRFP.ai list prices. I saw them only through third-party or competitor summaries.
  - Loopio's "$20k/yr" figure. It appeared in a search snippet; the live pricing page I opened shows no price.
  - Reducto, Unstructured, Inventive and TruLens details.
  - Hardware figures for local models. They are rough rules of thumb, not sourced.
  - Whether ISO RFP documents carry any explicit reuse license. None of the pages I opened stated one.

---

## 1. Free field-truth test data: competitive transmission solicitations

FERC Order 1000 (2011) removed the federal right of first refusal for regionally cost-allocated projects. That is why ISOs/RTOs run developer solicitations. I could not open the FERC page because it returned 403, so the date and summary come from general knowledge and are verified=no.

| Source | Where docs live | Amendments / addenda published? | Approx size | License / usage notes | URL | verified |
|---|---|---|---|---|---|---|
| **PJM** RTEP competitive windows (2014 to 2026) | Competitive Planning Process page lists every window. 2026 RTEP Window 1 open 7/20 to 10/12/2026. Redacted public proposals linked per window. Designated Entity Agreement PDFs. Manual 14F governs. | **Yes.** Page shows addenda (2016/17 W1, W3), amended files (2024 W1 VEPCO, 2022 W3 Transource), versioned analytical files (V5, V8), and mid-cycle updates. | Non-CEII "without analytical files" zip is about 1 MB. CEII zips are 39 to 144 MB. Dozens of windows. | Analytical/model files are CEII and need access approval. Redacted proposals and window docs are public. No explicit reuse license seen. | https://www.pjm.com/planning/competitive-planning-process | yes |
| PJM 2025 RTEP Window 1 summary (134 proposals, 19 entities) | ISAC deck, Dec 2025 | n/a | 1 deck | Public | https://www.pjm.com/-/media/DotCom/committees-groups/state-commissions/isac/2025/20251208/20251208-item-02---2025-rtep-window-1.pdf | search |
| **MISO** LRTP Tranche 2.1 competitive RFPs (7 competitive projects; first: Reid–IN/KY State Line 345 kV, RFP issued 1/31/2025, due 5/1/2025, Republic Transmission selected) | MISO Competitive Transmission Administration page (selection reports posted there per press) | Not confirmed. Historically MISO posted revised RFP parts, e.g. Duff–Coleman Part 2 instructions Rev 3 (Apr 2016), surfaced via a Missouri PSC filing. | Unknown. MISO RFPs are multi-part (Part 1 / Part 2 + templates). | Some MISO data needs login plus CEII/NDA. Unconfirmed for RFP docs. | https://www.publicpower.org/periodical/article/miso-announces-developer-kentuckyindiana-transmission-project | search |
| MISO Duff–Coleman Part 2 Proposal Instructions, Rev 3 (historic, with revision trail) | Missouri PSC EFIS docket attachment | Yes: Rev 3 implies prior revisions | 1 doc | Public regulatory filing | https://efis.psc.mo.gov/Document/Display/18138 | search |
| **SPP** Transmission Owner Selection Process (TOSP) | TOSP page links a redacted IEP recommendation report (RFP-000001) and a separate RFPs page plus "Order 1000 Documents" | Not stated on the page I opened. Questions go through SPP's request system. | RFPs carry a 90-day response window (per search) | Public reports are redacted | https://www.spp.org/engineering/transmission-owner-selection-process/ | yes (page); amendments: no |
| **CAISO** competitive solicitation, "Key Selection Factors" per Transmission Planning Process cycle (2013/14 to 2025/26) | stakeholdercenter.caiso.com, one PDF per cycle, citing tariff 24.5.4 factors (cost containment, financial resources, ROW) | Per-cycle postings, so cross-year diffs are possible. Addenda not confirmed. | Short PDFs, many years | Public, "informational" | https://stakeholdercenter.caiso.com/InitiativeDocuments/Key-Selection-Factors-2023-2024-Transmission-Planning-Process.pdf | search |
| **NYISO** Public Policy Transmission Need (PPTN): NYC offshore wind PPTN (withdrawn by NY PSC 7/17/2025) and Long Island PPTN (selected) | nyiso.com document library: solicitation info packets, technical conferences, final report | Revised decks exist (e.g. "Technical Conference Nov 6 Revised"). A withdrawn need is a good "superseded" test case. | Many PDFs per need | Public | https://www.nyiso.com/documents/20142/53825460/New-York-City-Offshore-Wind-Public-Policy-Transmission-Planning-Report.pdf/d015af8f-ffdf-b8eb-875e-6c213b696077 | search |
| **ISO-NE** competitive transmission RFPs (e.g. Boston 2028 RFP, 2019 to 2021) | ISO-NE page currently lists no open RFPs and no files. Historic RFP docs were distributed via the RFP360 web app. | Page does not mention addenda or Q&A | n/a now | Some materials are CEII and need an access request | https://www.iso-ne.com/system-planning/transmission-planning/competitive-transmission | yes |
| ERCOT | Not an Order 1000 jurisdictional RTO for competitive solicitation. Not researched. | n/a | n/a | n/a | n/a | no |

**Takeaway:** PJM is the best free field-truth corpus. It has many windows, publicly posted addenda and amended files, redacted proposals, and versioned files, all without CEII for the core docs. It gives real supersession chains to test amendment resolution. The next best are NYISO (revised plus withdrawn needs) and CAISO (year-over-year factor diffs).

---

## 2. Purpose-built RFP response software

| Vendor | What it does | Public pricing | Inbound RFP parsing + amendment diffing? | Where a lean POC beats / loses | URL | verified |
|---|---|---|---|---|---|---|
| Loopio | Answer/content library + generative AI drafting + project mgmt for **outbound** responses. Tiers: Foundations (10 seats), Enhanced, Enterprise. | Not published on the page I opened ("Let's Talk"). A snippet cites "from $20,000/yr". | Page claims no inbound requirement extraction and does not mention amendments. | **Beats:** amendment supersession, cited figure verification, on-prem. **Loses:** collaboration, content reuse, review workflows, polish. | https://loopio.com/pricing/ | yes (tiers); price: search |
| Responsive (formerly RFPIO) | Response management, answer library | Lite reportedly about $80/user/mo; higher tiers contact-sales. These figures come from the vendor's comparison page via search. | Not confirmed | Same as Loopio | https://www.responsive.io/glossary/compare/loopio-vs-responsive | search |
| AutoRFP.ai | AI response drafting, project-priced, unlimited users | Third-party reports: Scale $899/mo and Accelerate $1,299/mo, billed annually | Not confirmed | Their focus is drafting bid language, which is out of scope for us by stakeholder constraint | https://g2.com/products/autorfp-ai/pricing | search |
| Inventive, Arphie, SiftHub, Wolfia | Same category (AI RFP response). Seen only as competitor blogs. | Not checked | Not checked | n/a | https://www.inventive.ai/blog-posts/autorfp-ai-pricing-review-and-features | no |

**Read:** this category is built for **sellers answering questionnaires** with drafted language. None of the material I saw claims what our POC does: deterministic amendment supersession, clause-cited Q&A for internal staff on an **inbound** utility RFP, and verbatim figure checks. Our position is complementary, not a competitor. Their lack of these features is "not seen", not "confirmed absent".

---

## 3. Document parsing for long, sectioned PDFs

| Tool | License | Free tier | Local-run | Notes | URL | verified |
|---|---|---|---|---|---|---|
| Docling | MIT for the code; bundled models carry their own licenses | Free | **Yes** (air-gapped stated) | Layout, reading order, table structure, OCR. Section hierarchy and page provenance were not stated on the README I opened. | https://github.com/docling-project/docling | yes |
| PyMuPDF | AGPL or commercial (Artifex) | Free under AGPL | Yes | Fast text plus page coordinates. AGPL matters if the tool is distributed or served. | https://pypi.org/project/PyMuPDF/1.19.6/ | search |
| Marker | Code GPL-3.0; weights reportedly non-commercial with a revenue threshold | Conditional | Yes (GPU helps) | Confirm the commercial terms in the repo before use | https://snyk.io/advisor/python/marker-pdf | search |
| LlamaParse | Proprietary SaaS | 10k credits/mo (about 1k pages); $1.25 per 1k credits | **No** (hosted) | Conflicts with the "runs in client environment" constraint | https://developers.llamaindex.ai/llamaparse/general/pricing/ | search |
| Unstructured, Reducto | Not checked | n/a | Unstructured OSS yes; Reducto is hosted (unverified) | n/a | n/a | no |

---

## 4. Citation-grounded QA evals and guardrails

| Tool / benchmark | License | Local-run | Fit for our POC | URL | verified |
|---|---|---|---|---|---|
| Ragas | Apache-2.0 (repo moved to vibrantlabsai org) | Yes (needs a judge LLM) | Faithfulness and context-precision metrics; useful beyond our 18-case golden set | https://pypi.org/project/ragas/0.1.20 | search |
| DeepEval | Apache-2.0 per PyPI metadata (one directory says MIT) | Yes | pytest-style LLM test cases; could wrap the golden eval | https://cloudsmith.com/navigator/pypi/deepeval | search |
| promptfoo | MIT. Search summary says the project joined OpenAI in Mar 2026 and remains MIT; unverified. | Yes (CLI) | Regression/A-B of Claude vs Qwen on the same cases, plus red-team | https://www.npmjs.com/package/promptfoo | search |
| garak (NVIDIA) | Apache-2.0 (originally GPL) | Yes | LLM vulnerability probes such as prompt injection inside RFP text | https://en.wikipedia.org/wiki/Garak_(software) | search |
| TruLens | MIT (one source) | Yes | Groundedness feedback functions | https://data.safetycli.com/packages/pypi/trulens | search |
| ALCE benchmark (arXiv 2305.14627) | Code on GitHub | Yes | Public benchmark for generating text **with citations**, scoring citation quality. Closest public analogue to our cite-every-answer rule. | https://arxiv.org/abs/2305.14627v2 | search |
| Vectara HHEM hallucination leaderboard | Leaderboard plus open HHEM model | HHEM yes | Measures faithfulness when summarizing a document. Being revised to a more granular board. | https://github.com/vectara/hallucination-leaderboard | search |

---

## 5. Local models for on-prem selection/extraction

| Family | License | Rough hardware (rule of thumb, not sourced) | Evidence relevant to faithful extraction | URL | verified |
|---|---|---|---|---|---|
| Qwen 2.5 7B Instruct (our measured: 14/18 vs Claude 18/18) | Apache-2.0 per aggregators; check the official LICENSE | About 16 GB VRAM at bf16; about 5 to 6 GB at 4-bit; runs on an Apple Silicon laptop | Our own golden eval is the most relevant evidence. No public score located in this scan. | https://dev.co/ai/llms/qwen2-5-7b-instruct | search |
| Llama, Mistral, Phi, Gemma | Varying licenses (Llama community license, Apache for most Mistral/Phi, Gemma terms) | Similar for 7 to 9B; 2 to 4B models fit CPU | Vectara HHEM leaderboard is the best public faithfulness comparison. I did not extract per-model numbers. | https://github.com/vectara/hallucination-leaderboard | no (licenses not checked this scan) |

**Read:** the 4-case gap between Qwen 7B and Claude is the decision-relevant number. The next step is to run the same 18 cases on one or two other 7 to 14B models, not to search for more leaderboards.

---

## 6. Synthetic data / synthetic research vendors (company level)

| Company | Offer | Applies to stress-testing document QA? | URL | verified |
|---|---|---|---|---|
| Gretel (acquired by NVIDIA, reported Mar 2025) | Synthetic data generation; tech folded into NVIDIA's gen-AI developer services | Partly. It can generate synthetic question variants and tabular data. RFP-clause fidelity still needs real documents. | https://techcrunch.com/2025/03/19/nvidia-reportedly-acquires-synthetic-data-startup-gretel | search |
| Evidenza | Synthetic B2B buyer panels for marketing research (accuracy claims mostly vendor/press) | **No.** It simulates buyer opinions, not document ground truth. Not useful for testing citation accuracy. | https://societies.io/compare/evidenza | search |

**Read:** for this POC, the cheapest stress test is perturbing real PJM/NYISO documents: inject a superseding amendment, delete a clause, alter a figure. That is better than buying synthetic data, because ground truth stays known.

---

## 7. OpenTelemetry GenAI semantic conventions

- **Status:** `Development` (not stable). The conventions moved out of the main semconv repo into `open-telemetry/semantic-conventions-genai`. The opentelemetry.io page now redirects there. (verified: yes)
- **Inference span name:** `{gen_ai.operation.name} {gen_ai.request.model}`. Retrieval spans: `{gen_ai.operation.name} {gen_ai.data_source.id}`. Tool: `execute_tool {gen_ai.tool.name}`.
- **Required:** `gen_ai.operation.name`, `gen_ai.provider.name` (supersedes the older `gen_ai.system`).
- **Conditionally required:** `gen_ai.request.model`, `gen_ai.conversation.id`, `gen_ai.output.type`, `gen_ai.prompt.name` / `gen_ai.prompt.version`, `gen_ai.request.seed`, `gen_ai.request.stream`.
- **Recommended:** `gen_ai.response.model`, `gen_ai.response.id`, `gen_ai.response.finish_reasons`, `gen_ai.request.temperature`, `gen_ai.request.max_tokens`, `gen_ai.usage.input_tokens`, `gen_ai.usage.output_tokens`, `gen_ai.usage.cache_read.input_tokens`, `gen_ai.usage.cache_write.input_tokens`.
- **Opt-in (content capture):** `gen_ai.input.messages`, `gen_ai.output.messages`, `gen_ai.system_instructions`, `gen_ai.tool.definitions`.
- `OTEL_SEMCONV_STABILITY_OPT_IN` was not mentioned in the pages read (verified: no).

| Claim | URL | verified |
|---|---|---|
| Moved; old page unmaintained | https://opentelemetry.io/docs/specs/semconv/gen-ai/gen-ai-spans | yes |
| Status Development, span name formats | https://raw.githubusercontent.com/open-telemetry/semantic-conventions-genai/main/docs/gen-ai/gen-ai-spans.md | yes |
| Inference attributes and requirement levels | https://raw.githubusercontent.com/open-telemetry/semantic-conventions-genai/main/docs/gen-ai/client-inference.md | yes |

**Action:** rename our trace fields to these names, for example `model` to `gen_ai.request.model` and `in_tok` to `gen_ai.usage.input_tokens`. Keep message content out by default, which matches the opt-in guidance. Pin the convention version in the README because the status is Development.

---

## 8. The water line

| Capability | SOTA approach | Free / cheap option | Our POC today | Gap | Action | Reasoning |
|---|---|---|---|---|---|---|
| Ingest | Layout-aware parsing (Docling, LlamaParse, Reducto) with table/section structure | Docling (MIT, local) | Local Python parse of RFP + amendments | Likely weaker on tables and scanned pages | **Cite as production path** (Docling) | Keeps local-run; adding it now adds moving parts the stakeholders asked to avoid |
| Amendment resolution | No purpose-built vendor seen; RFP suites are answer libraries | None found | **Deterministic supersession in code** | None seen in market (absence not proven) | **Keep / highlight** | This is the differentiator; prove it on PJM addenda and amended files |
| Retrieval | Hybrid BM25 + embeddings + rerank | OSS stack, local | Client-environment indexing | Measure recall only if misses appear | **Ignore for now** | The 18/18 eval shows no retrieval bottleneck yet |
| Cited answering | Citation-trained generation (ALCE-style), attribution checks | Open models + verbatim checks | LLM **selects** clauses; figures checked verbatim in code | Stronger than generate-then-cite on figure faithfulness | **Keep; cite ALCE** as the public frame | Selection plus a code check removes the figure-hallucination class by construction |
| Eval | Ragas / DeepEval / promptfoo regression + HHEM-type faithfulness | All free, local | 18-case golden eval, Claude 18/18, Qwen 7B 14/18 at about $0.0057/question | Small n; no adversarial cases | **Adopt promptfoo** (or DeepEval) to run the same golden set across models + add perturbation cases | Cheap, local, makes the Claude-vs-local tradeoff repeatable |
| Observability | OTel GenAI semconv (Development status) | OTel SDK | Custom trace fields | Field names non-standard | **Adopt the names now** (rename only, no new dependency) | Zero-cost alignment; any OTel backend reads it later |
