# Briefing video: "FDE LAB INTRO" (1:25), Stefan, Strategic FDE lead

Captured 2026-10-10 from YouTube auto-generated captions (played in full with captions on; ~188 words).
Auto-captions may contain small transcription errors. Summary, not verbatim:

- Purpose: see how the candidate approaches real customer problems and decision-making, and turns ideas
  into practical solutions.
- Explicitly **not about a perfect answer**: how you structure ambiguity, evaluate trade-offs, use the
  available data, and communicate your reasoning clearly.
- Before starting: review the brief, supporting materials, deadlines, submission requirements; the
  workspace checklist is there if helpful; use "Get help" or the recruiting team if anything is unclear.
- **The final ZIP must include source code, a README, and a presentation PDF.**
- Take your time, be thoughtful, let your own perspective come through.
