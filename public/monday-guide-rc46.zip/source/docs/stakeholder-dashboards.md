# Stakeholder dashboards on monday.com, spec v2 (post-gauntlet, hardened, pre-mortem)

Grades: A client docs · B counted in build records · C cited third-party · D inference · E recollection.
v1 -> v2 driver: a 4-persona gauntlet (Elena, Doug, Nina, Sam Ito). Headline finding: **v1 tracked tool performance; stakeholders need the bid.** Tool metrics move to one Pilot Health panel.

## Executive summary (read this; the rest is detail)
**Outcome:** each RET stakeholder opens one monday dashboard and sees the bid, not the tool: what is due and when, whether RET is eligible, what is at risk, what they must decide, and whether any answer is verified.
**Key results (targets are placeholders RET confirms; none are claimed yet):**
- KR1 Every RFP and amendment deadline is on the Deadlines board, sourced to its clause, with 0 dates disagreeing with Doug's spreadsheet over the parallel run.
- KR2 Every amendment change appears with old/new value within one sync of ingest; caught/expected = 4/4 for Amendment 1 (expected list pre-registered).
- KR3 100% of answers used in the bid carry an authenticated Verified-by before use.
- KR4 0 permission-probe failures (non-member/guest) and 0 injection strings reaching a prompt.
- KR5 Each stakeholder answers "what do I do next?" from their dashboard alone (checked in a walkthrough).
**Dependencies:** RET registration status (Sep 22); data-policy and provider sign-off (Sam); a service-account monday token; a monday plan with the needed permissions and dashboard API (unverified on free tier); Doug's spreadsheet for the parallel run; RET's ISO Business Day calendar.
**Blockers:** hosted model on real RET data until sign-off (hard block; local model is the alternative). Nothing else blocks the Deadlines and Amendment boards: they use only the RFP text.
**Unknowns:** whether RET registered and paid the deposit; monday token scope granularity and per-board permission semantics on RET's plan; selection date for the protest-window retention; who holds legal hold.
**Top risks (impact from the RFP; likelihood blank until based):** missed deadline or deposit difference (disqualification/forfeit); direct ISO contact (§4.2 disqualification); a counted metric read as an accuracy guarantee; risk register exposed; write-back injection; API budget exhaustion near deadline; spreadsheet divergence; token owned by a person who leaves.
**Trade-offs that shaped the design:**
- Bid-first headline over tool metrics (gauntlet: all four personas) -> tool metrics demoted to one Pilot Health panel.
- Repo as source of truth vs monday edits -> monday owns only Verified-by and Status; other edits are reverted *and surfaced*, never silent.
- Calendar-day SLAs over business days until RET supplies the ISO calendar (less precise, never wrong in RET's favour).
- Blank likelihoods over guessed ones (looks less finished, but no unbased rating reads as a guarantee).
- Parallel run with Doug's spreadsheet over forced cutover (slower adoption, earns trust).
- Generated boards via sink.py over hand-built (more upfront work; no drift, full audit log).
**Delivery plan:** trust + access layer -> Deadlines + Amendment Log (grade-A data only, dry-run first) -> Risks + Actions -> dashboards -> posterior checks -> deck slide on the gauntlet loop. Detail in §6.

## 0. Trust layer (build first; everything depends on it)
- **Face disclaimer** on every dashboard (Nina): "Decision support. Not verified until Verified-by is shown. Not a representation to the ISO. Do not contact ISO staff (RFP §4.2)."
- **Label rename:** "Measured" -> "Counted in records, as of <timestamp>". Every count shows its as-of time and the test or record behind it. No "mitigated" without a named control; else "partially addressed, residual risk".
- **No unbased likelihood ratings.** Likelihood is blank until a basis exists; Impact may be set from the RFP (e.g. disqualification = High, grade A).
- **Last synced** stamp on every dashboard; red when older than the sync interval x2.

## 1. Access and trust model (Sam) — before any board is created
- Token: a dedicated service account (not a person), named owner, rotation date recorded; `./rfp dashboards --audit` prints owner, account, last rotation (never the value). Scope granularity on monday tokens: **unverified, check docs (D)**.
- Boards Risks, Actions, Deadlines: private/shareable to named RET members only; **no guests**. Filters are views, never the permission boundary. Scripted test: a non-member and a guest get no access. (monday permission semantics per plan: **verify, D**.)
- **Write-back is untrusted input.** Only Verified-by (People column = authenticated user, not text) and Status may be written in monday. The pipeline reads them as inert data, validates against an allowlist, and **never** places monday-originated text in a model prompt. Test: an injection string in a cell never reaches provider.py.
- **Conflict rule (Nina/Sam):** repo owns facts, dates, metrics, risk text; monday owns Verified-by and Status only. A manual edit to a repo-owned field is overwritten on next sync **and** logged + surfaced as a "manual edit reverted" item to the owner. Never silent.
- **Append-only audit log** (`flightlog/board_writes.jsonl`): key, field, old, new, timestamp, actor (sink or user id from activity log). Verified-by history kept; editing an answer after verification clears Verified-by.
- **Retention:** dated export of answers + verifications + change history; legal-hold flag; kept through the §12.2 protest window (10 Business Days after selection; selection date per RFP, check §3.2). Who holds legal hold: question for RET counsel.
- **Failure modes:** 429/5xx -> backoff, max retries, no partial row writes (write a row's columns in one mutation), a run lock so two syncs can't race the 1,000/day budget; model down -> "AI unavailable" + clause pointers (exists, K15).

## 2. Boards
Existing: Solicitations, Key Facts, Questions, Pilot Scorecard (IDs in HANDOFF).
New (find-or-create via sink.py, idempotent):
1. **RET · Deadlines** (Doug's top ask): Key, Event, Date, Time, Time zone (CT), Source clause, Superseded by, Status (Upcoming / Due ≤7d / Passed / Unknown-whether-done), Owner, Countdown (formula or synced days-left).
   Seed rows (all grade A, from data/):
   - Registration: Sep 22, 2026, 5:00 PM CT (§3.2), Status **Unknown-whether-done** -> action to RET.
   - Q&A window closes: Oct 16, 2026, 5:00 PM CT (§3.2; unchanged per A1.1).
   - Remit deposit difference $25,000 (Derived: $100,000 − $75,000, A1.2): due Oct 17, 2026 (Derived: 15 calendar days after Oct 2 issuance; applies only if already registered).
   - Proposal submission: **Dec 4, 2026, 5:00 PM CT** (A1.1 supersedes §3.2 Nov 13; portal timestamp dispositive §3.4).
   - Portal check: last checked <timestamp> (§4.3 "solely responsible for monitoring"); stale after 24 h.
2. **RET · Amendment Log**: per change: clause, old value, new value, issued date, effective, affected parties ("already registered" for A1.2), action created, Verified-by. Ground truth for "changes caught" = a hand-keyed expected list (A1.1–A1.4); metric = caught/expected, not self-counted. Referenced-but-not-ingested attachments (Appendix F) flagged.
3. **RET · Risks**: Key, Risk, Stakeholders (multi), Impact (+basis), Likelihood (+basis or blank), Control (named) / residual, Owner, Status, Revisit trigger, Source. Shared risks appear on every affected dashboard (Elena: provider sign-off blocks her launch).
4. **RET · Actions**: Key, Action, Owner (role), Why, Due (date + basis: RFP-derived or Estimate), Acceptance criteria (testable), Status, Blocked by.

## 3. Dashboards (pull, not push: headline row, detail one click away)
### Elena · bid decision header (replaces tool metrics)
- Days to each deadline; **eligibility gates** §5.1 (two prior 230 kV+ projects), §5.2 (investment grade), §5.3 (QTD status), §5.5 new (cyber attestation, Appendix F) each Met / Not met / Unknown + owner + clause; **cash at risk** $100,000 deposit (A1.2) + $2,000,000 letter of credit (§7.2); amendments last checked; registration status.
- Hours saved per bid: **Not counted yet**, shown only in the Pilot Health panel, not her headline.
- Admin chores (plan tier) move to Sam/procurement.
### Doug · compliance and changes
- Deadlines board with countdowns; Amendment Log with old/new; compliance-matrix delta (new §5.5 row owned by Volume IV); referenced-attachment check; portal-check stamp.
- Parallel run: keeps his spreadsheet through submission; acceptance = dashboard and spreadsheet agree on every date and change for the full cycle.
- SLA in **calendar days** until RET supplies an ISO Business Day calendar.
### Nina · review and record
- Verified-by coverage (answers with authenticated Verified-by / total), unverified answers list, communications guard panel (§4.1/§4.2: any question asking to contact the ISO is routed to "portal Q&A only" and listed here), sensitivity label per record, data-flow log (provider calls by date + sign-off ref), retention/hold status.
- Carve-outs stated on the face: no bid drafting; decision support only; no outbound messaging to the ISO.
### Sam Ito · access and operations
- Token owner/rotation, board permission test result, monday calls today / 1,000 + lock status, last sync + failures, chars sent to AI per question, audit-log tail, security scan status (from CI), provider sign-off (blocking: no real RET data to a hosted model until signed; local model is the alternative).
### Pilot Health (shared, one panel)
- Tool metrics from v1 (AI time, cost/question, duplicates, attack tests) with "as of / under tests X; not a security or accuracy assurance".

## 4. Hardening
**Anterior (before data enters / before a write):**
- Input allowlist on write-back; People column for Verified-by; size and type checks; injection strings rejected from prompts.
- Pre-write diff + dry-run (`--plan`) prints exactly what would change and the API cost; budget check against 1,000/day; run lock.
- Date facts typed (date, time, TZ) and parsed from source text, cross-checked to the amendment resolver's supersession; build fails if a seeded date has no source clause.
- Expected-change list per amendment (ground truth) authored before counting (pre-registered).
**Posterior (after a write):**
- Read-back verify: re-query written rows, compare to intended values; mismatch -> alert item + K-entry.
- Drift detector: monday values vs repo each sync; manual edits surfaced, never silent.
- Freshness alarms: last sync, portal check, deadline ≤7 days.
- Audit-log replay test: reconstruct one board state from the log alone.
- Permission probe: periodic non-member/guest access test.

## 5. Pre-mortem: "It's Nov 20, the pilot failed. Why?"
| # | Failure story | Likelihood basis | Early signal | Prevention in this spec |
|---|---|---|---|---|
| P1 | RET never registered (Sep 22); bid was impossible; dashboards were moot | Unknown (no record) | Registration row stays Unknown | First action, owner Elena, before any build beyond Deadlines |
| P2 | Deposit difference not remitted by Oct 17 | A1.2 is easy to miss | Deadline row Due ≤7d red | Deadlines board + Doug action, calendar days |
| P3 | Stakeholder trusted a stale/unsynced board after an Amendment 2 | §4.3 puts monitoring on the bidder | Portal-check stamp stale | Portal-check row, last-synced red, amendment log |
| P4 | Someone emailed an ISO contact after seeing the Questions board | Sample Q7 asks exactly this | Comms guard panel item | Face disclaimer + routing to portal Q&A only |
| P5 | A "Counted" metric was quoted to a partner as an accuracy rate | Nina's concern | Metric copied to external doc | Label rename, as-of/test scope on every count |
| P6 | Risk register visible to the whole account / a guest | monday default sharing (D) | Permission probe fails | Private boards, no guests, scripted probe |
| P7 | Free-text write-back injected into a prompt | Sam's concern | Injection test | Write-back never reaches prompts; allowlist |
| P8 | Daily API budget exhausted by a retry loop mid-deadline | 1,000/day free tier (C) | calls/day tile > 80% | Lock, backoff, budget check, diff-before-write |
| P9 | Doug kept his spreadsheet; the two diverged; nobody knew which was right | Doug said so | Parallel-run mismatch | Parallel-run reconciliation as acceptance |
| P10 | Hosted model used on real RET data before sign-off | A-S1 open | Provider sign-off tile red | Hard block in config until sign-off date recorded |
| P11 | Consultant left; token owned by a person expired | Sam's concern | Token owner = individual | Service account + rotation date + support owner action |

## 6. Build order (for the writer)
1. Trust layer + access model + audit log (no boards yet); tests: injection, permission (if API allows), lock, read-back.
2. Deadlines + Amendment Log boards from data/ (grade A only), with `--plan` dry run first.
3. Risks + Actions from `ops/stakeholders.json` (authored text; dates/money pulled from records; likelihood blank unless based).
4. Dashboards: Zach in UI or `create_dashboard` (verify API availability on free tier, D); one per stakeholder + Pilot Health.
5. Posterior checks: read-back, drift, freshness, replay.
6. Deck: one slide showing gauntlet -> v2 changes (v1 tool metrics -> bid header) as the anti-fragile loop; pre-mortem table in appendix.
Budget estimate (D): ~60–80 monday calls first run; ~0–5 per re-run.
