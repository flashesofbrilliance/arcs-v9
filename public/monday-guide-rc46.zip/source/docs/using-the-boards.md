# Using the boards (for RET staff)

Everything here happens in monday.com. No terminal, no installs. A few words used below:

- **RFP:** request for proposals, the solicitation document RET is deciding whether to bid on.
- **ISO:** the independent system operator, the grid operator that issued the RFP and answers bidders' questions.
- **§ (section):** a numbered clause of the RFP, like §3.2. Clauses that start with A come from an amendment:
  §A1.1 is clause 1 of Amendment No. 1.

Three boards hold the pilot:

- **RET · Solicitations:** each document and amendment received, and what each amendment changes.
- **RET · Key Facts:** the dates, deposits and requirements that matter, each with its exact source wording.
- **RET · Questions:** where you ask.

## Ask a question

1. Open **RET · Questions** and add a new item.
2. Type your question in the **Question** column, in your own words ("when's the bid due now?" works).
3. Leave **State** empty. Within about a minute the item fills in: **State**, **Answer** and **Citations**.

If nothing appears after five minutes, the program that answers questions is probably not running: tell whoever
installed it (the IT admin who followed ONBOARDING.md).

## What each answer state means

| State | What it means | What to do |
|---|---|---|
| **Answered** | The answer is backed by the quoted RFP text, and every figure in it was checked against that text. | Read the citations before you rely on it. |
| **Needs review** | The system found something it will not settle on its own: amendment wording it could not read, or an answer whose summary failed its check. | A person reads the cited text and decides. |
| **Not addressed in RFP** | The documents do not answer this. It will not guess. | Ask the ISO through its Q&A portal. |
| **AI unavailable** | The AI service did not respond. Nothing was guessed. | Retry later: click the **State** cell and pick the empty (grey) option, or **New**. |
| **Refused to guess** | The AI's reply cited text that is not in the documents, or could not be read, so it was thrown away. | Re-ask in other words in a new item, or tell the IT admin who installed it. |

## Follow a citation to the source

The **Citations** column lists each clause used, like `§A1.1 (Amendment No. 1, issued October 2, 2026, §A1.1)`.
Click the item's name to open it; the panel that opens shows its **Updates**: the full answer is posted there with the exact wording of every cited
clause, so you can check it without opening the PDF. When an amendment changed a clause, both are cited and the
note says which one governs.

## The Verified by column

On **RET · Key Facts**, each fact has a **Verified by** column, empty until a person has checked the fact against
the source document. It is a plain text column: click it and type your name when you have. Treat an empty one as not yet checked by a person.

## What it will not do, by design

It will not guess, draft bid language, decide whether to bid, contact the ISO, or send the whole document to the AI.
To the AI: fixed instructions, the question and a few clauses. To monday.com: answers, quoted clauses and the RFP files (RET board permissions).
