# Native monday agent vs this pipeline: comparison design

Status: designed, not run. Written 2026-10-10 for HANDOFF item 6. "inference" marks anything not stated in a repo file or a cited page. Paths are relative to the repository root.

## 1. Native options that could answer the same questions

| Option | Needs | Can it return citations? | Source |
|---|---|---|---|
| Models API (`monday-standard` = claude-sonnet-4-6) | Pro or Enterprise workspace, `ai:consume` scope, credits, base URL `https://api.monday.com/platform-ai-gateway/openai/v1` | The gateway returns model text only. Citations would have to come from our own prompt and our own check. | docs/monday-native.md section 1 |
| `run_prompt` mutation | API 2026-10 or later, `AI:Consume`, Pro or above, External AI gateway permission | No. It returns only `content`, single turn, no source fields. | docs/monday-native.md section 2 |
| AI columns (extract, summarize, categorize) | API 2026-10 to configure, Standard or above, credits | No. Reads item name, updates thread or columns only. No file or PDF source type is listed. | docs/monday-platform.md section 10.1 |
| Built-in monday agent | Agents enabled (early access), `API-Version: dev`, credits, board access granted per agent | Not documented. The product page says agents use "docs, PDFs, and boards" as context but gives no citation behaviour. | docs/monday-platform.md section 10.2 |
| External agent (webhook or Claude-managed) | Early access, `API-Version: dev`, public HTTPS endpoint (webhook mode), credits | Only what our own code returns. In webhook mode it would be our pipeline behind monday's trigger, so it tests the trigger, not a native answerer. Inference. | docs/monday-platform.md section 10.2 |
| Sidekick | All workspaces, in the Basic+ credit bundle | Not stated on the product page. It also searches the web, which breaks the data rule. | docs/monday-platform.md section 10.3 |

Only the built-in agent and Sidekick are true "native answerers". Both have undocumented citation behaviour, so "can it cite at all" is a measured outcome, not an assumption.

## 2. Comparison protocol

- **Questions and rubric.** Same 30 cases: 18 in source/eval/golden.json and 12 in source/eval/golden_wave2.json. Same per-case fields (`status`, `must_cite`, `must_say`, `must_not_say`, `must_note`). Score with the existing `check(case, r)` in source/eval/run_eval.py, unchanged.
- **Adapter (inference).** `check()` expects `r = {status, answer, citations[{clause_id, text}], notes}`. A native agent returns free text. Write a small adapter that (a) maps every quoted passage to a clause by exact substring match against the ingested clauses, and (b) maps the agent's own answered or refused wording to `status`. A passage that matches no clause counts as an uncited claim. Freeze the adapter before the first run.
- **Fairness.**
  - Same documents: data/rfp_maple_creek.txt and data/rfp_maple_creek_amendment_1.txt, the two files run_eval.py ingests. Upload or paste identically.
  - Same question wording, verbatim from the golden file. No prompt tuning per case. One system prompt for the native side, written once and committed before the first run.
  - At least 3 runs per case per side, to expose nondeterminism. Report pass rate as k of 3 per case and the share of cases that flip between runs.
  - Run both sides on the same day so a silent model change (docs/monday-native.md section 1 says monday can change the model per tier) does not split them.
- **Metrics.**
  - Pass rate: cases passing all 3 runs, and mean across runs.
  - Citation behaviour: share of answers with at least one matched clause; share of quoted text that is verbatim; share of refusals where the pipeline refuses (status mismatch counts as a fail in `check()`).
  - Latency: wall clock per question, median and worst. Pipeline baseline is E-latency, median AI time about 1.6 s (evidence/evidence.jsonl). Note the pipeline also waits for a 60 s poll (E-poll), so report AI time and end-to-end separately.
  - Cost: native side from AI credits, read from the `x-monday-credits-used` header (Models API) or the usage dashboard (agents), converted at "1,000 credits = $10" (docs/monday-platform.md section 10.7, marketing page, check wording). Pipeline baseline is E-cost-per-q, $0.0037 per question. Cost per passing case, not only per call.
- **Record everything.** One JSONL row per run, same shape as flightlog/eval_runs.jsonl, with raw native response kept.

## 3. Recorded block (slide text)

On 2026-10-10 the comparison could not be run. Our monday account is on the free plan, which has no AI credits. A probe of the Models API at `/platform-ai-gateway/openai/v1/chat/completions` returned HTTP 403 `insufficient_credits` ("AI credits limit reached") (evidence row E-monday-models-api). monday's docs require a Pro or Enterprise workspace for that API. The built-in agents are early access, use the `dev` API version and consume credits; a webhook agent also needs a public HTTPS endpoint, which our local setup does not have (docs/monday-platform.md section 10.2). No monday AI call was made beyond that one probe, and no native result is claimed. The design above runs unchanged once an account with credits exists.

## 4. Decision rule, pre-registered before any run

Thresholds are set now. They are judgment calls, not derived from data (inference).

Recommend the native option instead of this pipeline only if all of these hold on the 30 cases:

1. Pass rate across 3 runs is within 2 cases of the pipeline's, and no case in the pipeline's forbidden-figure class (`must_not_say`) fails on the native side in any run.
2. At least 95 percent of native answers carry a matched verbatim clause citation (constraint C1 in docs/monday-native.md).
3. Native cost per passing case is no more than 3 times the pipeline's, or the extra cost is under the monthly credit allowance of the plan the client already pays for.
4. The client's data rule is met in writing: monday documents retention and training terms for the path used (docs/monday-native.md section 1 says they are undocumented today).

If 1 or 2 fails: keep the pipeline, and say native is unsuitable for cited answers. If only 3 or 4 fails: keep the pipeline and name native as a rollout path pending commercial or legal terms. If native is better on pass rate by more than 2 cases with citations intact: report that honestly and reopen the build-versus-buy question; do not adjust thresholds after seeing results.
