# Critical path, root causes, and what the detours cost

Measured from git commit times and `flightlog/model_calls.jsonl` unless marked *(est.)*. Clock started
when the brief was read: 2026-10-10 10:07 ET.

## Critical path to done, five levels deep

Done = a submitted ZIP and a live demo in which the panel's unseen question goes through the real user
path and comes back cited, verbatim and amendment-aware.

| Level | Step | Depends on | Status | Blocks |
|---|---|---|---|---|
| 1 | Submit the ZIP (gate `package.py`, E1-E7) | 2, slides in `presentation/`, the 5 dashboard checklist items | open | everything |
| 2 | Rehearsed demo: the panel's question goes in through monday.com and comes back cited | 3 | open | 1 |
| 3 | Live-question path: a new item on the Questions board, picked up, answered, written back | 4 | open | 2 |
| 4 | Boards and sync: Key Facts board (Elena's same-day facts) + Questions board, GraphQL writes | 5 | open | 3 |
| 5 | **A monday.com trial account and an API token** | Zach | **BLOCKED (human)** | 4, 3, 2, 1 |

**Finding:** since 10:24 the critical path has been blocked at level 5. Everything built since then
(eval, Qwen comparison, M1, ledgers) runs *parallel to* the critical path, not on it. That was the right
use of blocked time only as long as it doesn't delay level 4 once the token arrives. Next action when
the token lands: levels 4 and 3 before anything else.

## Root cause: the "test was wrong" class (K7, K9), five whys

1. Why did the eval fail on a correct answer (K7) and the fuzz flag correct behavior (K9)? The
   expectation encoded my assumption instead of the source's behavior.
2. Why did the expectation encode my assumption? I wrote it from memory of the document (title-case
   date) and from a simplified model of ingest order (ignoring reformatted copies).
3. Why from memory? Writing the expectation was faster than deriving it from the artifact.
4. Why was that allowed? No step required an expectation to be checked against the source before it
   was used to judge the system.
5. Why no such step? The build loop treated tests as ground truth by default. **Root cause: tests had
   no provenance requirement.**

**Repair (structural, not just the two instances):** every golden expectation now has to be a literal
substring of the source or a computed property of it, checked by `eval/check_golden.py` before any eval
runs. On a failure, read one failing case end to end before touching the system.

## Wrong turns, with opportunity cost

| # | Direction | Why it was wrong | Cost | Drift from done |
|---|---|---|---|---|
| R1 | Searching memory and transcripts for Ridgeline pre-work | It didn't exist in any store I can see; I should have asked first | ~8 tool calls, ~3 min *(est.)* | none on the critical path |
| R2 | Framing local Qwen as a scope question (K8) | Neither the brief nor cost required it | 2 conversation turns | low |
| R3 | Disk cleanup detour | Necessary for Qwen, but Qwen is off the critical path | ~10 min of turns *(est.)* | low |
| R4 | Considering a hosted third-party model portal and a public progress page | Would breach Sam Ito's constraint and the materials' confidentiality | 2 turns, no code | none (rejected) |
| R5 | A 30,000-run fuzz of a deterministic layer | Found zero system defects; 1,000 runs would have found K9 equally. Value is the proof, not discovery | ~1 min compute, ~5 min build | low; parallel to a blocked path |
| R6 | Estimated wall-minutes in flight spans (K10) | Guesses ran ~3x high while git had the real times | inflated cost ledger; a wrong number given to Zach | high for credibility; fixed below |

API spend so far: **$0.33** across 75 calls (57 Claude, 18 local at $0). Build time so far: **~34 min**
elapsed (10:07-10:41), plus Zach's own reading and pre-work, which the clock does not include.
