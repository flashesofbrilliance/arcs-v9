"""Multivariate scenario testing: every combination of faults, checked against invariants.

A scenario is canonical JSON (documents by content hash, faults with params, provider, mock fault);
its id is the hash of that JSON, so identical toggles always produce the same id and any change makes
a new one. Results are keyed by (scenario id, git commit) so a scenario that passed at one commit and
fails at a later one is reported as a regression.

python3 -m sim.scenarios matrix            # full factorial on the $0 mock (3,072 scenarios)
python3 -m sim.scenarios run FILE.json     # one saved scenario (e.g. exported from the test bench)
"""
import hashlib
import itertools
import json
import os
import subprocess
import sys
import time
from datetime import datetime, timezone

from rfp import answer, faults, parse, store

HERE = os.path.dirname(__file__)
ROOT = os.path.abspath(os.path.join(HERE, "..", ".."))
DATA = os.path.join(ROOT, "data")
SCEN_DIR = os.path.join(ROOT, "scenarios")
RUN_LOG = os.environ.get("SCENARIO_LOG", os.path.join(ROOT, "flightlog", "scenario_runs.jsonl"))

DOC_FAULT_DEFAULTS = {"delete_clause": "7.1", "change_figure": "$75,000=>$80,000", "unknown_amendment_phrasing": "",
                      "page_break_loss": "", "ocr_noise": "0.01"}
INGEST_FAULT_NAMES = ["duplicate_upload", "reformatted_duplicate", "amendment_first", "conflicting_amendment"]
MOCK_FAULTS = ["none", "timeout", "garbage", "wrong_figure", "fake_citation", "refuse"]
# Questions whose correct answer depends on Amendment 1 superseding the base RFP.
AMENDED = {"What is the bid deposit for the Maple Creek RFP?": "A1.2", "When are proposals due?": "A1.1"}
OK_STATUSES = {"answered", "partly_addressed", "not_addressed", "needs_review", "unavailable", "error"}
CONTENT_LOSS = {"delete_clause", "page_break_loss", "ocr_noise"}
GOLDEN = json.load(open(os.path.join(HERE, "..", "eval", "golden.json")))


def scenario_id(s):
    canon = json.dumps({k: s[k] for k in ("docs", "faults", "provider", "mock_fault")}, sort_keys=True)
    return hashlib.sha256(canon.encode()).hexdigest()[:12]


def make(fault_names, mock_fault, provider="mock"):
    docs = {f: parse.content_hash(parse.read_document(os.path.join(DATA, f)))[:12]
            for f in ("rfp_maple_creek.txt", "rfp_maple_creek_amendment_1.txt")}
    fl = sorted(({"name": n, "param": DOC_FAULT_DEFAULTS.get(n, "")} for n in fault_names), key=lambda f: f["name"])
    s = {"docs": docs, "faults": fl, "provider": provider, "mock_fault": mock_fault}
    s["id"] = scenario_id(s)
    return s


def head():
    try:
        return subprocess.check_output(["git", "-C", ROOT, "rev-parse", "--short", "HEAD"]).decode().strip()
    except subprocess.CalledProcessError:
        return None


def run(s, questions):
    """Run one scenario; return the list of invariant violations (empty = pass)."""
    os.environ["MODEL_PROVIDER"], os.environ["MOCK_FAULT"] = s["provider"], s["mock_fault"]
    base = faults.apply_doc_faults(parse.read_document(os.path.join(DATA, "rfp_maple_creek.txt")), s["faults"], False)
    amend = faults.apply_doc_faults(parse.read_document(os.path.join(DATA, "rfp_maple_creek_amendment_1.txt")), s["faults"], True)
    db = store.connect(":memory:")
    seq = faults.ingest_sequence(base, [amend], s["faults"])
    distinct = set()
    violations = []
    for label, text in seq:
        try:
            _, created = store.ingest(db, text, label)
        except store.DuplicateDocument:
            continue
        distinct.add(parse.content_hash(text))
    n_docs = db.execute("SELECT COUNT(*) FROM documents").fetchone()[0]
    if n_docs > len(distinct):  # V1: duplicates never create a second document
        violations.append("V1 duplicate created: %d documents for %d distinct texts" % (n_docs, len(distinct)))
    amendment_in = db.execute("SELECT 1 FROM documents WHERE kind='amendment'").fetchone() is not None
    for q in questions:
        try:
            r = answer.answer(db, q)
        except Exception as e:  # V2: never crash
            violations.append("V2 crash on %r: %s" % (q[:40], e))
            continue
        if r["status"] not in OK_STATUSES:
            violations.append("V3 unknown status %s" % r["status"])
        # The fast path answers with the governing clause text itself (verbatim by construction, K32).
        if r["status"] == "answered" and r.get("gate") != "verbatim ok" and not (r.get("gate") or "").startswith("fast path"):
            # The fallback (quote the source, no model sentence) is allowed only with a visible gate failure.
            if "failed the verbatim check" not in r["answer"]:
                violations.append("V4 answered with failed gate and no fallback on %r" % q[:40])
        need = AMENDED.get(q)
        cited = {c["clause_id"] for c in r.get("citations", [])}
        if need and amendment_in and r["status"] == "answered" and need not in cited:
            # V5: an amended fact answered cleanly from superseded text is Elena's incident.
            violations.append("V5 %r answered without governing %s (cited %s)" % (q[:30], need, sorted(cited)))
    # V6 (K21): usefulness. With a correctly behaving model and no fault that removes content, the questions
    # the RFP does answer must come back answered or flagged for review. Refusing everything is not safe; it
    # is a different failure.
    if s["mock_fault"] == "none" and not {f["name"] for f in s["faults"]} & CONTENT_LOSS:
        addressable = [c["q"] for c in GOLDEN if c["status"] == "answered" and c["q"] in questions]
        useful = sum(1 for q in addressable if answer.answer(db, q)["status"] in ("answered", "needs_review"))
        if useful < len(addressable):
            violations.append("V6 only %d of %d answerable questions answered" % (useful, len(addressable)))
    return violations


def vacuous(s):
    """A scenario whose model never answers passes V4/V5 trivially; report it, never count it as strength."""
    return s["mock_fault"] in ("timeout", "garbage", "fake_citation", "refuse")


def matrix():
    questions = [c["q"] for c in json.load(open(os.path.join(HERE, "..", "eval", "golden.json")))]
    names = list(DOC_FAULT_DEFAULTS) + INGEST_FAULT_NAMES
    sha, t0, results = head(), time.time(), []
    for k in range(len(names) + 1):
        for combo in itertools.combinations(names, k):
            for mf in MOCK_FAULTS:
                s = make(combo, mf)
                v = run(s, questions)
                results.append({"id": s["id"], "faults": [f["name"] for f in s["faults"]], "mock_fault": mf,
                                "pass": not v, "vacuous": vacuous(s), "violations": v[:3]})
    prev = previous_results()
    regressions = [r["id"] for r in results if not r["pass"] and prev.get(r["id"]) is True]
    by_v = {}
    for r in results:
        for v in r["violations"]:
            by_v[v.split()[0]] = by_v.get(v.split()[0], 0) + 1
    summary = {"t": datetime.now(timezone.utc).isoformat(), "commit": sha, "uncommitted_code": subprocess.run(["git", "-C", ROOT, "status", "--porcelain", "--untracked-files=no", "--", "source", "scripts"], capture_output=True, text=True).stdout.strip() != "", "scenarios": len(results),
               "passed": sum(r["pass"] for r in results),
               "load_bearing_passed": sum(r["pass"] and not r["vacuous"] for r in results),
               "vacuous": sum(r["vacuous"] for r in results), "violations_by_invariant": by_v,
               "regressions": regressions, "seconds": round(time.time() - t0, 1),
               "results": results}
    with open(RUN_LOG, "a") as f:
        f.write(json.dumps(summary) + "\n")
    print(json.dumps({k: v for k, v in summary.items() if k != "results"}, indent=1))
    failing = [r for r in results if not r["pass"]][:5]
    for r in failing:
        print("FAIL", r["id"], r["faults"], r["mock_fault"], r["violations"][:1])
    return 0 if summary["passed"] == len(results) else 1


def previous_results():
    if not os.path.exists(RUN_LOG):
        return {}
    last = None
    for line in open(RUN_LOG):
        if line.strip():
            last = json.loads(line)
    return {r["id"]: r["pass"] for r in (last or {}).get("results", [])}


if __name__ == "__main__":
    if len(sys.argv) > 2 and sys.argv[1] == "run":
        sc = json.load(open(sys.argv[2]))
        qs = sc.get("questions") or [c["q"] for c in json.load(open(os.path.join(HERE, "..", "eval", "golden.json")))]
        v = run(sc, qs)
        print("PASS" if not v else "\n".join(v))
        sys.exit(1 if v else 0)
    sys.exit(matrix())
