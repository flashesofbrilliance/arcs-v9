"""Stress test at real size: the sample RFP padded to ~600 pages with generated distractor sections in the same format.

python3 -m sim.longdoc [--pages 600]      (from source/)

Checks that ingest stays bounded, no clause is swallowed (K46), search still finds the governing clause for every test
question that must cite one (the 400-600 page risk on slide 9), and the deadline still resolves to Amendment 1.
Deterministic (seeded), free (no model call), standard library only.
"""
import argparse
import json
import os
import random
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.dirname(HERE)
ROOT = os.path.dirname(SRC)
sys.path.insert(0, SRC)
from rfp import answer, parse, store  # noqa: E402

TOPICS = ["Structural Steel", "Conductor Stringing", "Foundation Design", "Environmental Permitting", "Right-of-Way Clearing",
          "Substation Interface", "Protection and Control", "Grounding", "Vegetation Management", "Access Roads",
          "Quality Assurance", "Safety Program", "Spare Parts", "Testing and Commissioning", "Records Retention"]
WORDS = ("the selected developer shall provide submit maintain document inspect certify each component structure segment "
         "line equipment schedule report procedure requirement standard design drawing specification acceptance test "
         "within prior following applicable approved written notice engineer contractor facility system").split()


def padded(base, pages, seed=7):
    rnd = random.Random(seed)
    out, words, sec = [base], len(base.split()), 13
    while words < pages * 350:  # ~350 words per page
        title = rnd.choice(TOPICS)
        out.append("\nSECTION %d — %s (pp. %d–%d)\n" % (sec, title.upper(), sec * 3, sec * 3 + 2))
        for k in range(1, rnd.randint(6, 14)):
            text = " ".join(rnd.choice(WORDS) for _ in range(rnd.randint(25, 70)))
            out.append("%d.%d %s. %s.\n" % (sec, k, title, text.capitalize()))
            words += len(text.split())
        sec += 1
    return "\n".join(out), words, sec - 13


def main(argv=None):
    a = argparse.ArgumentParser(); a.add_argument("--pages", type=int, default=600); a = a.parse_args(argv)
    base = parse.read_document(os.path.join(ROOT, "data", "rfp_maple_creek.txt"))
    amend = parse.read_document(os.path.join(ROOT, "data", "rfp_maple_creek_amendment_1.txt"))
    big, words, extra = padded(base, a.pages)
    t = time.time(); db = store.connect(":memory:"); store.ingest(db, big, "big"); store.ingest(db, amend, "a1"); t_ingest = time.time() - t
    clauses = store.all_clauses(db)
    cases = [c for g in ("golden.json", "golden_wave2.json") for c in json.load(open(os.path.join(SRC, "eval", g))) if c["must_cite"]]
    found, misses, t = 0, [], time.time()
    for c in cases:
        ids = {x["clause_id"] for x in answer.expand_with_amendments(db, answer.retrieve(clauses, c["q"]))}
        fast = answer.fast_path(db, c["q"])
        if fast:
            ids |= {x["clause_id"] for x in fast.get("citations", [])}
        if all(m in ids for m in c["must_cite"]):
            found += 1
        else:
            misses.append(c["id"])
    t_search = (time.time() - t) / max(1, len(cases))
    dl = answer.fast_path(db, "When are proposals due?") or {}
    ok_deadline = "DECEMBER 4, 2026" in dl.get("answer", "")
    rate = found / len(cases)
    print("pages ~%d (%s words, %d generated sections, %d clauses)" % (a.pages, f"{words:,}", extra, len(clauses)))
    print("ingest %.2f s; search %.3f s per question" % (t_ingest, t_search))
    print("governing clause found: %d of %d (%.0f%%)%s" % (found, len(cases), 100 * rate, ("; missed " + ", ".join(misses)) if misses else ""))
    print("deadline resolves to Amendment 1: %s" % ok_deadline)
    ok = t_ingest < 30 and t_search < 1.0 and rate >= 0.9 and ok_deadline
    print("longdoc: %s" % ("PASS" if ok else "FAIL"))
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
