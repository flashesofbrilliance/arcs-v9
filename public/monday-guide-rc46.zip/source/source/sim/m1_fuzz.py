"""M1: deterministic fuzz of ingest + amendment resolution. No model calls; every run is real.

python3 -m sim.m1_fuzz --runs 30000 --seed 7

Each run builds a fresh in-memory store from a random sequence drawn from: the base RFP, Amendment 1,
synthetic Amendments 2 and 3, exact duplicates, whitespace-reformatted duplicates, and a conflicting
re-issue of an amendment number. Then it checks invariants that must hold whatever the order:

  I1 governing value: for every base clause, the effect that governs is the highest-numbered
     amendment that replaces it
  I2 no duplicates: each distinct text is stored once
  I3 never guess: phrasing no rule knows is UNRESOLVED, never a replacement
  I4 order independence: the final set of effects does not depend on ingest order
  I5 conflicts surface: a different text under an existing amendment number raises, never overwrites
"""
import argparse
import json
import os
import random
from collections import Counter
from datetime import datetime, timezone

from rfp import parse, store

ROOT = os.path.join(os.path.dirname(__file__), "..", "..")
DATA = os.path.join(ROOT, "data")
HEAD = "GRID OPERATOR HEARTLAND ISO\nRFP 2026-04 — MAPLE CREEK 345 kV TRANSMISSION PROJECT\n"

SYNTHETIC = {
    "A2": HEAD + """AMENDMENT NO. 2 — Issued October 20, 2026
This Amendment modifies RFP 2026-04 pursuant to Section 4.3 of the RFP.
A2.1 Section 7.1 (Bid Deposit) is revised: the bid deposit is increased from $100,000 to $125,000.
A2.2 Section 7.2 (Proposal Security) is revised: the proposal security amount is $2,500,000.
""",
    # Phrasing no rule knows: must come out UNRESOLVED (I3), never a silent replacement.
    "A3": HEAD + """AMENDMENT NO. 3 — Issued November 2, 2026
This Amendment modifies RFP 2026-04 pursuant to Section 4.3 of the RFP.
A3.1 Section 7.5 (Liquidated Damages) is hereby deleted in its entirety and replaced with the text in Attachment 1.
A3.2 Section 3.2 (Key Dates) is revised: the Proposal Submission Deadline is extended to DECEMBER 18, 2026, 5:00 PM CT.
""",
    # Same number as Amendment 2, different text: a human must choose (I5).
    "A2_conflict": HEAD + """AMENDMENT NO. 2 — Issued October 21, 2026
This Amendment modifies RFP 2026-04 pursuant to Section 4.3 of the RFP.
A2.1 Section 7.1 (Bid Deposit) is revised: the bid deposit is increased from $100,000 to $150,000.
""",
}


def corpus():
    c = {"base": parse.read_document(os.path.join(DATA, "rfp_maple_creek.txt")),
         "A1": parse.read_document(os.path.join(DATA, "rfp_maple_creek_amendment_1.txt"))}
    c.update(SYNTHETIC)
    return c


def reformat(text, rng):
    """Same words, different whitespace: must still be recognized as a duplicate."""
    return "\n".join((" " * rng.randint(0, 3)) + l + (" " * rng.randint(0, 2)) for l in text.splitlines()) + "\n\n"


def one_run(docs, rng):
    keys = ["base", "A1"] + rng.sample(["A2", "A3"], rng.randint(0, 2))
    seq = keys + [rng.choice(keys) for _ in range(rng.randint(0, 3))]          # exact duplicates
    seq += ["~" + rng.choice(keys) for _ in range(rng.randint(0, 2))]           # reformatted duplicates
    if "A2" in keys and rng.random() < 0.3:
        seq.append("A2_conflict")
    rng.shuffle(seq)

    db = store.connect(":memory:")
    fails, raised = [], []
    for k in seq:
        text = reformat(docs[k[1:]], rng) if k.startswith("~") else docs[k]
        try:
            store.ingest(db, text, k)
        except store.DuplicateDocument:
            raised.append(k)

    ingested = set(keys)
    # The conflict is only "the loser" if the real A2 landed first; otherwise A2 itself is rejected.
    first_a2 = next((k.lstrip("~") for k in seq if k.lstrip("~") in ("A2", "A2_conflict")), None)
    if first_a2 == "A2_conflict":
        ingested.discard("A2")
        ingested.add("A2_conflict")

    # I2 no duplicates
    n_docs = db.execute("SELECT COUNT(*) FROM documents").fetchone()[0]
    if n_docs != len(ingested):
        fails.append("I2 docs=%d expected=%d seq=%s" % (n_docs, len(ingested), seq))

    # I5 conflicts surface
    if "A2" in keys and "A2_conflict" in seq and not raised:
        fails.append("I5 conflicting Amendment No. 2 did not raise; seq=%s" % seq)

    # I3 never guess
    for r in db.execute("SELECT amendment_clause, op FROM effects WHERE amendment_clause='A3.1'"):
        if r["op"] != "unresolved":
            fails.append("I3 A3.1 classified as %s" % r["op"])

    # I1 governing value: the latest amendment that replaces a clause governs it
    has_a2 = bool(ingested & {"A2", "A2_conflict"})
    expect = {"7.1": "A2.1" if has_a2 else "A1.2",
              "3.2": "A3.2" if "A3" in ingested else "A1.1",
              "7.2": "A2.2" if "A2" in ingested else None}
    for clause, want in expect.items():
        got = store.governing(db, clause)
        got = got["amendment_clause"] if got else None
        if got != want:
            fails.append("I1 %s governed by %s, expected %s; seq=%s" % (clause, got, want, seq))

    effects = frozenset((r["amendment_clause"], r["op"], r["target"]) for r in db.execute("SELECT * FROM effects"))
    return fails, frozenset(ingested), effects, len(raised)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--runs", type=int, default=30000)
    ap.add_argument("--seed", type=int, default=7)
    args = ap.parse_args()
    rng, docs = random.Random(args.seed), corpus()

    fail_kinds, examples, by_set, conflicts = Counter(), {}, {}, 0
    order_violations = 0
    for _ in range(args.runs):
        fails, ingested, effects, raised = one_run(docs, rng)
        conflicts += raised
        # I4 order independence: same ingested set must always yield the same effects
        prev = by_set.setdefault(ingested, effects)
        if prev != effects:
            order_violations += 1
            fails.append("I4 effects differ for the same document set")
        for f in fails:
            kind = f.split()[0]
            fail_kinds[kind] += 1
            examples.setdefault(kind, f)

    failed_runs = sum(fail_kinds.values())
    out = {"t": datetime.now(timezone.utc).isoformat(), "sim": "M1", "runs": args.runs, "seed": args.seed,
           "failures_by_invariant": dict(fail_kinds), "examples": examples,
           "distinct_document_sets": len(by_set), "conflicts_raised": conflicts}
    with open(os.environ.get("SIM_LOG", os.path.join(ROOT, "flightlog", "sim_runs.jsonl")), "a") as f:
        f.write(json.dumps(out) + "\n")
    print(json.dumps(out, indent=1))
    return 1 if failed_runs else 0


if __name__ == "__main__":
    raise SystemExit(main())
