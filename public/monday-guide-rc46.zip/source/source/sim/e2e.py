"""End-to-end dry run of the demo path, from a cold start, compared to pre-registered expected outputs.

python3 -m sim.e2e [--runs 3] [--provider mock|claude] [--monday fake|live] [--from-zip]     (from source/)

Steps, each timed: ingest -> parse -> resolve -> key facts -> sync boards (twice: the second run must create nothing)
-> reset -> post the demo questions to the Questions board -> poll once -> read the answers back from the board ->
compare each to source/eval/e2e_expected.json (written before the first run). On the mock provider it also runs one
pass per mock fault and requires the board to show a degraded state, never a wrong answer.
--monday fake (default) uses an in-memory board so the run is free and runs in CI; --monday live uses the real
account (about 140 calls per run by the pre-registered estimate; the daily cap is 1,000).
--from-zip runs from a copy unpacked from dist/submission.zip, so the panel's self-contained package is what is tested.
Results append to flightlog/e2e_runs.jsonl.
"""
import argparse
import contextlib
import io
import json
import os
import re
import subprocess
import sys
import tempfile
import time
import zipfile
from datetime import datetime, timezone
from unittest import mock

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.dirname(HERE)
ROOT = os.path.dirname(SRC)


class FakeMonday:
    """In-memory stand-in for every GraphQL call the pipeline makes (same shapes as the real API's replies)."""

    def __init__(self):
        self.boards, self.next_id, self.calls = {}, 1000, []

    def _id(self):
        self.next_id += 1
        return str(self.next_id)

    def _cols(self, b):
        return [{"id": "name", "title": "Name", "type": "name"}] + self.boards[b]["columns"]

    def _row(self, b, iid):
        it = self.boards[b]["items"][iid]
        cv = []
        for c in self.boards[b]["columns"]:
            raw = it["values"].get(c["id"])
            v = json.loads(raw) if raw else None
            text = (v.get("label") or v.get("text") or "") if isinstance(v, dict) else (v or "")
            cv.append({"id": c["id"], "type": c["type"], "value": raw, "text": str(text)})
        return {"id": iid, "name": it["name"], "column_values": cv}

    def gql(self, query, variables=None, purpose="query", retries=3):
        v = variables or {}
        self.calls.append(purpose)
        if "boards(limit: 200" in query:
            return {"boards": [{"id": b, "name": d["name"]} for b, d in self.boards.items()]}
        if "create_board" in query:
            b = self._id()
            self.boards[b] = {"name": v["n"], "columns": [], "items": {}, "updates": []}
            self.boards[b]["items"][self._id()] = {"name": "Task 1", "values": {}, "archived": False}
            return {"create_board": {"id": b}}
        if "columns { id title type }" in query:
            return {"boards": [{"columns": self._cols(v["b"][0])}]}
        if "create_column" in query:
            ctype = re.search(r"column_type: (\w+)", query).group(1)
            cid = "c%s" % self._id()
            self.boards[v["b"]]["columns"].append({"id": cid, "title": v["t"], "type": ctype})
            return {"create_column": {"id": cid}}
        if "items_page_by_column_values" in query:
            b = self.boards[v["b"]]
            hits = [iid for iid, it in b["items"].items() if not it["archived"]
                    and json.loads(it["values"].get(v["c"]) or "null") in v["v"]]
            return {"items_page_by_column_values": {"items": [self._row(v["b"], i) for i in hits]}}
        if "change_multiple_column_values" in query:
            it = self.boards[v["b"]]["items"][v["i"]]
            it["values"].update({k: json.dumps(val) for k, val in json.loads(v["v"]).items()})
            return {"change_multiple_column_values": {"id": v["i"]}}
        if "create_item" in query:
            iid = self._id()
            vals = json.loads(v.get("v") or "{}")
            self.boards[v["b"]]["items"][iid] = {"name": v["n"], "values": {k: json.dumps(x) for k, x in vals.items()}, "archived": False}
            return {"create_item": {"id": iid}}
        if "archive_item" in query:
            for d in self.boards.values():
                if v["i"] in d["items"]:
                    d["items"][v["i"]]["archived"] = True
            return {"archive_item": {"id": v["i"]}}
        if "create_update" in query:
            for d in self.boards.values():
                if v["i"] in d["items"]:
                    d["updates"].append((v["i"], v["b"]))
            return {"create_update": {"id": self._id()}}
        if "items_page(limit:" in query or "next_items_page" in query:
            # Pages like the real API: at most `limit` items, then a cursor until the board is exhausted.
            limit = int(re.search(r"limit: (\d+)", query).group(1))
            if "next_items_page" in query:
                b, start = v["c"].split(":")[0], int(v["c"].split(":")[1])
            else:
                b, start = v["b"][0], 0
            rows = [self._row(b, i) for i, it in self.boards[b]["items"].items() if not it["archived"]]
            page = {"items": rows[start:start + limit], "cursor": "%s:%d" % (b, start + limit) if start + limit < len(rows) else None}
            return {"next_items_page": page} if "next_items_page" in query else {"boards": [{"items_page": page}]}
        if "columns(ids: $c) { revision settings }" in query:
            # A new status column starts with monday.com's three default labels, as the real API does.
            lab = self.boards[v["b"][0]].setdefault("status_labels", [
                {"id": 0, "label": "Working on it", "index": 0, "hex": "#fdab3d"}, {"id": 1, "label": "Done", "index": 1, "hex": "#00c875"},
                {"id": 2, "label": "Stuck", "index": 2, "hex": "#df2f4a"}])
            return {"boards": [{"columns": [{"revision": "r%d" % len(self.calls), "settings": {"labels": lab}}]}]}
        if "update_status_column" in query:
            from rfp import sink as _sink
            hexes = dict(_sink.STATE_HEX, **{"Working on it": "#fdab3d", "Done": "#00c875", "Stuck": "#df2f4a"})
            for x in v["s"]["labels"]:   # the real API refuses to recolor a default label
                assert x["label"] not in ("Working on it", "Done", "Stuck") or x["color"] == _sink.DEFAULT_COLORS[x["label"]], "default label recolored"
            self.boards[v["b"]]["status_labels"] = [dict(x, id=x.get("id", 10 + k), hex=hexes.get(x["label"], "#c4c4c4"))
                                                    for k, x in enumerate(v["s"]["labels"])]
            return {"update_status_column": {"id": v["c"]}}
        if "groups { id title }" in query:
            b = self.boards[v["b"][0]]
            return {"boards": [{"groups": [{"id": "topics", "title": b.setdefault("group", "Group Title")}]}]}
        if "update_group" in query:
            self.boards[v["b"]]["group"] = v["v"]
            return {"update_group": {"id": "topics"}}
        if "items(ids:" in query and "column_values(ids:" in query:
            for d in self.boards.values():
                if v["i"][0] in d["items"]:
                    return {"items": [{"column_values": [{"text": d.setdefault("files", {}).get(v["i"][0], "")}]}]}
            return {"items": [{"column_values": [{"text": ""}]}]}
        raise AssertionError("FakeMonday: unhandled query: " + query[:80])

    def upload_file(self, item_id, column_id, path, purpose="upload file"):
        """Stand-in for the multipart upload: remembers the file name on the item, so a re-sync can be checked."""
        for d in self.boards.values():
            if str(item_id) in d["items"] or item_id in d["items"]:
                d.setdefault("files", {})[item_id] = os.path.basename(path)
        return self._id()


def norm(s):
    return re.sub(r"\s+", " ", s or "").strip()


def one_run(root, provider, fake, expected, fault="none", label=""):
    """One cold run of the demo path. Returns a result dict; never raises (a crash is a failed step)."""
    sys.path[:0] = [os.path.join(root, "source")]
    for m in [k for k in list(sys.modules) if k == "rfp" or k.startswith("rfp.") or k in ("sync_boards", "live_questions")]:
        del sys.modules[m]
    os.environ["MODEL_PROVIDER"] = provider
    os.environ["MOCK_FAULT"] = fault
    os.environ["MODEL_CALL_LOG"] = os.devnull if provider == "mock" else os.environ.get("MODEL_CALL_LOG", os.path.join(ROOT, "flightlog", "model_calls.jsonl"))
    steps, fails, t0 = {}, [], time.time()
    from rfp import monday, sink, store  # noqa: E402  (fresh import from the root under test)
    if not os.path.abspath(store.__file__).startswith(os.path.abspath(root)):  # K48: never test a different copy
        raise RuntimeError("imported %s, not the copy under test in %s" % (store.__file__, root))
    import sync_boards  # noqa: E402
    import live_questions  # noqa: E402
    patch = mock.patch.multiple(monday, gql=fake.gql, upload_file=fake.upload_file) if fake else contextlib.nullcontext()
    if fake:   # the stand-in boards get their own column-id record, never the real account's (K65)
        import tempfile
        os.environ["RFP_BOARD_STATE"] = os.path.join(tempfile.mkdtemp(), "boards.json")
    quiet = contextlib.redirect_stdout(io.StringIO())

    def step(name, fn):
        s = time.time()
        try:
            out = fn()
            steps[name] = {"ok": True, "s": round(time.time() - s, 2)}
            return out
        except Exception as e:
            steps[name] = {"ok": False, "s": round(time.time() - s, 2), "error": "%s: %s" % (type(e).__name__, str(e)[:160])}
            fails.append("%s crashed: %s" % (name, steps[name]["error"]))
            return None

    with patch, quiet:
        db = step("ingest + resolve", sync_boards.load)
        if db is not None:
            d = expected["documents"]
            n_base = db.execute("SELECT COUNT(*) FROM clauses c JOIN documents x ON x.sha256=c.doc_sha WHERE x.kind='base'").fetchone()[0]
            n_am = db.execute("SELECT COUNT(*) FROM documents WHERE kind='amendment'").fetchone()[0]
            ops = [r["op"] for r in db.execute("SELECT op FROM effects")]
            if n_base < d["base_clauses_min"]: fails.append("base clauses %d < %d" % (n_base, d["base_clauses_min"]))
            if n_am != d["amendments"]: fails.append("amendments %d != %d" % (n_am, d["amendments"]))
            if len(ops) < d["amendment_effects_min"]: fails.append("amendment effects %d < %d" % (len(ops), d["amendment_effects_min"]))
            if ops.count("unresolved") != d["unresolved"]: fails.append("unresolved %d != %d" % (ops.count("unresolved"), d["unresolved"]))
        calls_before = len(fake.calls) if fake else 0
        step("sync 1", sync_boards.main)
        created_counter = {"n": 0}
        real_upsert = sink.MondaySink.upsert

        def counting(self, *a, **k):
            r = real_upsert(self, *a, **k)
            created_counter["n"] += 1 if r[1] else 0
            return r
        with mock.patch.object(sink.MondaySink, "upsert", counting):
            step("sync 2 (must create nothing)", sync_boards.main)
        if created_counter["n"] != expected["sync"]["second_run_created"]:
            fails.append("second sync created %d items (expected 0)" % created_counter["n"])
        s = sink.MondaySink()
        qb = step("questions board", lambda: s.board("RET · Questions", sync_boards.QUESTION_COLS))
        qs = [q for q in expected["questions"] if q["tier"] == "any" or provider != "mock"]
        if fault != "none":
            qs = [q for q in expected["questions"] if q["tier"] == "claude"] or qs
        if qb:
            cols = s.columns[qb]
            for q in qs:
                monday.gql("mutation ($b: ID!, $n: String!, $v: JSON!) { create_item(board_id: $b, item_name: $n, column_values: $v) { id } }",
                           {"b": qb, "n": "[rehearsal] " + q["q"][:200], "v": json.dumps({cols["Question"]: {"text": q["q"]}})}, purpose="rehearsal question")
            with mock.patch.object(sys, "argv", ["live_questions", "--once"]):
                step("poll once", live_questions.main)
            rows = monday.all_items(qb, "id name column_values { id text }", purpose="read back answers")
            got = {}
            for it in rows:
                vals = {c["id"]: c["text"] for c in it["column_values"]}
                got[norm(vals.get(cols["Question"]) or it["name"].replace("[rehearsal] ", ""))] = vals
            label_for = {"answered": "Answered", "not_addressed": "Not addressed in RFP"}
            for q in qs:
                v = got.get(norm(q["q"]))
                if not v:
                    fails.append("%s: no answer on the board" % q["id"]); continue
                state, ans, cites = v.get(cols["State"], ""), v.get(cols["Answer"], ""), v.get(cols["Citations"], "")
                if fault != "none":
                    if state == "Answered" and any(f for f in re.findall(r"\$[\d,]+", ans) if f not in cites):
                        fails.append("%s under %s: board shows Answered with a figure not in its citations" % (q["id"], fault))
                    if "summary failed" in ans and state != "Needs review":
                        fails.append("%s under %s: summary withheld but board says %r" % (q["id"], fault, state))
                    continue
                if state != label_for[q["status"]]:
                    fails.append("%s: board state %r, expected %r" % (q["id"], state, label_for[q["status"]]))
                for c in q["must_cite"]:
                    if "§" + c not in cites:
                        fails.append("%s: missing citation %s" % (q["id"], c))
                for f in q["must_say"]:
                    if f.lower() not in (ans + " " + cites).lower():
                        fails.append("%s: missing %r" % (q["id"], f))
                for f in q["must_not_say"]:
                    if f in ans:
                        fails.append("%s: says %r" % (q["id"], f))
            if fake:
                from rfp.sink import ALLOWED_BOARDS
                stray = [d["name"] for d in fake.boards.values() if d["name"] not in ALLOWED_BOARDS]
                if stray: fails.append("Sam: boards outside the allowlist: %s" % stray)
                blob = json.dumps({b: d["items"] for b, d in fake.boards.items()})
                if re.search(r"sk" "-ant-|eyJhbG" "ciOi", blob): fails.append("Sam: a secret-shaped string reached the board")
            for it in rows:
                if it["name"].startswith("[rehearsal]"):
                    monday.gql("mutation ($i: ID!) { archive_item(item_id: $i) { id } }", {"i": it["id"]}, purpose="archive rehearsal item")
    sys.path.remove(os.path.join(root, "source"))
    secs = round(time.time() - t0, 2)
    pred = expected["predicted"][provider if provider in expected["predicted"] else "mock"]
    calls = (len(fake.calls) - calls_before) if fake else None
    poll = steps.get("poll once", {}).get("s", 0)
    per_q = poll / max(1, len(qs)) if qb else 0
    if per_q > pred["seconds_per_question_max"]:
        fails.append("took %.1f s per answered question, budget %d s (the demo slot)" % (per_q, pred["seconds_per_question_max"]))
    return {"label": label or provider, "fault": fault, "seconds": secs, "seconds_per_question": round(per_q, 2), "monday_calls": calls, "steps": steps,
            "pass": not fails, "fails": fails}


def unpack_zip():
    z = os.path.join(ROOT, "dist", "submission.zip")
    if not os.path.exists(z):
        subprocess.run([sys.executable, os.path.join(ROOT, "scripts", "package.py")], capture_output=True)
    d = tempfile.mkdtemp(prefix="rfp-e2e-")
    with zipfile.ZipFile(z) as f:
        f.extractall(d)
    # The ZIP holds the repo under source/ (source/rfp, source/source/...). Returning the ZIP root here made
    # one_run put <zip>/source on sys.path, which has no rfp package, so imports fell through to the repo (K48).
    return os.path.join(d, "source")


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--runs", type=int, default=3)
    ap.add_argument("--provider", default="mock", choices=["mock", "claude"])
    ap.add_argument("--monday", default="fake", choices=["fake", "live"])
    ap.add_argument("--from-zip", action="store_true")
    ap.add_argument("--no-log", action="store_true")
    a = ap.parse_args(argv)
    expected = json.load(open(os.path.join(SRC, "eval", "e2e_expected.json")))
    root = unpack_zip() if a.from_zip else ROOT
    results = []
    for i in range(a.runs):
        fake = FakeMonday() if a.monday == "fake" else None
        results.append(one_run(root, a.provider, fake, expected, label="%s run %d" % (a.provider, i + 1)))
    if a.provider == "mock":
        for f in expected["faults"]:
            results.append(one_run(root, "mock", FakeMonday() if a.monday == "fake" else None, expected, fault=f, label="mock fault " + f))
    # A step that behaves differently across identical runs is a failure even if each run passed (W10-type flake).
    sig = {json.dumps(sorted(r["fails"])) for r in results if r["fault"] == "none"}
    flaky = len(sig) > 1
    summary = {"t": datetime.now(timezone.utc).isoformat(), "provider": a.provider, "monday": a.monday, "from_zip": a.from_zip,
               "runs": len(results), "passed": sum(r["pass"] for r in results), "flaky": flaky, "results": results}
    uat = {}
    keys = {"Doug": ["E1", "E2", "E6", "second sync", "amendments", "base clauses", "unresolved", "amendment effects"],
            "Nina": ["E3", "E5", "under "], "Sam Ito": ["Sam:"], "Elena": ["E4", "E7", "per answered question", "no answer on the board", "crashed"]}
    for persona, checks in expected["uat"].items():
        hit = [f for r in results for f in r["fails"] if any(k in f for k in keys[persona])]
        uat[persona] = {"checks": checks, "pass": not hit, "failures": hit[:5]}
    summary["uat"] = uat
    if not a.no_log:
        with open(os.path.join(ROOT, "flightlog", "e2e_runs.jsonl"), "a") as f:
            f.write(json.dumps(summary) + "\n")
    print("UAT by persona (pass/fail on every run):")
    for p, u in uat.items():
        print("  %-8s %s  (%d checks)%s" % (p, "PASS" if u["pass"] else "FAIL", len(u["checks"]), "".join("\n      - " + f for f in u["failures"])))
    for r in results:
        print("%-24s %s  %5.1f s  monday calls %s%s" % (r["label"], "PASS" if r["pass"] else "FAIL", r["seconds"], r["monday_calls"],
                                                      "".join("\n    - " + x for x in r["fails"])))
    print("e2e: %d of %d runs passed%s (%s, monday %s%s)" % (summary["passed"], summary["runs"], ", RESULTS DIFFER ACROSS RUNS" if flaky else "",
                                                             a.provider, a.monday, ", from the ZIP" if a.from_zip else ""))
    return 0 if summary["passed"] == summary["runs"] and not flaky else 1


if __name__ == "__main__":
    sys.exit(main())
