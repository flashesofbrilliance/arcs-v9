"""./rfp start: one interactive session for a demo or a working day. Pre-flight checks, then the bench and the poller.

Checks run in order and stop at the first that fails, each printing one line:
  1. machine and keys (./rfp doctor: Python, .env, the monday.com token works, calls left today)
  2. answering model (Claude if a key is set; else a local model if Ollama is running; --provider overrides)
  3. documents (every RFP and amendment in data/ parses; how many clauses each)
  4. boards (the sync runs; safe to re-run, a re-run creates nothing)
  5. optional: --reset archives [rehearsal] questions first
Then the test bench starts in the background (http://127.0.0.1:8765) and the poller runs here, answering the
RET · Questions board every minute with no idle stop while this session is open. Ctrl-C stops both.
Standard library only.
"""
import argparse
import os
import signal
import socket
import subprocess
import sys
import time
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)


def say(state, what, detail=""):
    print("%-6s %-22s %s" % (state, what, detail), flush=True)


def run(*args):
    return subprocess.call([sys.executable, *args], cwd=HERE)


def ollama_up():
    try:
        urllib.request.urlopen("http://localhost:11434/api/tags", timeout=2).read()
        return True
    except Exception:
        return False


def port_free(port):
    with socket.socket() as s:
        return s.connect_ex(("127.0.0.1", port)) != 0


def main():
    ap = argparse.ArgumentParser(prog="rfp start")
    ap.add_argument("--provider", choices=["claude", "local"], help="answering model (default: Claude if a key is set, else local)")
    ap.add_argument("--reset", action="store_true", help="archive [rehearsal] questions before starting")
    ap.add_argument("--no-sync", action="store_true", help="skip the board sync")
    ap.add_argument("--interval", type=int, default=60)
    a = ap.parse_args()

    print("RET RFP Intelligence: pre-flight\n", flush=True)
    from rfp import runlock
    folder = os.path.dirname(HERE)
    h = runlock.holder("poller")
    if h:
        say("STOP", "poller", "already running: pid %s in %s; run ./rfp stop first" % (h.get("pid"), h.get("folder")))
        return 1
    if runlock.calls_left() <= runlock.RESERVE:
        say("STOP", "monday.com calls", "only %d left today; the poller would stop at once" % runlock.calls_left())
        return 1
    if run("doctor.py"):
        say("STOP", "machine and keys", "fix the FAIL or MISSING line above, then run ./rfp start again")
        return 1

    from rfp.config import env
    provider = a.provider or ("claude" if env("ANTHROPIC_API_KEY") else ("local" if ollama_up() else None))
    if provider is None:
        say("STOP", "answering model", "no Claude key and no local model running; add the key to .env or start Ollama")
        return 1
    if provider == "local" and not ollama_up():
        say("STOP", "answering model", "Ollama is not running on localhost:11434; run: ollama serve")
        return 1
    say("OK", "answering model", provider + ("" if provider == "local" else "; local fallback %s" % ("ready" if ollama_up() else "not running")))

    from sync_boards import documents
    from rfp import parse
    docs = documents()
    if not docs:
        say("STOP", "documents", "no RFP found in data/")
        return 1
    say("OK", "documents", "; ".join("%s (%d clauses)" % (f, len(parse.parse(raw).clauses)) for f, raw in docs))

    if a.reset:
        r = subprocess.run([sys.executable, "demo_reset.py"], cwd=HERE, capture_output=True, text=True)
        if r.returncode:
            print(r.stdout + r.stderr)
            say("STOP", "reset", "could not archive rehearsal questions")
            return 1
        say("OK", "reset", (r.stdout.strip().splitlines() or ["done"])[-1][:80])
    if not a.no_sync:
        r = subprocess.run([sys.executable, "sync_boards.py"], cwd=HERE, capture_output=True, text=True)
        if r.returncode:
            print(r.stdout + r.stderr)
            say("STOP", "boards", "the sync failed; see the message above")
            return 1
        try:
            import json
            out = json.loads(r.stdout[r.stdout.index("{"):r.stdout.rindex("}") + 1])
            n = out["items"]
            say("OK", "boards", "%d boards; %d created, %d updated, %d unchanged" % (len(out["boards"]), n["created"], n["updated"], n["unchanged"]))
        except (ValueError, KeyError):
            say("OK", "boards", "synced")

    # Closing the terminal or a kill must stop both children, not only Ctrl-C (K61).
    def _bye(signum, frame):
        raise KeyboardInterrupt
    signal.signal(signal.SIGTERM, _bye)
    signal.signal(signal.SIGHUP, _bye)

    bench = poller = None
    try:
        b = runlock.holder("bench")
        if b and os.path.abspath(b.get("folder", "")) == os.path.abspath(folder):
            say("OK", "test bench", "already running from this copy: http://127.0.0.1:8765/#bench")
        elif b:
            say("STOP", "test bench", "port 8765 is served by another copy: pid %s in %s; run ./rfp stop" % (b.get("pid"), b.get("folder")))
            return 1
        elif not port_free(8765):
            say("STOP", "test bench", "port 8765 is used by another program; free it, then start again")
            return 1
        else:
            bench = subprocess.Popen([sys.executable, "-m", "harness.server"], cwd=HERE,
                                     env=dict(os.environ, HARNESS_QUIET="1"), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            for _ in range(50):   # wait up to 5 s for it to answer, instead of assuming it started
                if bench.poll() is not None or not port_free(8765):
                    break
                time.sleep(0.1)
            if bench.poll() is not None or port_free(8765):
                say("STOP", "test bench", "did not start; run: cd source && python3 -m harness.server")
                return 1
            say("OK", "test bench", "http://127.0.0.1:8765/#bench · pages and code: http://127.0.0.1:8765/source/docs/site/index.html")

        print("\nReady. Ask on the RET · Questions board in monday.com; answers appear here within a minute. Ctrl-C stops.\n", flush=True)
        os.environ["MODEL_PROVIDER"] = provider
        poller = subprocess.Popen([sys.executable, "live_questions.py", "--interval", str(a.interval), "--max-idle-min", "0"], cwd=HERE)
        return poller.wait()
    except KeyboardInterrupt:
        return 0
    finally:
        started = [p for p in (poller, bench) if p]
        for p in started:
            if p.poll() is None:
                p.terminate()
                try:
                    p.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    p.kill()
        if started:
            print("\nStopped: %s." % " and ".join(n for n, p in (("poller", poller), ("test bench", bench)) if p), flush=True)


if __name__ == "__main__":
    sys.exit(main())
