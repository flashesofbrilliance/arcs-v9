"""Push the solicitation, its key facts, and its documents to monday.com. Safe to re-run: every write is
an upsert keyed by our own Key column, so a second run changes nothing it does not need to.

python3 sync_boards.py            (from source/)
Writes three boards: RET · Solicitations, RET · Key Facts, RET · Questions (empty, ready for staff).
"""
import json
import os
import sys

from rfp import monday, sink, store
from rfp.answer import cite

DATA = os.path.join(os.path.dirname(__file__), "..", "data")

# Elena's one-page fields -> the clause that defines each. Values are copied verbatim from whichever text
# governs (amendment or base); nothing here is summarised.
KEY_FACTS = [
    ("Proposal due date and key dates", "3.2"),
    ("Bid deposit", "7.1"),
    ("Risk carried by RET: proposal security", "7.2"),
    ("Post-selection security", "7.3"),
    ("Risk carried by RET: cost cap cannot be revised upward", "7.4"),
    ("Risk carried by RET: delay liquidated damages", "7.5"),
    ("Evaluation criteria and weights", "8.1"),
    ("Minimum transfer capability", "1.2"),
    ("Target in-service date", "1.3"),
    ("Eligibility: development experience", "5.1"),
    ("Eligibility: financial standing", "5.2"),
    ("Eligibility: cybersecurity attestation (new)", "5.5"),
    ("Contact rules during the solicitation", "4.2"),
    ("Proposal page limits", "11.4"),
]

SOLICITATION_COLS = [("Kind", "text"), ("Amendment no.", "numbers"), ("Issued", "text"), ("Clauses", "numbers"),
                     ("What it changes", "long_text"), ("Document", "file")]
FACT_COLS = [("Governing text (verbatim)", "long_text"), ("Source", "text"), ("Amended by", "text"),
             ("State", "status"), ("Verified by", "text")]
QUESTION_COLS = [("Question", "long_text"), ("State", "status"), ("Answer", "long_text"), ("Citations", "long_text"),
                 ("Call ID", "text")]


SKIPPED = set()


def documents(folder=None):
    """Every solicitation document in data/: the base RFP first, then amendments in number order, so a new
    Amendment No. 2 dropped into the folder applies on top of No. 1 with no code change. Only a named non-document
    file (the sample questions) is skipped; any other file with no clauses is refused as unreadable by store.ingest."""
    from rfp import parse as P
    folder = folder or DATA
    found = []
    for f in sorted(os.listdir(folder)):
        if not f.endswith(".txt"):
            continue
        raw = P.read_document(os.path.join(folder, f))
        d = P.parse(raw)
        if not d.clauses and store.may_have_no_clauses(f):
            SKIPPED.add(f)   # named by the sync's own output, never dropped silently
            continue
        found.append(((0, 0) if d.kind != "amendment" else (1, d.amendment_no or 0), f, raw))
    return [(f, raw) for _, f, raw in sorted(found)]


def load(folder=None):
    db = store.connect(":memory:")
    for f, raw in documents(folder):
        try:
            store.ingest(db, raw, f)
        except store.DuplicateDocument as e:
            raise store.DuplicateDocument("%s: %s" % (f, e)) from None   # name the file (K77)
    return db


def data_signature(folder=None):
    """A cheap fingerprint of the document folder: name, modified time and size of every .txt (K75)."""
    folder = folder or DATA
    out = []
    for f in sorted(os.listdir(folder)):
        if f.endswith(".txt"):
            st = os.stat(os.path.join(folder, f))
            out.append((f, st.st_mtime_ns, st.st_size))
    return tuple(out)


def main():
    try:
        db = load()
    except (store.UnreadableDocument, store.DuplicateDocument) as e:
        print("NEEDS REVIEW: nothing was synced. %s" % e, file=sys.stderr)
        return 2
    by_id = {c["clause_id"]: c for c in store.all_clauses(db)}
    s = sink.MondaySink()
    counts = {"created": 0, "updated": 0, "unchanged": 0}

    def tally(created):
        counts["unchanged" if created is None else "created" if created else "updated"] += 1

    sol = s.board("RET · Solicitations", SOLICITATION_COLS)
    for d in db.execute("SELECT * FROM documents ORDER BY kind DESC, amendment_no"):
        effects = db.execute("SELECT amendment_clause, op, target FROM effects WHERE doc_sha=?", (d["sha256"],)).fetchall()
        changes = "; ".join("§%s %s %s" % (e["amendment_clause"], e["op"].replace("_", " "),
                                           "any section" if e["target"] == "*" else "no section" if e["target"] is None
                                           else "§" + e["target"].replace(",", ", §")) for e in effects)
        n = db.execute("SELECT COUNT(*) FROM clauses WHERE doc_sha=?", (d["sha256"],)).fetchone()[0]
        name = d["title"] if d["kind"] == "base" else "Amendment No. %d (issued %s)" % (d["amendment_no"], d["issued"])
        iid, created = s.upsert(sol, d["sha256"][:16], name, {
            "Kind": sink.text(d["kind"]), "Amendment no.": sink.number(d["amendment_no"] or 0),
            "Issued": sink.text(d["issued"] or ""), "Clauses": sink.number(n),
            "What it changes": sink.long_text(changes or "Base document")})
        tally(created)
        if d["filename"] and os.path.exists(os.path.join(DATA, d["filename"])):
            s.attach_once(sol, iid, "Document", os.path.join(DATA, d["filename"]))

    facts = s.board("RET · Key Facts", FACT_COLS)
    for label, cid in KEY_FACTS:
        base = by_id.get(cid)
        gov = store.governing(db, cid)
        if gov:
            src, amended, text, state = by_id[gov["amendment_clause"]], "§" + gov["amendment_clause"], gov["amendment_text"], "Amended"
        elif base:
            src, amended, text, state = base, "", base["text"], "From base RFP"
        else:
            # A clause added by an amendment (e.g. 5.5) exists only inside the amendment that adds it.
            add = [e for e in store.effects_on(db, cid) if e["op"] == "adds" and e["target"] == cid]
            if not add:
                print("SKIP %s: clause %s not found" % (label, cid))
                continue
            src, amended, text, state = by_id[add[0]["amendment_clause"]], "§" + add[0]["amendment_clause"] + " (adds)", add[0]["amendment_text"], "Amended"
        unresolved = [e for e in store.effects_on(db, cid) if e["op"] == "unresolved"]
        if unresolved:
            state = "Needs review"
        _, created = s.upsert(facts, "fact:" + cid, label, {
            "Governing text (verbatim)": sink.long_text(text), "Source": sink.text(cite(src)),
            "Amended by": sink.text(amended), "State": sink.status(state)}, create_only={"Verified by": sink.text("")})
        tally(created)

    q = s.board("RET · Questions", QUESTION_COLS)
    s.color_states(q, "State", sink.STATE_COLORS)
    for bid in (sol, facts, q):
        s.name_group(bid, "Maple Creek RFP")
        archived = s.archive_template_rows(bid)
        if archived:
            print("archived template rows on board %s: %s" % (bid, archived))
    print(json.dumps({"boards": s.boards, "items": counts}, indent=1))
    for f in sorted(SKIPPED):
        print("not a solicitation document (no RFP clauses), skipped: %s" % f)
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except monday.MondayError as e:
        print("monday error (code %s, request %s): %s" % (e.code, e.request_id, e), file=sys.stderr)
        sys.exit(1)
