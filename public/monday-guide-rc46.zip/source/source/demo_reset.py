"""Before a demo: archive rehearsal questions so the panel starts from a clean Questions board.

python3 demo_reset.py            (from source/)
Archives (recoverable, never deletes) only items whose name starts with "[rehearsal]".
"""
from rfp import monday, sink
from sync_boards import QUESTION_COLS

s = sink.MondaySink()
b = s.board("RET · Questions", QUESTION_COLS)
items = monday.all_items(b, "id name", purpose="find rehearsal items")
done = [i["name"] for i in items if i["name"].startswith("[rehearsal]")]
for i in items:
    if i["name"].startswith("[rehearsal]"):
        monday.gql("mutation ($i: ID!) { archive_item(item_id: $i) { id } }", {"i": i["id"]}, purpose="archive rehearsal item")
print("archived %d rehearsal item(s): %s" % (len(done), done))
