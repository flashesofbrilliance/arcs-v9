"""Golden eval: python3 -m eval.run_eval [--provider claude|local]

A case passes only if status, required citations, required figures, forbidden figures and required
notes all hold. Results and cost land in flightlog/eval_runs.jsonl for the flight report.
"""
import argparse
import json
import os
import tempfile
from datetime import datetime, timezone

from rfp import answer, parse, store
from rfp.answer import has_figure

HERE = os.path.dirname(__file__)
ROOT = os.path.join(HERE, "..", "..")
DATA = os.path.join(ROOT, "data")


def check(case, r):
    fails = []
    # A carve-out the RFP only partly settles may honestly come back either way; such a case lists both statuses
    # and still has to cite the clause and say the carve-out (the other checks below).
    allowed = case.get("accept_status") or [case["status"]]
    if r["status"] not in allowed:
        fails.append("status %s != %s" % (r["status"], "/".join(allowed)))
    cited = {c["clause_id"] for c in r.get("citations", [])}
    fails += ["missing cite %s" % c for c in case["must_cite"] if c not in cited]
    said = r["answer"] + " " + " ".join(c["text"] for c in r.get("citations", []))
    fails += ["missing figure %s" % f for f in case["must_say"] if not has_figure(said, f)]
    fails += ["forbidden %s" % f for f in case["must_not_say"] if has_figure(r["answer"], f)]
    if case.get("must_note") and not any(case["must_note"] in n for n in r.get("notes", [])):
        fails.append("missing note on %s" % case["must_note"])
    return fails


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--provider", default=os.environ.get("MODEL_PROVIDER", "claude"))
    ap.add_argument("--only", nargs="*")
    ap.add_argument("--golden", default="golden.json")
    args = ap.parse_args()
    os.environ["MODEL_PROVIDER"] = args.provider

    db = store.connect(os.path.join(tempfile.mkdtemp(), "eval.db"))
    for f in ("rfp_maple_creek.txt", "rfp_maple_creek_amendment_1.txt"):
        store.ingest(db, parse.read_document(os.path.join(DATA, f)), f)

    cases = json.load(open(os.path.join(HERE, args.golden)))
    if args.only:
        cases = [c for c in cases if c["id"] in args.only]
    results = []
    for case in cases:
        try:
            r = answer.answer(db, case["q"])
            fails = check(case, r)
        except Exception as e:
            r, fails = {"status": "error", "answer": str(e)}, ["exception: %s" % e]
        results.append({"id": case["id"], "pass": not fails, "fails": fails, "gate": r.get("gate"),
                        "answer": r["answer"], "cited": [c["clause_id"] for c in r.get("citations", [])]})
        print("%-4s %s %s" % (case["id"], "PASS" if not fails else "FAIL", "; ".join(fails)))

    passed = sum(r["pass"] for r in results)
    print("\n%d/%d passed (%s)" % (passed, len(results), args.provider))
    with open(os.path.join(ROOT, "flightlog", "eval_runs.jsonl"), "a") as f:
        from rfp import provider as _prov
        model = {"claude": _prov.CLAUDE_MODEL, "local": _prov.LOCAL_MODEL}.get(args.provider, args.provider)
        f.write(json.dumps({"t": datetime.now(timezone.utc).isoformat(), "provider": args.provider, "model": model, "set": args.golden,
                            "passed": passed, "total": len(results), "results": results}) + "\n")
    return 0 if passed == len(results) else 1


if __name__ == "__main__":
    raise SystemExit(main())
