"""Regression gate: compare the latest results, case by case, against the last-known-good baseline.

python3 -m eval.regress check     # exit 1 if any case that passed in the baseline now fails
python3 -m eval.regress bless     # make the latest results the new baseline (only when all green)

Reads the latest run of each eval set (flightlog/eval_runs.jsonl) and the latest scenario matrix
(flightlog/scenario_runs.jsonl). A score can stay flat while a case flips; this compares cases, not totals.
"""
import json
import os
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
BASE = os.path.join(ROOT, "eval_baseline.json")


def latest():
    out = {}
    runs = os.path.join(ROOT, "flightlog", "eval_runs.jsonl")
    for line in open(runs):
        r = json.loads(line)
        if r["provider"] != "claude":
            continue
        # A run where no model replied (every failure a provider setup error, e.g. no API key) says nothing about
        # the system; it must not become the "latest" result and fake a regression (D-SETUPRUN).
        bad = [x for x in r["results"] if not x["pass"]]
        if bad and all(str(x.get("gate", "")).startswith("provider:") for x in bad):
            continue
        name = r.get("set") or "golden.json"
        out[name] = {x["id"]: x["pass"] for x in r["results"]}
    sc = os.path.join(ROOT, "flightlog", "scenario_runs.jsonl")
    if os.path.exists(sc):
        last = None
        for line in open(sc):
            if line.strip():
                last = json.loads(line)
        if last:
            out["scenarios"] = {x["id"]: x["pass"] for x in last["results"]}
    return out


def main(cmd):
    now = latest()
    if cmd == "bless":
        bad = [(s, c) for s, cases in now.items() for c, ok in cases.items() if not ok]
        if bad:
            print("refusing to bless: %d failing cases, e.g. %s" % (len(bad), bad[:3]))
            return 1
        json.dump(now, open(BASE, "w"), indent=1, sort_keys=True)
        print("baseline blessed: %s" % {s: len(c) for s, c in now.items()})
        return 0
    if not os.path.exists(BASE):
        print("no baseline yet: run all sets green, then `python3 -m eval.regress bless`")
        return 1
    base = json.load(open(BASE))
    regressions = [(s, c) for s, cases in base.items() for c, ok in cases.items() if ok and now.get(s, {}).get(c) is False]
    missing = [(s, c) for s, cases in base.items() for c in cases if c not in now.get(s, {})]
    for s, c in regressions:
        print("REGRESSION %s %s: passed in baseline, fails now" % (s, c))
    for s, c in missing[:5]:
        print("NOT RUN %s %s" % (s, c))
    # A case added after the last bless has no baseline to regress from; it must still pass before it ships.
    new_failing = [(s, c) for s, cases in now.items() for c, ok in cases.items() if not ok and c not in base.get(s, {})]
    for s, c in new_failing[:5]:
        print("NEW CASE FAILING %s %s" % (s, c))
    print("regression check: %d regressions, %d cases not run, %d new cases failing" % (len(regressions), len(missing), len(new_failing)))
    return 1 if regressions or missing or new_failing else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1] if len(sys.argv) > 1 else "check"))
