"""Golden provenance gate (root cause of K7/K9: tests had no provenance requirement).

Every expected figure must appear verbatim in the source documents; every forbidden figure must NOT
(it exists only if someone computes it); every required citation must be a clause the parser produced.
python3 -m eval.check_golden    # exit 1 on any expectation that is not grounded in the source
"""
import json
import os
import sys

from rfp import parse
from rfp.answer import has_figure

HERE = os.path.dirname(__file__)
DATA = os.path.join(HERE, "..", "..", "data")


def main():
    texts = {f: open(os.path.join(DATA, f)).read() for f in ("rfp_maple_creek.txt", "rfp_maple_creek_amendment_1.txt")}
    corpus = " ".join(" ".join(c.text for c in parse.parse(t).clauses) for t in texts.values())
    ids = {c.clause_id for t in texts.values() for c in parse.parse(t).clauses}
    errors = []
    for case in json.load(open(os.path.join(HERE, sys.argv[1] if len(sys.argv) > 1 else "golden.json"))):
        errors += ["%s: expected figure %r is not verbatim in the source" % (case["id"], f)
                   for f in case["must_say"] if not has_figure(corpus, f)]
        errors += ["%s: forbidden figure %r appears in the source, so forbidding it is wrong" % (case["id"], f)
                   for f in case["must_not_say"] if has_figure(corpus, f)]
        errors += ["%s: citation %r is not a parsed clause" % (case["id"], c)
                   for c in case["must_cite"] if c not in ids]
    for e in errors:
        print("UNGROUNDED " + e)
    print("golden provenance: %d issues" % len(errors))
    return 1 if errors else 0


if __name__ == "__main__":
    raise SystemExit(main())
