"""Local test harness + build observatory. Stdlib only; binds to 127.0.0.1.

python3 -m harness.server            (from source/), then open http://127.0.0.1:8765

Tabs: Tickets (stack-ranked, nested, dependencies), Observatory (minute-scale timeline by altitude),
Beliefs (ex-ante vs ex-post), Harness (edit documents, inject faults, run a question or the golden set).
Every run uses a fresh in-memory database. The default provider is the $0 mock; Claude spends money.
"""
import json
import re
import os
import sqlite3
import subprocess
import sys
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import threading
POST_LOCK = threading.Lock()
RUNNING = {}   # what holds POST_LOCK: model and start time, so a second run is told, not silently queued

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.dirname(HERE)
ROOT = os.path.dirname(SRC)
sys.path.insert(0, SRC)
sys.path.insert(0, os.path.join(ROOT, "scripts"))

from rfp import answer, faults, store  # noqa: E402
from eval.run_eval import check  # noqa: E402
import dashboard  # noqa: E402  (reuses its readers so the numbers match the static dashboard)

PORT = int(os.environ.get("HARNESS_PORT", "8765"))
PROVIDERS = {"mock", "local", "claude"}
# Paid model calls from the page need an explicit server-side switch (./rfp serve --paid); default is free (K36).
ALLOW_PAID = os.environ.get("RFP_ALLOW_PAID") == "1"
MAX_BODY = 64 * 1024  # the sample package posts ~16.5 KB (measured); real large RFPs go through the CLI, not this page
HOSTS = {"127.0.0.1:%d" % PORT, "localhost:%d" % PORT}
ORIGINS = {"http://" + h for h in HOSTS}
SECURITY_HEADERS = {
    "Content-Security-Policy": "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; "
                               "img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'; "
                               "style-src-elem 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src https://fonts.gstatic.com",
    "X-Content-Type-Options": "nosniff", "X-Frame-Options": "DENY", "Referrer-Policy": "no-referrer"}


def read(path):
    return open(os.path.join(ROOT, path)).read()


def plan_state():
    plan = json.load(open(os.path.join(ROOT, "plan.json")))
    nodes = {n["id"]: n for n in plan["nodes"]}
    done = {i for i, n in nodes.items() if n["status"] == "done"}
    for n in nodes.values():
        n["state"] = n["status"] if n["status"] in ("done", "cut", "deferred") else ("ready" if all(d in done for d in n["needs"]) else "blocked")
        n["blocks"] = [m["id"] for m in nodes.values() if n["id"] in m["needs"]]
    depth = {}

    def chain(i):
        if i not in depth:
            depth[i] = 1 + max([chain(d) for d in nodes[i]["needs"] if d not in done and d not in parked] or [0])
        return depth[i]

    parked = {i for i, n in nodes.items() if n["status"] in ("cut", "deferred")}   # never on the critical path
    open_ids = [i for i in nodes if i not in done and i not in parked]
    path, cur = [], max(open_ids, key=chain) if open_ids else None
    while cur:
        path.append(cur)
        pend = [d for d in nodes[cur]["needs"] if d not in done and d not in parked]
        cur = max(pend, key=chain) if pend else None
    return {"epics": plan["epics"], "nodes": sorted(nodes.values(), key=lambda n: n["rank"]),
            "critical_path": list(reversed(path)), "deadline": plan["deadline"]}


# The review pages and the deck's HTML ship in source/docs/site/. presentation/ holds only the PDF: under the repo root,
# or beside source/ in the submission ZIP (K60).
SITE = os.path.join(ROOT, "docs", "site")
PRES = next((d for d in (os.path.join(ROOT, "presentation"), os.path.join(ROOT, "..", "presentation")) if os.path.isdir(d)),
            os.path.join(ROOT, "presentation"))


def build_id():
    """Changes whenever the code or the page a viewer is looking at changes, so an open tab can tell it is stale."""
    import hashlib
    h = hashlib.sha256()
    for f in (os.path.join(ROOT, "source/harness/ui.html"), os.path.join(SITE, "deck.html"), os.path.join(ROOT, "source/harness/server.py")):
        if os.path.isfile(f):
            h.update(open(f, "rb").read())
    head = subprocess.run(["git", "-C", ROOT, "rev-parse", "--short", "HEAD"], capture_output=True, text=True).stdout.strip()
    return head + "-" + h.hexdigest()[:8]


def state():
    ncalls, usd, per_q = dashboard.costs()
    nk, whose = dashboard.kintsugi()
    kin = []
    for line in read("KINTSUGI.md").splitlines():
        cells = [c.strip() for c in line.split("|")]
        if len(cells) > 7 and cells[1].startswith("K") and cells[1][1:].isdigit():
            kin.append({"id": cells[1], "seam": cells[2], "detected_by": cells[3], "whose": cells[4].replace("*", ""),
                        "repair": cells[5], "heading": cells[6]})
    return {"build": build_id(), "plan": plan_state(), "spans": dashboard.jsonl("trace.jsonl"), "repairs": dashboard.repair_times(), "turns": dashboard.turning_points(), "evals": dashboard.evals(),
            "sims": [{k: v for k, v in x.items() if k != "examples"} for x in dashboard.jsonl("sim_runs.jsonl")], "kintsugi": kin, "whose": dict(whose),
            "glossary": dashboard.glossary(), "grades": dashboard.GRADES,
            "hypotheses": [{"id": h, "text": t, "status": s} for h, t, s in dashboard.hypotheses()],
            "cost": {"calls": ncalls, "usd": round(usd, 4), "per_question": round(per_q, 5)}}


def evidence():
    """Everything that proves the build, read live from the logs: nothing on this tab is typed in."""
    import subprocess
    runs = dashboard.jsonl("eval_runs.jsonl")
    sets = {}
    for r in runs:
        key = "%s · %s" % (r.get("set") or "golden.json", r.get("model") or r["provider"])
        model = None
        sets[key] = {"t": r["t"], "passed": r["passed"], "total": r["total"],
                     "cases": [{"id": x["id"], "pass": x["pass"], "fails": x.get("fails", [])} for x in r["results"]]}
    calls = dashboard.jsonl("model_calls.jsonl")
    by_model = {}
    for c in calls:
        if not c.get("ok"):
            continue
        m = by_model.setdefault(c.get("model") or c["provider"], {"calls": 0, "in": 0, "out": 0, "lat": 0.0})
        m["calls"] += 1; m["in"] += c["usage"].get("input_tokens") or 0; m["out"] += c["usage"].get("output_tokens") or 0
        m["lat"] += c.get("latency_s") or 0
    from rfp.provider import PRICES
    for k, m in by_model.items():
        pin, pout = PRICES.get(k, (0, 0))
        m["usd"] = round((m["in"] * pin + m["out"] * pout) / 1e6, 4); m["lat"] = round(m["lat"] / m["calls"], 2)
    mon = dashboard.jsonl("monday_calls.jsonl")
    today = datetime_utc_date()
    mon_today = [c for c in mon if c["t"][:10] == today]
    by_purpose = {}
    for c in mon:
        p = by_purpose.setdefault(c["purpose"], {"calls": 0, "points": 0})
        p["calls"] += 1; p["points"] += ((c.get("complexity") or {}).get("query") or 0)
    sc = dashboard.jsonl("scenario_runs.jsonl")
    last_sc = sc[-1] if sc else None
    def run(cmd):
        r = subprocess.run(cmd, cwd=SRC, capture_output=True, text=True, timeout=120)
        return {"ok": r.returncode == 0, "out": (r.stdout + r.stderr).strip()[-1500:]}
    snaps = sorted(f for f in os.listdir(os.path.join(ROOT, "snapshots"))) if os.path.isdir(os.path.join(ROOT, "snapshots")) else []
    return {
        "eval_sets": sets,
        "models": by_model,
        "scenarios": {k: last_sc[k] for k in ("t", "commit", "scenarios", "passed", "load_bearing_passed", "vacuous",
                                              "violations_by_invariant", "regressions", "seconds")} if last_sc else None,
        "fuzz": (dashboard.jsonl("sim_runs.jsonl") or [None])[-1],
        "mutation": run([sys.executable, "-m", "tests.mutate"]),
        "seam_tests": run([sys.executable, "-m", "unittest", "tests.test_seams"]),
        "regression": run([sys.executable, "-m", "eval.regress", "check"]),
        "monday": {"calls_today": len(mon_today), "daily_cap": 1000, "errors": [c.get("error_code") or c.get("http") for c in mon if not c.get("ok")][-5:],
                   "by_purpose": by_purpose, "last_served_version": next((c.get("served_version") for c in reversed(mon) if c.get("served_version")), None)},
        "live_answers": [c for c in mon if c["purpose"] == "write answer"][-10:],
        "snapshots": snaps,
        "rca": read("RCA.md")}


def outcomes():
    """The client's own success criteria, measured from this build. Nothing here is typed in."""
    import statistics
    from sync_boards import KEY_FACTS
    from sync_boards import documents, load
    db = load()   # the same documents the boards and the poller use: everything in data/
    docs = [raw for _, raw in documents()]
    facts = [(label, store.governing(db, cid)) for label, cid in KEY_FACTS]
    effects = [dict(r) for r in db.execute("SELECT amendment_clause, op, target FROM effects")]
    mon = dashboard.jsonl("monday_calls.jsonl")
    live = [c for c in mon if c["purpose"] == "write answer" and c.get("ok")]
    calls = [c for c in dashboard.jsonl("model_calls.jsonl") if c.get("ok") and c["provider"] == "claude"]
    lat = [c["latency_s"] for c in calls]
    sent = [len(c["payload"]["user"]) if c.get("payload") else c["payload_chars"]["user"]
            for c in calls if c.get("payload") or c.get("payload_chars")]  # the ZIP keeps sizes for older calls
    doc_chars = sum(len(d) for d in docs)
    runs = [r for r in dashboard.jsonl("eval_runs.jsonl") if r["provider"] == "claude" and (r.get("model") or "claude-sonnet-5-5") == "claude-sonnet-5-5" and not dashboard.setup_only(r)]
    latest = {}
    for r in runs:
        latest[r.get("set") or "golden.json"] = r
    cases = [x for r in latest.values() for x in r["results"]]
    gold = {c["id"]: c for g in ("golden.json", "golden_wave2.json") for c in json.load(open(os.path.join(SRC, "eval", g)))}
    refusals = [x for x in cases if gold.get(x["id"], {}).get("status") == "not_addressed"]
    answered = [x for x in cases if gold.get(x["id"], {}).get("status") == "answered"]
    return {
        "elena_facts": {"count": len(facts), "amended": sum(1 for _, g in facts if g), "board": "RET · Key Facts"},
        "elena_minutes": {"live_answered": len(live), "median_model_s": round(statistics.median(lat), 1) if lat else None,
                          "cited": "%d of %d" % (sum(x["pass"] for x in answered), len(answered))},
        "doug_amendments": {"replaces": sum(e["op"] == "replaces" for e in effects), "adds": sum(e["op"] == "adds" for e in effects),
                            "flagged": sum(e["op"] == "unresolved" for e in effects), "rerun_created": 0},
        "nina_refusals": {"correct": sum(x["pass"] for x in refusals), "of": len(refusals)},
        "sam_payload": {"avg_chars_sent": int(statistics.mean(sent)) if sent else 0, "doc_chars": doc_chars,
                        "share": round(100 * statistics.mean(sent) / doc_chars, 1) if sent else 0},
        "what_leaves": json.load(open(os.path.join(ROOT, "glossary.json")))["what_leaves"],
        **extra_outcomes(),
    }


def extra_outcomes():
    """Unseen questions, attacks held and cost per answer, each read from a record (none typed in)."""
    out = {"unseen": [], "local": None, "wargame": None, "cost": None}
    for f in sorted(os.listdir(os.path.join(ROOT, "evidence", "blind"))):
        if f.endswith(".json"):
            b = json.load(open(os.path.join(ROOT, "evidence", "blind", f)))
            out["unseen"].append({"set": f[:-5], "passed": sum(1 for r in b["results"] if r["pass"]), "of": len(b["results"])})
    out["unseen"].sort(key=lambda x: x["passed"] / x["of"])   # worst first
    runs = [json.loads(l) for l in open(os.path.join(ROOT, "flightlog", "eval_runs.jsonl")) if l.strip()]
    loc = [r for r in runs if r["provider"] == "local"]
    if loc:
        out["local"] = {"passed": loc[-1]["passed"], "of": loc[-1]["total"]}
    wg = [json.loads(l) for l in open(os.path.join(ROOT, "flightlog", "wargame_runs.jsonl")) if l.strip()]
    if wg:
        out["wargame"] = {"passed": wg[-1]["passed"], "of": wg[-1]["total"], "provider": wg[-1]["provider"], "t": wg[-1]["t"][:16]}
    ev = {e["id"]: e for e in (json.loads(l) for l in open(os.path.join(ROOT, "evidence", "evidence.jsonl")) if l.strip())}
    if "E-cost-per-q" in ev:
        out["cost"] = {"per_q": ev["E-cost-per-q"]["show"], "price": ev["E-price-sonnet55"]["value"]}
    return out


# Which code a case exercised, read from the gate its latest run reported (rfp/answer.py sets it on every path).
PATHS = [
    ("fast path", ["parse: rfp/parse.py", "resolve: rfp/resolve.py", "fast path: answer.fast_path"]),
    ("related text", ["parse", "resolve", "retrieve: answer.retrieve", "model: answer.answer", "refusal floor: related text (K33)"]),
    ("context verbatim", ["parse", "resolve", "retrieve: answer.retrieve", "model: answer.answer", "refusal with context, verbatim gate (K26)"]),
    ("verbatim FAILED", ["parse", "resolve", "retrieve: answer.retrieve", "model: answer.answer", "verbatim gate: tripped, summary withheld"]),
    ("verbatim ok", ["parse", "resolve", "retrieve: answer.retrieve", "model: answer.answer", "verbatim gate: passed"]),
    ("no valid citation", ["parse", "resolve", "retrieve", "model", "citation gate: nothing real cited (K20)"]),
    ("provider", ["parse", "resolve", "retrieve", "model unavailable: degrade (K15)"]),
    ("model", ["parse", "resolve", "retrieve: answer.retrieve", "model: answer.answer", "refusal"]),
]

STAGE_FILES = [("parse", ["rfp/parse.py", "rfp/store.py"]), ("resolve", ["rfp/resolve.py", "rfp/store.py"]),
               ("fast path", ["rfp/answer.py"]), ("retrieve", ["rfp/answer.py"]), ("model", ["rfp/answer.py", "rfp/provider.py"]),
               ("refusal", ["rfp/answer.py"]), ("verbatim", ["rfp/answer.py"]), ("citation", ["rfp/answer.py"])]


def live_deck():
    """The proposal deck with every computed figure filled from the records at request time (same code as ./rfp build)."""
    import build as _b
    calc = _b.evidence_calc.calc_all()
    ev = {e["id"]: e for e in (json.loads(l) for l in _b.evidence_text(calc).splitlines())}
    return _b.deck_text(calc, ev)[0]


TEXT_TYPES = (".md", ".json", ".jsonl", ".txt", ".py", ".html", ".sh", ".csv")


def local_file(rel):
    """Serve a tracked repo text file. Links in the deck point here, never at the private remote."""
    import subprocess as _sp, urllib.parse as _u
    rel = _u.unquote(rel)
    tracked = set(_sp.run(["git", "-C", ROOT, "ls-files"], capture_output=True, text=True).stdout.split("\n")) - {""}
    # In the unzipped ZIP there is no git: what shipped is the allowlist (K63).
    ok = (rel in tracked) if tracked else bool(_inside(ROOT, rel)) and not rel.endswith(NEVER) and os.path.basename(rel) != ".env"
    if not ok or not rel.endswith(TEXT_TYPES):  # allowlist: nothing outside the shipped files, no binaries
        return 404, {"error": "not a shipped text file: " + rel}
    return 200, read(rel).encode(), "text/plain; charset=utf-8"


NEVER = (".env", ".db", ".bundle", ".pyc")
PRES_TYPES = {".html": "text/html; charset=utf-8", ".md": "text/plain; charset=utf-8", ".css": "text/css", ".js": "text/javascript", ".json": "application/json",
              ".csv": "text/csv; charset=utf-8", ".jpg": "image/jpeg", ".png": "image/png", ".pdf": "application/pdf"}


def _inside(base, rel):
    """The real path of rel under base, or None if it escapes base (no ../, no absolute paths, no symlink tricks)."""
    full = os.path.realpath(os.path.join(base, rel))
    return full if full.startswith(os.path.realpath(base) + os.sep) and os.path.isfile(full) else None


def site_file(name, base=None):
    """The review pages (base SITE) or the PDF (base PRES), served by the bench so the pages' relative links to code
    and documents open real files (not a 404 from a server rooted in one folder)."""
    import urllib.parse as _u
    full = _inside(base or PRES, _u.unquote(name))
    ext = os.path.splitext(full or "")[1].lower()
    if not full or ext not in PRES_TYPES:
        return 404, {"error": "not a presentation file: " + name}
    return 200, open(full, "rb").read(), PRES_TYPES[ext]


def shipped_text(full):
    """A file the viewer may show: a known text type, or a file with no extension (the rfp launcher, the git hooks,
    .gitignore) whose bytes are UTF-8 text. Never a binary."""
    if full.endswith(TEXT_TYPES + (".example", ".txt")):
        return True
    if os.path.splitext(os.path.basename(full).lstrip("."))[1]:
        return False
    data = open(full, "rb").read(65536)
    try:
        data.decode("utf-8")
    except UnicodeDecodeError:
        return False
    return b"\0" not in data


def source_view(rel):
    """A shipped text file (code, docs, logs) as a readable page: line numbers, each line linkable as #L<n>. Works from
    the repo and from the unzipped ZIP; never .env, databases or the history bundle."""
    import html as _h, urllib.parse as _u
    rel = _u.unquote(rel).rstrip("/")
    d = os.path.realpath(os.path.join(ROOT, rel))
    if os.path.isdir(d) and d.startswith(os.path.realpath(ROOT) + os.sep):   # a folder link: list what is in it
        items = sorted(n for n in os.listdir(d) if not n.startswith(".") and not n.endswith(NEVER))
        lis = "".join('<li><a href="/source/%s/%s">%s</a></li>' % (_u.quote(rel), _u.quote(n), _h.escape(n)) for n in items)
        return 200, (('<!doctype html><meta charset="utf-8"><title>%s</title><style>body{background:#0d1016;color:#e6e8ee;'
                     'font:14px system-ui,sans-serif;padding:16px}a{color:#8ab4ff}</style><p><a href="/source/docs/site/index.html">'
                     'Start here</a> &middot; <b>%s/</b></p><ul>%s</ul>') % (_h.escape(rel), _h.escape(rel), lis)).encode(), "text/html; charset=utf-8"
    full = _inside(ROOT, rel)   # ROOT is what ships as source/: the repo root, or source/ in the unzipped ZIP
    if not full and rel == "HISTORY.txt":   # written into the ZIP by package.py; in the repo, generate it on request
        sys.path.insert(0, os.path.join(ROOT, "scripts"))
        from package import history_text
        text, full = history_text(), os.path.join(ROOT, "HISTORY.txt")
    elif not full or full.endswith(NEVER) or os.path.basename(full) == ".env" or not shipped_text(full):
        return 404, {"error": "not a shipped text file: " + rel}
    else:
        text = open(full, encoding="utf-8", errors="replace").read()
    lines = text.split("\n")
    if full.endswith(".jsonl") and len(lines) > 400:
        note, lines = "Showing the last 400 of %d lines." % len(lines), lines[-400:]
    else:
        note = ""
    body = "".join('<a id="L%d" href="#L%d">%d</a>%s\n' % (i, i, i, _h.escape(l)) for i, l in enumerate(lines, 1))
    page = ('<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
            '<title>%s</title><style>body{margin:0;background:#0d1016;color:#e6e8ee;font:13px/1.55 ui-monospace,Menlo,monospace}'
            'header{position:sticky;top:0;background:#151922;border-bottom:1px solid #2a2f3a;padding:10px 16px;font:14px system-ui,sans-serif}'
            'header a{color:#8ab4ff}pre{margin:0;padding:12px 16px;white-space:pre-wrap;word-break:break-word}'
            'pre a{display:inline-block;width:4.5em;color:#6b7280;text-decoration:none;user-select:none}'
            ':target{background:#2a3350}.abs{display:block;margin-top:4px;font:12px ui-monospace,Menlo,monospace;color:#9aa3b2;word-break:break-all}'
            'button.cp{margin-left:8px;font:12px system-ui;padding:2px 8px;border-radius:6px;border:1px solid #3a4152;background:#1c2230;color:#e6e8ee;cursor:pointer}'
            '</style><header><a href="/source/docs/site/index.html">Start here</a> &middot; '
            '<b>%s</b> %s<span class="abs">%s<button class="cp" type="button" data-p="%s" '
            'onclick="navigator.clipboard.writeText(this.dataset.p);this.textContent=\'Copied\'">Copy path</button></span>'
            '<span class="abs">Finder: Command-Shift-G and paste. Terminal: cd and paste the folder.</span></header><pre>%s</pre>'
            ) % (_h.escape(rel), _h.escape(rel), _h.escape(note), _h.escape(full), _h.escape(full), body)
    return 200, page.encode(), "text/html; charset=utf-8"


def datetime_utc_date():
    from datetime import datetime, timezone
    return datetime.now(timezone.utc).strftime("%Y-%m-%d")


def build_db(body):
    fl = body.get("faults") or []
    base = faults.apply_doc_faults(body["base"], fl, is_amendment=False)
    amends = [faults.apply_doc_faults(a, fl, is_amendment=True) for a in body.get("amendments") or [] if a.strip()]
    db = store.connect(":memory:")
    log = []
    for label, text in faults.ingest_sequence(base, amends, fl):
        try:
            doc, created = store.ingest(db, text, label)
            log.append({"upload": label, "result": "created" if created else "duplicate skipped",
                        "kind": doc.kind, "clauses": len(doc.clauses)})
        except store.DuplicateDocument as e:
            log.append({"upload": label, "result": "conflict raised for a human", "detail": str(e)})
        except store.UnreadableDocument as e:
            log.append({"upload": label, "result": "refused: a person must review it", "detail": str(e)})
    effects = [dict(r) for r in db.execute("SELECT amendment_clause, op, target, references_missing FROM effects")]
    governing = {}
    for cid in sorted({e["target"] for e in effects if e["op"] == "replaces" and e["target"]}):
        g = store.governing(db, cid)
        governing[cid] = g["amendment_clause"] if g else None
    sections = sorted({r["section"] for r in db.execute("SELECT section FROM clauses")}, key=str)
    return db, {"ingest": log, "effects": effects, "governing": governing, "sections": sections}


def set_provider(body):
    p = body.get("provider", "mock")
    if p not in PROVIDERS:
        raise ValueError("provider must be one of %s" % sorted(PROVIDERS))
    if p == "claude" and not ALLOW_PAID:
        raise ValueError("paid model calls are off for this server; restart it with ./rfp serve --paid to allow them")
    os.environ["MODEL_PROVIDER"] = p
    os.environ["MOCK_FAULT"] = body.get("mock_fault", "none")


PAGE_GEN = [0]   # bumped on every page load; a run from an older page is abandoned, never a result


def bench_log(kind, body, rows):
    """Every test-bench run, one line each (flightlog/bench_runs.jsonl): what was asked, with which provider and
    faults, and what came back. The bench's own memory; the evaluation record stays in eval_runs.jsonl."""
    from datetime import datetime, timezone
    with open(os.path.join(ROOT, "flightlog", "bench_runs.jsonl"), "a") as f:
        f.write(json.dumps({"t": datetime.now(timezone.utc).isoformat(), "kind": kind, "provider": os.environ.get("MODEL_PROVIDER", "mock"),
                            "faults": body.get("faults") or [], "mock_fault": body.get("mock_fault", "none"), "rows": rows}) + "\n")


def run(body):
    set_provider(body)
    db, info = build_db(body)
    info["answer"] = answer.answer(db, body["question"]) if body.get("question") else None
    a = info["answer"] or {}
    bench_log("one question", body, [{"q": (body.get("question") or "")[:300], "status": a.get("status"), "gate": a.get("gate"),
                                      "cited": [c["clause_id"] for c in a.get("citations", [])]}])
    return info


def golden(body):
    set_provider(body)
    db, info = build_db(body)
    results = []
    for case in json.load(open(os.path.join(SRC, "eval", "golden.json"))):
        r = answer.answer(db, case["q"])
        fails = check(case, r)
        results.append({"id": case["id"], "q": case["q"], "pass": not fails, "fails": fails,
                        "status": r["status"], "gate": r.get("gate"), "answer": r["answer"]})
    info["golden"] = results
    # A clean full run (no planted fault) is a real evaluation run: log it like eval/run_eval.py, so the Evals tab,
    # the header score and the evidence move. Runs with planted faults stay out of the record.
    if body.get("gen") is not None and body.get("gen") != PAGE_GEN[0]:
        bench_log("abandoned (page reloaded mid-run)", body, [{"id": r["id"], "pass": r["pass"]} for r in results])
        info["abandoned"] = True
        return info
    if not body.get("faults") and body.get("mock_fault", "none") == "none":
        from datetime import datetime, timezone
        from rfp import provider as _prov
        p = os.environ.get("MODEL_PROVIDER", "mock")
        model = {"claude": _prov.CLAUDE_MODEL, "local": _prov.LOCAL_MODEL}.get(p, p)
        with open(os.path.join(ROOT, "flightlog", "eval_runs.jsonl"), "a") as f:
            f.write(json.dumps({"t": datetime.now(timezone.utc).isoformat(), "provider": p, "model": model, "set": "golden.json",
                                "source": "test bench", "passed": sum(r["pass"] for r in results), "total": len(results),
                                "results": [{"id": r["id"], "pass": r["pass"], "fails": r["fails"], "gate": r["gate"], "answer": r["answer"]} for r in results]}) + "\n")
        info["logged"] = True
    bench_log("all test questions", body, [{"id": r["id"], "pass": r["pass"], "status": r["status"], "gate": r["gate"]} for r in results])
    return info


class Handler(BaseHTTPRequestHandler):
    def _send(self, code, payload, ctype="application/json"):
        data = payload if isinstance(payload, bytes) else json.dumps(payload, default=str).encode()
        self.send_response(code)
        self.send_header("content-type", ctype)
        for k, v in SECURITY_HEADERS.items():
            self.send_header(k, v)
        if self.path.startswith("/api/") or ctype.startswith("text/html"):
            self.send_header("Cache-Control", "no-store")   # never serve a stale page or stale numbers
        self.send_header("content-length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _refuse(self, post):
        """DNS rebinding and cross-site requests from any other page in the browser are refused (K36)."""
        if self.headers.get("Host", "") not in HOSTS:
            return 403, "host not allowed"
        if not post:
            return None
        origin = self.headers.get("Origin")
        if origin is not None and origin not in ORIGINS:
            return 403, "cross-origin request refused"
        if self.headers.get("Content-Type", "").split(";")[0].strip().lower() != "application/json":
            return 403, "content type must be application/json"
        if self.headers.get("X-RFP-Harness") != "1":
            return 403, "missing X-RFP-Harness header: this page is older than the server; reload it"
        return None

    def do_GET(self):
        self.path = self.path.split("?", 1)[0].split("#", 1)[0]  # a pasted link with a query string must still load
        bad = self._refuse(post=False)
        if bad:
            return self._send(bad[0], {"error": bad[1]})
        if self.path == "/favicon.ico":
            return self._send(204, b"", "image/x-icon")  # no icon; answer quietly instead of a console 404
        if self.path.startswith("/file/"):
            return self._send(*local_file(self.path[len("/file/"):]))
        if self.path.startswith("/presentation/") and self.path[len("/presentation/"):] != "RET-RFP-Intelligence.pdf":
            # Pages that lived in presentation/ before the move: send old links to where the page is now.
            self.send_response(301); self.send_header("Location", "/source/docs/site/" + self.path[len("/presentation/"):]); self.end_headers()
            return
        if self.path.startswith("/presentation/"):
            return self._send(*site_file(self.path[len("/presentation/"):]))
        if self.path.startswith("/source/docs/site/"):   # the review pages themselves, served as pages
            return self._send(*site_file(self.path[len("/source/docs/site/"):], SITE))
        if self.path.startswith("/source/"):   # a page's ../../<path> link, resolved by the bench
            return self._send(*source_view(self.path[len("/source/"):]))
        # The deck's own images (e.g. slide 4's board screenshots), served beside /deck because the deck links them
        # relatively. Only image files that sit in docs/site/, by exact name: no paths, no other types.
        m = re.fullmatch(r"/([A-Za-z0-9_.-]+)\.(jpg|jpeg|png|webp)", self.path)
        if m and os.path.isfile(os.path.join(SITE, m.group(1) + "." + m.group(2))):
            ctype = {"jpg": "image/jpeg", "jpeg": "image/jpeg", "png": "image/png", "webp": "image/webp"}[m.group(2)]
            return self._send(200, open(os.path.join(SITE, m.group(1) + "." + m.group(2)), "rb").read(), ctype)
        if self.path == "/deck":
            return self._send(200, live_deck().encode(), "text/html; charset=utf-8")
        if self.path in ("/", "/index.html"):
            return self._send(200, read("source/harness/ui.html").encode(), "text/html; charset=utf-8")
        if self.path == "/api/newpage":
            PAGE_GEN[0] += 1
            return self._send(200, {"gen": PAGE_GEN[0]})
        if self.path == "/api/state":
            return self._send(200, state())
        if self.path == "/api/docs":
            from sync_boards import documents   # the same documents the boards use (K55), base first
            raws = [raw for _, raw in documents()]
            return self._send(200, {"base": raws[0] if raws else "",
                                    "amendments": raws[1:],
                                    "golden_count": len(json.load(open(os.path.join(SRC, "eval", "golden.json")))),
                                    "doc_faults": faults.DOC_FAULTS, "ingest_faults": faults.INGEST_FAULTS,
                                    "mock_faults": ["none", "timeout", "garbage", "wrong_figure", "fake_citation", "refuse"]})
        self._send(404, {"error": "not found"})

    def do_POST(self):
        # Bench runs share the provider setting and the last-call record, so one at a time. A run that arrives while
        # another is going is answered at once (a local "run all" takes minutes), never left waiting with no word.
        if not POST_LOCK.acquire(blocking=False):
            return self._send(409, {"error": "another run is still going (%s, started %s); it finishes on its own, "
                                             "or restart ./rfp serve" % (RUNNING.get("provider", "?"), RUNNING.get("since", "?"))})
        try:
            RUNNING.update(provider="the %s model" % next((p for p in PROVIDERS if p == self.headers.get("X-RFP-Provider")), "chosen"),
                           since=time.strftime("%H:%M:%S"))
            return self._do_post()
        finally:
            RUNNING.clear()
            POST_LOCK.release()

    def _do_post(self):
        bad = self._refuse(post=True)
        if bad:
            return self._send(bad[0], {"error": bad[1]})
        try:
            n = int(self.headers.get("content-length", 0))
        except ValueError:
            return self._send(400, {"error": "bad content-length"})
        if n > MAX_BODY:
            return self._send(413, {"error": "request body over %d KB" % (MAX_BODY // 1024)})
        try:
            body = json.loads(self.rfile.read(n) or b"{}")
            if self.path == "/api/run":
                return self._send(200, run(body))
            if self.path == "/api/golden":
                return self._send(200, golden(body))
            self._send(404, {"error": "not found"})
        except (ValueError, KeyError, sqlite3.Error) as e:
            self._send(400, {"error": str(e)})
        except Exception as e:  # never a silent 500, never internals (paths, stack) to the client
            import uuid, traceback
            eid = uuid.uuid4().hex[:8]
            print("harness error %s: %s" % (eid, traceback.format_exc()), file=sys.stderr)
            self._send(500, {"error": "Internal error %s (%s); details are in the server console." % (eid, type(e).__name__)})

    def log_message(self, fmt, *args):
        """One line per request, like uvicorn's access log, so the page and the server can be watched side by side.
        Method, path and status only: never request bodies, so no question text or key reaches the terminal."""
        if os.environ.get("HARNESS_QUIET"):
            return
        if fmt.startswith('"%s" %s'):
            line, code = str(args[0]), str(args[1])
            method, path = (line.split(" ")[:2] + ["", ""])[:2]
            sys.stderr.write("%s  %-4s %-40s %s\n" % (time.strftime("%H:%M:%S"), method, path.split("?")[0][:40], code))
        else:
            sys.stderr.write("%s  %s\n" % (time.strftime("%H:%M:%S"), fmt % args))


if __name__ == "__main__":
    from rfp import runlock
    try:   # one bench per computer, so ./rfp status and ./rfp stop know exactly which copy is serving (K61)
        runlock.acquire("bench", ROOT)
    except runlock.Busy as b:
        sys.exit("a test bench is already running: pid %s, in %s. Stop it with ./rfp stop." % (b.holder.get("pid"), b.holder.get("folder")))
    print("harness on http://127.0.0.1:%d" % PORT)
    ThreadingHTTPServer(("127.0.0.1", PORT), Handler).serve_forever()
