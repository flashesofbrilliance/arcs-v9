"""Sync the pilot scorecard to monday.com: one item per success measure, for a native dashboard.

python3 scorecard_sync.py            (from source/)
Values come from the build's own records (harness.server.outcomes). Each row states whether its value is
Measured, Derived (arithmetic on measured values, shown in Source) or Not measured yet. Re-running only
writes rows whose values changed.
"""
import sys

from harness import server
from rfp import monday, sink

COLS = [("Value", "numbers"), ("Unit", "text"), ("Target", "text"), ("Who it is for", "text"),
        ("Basis", "status"), ("Source", "long_text")]


def rows():
    o = server.outcomes()
    lat = o["elena_minutes"]["median_model_s"] or 0
    cited_ok, cited_n = (int(x) for x in o["elena_minutes"]["cited"].split(" of "))
    return [
        ("facts", "Key facts posted to the board", o["elena_facts"]["count"], "facts", "all critical fields, same day", "Elena", "Measured", "Key Facts board sync"),
        ("amended", "Key facts changed by an amendment", o["elena_facts"]["amended"], "facts", "every change shown", "Doug", "Measured", "Key Facts board sync"),
        ("release_to_board", "Time from RFP release to facts on the board", None, "hours", "same day", "Elena", "Not measured yet", "Needs a real release in the pilot"),
        ("ai_time", "Median AI time per question", lat, "seconds", "minutes, not days", "Elena", "Measured", "model call log"),
        ("end_to_end", "End-to-end answer time on the board", round(60 + lat, 1), "seconds (upper bound)", "minutes, not days", "Elena", "Derived", "60 s polling interval + measured AI time"),
        ("cited", "Answerable test questions answered with sources", round(100 * cited_ok / cited_n), "%", "100%", "Nina", "Measured", "%d of %d test questions" % (cited_ok, cited_n)),
        ("declined", "Unanswerable test questions declined plainly", round(100 * o["nina_refusals"]["correct"] / o["nina_refusals"]["of"]), "%", "100%", "Nina", "Measured", "%d of %d test questions" % (o["nina_refusals"]["correct"], o["nina_refusals"]["of"])),
        ("changes", "Amendment changes caught", o["doug_amendments"]["replaces"] + o["doug_amendments"]["adds"], "changes", "all", "Doug", "Measured", "Amendment 1: %d replaced, %d added" % (o["doug_amendments"]["replaces"], o["doug_amendments"]["adds"])),
        ("dupes", "Duplicates created by re-syncing", o["doug_amendments"]["rerun_created"], "items", "0", "Doug", "Measured", "repeat sync run"),
        ("payload", "Characters sent to the AI per question", o["sam_payload"]["avg_chars_sent"], "characters", "only what the question needs", "Sam Ito", "Measured", "model call log (question + retrieved clauses)"),
        ("live", "Questions answered live from the board", o["elena_minutes"]["live_answered"], "questions", "every question asked", "Elena", "Measured", "Questions board write log"),
        ("verified", "Answers verified by staff", None, "%", "tracked per cycle", "Nina", "Not measured yet", "Verified-by column, starts in the pilot"),
    ]


def main():
    s = sink.MondaySink()
    b = s.board("RET · Pilot Scorecard", COLS)
    counts = {"created": 0, "updated": 0, "unchanged": 0}
    for key, name, value, unit, target, who, basis, source in rows():
        vals = {"Unit": sink.text(unit), "Target": sink.text(target), "Who it is for": sink.text(who),
                "Basis": sink.status(basis), "Source": sink.long_text(source)}
        if value is not None:
            vals["Value"] = sink.number(value)
        _, created = s.upsert(b, "score:" + key, name, vals)
        counts["unchanged" if created is None else "created" if created else "updated"] += 1
    s.archive_template_rows(b)
    print({"board": b, **counts})


if __name__ == "__main__":
    try:
        main()
    except monday.MondayError as e:
        print("monday error (code %s): %s" % (e.code, e), file=sys.stderr)
        sys.exit(1)
