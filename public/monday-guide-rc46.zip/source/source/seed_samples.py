"""Put RET's 14 sample questions on the Questions board and answer them there, as standing proof.

python3 seed_samples.py           (from source/; ./rfp samples)
Each is posted as "[sample] <question>" through the same path a staff member uses, then answered by one poller pass
on the configured model, with its citations. Re-running posts only the ones missing. The pre-demo reset archives
"[rehearsal]" items only, so these stay beside the panel's live question.
"""
import json
import os
import sys

import live_questions
from rfp import monday, sink
from sync_boards import QUESTION_COLS

HERE = os.path.dirname(os.path.abspath(__file__))
PREFIX = "[sample] "


def main():
    samples = [c for c in json.load(open(os.path.join(HERE, "eval", "golden.json"), encoding="utf-8")) if c["id"].startswith("Q")]
    s = sink.MondaySink()
    b = s.board("RET · Questions", QUESTION_COLS)
    have = {i["name"] for i in monday.all_items(b, "id name", purpose="find sample items")}
    col = s.columns[b]["Question"]
    new = [c for c in samples if PREFIX + c["q"][:200] not in have]
    for c in new:
        monday.gql("mutation ($b: ID!, $n: String!, $v: JSON!) { create_item(board_id: $b, item_name: $n, column_values: $v) { id } }",
                   {"b": b, "n": PREFIX + c["q"][:200], "v": json.dumps({col: {"text": c["q"]}})}, purpose="sample question")
    print("posted %d of %d sample questions (%d already on the board)" % (len(new), len(samples), len(samples) - len(new)))
    sys.argv = ["live_questions", "--once"]
    return live_questions.main()


if __name__ == "__main__":
    sys.exit(main())
