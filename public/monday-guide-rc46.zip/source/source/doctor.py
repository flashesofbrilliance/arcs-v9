"""./rfp doctor: is this machine ready? Checks Python, the .env file, both keys, and one free monday.com call.

Prints one line per check (OK / MISSING / FAIL) and never prints a key. Costs one monday.com read (whoami) and no
AI call. Exit 1 if anything needed for the live path is missing; the free mock path needs none of it.
"""
import json
import os
import subprocess
import sys
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)


def env_lines():
    p = os.path.join(ROOT, ".env")
    return [l.rstrip("\n") for l in open(p)] if os.path.exists(p) else None


FP_FILE = os.path.join(ROOT, ".rfp-model.json")   # the local model's digest as first seen; delete it to accept a deliberate update
OLLAMA_TAGS = "http://localhost:11434/api/tags"


def installed_digest(model):
    """The digest Ollama reports for the model: a string, "" if Ollama is up but does not have it, None if unreachable."""
    try:
        with urllib.request.urlopen(OLLAMA_TAGS, timeout=2) as r:
            models = json.load(r).get("models", [])
    except Exception:   # not running, refused, timed out, or not JSON: the local path is optional, so never a failure
        return None
    for m in models:
        if model in (m.get("name"), m.get("model"), (m.get("name") or "") + ":latest" if ":" not in model else None):
            return m.get("digest") or ""
    return ""


def check_model_fingerprint(line):
    """Pin the local model: record its digest the first time, then compare. Returns 1 if it changed, else 0."""
    from rfp.provider import LOCAL_MODEL
    what = "local model fingerprint"
    digest = installed_digest(LOCAL_MODEL)
    if digest is None:
        line("MISSING", what, "Ollama not reachable at localhost:11434; skipped (the mock and Claude paths do not need it)")
        return 0
    if not digest:
        line("MISSING", what, "%s is not installed in Ollama; skipped (ollama pull %s)" % (LOCAL_MODEL, LOCAL_MODEL))
        return 0
    known = json.load(open(FP_FILE)) if os.path.exists(FP_FILE) else None
    if known is None or known.get("model") != LOCAL_MODEL:
        json.dump({"model": LOCAL_MODEL, "digest": digest}, open(FP_FILE, "w"))
        line("OK", what, "recorded %s %s in .rfp-model.json" % (LOCAL_MODEL, digest[:12]))
        return 0
    if known.get("digest") == digest:
        line("OK", what, "%s unchanged (%s)" % (LOCAL_MODEL, digest[:12]))
        return 0
    line("FAIL", what, "%s is now %s, was %s. Answers measured on the old build may not hold. If the update is deliberate, delete .rfp-model.json and run doctor again to record the new one."
         % (LOCAL_MODEL, digest[:12], known.get("digest", "?")[:12]))
    return 1


def main():
    bad = 0

    def line(state, what, detail=""):
        print("%-8s %-32s %s" % (state, what, detail))

    v = sys.version_info
    ok = v >= (3, 9)
    line("OK" if ok else "FAIL", "Python 3.9 or newer", "%d.%d.%d" % v[:3])
    bad += not ok

    lines = env_lines()
    if lines is None:
        line("MISSING", ".env file", "create it at the folder root (ONBOARDING.md step 4); the mock path works without it")
        bad += 1
    else:
        line("OK", ".env file", "found")
        tracked = subprocess.run(["git", "-C", ROOT, "ls-files", "--error-unmatch", ".env"], capture_output=True).returncode == 0
        if tracked:
            line("FAIL", ".env kept out of git", "it is tracked: run git rm --cached .env")
            bad += 1
        from rfp.config import ConfigError, env
        try:
            has = bool(env("ANTHROPIC_API_KEY"))   # the same reader the AI client uses (K57)
        except ConfigError as e:
            line("FAIL", "Claude key (ANTHROPIC_API_KEY)", str(e))
            has, bad = True, bad + 1
        line("OK" if has else "MISSING", "Claude key (ANTHROPIC_API_KEY)", "present (not shown)" if has else "needed only for --provider claude")

    from rfp import monday
    try:
        monday.token()
        me = monday.whoami()["me"]
        line("OK", "monday.com token", "works: account %s, plan %s" % (me["account"]["name"], me["account"]["plan"]["tier"] if me["account"].get("plan") else "free"))
    except Exception as e:  # MondayError, network, or an unexpected reply; the message never contains the token
        line("FAIL", "monday.com token", str(e)[:120])
        bad += 1

    from rfp import runlock
    left = runlock.calls_left()
    line("OK" if left >= 200 else "LOW", "monday.com calls left today",
         "%d of 1,000 since 00:00 UTC, counted across every copy on this computer (free plan; a live rehearsal uses "
         "about 84, polling about 60 an hour; the poller stops at %d)" % (left, runlock.RESERVE))
    h = runlock.holder("poller")
    line("OK", "poller", "running: pid %s in %s" % (h.get("pid"), h.get("folder")) if h else "not running")
    bad += check_model_fingerprint(line)
    print("doctor: %s" % ("ready for the live path" if not bad else "%d item(s) to fix; ./rfp e2e --provider mock still works" % bad))
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
