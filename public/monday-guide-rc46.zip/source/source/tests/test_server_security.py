"""The local deck server refuses what a malicious page in the same browser could send (KINTSUGI K36).

python3 -m unittest tests.test_server_security      (from source/)
Starts the real handler on a free port bound to 127.0.0.1; no model or monday calls.
"""
import http.client
import json
import os
import socket
import threading
import unittest

s = socket.socket(); s.bind(("127.0.0.1", 0)); PORT = s.getsockname()[1]; s.close()
os.environ["HARNESS_PORT"] = str(PORT)
os.environ.pop("RFP_ALLOW_PAID", None)
os.environ["MODEL_CALL_LOG"] = os.devnull
import sys  # noqa: E402
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))  # runs from the repo root too

from harness import server  # noqa: E402

GOOD = {"Host": "127.0.0.1:%d" % PORT, "Content-Type": "application/json", "X-RFP-Harness": "1"}


class ServerSecurity(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.httpd = server.ThreadingHTTPServer(("127.0.0.1", PORT), server.Handler)
        threading.Thread(target=cls.httpd.serve_forever, daemon=True).start()

    @classmethod
    def tearDownClass(cls):
        cls.httpd.shutdown()

    def req(self, method, path, headers, body=None):
        c = http.client.HTTPConnection("127.0.0.1", PORT, timeout=10)
        c.putrequest(method, path, skip_host=True, skip_accept_encoding=True)
        for k, v in headers.items():
            c.putheader(k, v)
        data = body.encode() if isinstance(body, str) else body
        if data is not None:
            c.putheader("Content-Length", str(len(data)))
        c.endheaders(data)
        r = c.getresponse()
        out = r.status, dict(r.getheaders()), r.read()
        c.close()
        return out

    def test_binds_loopback_only(self):
        self.assertEqual(self.httpd.server_address[0], "127.0.0.1")

    def test_rebound_host_refused(self):
        self.assertEqual(self.req("GET", "/api/docs", {"Host": "attacker.example:%d" % PORT})[0], 403)
        self.assertEqual(self.req("GET", "/file/KINTSUGI.md", {"Host": "attacker.example"})[0], 403)

    def test_simple_cross_site_post_refused(self):
        # A text/plain POST needs no CORS preflight, so it is what a hostile page would send.
        st, _, _ = self.req("POST", "/api/run", {"Host": GOOD["Host"], "Content-Type": "text/plain"}, '{"provider": "mock"}')
        self.assertEqual(st, 403)

    def test_foreign_origin_refused(self):
        st, _, _ = self.req("POST", "/api/run", dict(GOOD, Origin="https://attacker.example"), '{"provider": "mock"}')
        self.assertEqual(st, 403)

    def test_missing_custom_header_refused(self):
        h = dict(GOOD); h.pop("X-RFP-Harness")
        self.assertEqual(self.req("POST", "/api/run", h, '{"provider": "mock"}')[0], 403)

    def test_paid_provider_off_by_default(self):
        st, _, b = self.req("POST", "/api/golden", GOOD, '{"provider": "claude"}')
        self.assertEqual(st, 400)
        self.assertIn("paid model calls are off", json.loads(b)["error"])

    def test_oversized_body_refused(self):
        self.assertEqual(self.req("POST", "/api/run", GOOD, "x" * (server.MAX_BODY + 1))[0], 413)

    def test_security_headers_present(self):
        st, h, _ = self.req("GET", "/api/state", {"Host": GOOD["Host"]})
        self.assertEqual(st, 200)
        h = {k.lower(): v for k, v in h.items()}
        self.assertIn("frame-ancestors 'none'", h["content-security-policy"])
        self.assertEqual(h["x-content-type-options"], "nosniff")
        self.assertEqual(h["x-frame-options"], "DENY")
        self.assertEqual(h["referrer-policy"], "no-referrer")
        self.assertEqual(h["cache-control"], "no-store")

    def test_busy_bench_answers_at_once(self):
        # A run arriving while another holds the bench is told so immediately, never queued with no word.
        self.assertTrue(server.POST_LOCK.acquire(blocking=False))
        try:
            st, _, body = self.req("POST", "/api/run", dict(GOOD, **{"Content-Type": "application/json", "X-RFP-Harness": "1"}), '{"provider": "mock"}')
        finally:
            server.POST_LOCK.release()
        self.assertEqual(st, 409)
        self.assertIn(b"another run is still going", body)

    def test_legitimate_page_request_works(self):
        data = os.path.join(os.path.dirname(__file__), "..", "..", "data")
        body = json.dumps({"provider": "mock", "base": open(os.path.join(data, "rfp_maple_creek.txt")).read(),
                           "amendments": [open(os.path.join(data, "rfp_maple_creek_amendment_1.txt")).read(), ""],
                           "question": "When are proposals due?"})
        self.assertLess(len(body), server.MAX_BODY)  # the real package must fit under the cap
        st, _, b = self.req("POST", "/api/run", dict(GOOD, Origin="http://127.0.0.1:%d" % PORT), body)
        self.assertEqual(st, 200, b[:200])


if __name__ == "__main__":
    unittest.main()
