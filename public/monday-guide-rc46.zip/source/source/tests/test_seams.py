"""One regression test per repaired seam (KINTSUGI.md). Each reproduces the original failure condition,
so it fails if the bug returns. Runs on the $0 mock; no network.

python3 -m unittest tests.test_seams      (from source/)
"""
import json
import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))  # runs from the repo root too
os.environ["MODEL_PROVIDER"] = "mock"
os.environ["MODEL_CALL_LOG"] = os.devnull
import tempfile  # noqa: E402
os.environ.setdefault("RFP_BOARD_STATE", os.path.join(tempfile.mkdtemp(), "boards.json"))   # `discover -s tests` skips tests/__init__

from rfp import answer, faults, parse, resolve, store  # noqa: E402

DATA = os.path.join(os.path.dirname(__file__), "..", "..", "data")
BASE = open(os.path.join(DATA, "rfp_maple_creek.txt")).read()
AMEND = open(os.path.join(DATA, "rfp_maple_creek_amendment_1.txt")).read()


def db_with(amend=AMEND):
    db = store.connect(":memory:")
    store.ingest(db, BASE, "base")
    store.ingest(db, amend, "amend")
    return db


def ask(db, q, mock="none"):
    os.environ["MOCK_FAULT"] = mock
    return answer.answer(db, q)


class Seams(unittest.TestCase):
    def test_K2_amendment_detected(self):
        self.assertEqual(store.ingest(store.connect(":memory:"), AMEND, "a")[0].kind, "amendment")

    def test_K3_section_preamble_kept(self):
        ids = {c["clause_id"] for c in store.all_clauses(db_with())}
        self.assertIn("2", ids)

    def test_K5_due_finds_deadline(self):
        cands = [c["clause_id"] for c in answer.retrieve(store.all_clauses(db_with()), "When are proposals due?")]
        self.assertIn("3.2", cands)

    def test_K11_figure_boundaries(self):
        self.assertFalse(answer.has_figure("limit $25,000,000 per", "$25,000"))
        self.assertTrue(answer.has_figure("pay $25,000.", "$25,000"))

    def test_K15_timeout_degrades(self):
        self.assertEqual(ask(db_with(), "How much is the bid deposit?", "timeout")["status"], "unavailable")

    def test_K16_wrong_figure_trips_gate(self):
        r = ask(db_with(), "How much is the bid deposit?", "wrong_figure")
        self.assertTrue(r["gate"].startswith("verbatim FAILED"))

    def test_K17_revision_never_no_change(self):
        e = resolve.classify("A1.1", "Section 3.2 (Key Dates) is hereby struck and replaced as follows: the deadline "
                                     "is extended. All other dates in Section 3.2 are unchanged.")
        self.assertNotEqual(e.op, resolve.NO_CHANGE)

    def test_K18_unresolved_flags_answer(self):
        db = db_with(faults.unknown_amendment_phrasing(AMEND))
        self.assertEqual(ask(db, "What is the bid deposit?")["status"], "needs_review")
        self.assertEqual(ask(db, "When are proposals due?")["status"], "needs_review")

    def test_K19_governing_amendment_always_cited(self):
        # Reproduce the original condition: the model cites a neighbour (§3.4), not the amended clause.
        import json
        from unittest import mock
        reply = json.dumps({"status": "answered", "clause_ids": ["3.4"], "answer": "Late proposals are not accepted."})
        with mock.patch.object(answer.provider, "complete", return_value=reply):
            r = answer.answer(db_with(), "When are proposals due?")
        self.assertIn("A1.1", {c["clause_id"] for c in r["citations"]})

    def test_K79_unrelated_retrieved_amendment_is_not_cited(self):
        import json
        from unittest import mock
        reply = json.dumps({"status": "answered", "clause_ids": ["4.2", "4.1"],
                            "answer": "Questions go to the contracting officer in writing."})
        with mock.patch.object(answer.provider, "complete", return_value=reply):
            r = answer.answer(db_with(), "Can we contact the ISO directly about the bid?")
        ids = {c["clause_id"] for c in r["citations"]}
        self.assertTrue({"4.2", "4.1"} <= ids, ids)
        self.assertNotIn("A1.2", ids, "the deposit amendment was retrieved, not cited")

    def test_K20_fake_citation_is_error(self):
        self.assertEqual(ask(db_with(), "How much is the bid deposit?", "fake_citation")["status"], "error")

    def test_K25_word_forms_meet(self):
        for a, b in [("announced", "announcement"), ("exception", "exceptions"), ("deadline", "deadlines")]:
            self.assertEqual(answer.stem(a), answer.stem(b))

    def test_K32_fast_path_boundaries(self):
        # Answers one exact fact with no model call, verbatim from the governing text.
        r = ask(db_with(), "What is the bid deposit for the Maple Creek RFP?", "garbage")
        self.assertEqual(r["status"], "answered")
        self.assertIn("$100,000", r["answer"])
        self.assertIn("A1.2", {c["clause_id"] for c in r["citations"]})
        # A question about a property of the fact must not take the fast path.
        self.assertIsNone(answer.fast_path(db_with(), "Is the bid deposit refundable if we lose?"))
        # An amendment the rules cannot read disables the fast path for that fact.
        self.assertIsNone(answer.fast_path(db_with(faults.unknown_amendment_phrasing(AMEND)), "When are proposals due?"))

    def test_K7_golden_is_verbatim(self):
        self.assertIn("DECEMBER 4, 2026", AMEND)  # the source's exact form, which the golden must assert

    def test_K33_bare_refusal_still_shows_related_text(self):
        # Worst case: the model refuses with no clause_ids on both calls. W10 must still cite §3.2 (March 2027).
        real = answer.provider.complete
        answer.provider.complete = lambda *a, **k: '{"status": "not_addressed", "clause_ids": [], "answer": "No."}'
        try:
            r = answer.answer(db_with(), "On what exact day will the winner be announced?")
        finally:
            answer.provider.complete = real
        self.assertEqual(r["status"], "not_addressed")
        self.assertIn("3.2", {c["clause_id"] for c in r["citations"]})
        self.assertIn("March 2027", " ".join(c["text"] for c in r["citations"]))
        self.assertNotIn("March", r["answer"])  # related text is cited, never stated as the answer

    def test_K38_scope_and_size_hold_when_the_model_obeys(self):
        # A fooled model that drafts or decides must not reach the reader; nor may a flood question reach the model.
        self.assertEqual(ask(db_with(), "Draft the executive summary for our Volume I proposal.")["status"], "not_addressed")
        self.assertEqual(ask(db_with(), "Should RET bid on Maple Creek? Yes or no.")["status"], "not_addressed")
        self.assertEqual(ask(db_with(), "Is the deposit refundable? " + "x " * 3000)["gate"], "question too long")
        self.assertIsNone(answer.DRAFT.search("How do we prepare the proposal security?"))
        self.assertIsNone(answer.VERDICT.search("Should we include drawings in Volume II?"))

    def test_K42_unreadable_document_is_refused_not_silently_empty(self):
        # A real federal form layout (SF-33 fields, FAR clause numbers) the parser does not know: refuse, do not store.
        federal = ("1. SOLICITATION NUMBER W912P525RA001 2. TYPE OF SOLICITATION NEGOTIATED (RFP) 3. DATE ISSUED 04 FEB 2025\n"
                   + "52.236-27 Site Visit (Construction). (Alternate I) (Feb 1995) offers due as stated in block 13. " * 40)
        db = store.connect(":memory:")
        with self.assertRaises(store.UnreadableDocument):
            store.ingest(db, federal, "federal")
        r = answer.answer(db, "When are offers due?")
        self.assertEqual(r["status"], "error")
        self.assertNotIn("Not addressed", r["answer"])

    def test_K46_swallowed_text_refused_and_payload_capped(self):
        # Unrecognised pages after a valid clause become one giant clause: refuse at ingest...
        swallowed = BASE + "\n" + "52.236-27 Site Visit (Construction). (Alternate I) (Feb 1995) " * 120
        with self.assertRaises(store.UnreadableDocument):
            store.ingest(store.connect(":memory:"), swallowed, "mixed")
        # ...and, behind that, never send an oversized payload to the model, even if a giant clause got stored somehow
        # (planted directly, bypassing ingest), using the real default cap.
        db = db_with()
        sha = db.execute("SELECT doc_sha FROM clauses LIMIT 1").fetchone()[0]
        db.execute("INSERT INTO clauses VALUES (?,?,?,?,?,?)",
                   ("99.1", sha, "99", "Refundability", "pp. 1", "Bid deposit refundable refund " * 4000))
        r = answer.answer(db, "Is the bid deposit refundable if we lose?")
        self.assertEqual(r["status"], "error")
        self.assertIn("payload over cap", r["gate"])


    def test_K51_resync_never_erases_what_a_person_typed(self):
        # The sync wrote an empty "Verified by" on every run, so a name a person typed would vanish on the next sync.
        import io, contextlib, json as _json
        from unittest import mock
        from rfp import monday
        from sim import e2e
        import sync_boards
        fake = e2e.FakeMonday()
        with mock.patch.multiple(monday, gql=fake.gql, upload_file=fake.upload_file), contextlib.redirect_stdout(io.StringIO()):
            sync_boards.main()
            facts = next(d for d in fake.boards.values() if d["name"] == "RET · Key Facts")
            col = next(c["id"] for c in facts["columns"] if c["title"] == "Verified by")
            item = next(it for it in facts["items"].values() if not it["archived"] and it["name"] != "Task 1")
            item["values"][col] = _json.dumps("Doug")
            sync_boards.main()
        self.assertEqual(_json.loads(item["values"][col]), "Doug")


    def test_K55_new_amendment_needs_no_code_change(self):
        # sync_boards.load() once read two hard-coded files, so an Amendment No. 2 could not reach the boards (brief trace).
        # Dropped into the folder, it must govern on top of No. 1, whatever its filename sorts as and whichever dash it uses.
        import shutil, tempfile
        import sync_boards
        d = tempfile.mkdtemp()
        try:
            for f in ("rfp_maple_creek.txt", "rfp_maple_creek_amendment_1.txt", "sample_questions.txt"):
                shutil.copy(os.path.join(DATA, f), d)
            open(os.path.join(d, "a2.txt"), "w").write(
                "GRID OPERATOR HEARTLAND ISO\nRFP 2026-04 \u2014 MAPLE CREEK 345 kV TRANSMISSION PROJECT\n"
                "AMENDMENT NO. 2 - Issued October 20, 2026\nThis Amendment modifies RFP 2026-04 pursuant to Section 4.3 of the RFP.\n"
                "All other terms remain in full force and effect.\nA2.1 Section 7.1 (Bid Deposit) is revised: the bid deposit is\n"
                "increased from $100,000 to $125,000.\n")
            names = [f for f, _ in sync_boards.documents(d)]
            self.assertEqual(names, ["rfp_maple_creek.txt", "rfp_maple_creek_amendment_1.txt", "a2.txt"])  # base, then by number
            gov = store.governing(sync_boards.load(d), "7.1")
            self.assertIsNotNone(gov)
            self.assertTrue(str(dict(gov).get("amendment_clause", "")).startswith("A2"), dict(gov))
        finally:
            shutil.rmtree(d)

    def test_K56_every_question_is_read_past_the_first_page(self):
        # The poller once read items_page(limit: 100) with no cursor: question 101 onward was never answered (brief trace).
        from unittest import mock
        from rfp import monday
        from sim import e2e
        fake = e2e.FakeMonday()
        fake.boards["Q"] = {"columns": [], "items": {str(i): {"name": "q%d" % i, "values": {}, "archived": False} for i in range(230)}}
        with mock.patch.object(monday, "gql", fake.gql):
            items = monday.all_items("Q", "id name", limit=100)
        self.assertEqual(len(items), 230)
        self.assertEqual(len({i["id"] for i in items}), 230)

    def test_K57_claude_key_is_read_from_env_file(self):
        # ONBOARDING puts the key in .env and doctor reported it present, but the client read only the environment.
        import tempfile
        from unittest import mock
        from rfp import provider
        d = tempfile.mkdtemp()
        open(os.path.join(d, ".env"), "w").write("MONDAY_API_TOKEN=x\nANTHROPIC_API_KEY=test-key-from-file\n")
        with mock.patch.dict(os.environ, {}, clear=False):
            os.environ.pop("ANTHROPIC_API_KEY", None)
            self.assertEqual(provider.claude_key(d), "test-key-from-file")
            open(os.path.join(d, ".env"), "w").write("MONDAY_API_TOKEN=x\n")
            with self.assertRaises(provider.ProviderError):
                provider.claude_key(d)

    def test_K52_no_key_run_never_becomes_the_headline(self):
        # A run where no model replied (no API key) once became "the latest run" and slide 6 was rebuilt as 4 of 18.
        import json as _json
        from unittest import mock
        sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "scripts"))
        import evidence_calc
        real = evidence_calc.jsonl
        before = evidence_calc.calc_all()["E-eval-wave1"]["show"]
        nokey = {"t": "2099-01-01T00:00:00+00:00", "provider": "claude", "model": "claude-sonnet-5-5", "set": "golden.json",
                 "passed": 4, "total": 18, "results": [{"id": "Q%d" % i, "pass": i <= 4,
                 "gate": None if i <= 4 else "provider: ANTHROPIC_API_KEY is not set"} for i in range(1, 19)]}
        with mock.patch.object(evidence_calc, "jsonl", lambda n: real(n) + ([nokey] if n == "eval_runs.jsonl" else [])):
            after = evidence_calc.calc_all()["E-eval-wave1"]["show"]
        self.assertEqual(after, before)

    def test_K61_compact_graphql_keeps_its_nested_braces(self):
        from rfp import monday
        q = monday.with_complexity("query{boards(limit:2){id name}}")
        self.assertEqual(q, "query{boards(limit:2){id name} complexity { before after query reset_in_x_seconds } }")
        self.assertEqual(q.count("{"), q.count("}"))

    def test_K61_one_poller_per_computer_and_stop_releases_it(self):
        import subprocess, tempfile, time
        from unittest import mock
        from rfp import runlock
        d = tempfile.mkdtemp()
        with mock.patch.dict(os.environ, {"RFP_RUN_DIR": d}):
            here = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            holder = subprocess.Popen([sys.executable, "-c", "import sys,time; sys.path.insert(0,%r); from rfp import runlock; "
                                       "runlock.acquire('poller','/elsewhere'); print('held', flush=True); time.sleep(60)" % here],
                                      stdout=subprocess.PIPE, env=dict(os.environ))
            self.assertEqual(holder.stdout.readline().strip(), b"held")
            with self.assertRaises(runlock.Busy) as b:
                runlock.acquire("poller", here)
            self.assertEqual(b.exception.holder["pid"], holder.pid)
            r = subprocess.run([sys.executable, "live_questions.py", "--once"], cwd=here, capture_output=True, text=True, env=dict(os.environ))
            self.assertEqual(r.returncode, 3, r.stderr)          # a second poller refuses before any network call
            self.assertIn("already running", r.stderr)
            ok, msg = runlock.stop("poller")
            self.assertTrue(ok, msg)
            self.assertIsNone(runlock.holder("poller"))
            holder.wait(5)

    def test_K61_poller_will_not_start_below_the_daily_reserve(self):
        import subprocess, tempfile
        from unittest import mock
        from rfp import runlock
        d = tempfile.mkdtemp()
        with mock.patch.dict(os.environ, {"RFP_RUN_DIR": d, "RFP_CALL_RESERVE": "100"}):
            for _ in range(901):
                runlock.count_call()
            self.assertEqual(runlock.calls_left(), 99)
            here = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            r = subprocess.run([sys.executable, "live_questions.py", "--once"], cwd=here, capture_output=True, text=True, env=dict(os.environ))
            self.assertEqual(r.returncode, 4, r.stderr)
            self.assertIsNone(runlock.holder("poller"))          # it exited, and the OS released its lock


    def test_K63_bench_shows_shipped_files_and_nothing_else(self):
        from harness import server
        self.assertEqual(server.source_view("source/rfp/monday.py")[0], 200)
        self.assertEqual(server.source_view("DECISIONS.md")[0], 200)
        for bad in (".env", "../../etc/passwd", "..%2F..%2Fetc%2Fpasswd", "rfp.db", "history.bundle", "/etc/passwd"):
            self.assertEqual(server.source_view(bad)[0], 404, bad)
        self.assertEqual(server.site_file("index.html", server.SITE)[0], 200)
        self.assertEqual(server.site_file("RET-RFP-Intelligence.pdf")[0], 200)
        self.assertEqual(server.site_file("../../README.md", server.SITE)[0], 404)


    def test_unreadable_amendment_flags_the_fact_and_the_answer(self):
        # Doug's case: Amendment No. 2 worded so no rule can read it. The deposit fact must turn "Needs review" and an
        # answer must say a person has to check, never keep presenting Amendment 1's figure as settled.
        import shutil, tempfile
        from unittest import mock
        from sync_boards import load
        from rfp import store
        root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        for wording in ("The deposit referenced in Section 7 is hereby revised to $150,000.",
                        "The bid deposit set out in Section 7.1 is hereby revised to $150,000."):
            d = tempfile.mkdtemp()
            for f in ("rfp_maple_creek.txt", "rfp_maple_creek_amendment_1.txt"):
                shutil.copy(os.path.join(root, "data", f), d)
            head = open(os.path.join(root, "data", "rfp_maple_creek_amendment_1.txt")).read().splitlines()[:6]
            head = [l.replace("AMENDMENT NO. 1", "AMENDMENT NO. 2") for l in head]
            open(os.path.join(d, "rfp_maple_creek_amendment_2.txt"), "w").write("\n".join(head + ["A2.1 " + wording]) + "\n")
            db = load(d)
            self.assertTrue([e for e in store.effects_on(db, "7.1") if e["op"] == "unresolved"], wording)
            with mock.patch.dict(os.environ, {"MODEL_PROVIDER": "mock"}):
                r = answer.answer(db, "What is the bid deposit?")
            self.assertEqual(r["status"], "needs_review", wording)
            self.assertTrue(any("A2.1" in n and "person must check" in n for n in r.get("notes") or []), wording)


    def test_K65_renamed_column_is_harmless_and_deleted_column_stops_the_sync(self):
        import tempfile
        from unittest import mock
        from rfp import monday, sink
        from sim.e2e import FakeMonday
        fake = FakeMonday()
        cols = [("Governing text (verbatim)", "long_text"), ("State", "status")]
        with mock.patch.dict(os.environ, {"RFP_BOARD_STATE": os.path.join(tempfile.mkdtemp(), "b.json")}), \
                mock.patch.object(monday, "gql", fake.gql):
            bid = sink.MondaySink().board("RET · Key Facts", cols)
            first = dict(fake.boards[bid]["columns"][i] and (c["title"], c["id"]) for i, c in enumerate(fake.boards[bid]["columns"]))
            # Someone renames a column in monday.com: the next sync must reuse it, not create a duplicate.
            for c in fake.boards[bid]["columns"]:
                if c["title"] == "Governing text (verbatim)":
                    c["title"] = "Clause text"
            s2 = sink.MondaySink()
            s2.board("RET · Key Facts", cols)
            self.assertEqual(len(fake.boards[bid]["columns"]), len(first), "a rename created a duplicate column")
            self.assertEqual(s2.columns[bid]["Governing text (verbatim)"], first["Governing text (verbatim)"])
            # Someone deletes the Key column: stop loudly, create nothing.
            fake.boards[bid]["columns"] = [c for c in fake.boards[bid]["columns"] if c["title"] != "Key"]
            n = len(fake.boards[bid]["columns"])
            with self.assertRaises(monday.MondayError) as e:
                sink.MondaySink().board("RET · Key Facts", cols)
            self.assertEqual(e.exception.code, "COLUMN_MISSING")
            self.assertEqual(len(fake.boards[bid]["columns"]), n)


    def test_K66_failed_quote_update_leaves_the_question_open_and_retries_without_rebilling(self):
        import io, contextlib
        from unittest import mock
        from rfp import monday, sink
        from sim.e2e import FakeMonday
        import live_questions as lq
        from sync_boards import QUESTION_COLS, load
        fake = FakeMonday()
        db = load()
        lq.FAILED.clear(); lq.PENDING.clear(); lq.TRIES.clear()
        import tempfile
        with mock.patch.object(monday, "gql", fake.gql), mock.patch.dict(os.environ, {
                "MODEL_PROVIDER": "mock", "RFP_BOARD_STATE": os.path.join(tempfile.mkdtemp(), "b.json")}):
            s = sink.MondaySink()
            board = s.board("RET · Questions", QUESTION_COLS)
            cols = s.columns[board]
            iid, _ = s.upsert(board, "q-test", "When are proposals due?",
                              {"Question": sink.text("When are proposals due?"), "State": sink.status("New")})
            state = lambda: next(c["text"] for c in fake._row(board, iid)["column_values"] if c["id"] == cols["State"])
            calls = {"answer": 0}
            real_answer = lq.answer.answer
            def counted(*a, **k):
                calls["answer"] += 1
                return real_answer(*a, **k)
            real_comment = s.comment
            fail = {"n": 1}
            def flaky(item, *a, **k):
                if fail["n"] and str(item) == str(iid):
                    fail["n"] -= 1
                    raise monday.MondayError("simulated outage", code="500")
                return real_comment(item, *a, **k)
            with mock.patch.object(lq.answer, "answer", counted), mock.patch.object(s, "comment", flaky), \
                    contextlib.redirect_stderr(io.StringIO()) as err, contextlib.redirect_stdout(io.StringIO()):
                lq.poll_once(s, db, board)
                self.assertIn(state(), lq.OPEN, "a failed quote must leave the question open, not 'Answered'")
                self.assertIn("retrying next cycle", err.getvalue())
                lq.poll_once(s, db, board)
            self.assertEqual(state(), "Answered")
            self.assertEqual(calls["answer"], 2, "one model call for our item and one for the board's template row; the retry reused ours")


    def test_item_name_only_row_gets_its_question_column_filled_and_a_typed_one_is_kept(self):
        import io, contextlib, tempfile
        from unittest import mock
        from rfp import monday, sink
        from sim.e2e import FakeMonday
        import live_questions as lq
        from sync_boards import QUESTION_COLS, load
        fake = FakeMonday()
        db = load()
        lq.FAILED.clear(); lq.PENDING.clear(); lq.TRIES.clear()
        with mock.patch.object(monday, "gql", fake.gql), mock.patch.dict(os.environ, {
                "MODEL_PROVIDER": "mock", "RFP_BOARD_STATE": os.path.join(tempfile.mkdtemp(), "b.json")}):
            s = sink.MondaySink()
            board = s.board("RET · Questions", QUESTION_COLS)
            cols = s.columns[board]
            bare, _ = s.upsert(board, "q-bare", "When are proposals due?", {"State": sink.status("New")})
            typed, _ = s.upsert(board, "q-typed", "item title kept apart",
                                {"Question": sink.long_text("What is the bid deposit?"), "State": sink.status("New")})
            col = lambda iid, name: next(c["text"] for c in fake._row(board, iid)["column_values"] if c["id"] == cols[name])
            with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
                lq.poll_once(s, db, board)
            self.assertEqual(col(bare, "State"), "Answered")
            self.assertEqual(col(bare, "Question"), "When are proposals due?")
            self.assertEqual(col(typed, "Question"), "What is the bid deposit?")


    def test_local_model_fingerprint_records_then_compares(self):
        import io, json, tempfile, contextlib
        from unittest import mock
        import doctor
        from rfp.provider import LOCAL_MODEL
        def reply(digest):
            body = json.dumps({"models": [{"name": LOCAL_MODEL, "model": LOCAL_MODEL, "digest": digest}]}).encode()
            return mock.MagicMock(**{"__enter__.return_value": io.BytesIO(body)})
        def run(digest):
            out = []
            with mock.patch.object(doctor.urllib.request, "urlopen", return_value=reply(digest)):
                bad = doctor.check_model_fingerprint(lambda *a: out.append(a))
            return bad, out[0]
        with tempfile.TemporaryDirectory() as tmp, mock.patch.object(doctor, "FP_FILE", os.path.join(tmp, ".rfp-model.json")):
            bad, (state, _, detail) = run("aaaa1111bbbb2222")
            self.assertEqual((bad, state), (0, "OK")); self.assertIn("recorded", detail)
            self.assertEqual(json.load(open(doctor.FP_FILE))["digest"], "aaaa1111bbbb2222")
            bad, (state, _, detail) = run("aaaa1111bbbb2222")
            self.assertEqual((bad, state), (0, "OK")); self.assertIn("unchanged", detail)
            bad, (state, _, detail) = run("cccc3333dddd4444")
            self.assertEqual((bad, state), (1, "FAIL")); self.assertIn("delete .rfp-model.json", detail)
            self.assertEqual(json.load(open(doctor.FP_FILE))["digest"], "aaaa1111bbbb2222", "a changed model must not overwrite the record")
            with mock.patch.object(doctor.urllib.request, "urlopen", side_effect=OSError("refused")):
                out = []
                self.assertEqual(doctor.check_model_fingerprint(lambda *a: out.append(a)), 0)
                self.assertEqual(out[0][0], "MISSING")


    def test_K69_superseded_figure_alone_fails_the_gate(self):
        import json
        from unittest import mock
        q = "How much must each respondent pay with its registration?"
        for said, ok in (("Each respondent pays $75,000.", False), ("It rose from $75,000 to $100,000.", True)):
            reply = json.dumps({"status": "answered", "clause_ids": ["7.1", "A1.2"], "answer": said})
            with mock.patch.object(answer.provider, "complete", return_value=reply):
                r = answer.answer(db_with(), q)
            if r.get("gate", "").startswith("fast path"):
                self.skipTest("question took the fast path")
            self.assertEqual(r["gate"] == "verbatim ok", ok, (said, r["gate"]))

    def test_K71_every_replacing_amendment_is_checked_not_only_the_last(self):
        import json
        from unittest import mock
        a2 = "AMENDMENT NO. 2 \u2014 Issued October 20, 2026\nA2.1 Section 7.1 (Bid Deposit) is revised: the bid deposit is increased from $100,000 to $125,000.\n"
        db = db_with()
        store.ingest(db, a2, "a2")
        q = "How much must respondents remit as deposit security?"
        for said, ok in (("The bid deposit is $75,000.", False), ("The bid deposit is $100,000.", False),
                         ("The bid deposit is $125,000.", True)):
            reply = json.dumps({"status": "answered", "clause_ids": ["7.1"], "answer": said})
            with mock.patch.object(answer.provider, "complete", return_value=reply):
                r = answer.answer(db, q)
            self.assertEqual(r["gate"] == "verbatim ok", ok, (said, r["gate"]))
            self.assertTrue(any("Amendment \u00a7A2.1" in n for n in r["notes"]), r["notes"])

    def test_K72_unclassified_amendment_clause_flags_what_it_may_touch(self):
        from unittest import mock

        def with_a2(clause):
            db = db_with()
            store.ingest(db, "AMENDMENT NO. 2 \u2014 Issued October 20, 2026\nA2.1 %s\n" % clause, "a2")
            return db

        def flagged(db, cid):
            return [e["amendment_clause"] for e in store.effects_on(db, cid) if e["op"] == "unresolved"]

        def ask_mock(db, q):
            with mock.patch.dict(os.environ, {"MODEL_PROVIDER": "mock"}):
                return answer.answer(db, q)

        # Plural: "Sections 3.2 and 3.4 are revised" names two sections; both are flagged, an unrelated one is not.
        db = with_a2("Sections 3.2 and 3.4 are revised: the dates move.")
        self.assertEqual(flagged(db, "3.2"), ["A2.1"])
        self.assertEqual(flagged(db, "3.4"), ["A2.1"])
        self.assertEqual(flagged(db, "8.1"), [])
        self.assertEqual(ask_mock(db, "When are proposals due?")["status"], "needs_review")
        # Operative (figure or change verb) but naming no section: it may touch anything, so everything is flagged.
        for clause in ("The bid deposit is increased to $125,000.", "Dates are moved by one week."):
            db = with_a2(clause)
            self.assertEqual(flagged(db, "7.1"), ["A2.1"], clause)
            self.assertEqual(flagged(db, "3.2"), ["A2.1"], clause)
            self.assertEqual(ask_mock(db, "What is the bid deposit?")["status"], "needs_review", clause)
            self.assertIsNone(answer.fast_path(db, "When are proposals due?"), clause)
        # Purely informational (no figure, no change verb): flags nothing.
        db = with_a2("Note. Questions received are answered in the Q and A log.")
        self.assertEqual(flagged(db, "7.1"), [])
        self.assertEqual(ask_mock(db, "What is the bid deposit?")["status"], "answered")

    def test_K73_amendment_shaped_file_that_parses_to_nothing_is_refused_not_stored(self):
        import contextlib, io, shutil, tempfile
        from unittest import mock
        import sync_boards
        notice = ("Amendment 2\nDated October 20\n"
                  "1. The bid deposit in Section 7.1 is increased from $100,000 to $125,000.\n")
        db = store.connect(":memory:")
        with self.assertRaises(store.UnreadableDocument):
            store.ingest(db, notice, "notice")
        self.assertEqual(db.execute("SELECT COUNT(*) FROM documents").fetchone()[0], 0)
        d = tempfile.mkdtemp()
        for f in ("rfp_maple_creek.txt", "rfp_maple_creek_amendment_1.txt", "sample_questions.txt"):
            shutil.copy(os.path.join(DATA, f), d)
        sync_boards.SKIPPED.clear()
        loaded = sync_boards.load(d)   # the questions file is not a solicitation document: skipped by name, never an error
        self.assertEqual(loaded.execute("SELECT COUNT(*) FROM documents").fetchone()[0], 2)
        self.assertEqual(sync_boards.SKIPPED, {"sample_questions.txt"})
        open(os.path.join(d, "rfp_maple_creek_amendment_2.txt"), "w").write(notice)
        with self.assertRaises(store.UnreadableDocument):
            sync_boards.load(d)
        out = io.StringIO()
        with mock.patch.object(sync_boards, "DATA", d), contextlib.redirect_stdout(out), contextlib.redirect_stderr(out):
            rc = sync_boards.main()
        self.assertNotEqual(rc, 0)
        self.assertIn("NEEDS REVIEW", out.getvalue())
        self.assertIn("rfp_maple_creek_amendment_2.txt", out.getvalue())

    def test_K70_new_failing_case_blocks_the_gate(self):
        import io, contextlib, tempfile
        from unittest import mock
        from eval import regress
        base = os.path.join(tempfile.mkdtemp(), "baseline.json")
        json.dump({"golden.json": {"Q1": True}}, open(base, "w"))
        now = {"golden.json": {"Q1": True, "T9": False}}
        with mock.patch.object(regress, "BASE", base), mock.patch.object(regress, "latest", lambda: now), \
                contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(regress.main("check"), 1)

    def test_K68_encoding_and_typography_faults_stay_safe(self):
        import tempfile
        from sim import scenarios as S
        qs = [c["q"] for c in S.GOLDEN]
        for name in ("legacy_encoding", "typographic_figures", "crlf_line_endings", "abbreviated_figures"):
            for mf in ("none", "wrong_figure"):
                self.assertEqual(S.run(S.make([name], mf), qs), [], "%s with mock %s" % (name, mf))
        raw = open(os.path.join(DATA, "rfp_maple_creek.txt"), encoding="utf-8").read()
        want = len(parse.parse(raw).clauses)
        path = os.path.join(tempfile.mkdtemp(), "rfp.txt")
        for data in (raw.encode("cp1252", "replace"), b"\xef\xbb\xbf" + raw.encode("utf-8")):
            open(path, "wb").write(data)
            self.assertEqual(len(parse.parse(parse.read_document(path)).clauses), want)

    def test_K74_clause_revising_two_sections_is_unresolved_with_both_targets(self):
        from unittest import mock
        two = ("Section 3.2 (Key Dates) is revised: the deadline moves to January 8, 2027. Section 7.1 (Bid Deposit) "
               "is also revised: the bid deposit is increased from $100,000 to $150,000.")
        e = resolve.classify("A2.1", two)
        self.assertEqual((e.op, e.target), (resolve.UNRESOLVED, "3.2,7.1"))
        # the shipped amendment is unchanged: A1.1 to A1.4 still resolve as before
        got = [(x.amendment_clause, x.op, x.target) for x in resolve.effects(parse.parse(AMEND))]
        self.assertEqual(got, [("A1.1", "replaces", "3.2"), ("A1.2", "replaces", "7.1"),
                               ("A1.3", "adds", "5.5"), ("A1.4", "confirms_unchanged", "8.1")])
        db = db_with()
        store.ingest(db, "AMENDMENT NO. 2 \u2014 Issued October 20, 2026\nA2.1 %s\n" % two, "a2")
        self.assertIsNone(answer.fast_path(db, "What is the bid deposit?"))
        with mock.patch.dict(os.environ, {"MODEL_PROVIDER": "mock"}):
            self.assertEqual(answer.answer(db, "What is the bid deposit?")["status"], "needs_review")

    def test_K75_poller_reloads_documents_when_data_changes_and_keeps_old_on_failure(self):
        import contextlib, io, shutil, tempfile
        import live_questions
        d = tempfile.mkdtemp()
        for f in ("rfp_maple_creek.txt", "rfp_maple_creek_amendment_1.txt"):
            shutil.copy(os.path.join(DATA, f), d)
        db = live_questions.load_documents(d)
        sig = live_questions.data_signature(d)
        self.assertEqual(live_questions.refresh(db, sig, d), (db, sig))   # nothing changed: same db, no reload
        a2 = "AMENDMENT NO. 2 \u2014 Issued October 20, 2026\nA2.1 Section 7.1 (Bid Deposit) is revised: the bid deposit is increased from $100,000 to $125,000.\n"
        open(os.path.join(d, "rfp_maple_creek_amendment_2.txt"), "w").write(a2)
        db2, sig2 = live_questions.refresh(db, sig, d)
        self.assertIsNot(db2, db)
        self.assertNotEqual(sig2, sig)
        self.assertEqual(db2.execute("SELECT COUNT(*) FROM documents").fetchone()[0], 3)
        open(os.path.join(d, "rfp_maple_creek_amendment_2.txt"), "w").write("Amendment 2\nDated October 20\n1. something with no clause layout\n")
        err = io.StringIO()
        with contextlib.redirect_stderr(err):
            db3, sig3 = live_questions.refresh(db2, sig2, d)
        self.assertIs(db3, db2)              # a broken re-issue keeps the previous documents
        self.assertIn("rfp_maple_creek_amendment_2.txt", err.getvalue())
        self.assertIn("NEEDS REVIEW", err.getvalue())

    def test_K76_ordinary_process_questions_are_not_refused_by_the_scope_gate(self):
        for q in ("Should we submit hard copies?", "Should we respond to Volume IV?", "Do we go through the portal?",
                  "Will we win points for local content?", "Can we rewrite our proposal after submission?"):
            self.assertIsNone(answer.DRAFT.search(q), q)
            self.assertIsNone(answer.VERDICT.search(q), q)
            self.assertNotIn("scope", ask(db_with(), q).get("gate", ""), q)
        for q in ("Draft the executive summary for our Volume I proposal.", "Rewrite our executive summary.",
                  "Please rewrite the cover letter for the bid.", "Can you write our proposal narrative?",
                  "Should we bid on Maple Creek?", "Should RET bid on Maple Creek? Yes or no.", "Will we win this contract?",
                  "What are our chances of winning?", "Do we go ahead and bid?", "Should we go for it?"):
            self.assertTrue(answer.DRAFT.search(q) or answer.VERDICT.search(q), q)

    def test_K77_duplicate_amendment_is_a_needs_review_line_not_a_traceback(self):
        import contextlib, io, shutil, tempfile
        from unittest import mock
        import live_questions
        import sync_boards
        d = tempfile.mkdtemp()
        for f in ("rfp_maple_creek.txt", "rfp_maple_creek_amendment_1.txt"):
            shutil.copy(os.path.join(DATA, f), d)
        open(os.path.join(d, "rfp_maple_creek_amendment_1_reissued.txt"), "w").write(AMEND.replace("DECEMBER 4", "DECEMBR 4"))
        with self.assertRaises(store.DuplicateDocument) as cm:
            sync_boards.load(d)
        self.assertIn("rfp_maple_creek_amendment_1_reissued.txt", str(cm.exception))
        out = io.StringIO()
        with mock.patch.object(sync_boards, "DATA", d), contextlib.redirect_stdout(out), contextlib.redirect_stderr(out):
            rc = sync_boards.main()
        self.assertNotEqual(rc, 0)
        self.assertIn("NEEDS REVIEW", out.getvalue())
        self.assertIn("rfp_maple_creek_amendment_1_reissued.txt", out.getvalue())
        # the poller keeps the previous documents rather than dying
        db = live_questions.load_documents(DATA)
        err = io.StringIO()
        with contextlib.redirect_stderr(err):
            db2, _ = live_questions.refresh(db, None, d)
        self.assertIs(db2, db)
        self.assertIn("NEEDS REVIEW", err.getvalue())

    def test_K78_refusal_with_context_checks_amendments_and_stale_figures(self):
        from unittest import mock

        def stub(figure):
            reply = json.dumps({"status": "not_addressed", "clause_ids": ["7.1"], "answer": figure})
            with mock.patch.object(answer.provider, "complete", return_value=reply):
                return answer.answer(db_with(), "Is the bid deposit negotiable by phone?")

        stale = stub("The deposit is $75,000.")
        self.assertNotIn("verbatim ok", stale["gate"])
        self.assertNotIn("$75,000", stale["answer"])
        ok = stub("The deposit is increased from $75,000 to $100,000.")
        self.assertEqual(ok["gate"], "model; context verbatim ok")
        self.assertIn("A1.2", {c["clause_id"] for c in ok["citations"]})   # the amendment rides along
        cur = stub("The deposit is $100,000.")
        self.assertEqual(cur["gate"], "model; context verbatim ok")
        self.assertIn("A1.2", {c["clause_id"] for c in cur["citations"]})


if __name__ == "__main__":
    unittest.main()
