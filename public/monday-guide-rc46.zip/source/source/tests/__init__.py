"""Tests run from the repo root or from source/: put source/ on the path either way."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Tests talk to stand-in boards: their column ids must never land in the real account's record (K65).
import tempfile  # noqa: E402
os.environ.setdefault("RFP_BOARD_STATE", os.path.join(tempfile.mkdtemp(), "boards.json"))
