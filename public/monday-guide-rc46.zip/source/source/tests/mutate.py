"""Mutation check: undo each repair on today's code, one at a time, and require a seam test to fail.
A repair whose mutation survives has no load-bearing test. python3 -m tests.mutate"""
import io
import re
import os
import unittest
from unittest import mock

os.environ["MODEL_PROVIDER"] = "mock"
os.environ["MODEL_CALL_LOG"] = os.devnull
from rfp import answer, resolve, store  # noqa: E402
from tests import test_seams  # noqa: E402

orig_classify = resolve.classify
orig_superseded = answer.superseded
never = __import__("re").compile(r"(?!x)x")
MUTANTS = {
    "K11 substring figure match": mock.patch.object(answer, "has_figure", lambda h, f: f in h),
    "K15 timeout crashes": mock.patch.object(answer.provider, "complete", side_effect=answer.provider.ProviderError("x")),
    "K17 'unchanged' wins over revision": mock.patch.object(resolve, "CHANGE_WORDS_RE", mock.Mock(search=lambda t: None)),
    "K18 unresolved not targeted": mock.patch.object(resolve, "SECTION_REF_RE", mock.Mock(finditer=lambda t: iter(()))),
    "K71 only last replacement checked": mock.patch.object(answer, "superseded", lambda db, cls: orig_superseded(db, sorted(set(cls))[-1:])),
    "K72 plural sections not read": mock.patch.object(resolve, "SECTION_REF_RE", __import__("re").compile(r"\bSection\s+(\d+(?:\.\d+)?)")),
    "K72 operative clause not global": mock.patch.object(resolve, "OPERATIVE_RE", never),
    "K72 every clause operative": mock.patch.object(resolve, "OPERATIVE_RE", __import__("re").compile(r"")),
    "K74 two-section revision read as one": mock.patch.object(resolve, "REVISION_TARGETS_RE", never),
    "K76 scope gate refuses process questions": mock.patch.object(answer, "VERDICT", __import__("re").compile(
        r"\b(should (we|ret|i) (bid|submit|respond|pursue|go for)|(do|should|would) (we|you|ret) (bid|go)\b|will we win)", re.I)),
    "K19 governing not attached": mock.patch.object(store, "governing", lambda db, cid: None),
    "K25 no stemming": mock.patch.object(answer, "stem", lambda t: t),
    "K33 no related-text floor": mock.patch.object(answer, "related_text", lambda q, c: []),
    "K38 no scope guard (draft)": mock.patch.object(answer, "DRAFT", __import__("re").compile(r"(?!x)x")),
    "K38 no scope guard (verdict)": mock.patch.object(answer, "VERDICT", __import__("re").compile(r"(?!x)x")),
    "K38 no question length cap": mock.patch.object(answer, "QUESTION_MAX", 10 ** 9),
    "K42/K73 empty documents accepted": mock.patch.object(store, "may_have_no_clauses", lambda f: True),
    "K46 giant clauses accepted": mock.patch.object(store, "MAX_CLAUSE_WORDS", 10 ** 9),
    "K46 no payload cap": mock.patch.object(answer, "PAYLOAD_MAX", 10 ** 9),
}
survivors = []
for name, patch in MUTANTS.items():
    with patch:
        r = unittest.TextTestRunner(stream=io.StringIO(), verbosity=0).run(
            unittest.defaultTestLoader.loadTestsFromModule(test_seams))
    killed = not r.wasSuccessful()
    print("%-34s %s" % (name, "caught by %d test(s)" % (len(r.failures) + len(r.errors)) if killed else "SURVIVED: no test guards this"))
    if not killed:
        survivors.append(name)
raise SystemExit(1 if survivors else 0)
