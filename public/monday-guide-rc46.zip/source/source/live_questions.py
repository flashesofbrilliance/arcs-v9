"""Live question path: staff add a question to the RET · Questions board; this answers it and writes back.

python3 live_questions.py --once            # one pass (rehearsal, CI)
python3 live_questions.py --interval 60     # poll during a demo or a live response cycle

Design, from measured platform limits (docs/monday-platform.md, KINTSUGI K22/K23):
- Polling, not webhooks: a webhook needs a public URL, and this runs inside RET's environment.
- 60 s default: the free tier allows 1,000 API calls a day; one idle poll costs one call.
- An item is picked up only when its State is empty or "New"; it is moved to a final state when answered,
  so a question is never processed twice, even if the process restarts.
- The answer, its citations and the model call id are written to the item, and the full cited answer is
  posted as an update so reviewers see the source text next to the answer.
"""
import argparse
import os
import sys
import time

from rfp import answer, monday, runlock, sink, store
from sync_boards import QUESTION_COLS, data_signature, load

STATE_LABEL = {"answered": "Answered", "needs_review": "Needs review", "not_addressed": "Not addressed in RFP",
               "unavailable": "AI unavailable", "error": "Refused to guess"}
OPEN = {"", "New"}
FAILED = set()   # items whose writes failed WRITE_TRIES times this run; left open on the board for a person
PENDING = {}     # item id -> answer already computed but not yet fully written (retried without a new model call)
TRIES = {}
WRITE_TRIES = 3


def load_documents(folder=None):
    return load(folder)


def refresh(db, sig, folder=None):
    """Reload the documents when data/ changed (a new amendment dropped in mid-cycle). If the reload fails, keep the
    previous documents and say so; the folder fingerprint is still recorded so the failure is logged once, not every
    cycle, and a corrected file (a new fingerprint) is tried again (K75, K77)."""
    now = data_signature(folder)
    if now == sig:
        return db, sig
    try:
        return load_documents(folder), now
    except Exception as e:
        print("%s NEEDS REVIEW: the documents changed but could not be read; still answering from the previous ones. "
              "%s: %s" % (time.strftime("%H:%M:%S"), type(e).__name__, e), file=sys.stderr, flush=True)
        return db, now


def pending(s, board_id):
    cols = s.columns[board_id]
    out = []
    for it in monday.all_items(board_id, "id name column_values { id text }", purpose="poll questions"):
        v = {c["id"]: (c["text"] or "") for c in it["column_values"]}
        if v.get(cols["State"], "") in OPEN:
            typed = v.get(cols["Question"], "").strip()
            q = typed or it["name"].strip()
            if q:
                out.append((it["id"], q, not typed))
    return out


def answer_one(s, db, board_id, item_id, question, r=None, fill_question=False):
    """Answer one item and write it back. The quoted clauses are posted FIRST and the item is marked answered LAST, so
    a failure in between leaves the question open on the board, never "Answered" without its quoted source (K66).
    Pass r to retry only the writes for an answer already computed (no second model call). fill_question also writes the
    Question column (the row was typed as an item name only) in the same single mutation as the State."""
    cols = s.columns[board_id]
    if r is None:
        r = answer.answer(db, question)
    PENDING[item_id] = r
    cites = "\n".join("§%s (%s)" % (c["clause_id"], c["cite"]) for c in r.get("citations", []))
    notes = "\n".join(r.get("notes") or [])
    label = STATE_LABEL.get(r["status"], r["status"])
    if (r.get("gate") or "").startswith("verbatim FAILED"):
        label = "Needs review"  # the model's summary was withheld; the board must not say "Answered" (e2e fault pass)
    from html import escape as h   # the update is HTML: model and RFP text are escaped, so no link can be injected
    quoted = "\n\n".join("<b>§%s</b> %s<br>%s" % (h(c["clause_id"]), h(c["cite"]), h(c["text"])) for c in r.get("citations", []))
    if not r.get("_quoted"):   # a retry after the quote posted does not post it twice
        s.comment(item_id, "<b>%s</b><br>%s%s<br><br>%s" % (
            h(label), h(r["answer"]),
            ("<br><i>" + h(notes).replace("\n", "<br>") + "</i>") if notes else "", quoted or "No citation."))
        r["_quoted"] = True
    values = {cols["State"]: {"label": label},
              cols["Answer"]: {"text": r["answer"] + ("\n\n" + notes if notes else "")},
              cols["Citations"]: {"text": cites or "none"},
              cols["Call ID"]: (r.get("provenance") or {}).get("call_id") or ""}
    if fill_question:
        values[cols["Question"]] = {"text": question}
    import json
    monday.gql("mutation ($b: ID!, $i: ID!, $v: JSON!) { change_multiple_column_values(board_id: $b, item_id: $i, "
               "column_values: $v, create_labels_if_missing: true) { id } }",
               {"b": board_id, "i": item_id, "v": json.dumps(values)}, purpose="write answer")
    PENDING.pop(item_id, None)
    return r["status"]


def poll_once(s, db, board):
    """One pass over the board: answer every open question. Returns True if there was anything to do."""
    todo = pending(s, board)
    for item_id, q, fill in todo:
        if item_id in FAILED:
            continue   # its writes failed WRITE_TRIES times; never re-bill it every cycle
        try:
            status = answer_one(s, db, board, item_id, q, PENDING.get(item_id), fill)
        except Exception as e:   # one bad item must not stop the others, or the poller
            TRIES[item_id] = TRIES.get(item_id, 0) + 1
            done = "answered, not yet written" if item_id in PENDING else "not answered"
            if TRIES[item_id] >= WRITE_TRIES:
                FAILED.add(item_id)
                nxt = "left open on the board for a person; skipped until restart"
            else:
                nxt = "still open on the board; retrying next cycle (%d of %d)%s" % (
                    TRIES[item_id], WRITE_TRIES, ", with no new model call" if item_id in PENDING else "")
            print("%s item %s %s (%s: %s); %s" % (time.strftime("%H:%M:%S"), item_id, done, type(e).__name__, e, nxt),
                  file=sys.stderr, flush=True)
            continue
        print("%s answered item %s: %s -> %s" % (time.strftime("%H:%M:%S"), item_id, q[:60], status), flush=True)
    return bool(todo)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--once", action="store_true")
    ap.add_argument("--interval", type=int, default=60)
    ap.add_argument("--max-idle-min", type=int, default=30,
                    help="stop after this many minutes with no new question (protects the 1,000 calls/day budget)")
    args = ap.parse_args()
    # One poller per account, machine-wide: two would answer the same question twice and double the calls (K61).
    try:
        runlock.acquire("poller", os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    except runlock.Busy as b:
        print("a poller is already running: pid %s, in %s, since %s. Stop it with ./rfp stop, then start again."
              % (b.holder.get("pid"), b.holder.get("folder"), b.holder.get("started")), file=sys.stderr, flush=True)
        return 3
    if runlock.calls_left() <= runlock.RESERVE:
        print("only %d monday.com calls left today (shared count); not starting, to keep %d for a demo (K61)"
              % (runlock.calls_left(), runlock.RESERVE), file=sys.stderr, flush=True)
        return 4
    try:
        db = load_documents()
    except (store.UnreadableDocument, store.DuplicateDocument) as e:
        print("NEEDS REVIEW: no questions will be answered. %s" % e, file=sys.stderr, flush=True)
        return 2
    sig = data_signature()
    s = sink.MondaySink()
    board = s.board("RET · Questions", QUESTION_COLS)
    idle_since = time.time()
    while True:
        if runlock.calls_left() <= runlock.RESERVE:
            print("only %d monday.com calls left today (shared count); stopping to keep %d for a demo (K61)"
                  % (runlock.calls_left(), runlock.RESERVE), file=sys.stderr, flush=True)
            return 4
        db, sig = refresh(db, sig)
        try:
            if poll_once(s, db, board):
                idle_since = time.time()
        except monday.MondayError as e:
            print("monday error (code %s): %s; retrying next cycle" % (e.code, e), file=sys.stderr, flush=True)
        if args.once:
            return 0
        if args.max_idle_min and time.time() - idle_since > args.max_idle_min * 60:
            print("no new questions for %d min; stopping to save the daily API budget (KINTSUGI K22)" % args.max_idle_min, flush=True)
            return 0
        time.sleep(max(args.interval, 30))


if __name__ == "__main__":
    os.environ.setdefault("MODEL_PROVIDER", "claude")
    sys.exit(main())
