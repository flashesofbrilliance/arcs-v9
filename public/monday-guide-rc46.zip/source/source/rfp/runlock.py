"""Machine-wide run state, shared by every copy of this project on one computer (repo, unzipped ZIPs, test copies).

Why machine-wide: the monday.com account, its board and its 1,000 calls a day are shared by every copy, so the
guards must be too. One forgotten poller in a test copy once ran for three hours beside two others (K61).

- One poller at a time: an exclusive lock held for the poller's whole life. The OS releases it when the process
  ends, however it ends, so a crash can never leave a stale lock.
- One shared count of monday.com calls per UTC day, written by every copy, so "calls left" is true for the account.
- A record of what is running (process id, folder, start time) so `./rfp status` and `./rfp stop` act on facts.

Location: ~/.rfp-run, or RFP_RUN_DIR (tests). Standard library only; POSIX (macOS, Linux).
"""
import fcntl
import json
import os
import signal
import subprocess
import time
from datetime import datetime, timezone

DAILY_LIMIT = 1000     # free plan: API calls a day (docs/monday-platform.md)
RESERVE = int(os.environ.get("RFP_CALL_RESERVE", "100"))   # the poller stops here, so a demo always has calls left
_HELD = {}


def run_dir():
    d = os.environ.get("RFP_RUN_DIR") or os.path.join(os.path.expanduser("~"), ".rfp-run")
    os.makedirs(d, exist_ok=True)
    return d


class Busy(Exception):
    """Another process holds the lock; .holder is its record (pid, folder, started)."""
    def __init__(self, holder):
        super().__init__("already running: pid %s in %s" % (holder.get("pid"), holder.get("folder")))
        self.holder = holder


def acquire(name, folder):
    """Take the exclusive lock `name` for this process's lifetime, or raise Busy with the holder's record."""
    path = os.path.join(run_dir(), name + ".lock")
    f = open(path, "a+")
    try:
        fcntl.flock(f, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        f.seek(0)
        try:
            holder = json.loads(f.read() or "{}")
        except ValueError:
            holder = {}
        f.close()
        raise Busy(holder)
    f.seek(0)
    f.truncate()
    f.write(json.dumps({"pid": os.getpid(), "folder": os.path.abspath(folder),
                        "started": datetime.now(timezone.utc).isoformat(timespec="seconds")}))
    f.flush()
    _HELD[name] = f   # keep the file open: closing it would release the lock
    return f


def holder(name):
    """The record of whoever holds `name` now, or None if nobody does (probed without taking it)."""
    path = os.path.join(run_dir(), name + ".lock")
    if not os.path.exists(path):
        return None
    with open(path, "a+") as f:
        try:
            fcntl.flock(f, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            f.seek(0)
            try:
                return json.loads(f.read() or "{}")
            except ValueError:
                return {}
        fcntl.flock(f, fcntl.LOCK_UN)
        return None


def stop(name, wait=5.0):
    """Stop whoever holds `name`: SIGTERM, then confirm the lock was released. Returns (stopped, message)."""
    h = holder(name)
    if h is None:
        return True, "%s: not running" % name
    pid = h.get("pid")
    if not isinstance(pid, int):
        return False, "%s: lock held but its record is unreadable; nothing stopped" % name
    try:
        os.kill(pid, signal.SIGTERM)
    except ProcessLookupError:
        pass
    end = time.time() + wait
    while time.time() < end:
        if holder(name) is None:
            return True, "%s: stopped pid %d (%s)" % (name, pid, h.get("folder"))
        time.sleep(0.1)
    return False, "%s: pid %d did not stop within %.0f s; stop it by hand: kill %d" % (name, pid, wait, pid)


def _today():
    return datetime.now(timezone.utc).strftime("%Y-%m-%d")


def count_call():
    """Add one monday.com call to the shared daily count (one byte per call; append is atomic for one byte)."""
    with open(os.path.join(run_dir(), "monday-calls-%s.count" % _today()), "ab") as f:
        f.write(b".")


def calls_today():
    path = os.path.join(run_dir(), "monday-calls-%s.count" % _today())
    return os.path.getsize(path) if os.path.exists(path) else 0


def calls_left():
    return DAILY_LIMIT - calls_today()
