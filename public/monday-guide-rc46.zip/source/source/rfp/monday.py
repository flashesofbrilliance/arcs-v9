"""monday.com GraphQL client. Stdlib only. Contract from docs/monday-platform.md (cited per row there).

- Personal token in the Authorization header, no "Bearer" prefix.
- API version pinned explicitly; the live version is read and logged at startup.
- Errors usually arrive as HTTP 200 with an errors[] array: every response is checked.
- Retries only on rate limits (429 / ComplexityException), 423, 5xx and network errors, waiting the
  server's retry_in_seconds or Retry-After; never on column-value or validation errors.
- Every call logs its complexity cost and request id to flightlog/monday_calls.jsonl (never the token).
"""
import json
import os
import time
import urllib.error
import urllib.request
from datetime import datetime, timezone

ROOT = os.path.join(os.path.dirname(__file__), "..", "..")
ENDPOINT = "https://api.monday.com/v2"
API_VERSION = os.environ.get("MONDAY_API_VERSION", "2026-07")
CALL_LOG = os.environ.get("MONDAY_CALL_LOG", os.path.join(ROOT, "flightlog", "monday_calls.jsonl"))
LOW_BUDGET = int(os.environ.get("MONDAY_LOW_BUDGET", "100000"))  # one write costs 30,000 (measured)
RETRYABLE_CODES = {"ComplexityException", "RATE_LIMIT_EXCEEDED", "maxConcurrencyExceeded", "IP_RATE_LIMIT_EXCEEDED"}


class MondayError(Exception):
    def __init__(self, message, code=None, request_id=None):
        super().__init__(message)
        self.code, self.request_id = code, request_id


def token():
    from rfp.config import ConfigError, env
    try:
        tok = env("MONDAY_API_TOKEN")   # never guess between two tokens: one stale line silently broke auth once
    except ConfigError as e:
        raise MondayError(str(e))
    if tok and (any(c in tok for c in "\"' \t") or not tok.startswith("eyJ")):
        raise MondayError("MONDAY_API_TOKEN does not look like a monday personal token (expected one unbroken "
                          "string starting 'eyJ', no quotes or spaces)")
    if not tok:
        raise MondayError("MONDAY_API_TOKEN is not set (see README)")
    return tok


def _log(entry):
    try:   # every attempt that reached the network counts against the account's shared daily limit (K61)
        from rfp import runlock
        runlock.count_call()
    except OSError:
        pass
    os.makedirs(os.path.dirname(CALL_LOG), exist_ok=True)
    with open(CALL_LOG, "a") as f:
        f.write(json.dumps(entry) + "\n")


def with_complexity(query):
    """Add the complexity selection inside the document's outer braces. Removes exactly one closing brace: an
    earlier rstrip("}") also ate nested ones, so a compact "query{boards{id name}}" was sent broken (K61)."""
    if "complexity" in query:
        return query
    q = query.rstrip()
    if not q.endswith("}"):
        raise MondayError("GraphQL document must end with '}'")
    return q[:-1] + " complexity { before after query reset_in_x_seconds } }"


def gql(query, variables=None, purpose="query", retries=3):
    """Run one GraphQL document. Returns data; raises MondayError with the API's own code."""
    # Ask for the complexity cost on every call so the budget is measured, not assumed.
    query = with_complexity(query)
    body = json.dumps({"query": query, "variables": variables or {}}).encode()
    headers = {"Authorization": token(), "Content-Type": "application/json", "API-Version": API_VERSION}
    for attempt in range(retries + 1):
        t0 = time.time()
        req = urllib.request.Request(ENDPOINT, data=body, headers=headers)
        entry = {"t": datetime.now(timezone.utc).isoformat(), "purpose": purpose, "api_version": API_VERSION}
        try:
            with urllib.request.urlopen(req, timeout=60) as r:
                payload = json.loads(r.read())
                entry["served_version"] = r.headers.get("API-Version")
        except urllib.error.HTTPError as e:
            raw = e.read().decode(errors="replace")
            wait = int(e.headers.get("Retry-After") or 0) or _retry_seconds(raw)
            entry.update(ok=False, http=e.code, error=raw[:300], latency_s=round(time.time() - t0, 2))
            _log(entry)
            if e.code in (429, 423) or e.code >= 500:
                if attempt < retries:
                    time.sleep(wait or 2 ** attempt * 2)
                    continue
            raise MondayError("HTTP %d: %s" % (e.code, raw[:200]), code=str(e.code))
        except urllib.error.URLError as e:
            entry.update(ok=False, error=str(e.reason), latency_s=round(time.time() - t0, 2))
            _log(entry)
            if attempt < retries:
                time.sleep(2 ** attempt * 2)
                continue
            raise MondayError("cannot reach monday.com: %s" % e.reason)

        ext = payload.get("extensions") or {}
        data = payload.get("data") or {}
        cx = data.pop("complexity", None) if isinstance(data, dict) else None
        entry.update(request_id=ext.get("request_id"), complexity=cx, latency_s=round(time.time() - t0, 2))
        errors = payload.get("errors") or ([payload] if payload.get("error_code") else [])
        if errors:
            e0 = errors[0]
            code = (e0.get("extensions") or {}).get("code") or e0.get("error_code")
            entry.update(ok=False, error_code=code, error=(e0.get("message") or e0.get("error_message") or "")[:300])
            _log(entry)
            if code in RETRYABLE_CODES and attempt < retries:
                time.sleep(_retry_seconds(json.dumps(payload)) or 2 ** attempt * 2)
                continue
            raise MondayError(entry["error"] or "monday.com returned an error", code=code, request_id=ext.get("request_id"))
        entry["ok"] = True
        _log(entry)
        # Pace on the budget the server reports, instead of discovering the limit by error (K23).
        if cx and cx.get("after") is not None and cx["after"] < LOW_BUDGET:
            time.sleep(min(int(cx.get("reset_in_x_seconds") or 10) + 1, 61))
        return data
    raise MondayError("retries exhausted")


def all_items(board_id, fields, purpose="read items", limit=500):
    """Every item on a board, following the cursor (items_page returns at most 500 per page; RET logs ~180
    questions a cycle and a board keeps growing). `fields` is the GraphQL selection for one item."""
    page = gql("query ($b: [ID!]) { boards(ids: $b) { items_page(limit: %d) { cursor items { %s } } } }" % (limit, fields),
               {"b": [board_id]}, purpose=purpose)["boards"][0]["items_page"]
    items = list(page["items"])
    while page.get("cursor"):
        page = gql("query ($c: String!) { next_items_page(cursor: $c, limit: %d) { cursor items { %s } } }" % (limit, fields),
                   {"c": page["cursor"]}, purpose=purpose + " (next page)")["next_items_page"]
        items.extend(page["items"])
    return items


def _retry_seconds(raw):
    try:
        d = json.loads(raw)
    except ValueError:
        return 0
    for e in d.get("errors") or [d]:
        s = (e.get("extensions") or {}).get("retry_in_seconds") or e.get("retry_in_seconds")
        if s:
            return int(s)
    return 0


def whoami():
    """Free health check: who the token belongs to, which API version is served, budget left."""
    return gql("query { me { id name account { id name tier plan { tier max_users } } } version { kind value } }",
               purpose="whoami")


FILE_ENDPOINT = "https://api.monday.com/v2/file"


def upload_file(item_id, column_id, path, purpose="upload file"):
    """Attach a local file to an item's file column (multipart, monday's /v2/file endpoint). Logged like gql."""
    import mimetypes
    import uuid
    boundary = "----rfp" + uuid.uuid4().hex
    q = 'mutation ($file: File!) { add_file_to_column (item_id: %s, column_id: "%s", file: $file) { id } }' % (int(item_id), column_id)
    name = os.path.basename(path)
    parts = []
    for field, value in (("query", q), ("map", json.dumps({"image": "variables.file"}))):
        parts.append(("--%s\r\nContent-Disposition: form-data; name=\"%s\"\r\n\r\n%s\r\n" % (boundary, field, value)).encode())
    parts.append(("--%s\r\nContent-Disposition: form-data; name=\"image\"; filename=\"%s\"\r\nContent-Type: %s\r\n\r\n" % (boundary, name, mimetypes.guess_type(name)[0] or "application/octet-stream")).encode())
    parts.append(open(path, "rb").read())
    parts.append(("\r\n--%s--\r\n" % boundary).encode())
    body = b"".join(parts)
    headers = {"Authorization": token(), "Content-Type": "multipart/form-data; boundary=" + boundary, "API-Version": API_VERSION}
    t0 = time.time()
    entry = {"t": datetime.now(timezone.utc).isoformat(), "purpose": purpose, "api_version": API_VERSION}
    try:
        with urllib.request.urlopen(urllib.request.Request(FILE_ENDPOINT, data=body, headers=headers), timeout=120) as r:
            payload = json.loads(r.read())
    except urllib.error.HTTPError as e:
        entry.update(ok=False, http=e.code, error=e.read().decode(errors="replace")[:300], latency_s=round(time.time() - t0, 2))
        _log(entry)
        raise MondayError("file upload failed: HTTP %s" % e.code)
    entry.update(ok="errors" not in payload, latency_s=round(time.time() - t0, 2))
    _log(entry)
    if "errors" in payload:
        raise MondayError("file upload failed: %s" % str(payload["errors"])[:200])
    return payload["data"]["add_file_to_column"]["id"]
