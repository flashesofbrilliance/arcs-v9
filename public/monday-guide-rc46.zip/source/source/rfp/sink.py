"""Sink port: where results land. One adapter today (monday.com); the pipeline only calls this interface.

Idempotent by construction (Doug: "I don't want two trackers"):
- boards are found by name before being created,
- columns are found by title the first time, then by the id recorded then (.rfp-boards.json), so renaming a column
  in monday.com is harmless and deleting one stops the sync loudly instead of creating a duplicate (K65),
- items are upserted by our own `Key` text column (items_page_by_column_values matches the whole value),
  so running the sync twice changes values in place and never creates a second item.
Column-value formats follow docs/monday-platform.md section 4 (cited there).
"""
import json
import os

from rfp import monday


# The only boards this pipeline may create or write (war game S7, K38). Add a board here, in review, before any
# code can write to it.
ALLOWED_BOARDS = {"RET · Solicitations", "RET · Key Facts", "RET · Questions", "RET · Pilot Scorecard"}


ROOT = os.path.join(os.path.dirname(__file__), "..", "..")


def _state_path():
    return os.environ.get("RFP_BOARD_STATE") or os.path.join(ROOT, ".rfp-boards.json")


def _load_state():
    try:
        return json.load(open(_state_path()))
    except (OSError, ValueError):
        return {}


def _save_state(state):
    tmp = _state_path() + ".tmp"
    with open(tmp, "w") as f:
        json.dump(state, f, indent=1, sort_keys=True)
    os.replace(tmp, _state_path())   # atomic: a crash mid-write never leaves a half file


class MondaySink:
    def __init__(self, workspace_id=None):
        self.workspace_id = workspace_id
        self.columns = {}   # board_id -> {title: column_id}
        self.boards = {}    # name -> board_id

    # Boards and columns ------------------------------------------------------------------------------
    def board(self, name, columns):
        """columns: list of (title, column_type). Returns board_id, creating only what is missing."""
        if name not in ALLOWED_BOARDS:
            raise monday.MondayError("%r is not an allowed board (ALLOWED_BOARDS in rfp/sink.py)" % name)
        if name not in self.boards:
            found = monday.gql("query { boards(limit: 200, state: active) { id name } }", purpose="find board")
            match = [b for b in found["boards"] if b["name"] == name]
            if match:
                self.boards[name] = match[0]["id"]
            else:
                ws = ", workspace_id: %s" % self.workspace_id if self.workspace_id else ""
                made = monday.gql('mutation ($n: String!) { create_board(board_name: $n, board_kind: public%s) { id } }' % ws,
                                  {"n": name}, purpose="create board")
                self.boards[name] = made["create_board"]["id"]
        bid = self.boards[name]
        existing = monday.gql("query ($b: [ID!]) { boards(ids: $b) { columns { id title type } } }", {"b": [bid]},
                              purpose="read columns")["boards"][0]["columns"]
        by_title = {c["title"]: c["id"] for c in existing}
        ids = {c["id"] for c in existing}
        state = _load_state()
        saved = state.get(str(bid), {})
        cols = {}
        for title, ctype in [("Key", "text")] + list(columns):
            if title in saved:
                if saved[title] not in ids:   # deleted in monday.com: stop before writing anything (K65)
                    raise monday.MondayError(
                        "column %r (id %s) is missing from board %r; someone deleted it. Restore it in monday.com, or "
                        "remove its line from %s so the sync creates it again. Nothing was written."
                        % (title, saved[title], name, os.path.basename(_state_path())), code="COLUMN_MISSING")
                cols[title] = saved[title]          # found by id, so a rename in monday.com changes nothing
            elif title in by_title:
                cols[title] = by_title[title]
            else:
                made = monday.gql("mutation ($b: ID!, $t: String!) { create_column(board_id: $b, title: $t, column_type: %s) { id } }" % ctype,
                                  {"b": bid, "t": title}, purpose="create column")
                cols[title] = made["create_column"]["id"]
        if saved != cols:
            state[str(bid)] = cols
            _save_state(state)
        self.columns[bid] = cols
        return bid

    # Items --------------------------------------------------------------------------------------------
    def upsert(self, board_id, key, name, values, create_only=None):
        """values: {column title: value}, value already in monday's JSON shape (see helpers below).
        create_only: values written when the item is created and never again, so a re-sync can never erase
        what a person typed (e.g. "Verified by"). Returns (item_id, created)."""
        cols = self.columns[board_id]
        payload = {cols["Key"]: key}
        payload.update({cols[t]: v for t, v in values.items()})
        first = {cols[t]: v for t, v in (create_only or {}).items()}
        found = monday.gql(
            "query ($b: ID!, $c: String!, $v: [String]!) { items_page_by_column_values(board_id: $b, limit: 2, "
            "columns: [{column_id: $c, column_values: $v}]) { items { id column_values { id type value text } } } }",
            {"b": board_id, "c": cols["Key"], "v": [key]}, purpose="find item")["items_page_by_column_values"]["items"]
        if len(found) > 1:
            raise monday.MondayError("two items share key %r on board %s: refusing to guess which is real" % (key, board_id))
        if found:
            iid = found[0]["id"]
            # A write costs 30,000 complexity points and a read about 20 (KINTSUGI K23): skip unchanged items.
            # Status values are stored as {"index": n}; compare them by their visible label instead.
            current = {c["id"]: (c["text"] if c["type"] == "status" else _norm(c["value"])) for c in found[0]["column_values"]}
            changed = {k: v for k, v in payload.items() if current.get(k) != _norm(v)}
            if not changed:
                return iid, None
            monday.gql("mutation ($b: ID!, $i: ID!, $v: JSON!) { change_multiple_column_values(board_id: $b, item_id: $i, "
                       "column_values: $v, create_labels_if_missing: true) { id } }",
                       {"b": board_id, "i": iid, "v": json.dumps(payload)}, purpose="update item")
            return iid, False
        made = monday.gql("mutation ($b: ID!, $n: String!, $v: JSON!) { create_item(board_id: $b, item_name: $n, "
                          "column_values: $v, create_labels_if_missing: true) { id } }",
                          {"b": board_id, "n": name[:255], "v": json.dumps(dict(payload, **first))}, purpose="create item")
        return made["create_item"]["id"], True

    def name_group(self, board_id, title):
        """Rename monday's default "Group Title" group so the board reads as RET's, not a template. Only that
        default name is ever renamed: a group a person renamed is left alone."""
        groups = monday.gql("query ($b: [ID!]) { boards(ids: $b) { groups { id title } } }", {"b": [board_id]},
                            purpose="read groups")["boards"][0]["groups"]
        for g in groups:
            if g["title"] == "Group Title":
                monday.gql("mutation ($b: ID!, $g: String!, $v: String!) { update_group(board_id: $b, group_id: $g, "
                           "group_attribute: title, new_value: $v) { id } }", {"b": board_id, "g": g["id"], "v": title},
                           purpose="rename group")
                return True
        return False

    def color_states(self, board_id, column_title, colors):
        """Give each named status label its color (adding any label not created yet), so the board reads like the
        boards page: green answered, orange needs review, gray not addressed, red when the AI could not answer.
        Labels not named keep a color nobody else uses. One read when nothing needs changing (safe to re-run)."""
        col = self.columns[board_id][column_title]
        c = monday.gql("query ($b: [ID!], $c: [String]) { boards(ids: $b) { columns(ids: $c) { revision settings } } }",
                       {"b": [board_id], "c": [col]}, purpose="read status colors")["boards"][0]["columns"][0]
        labels = c["settings"]["labels"]
        names = {x["label"]: x for x in labels}
        if all(n in names and names[n].get("hex", "").lower() == STATE_HEX.get(n, "") for n in colors):
            return False
        taken = set(colors.values())
        spare = [x for x in SPARE_COLORS if x not in taken]
        out = []
        for x in labels:
            color = colors.get(x["label"]) or DEFAULT_COLORS.get(x["label"]) or spare.pop(0)
            out.append({"id": x["id"], "label": x["label"], "index": x["index"], "color": color, "is_done": x.get("is_done", False)})
        nxt = max([x["index"] for x in labels] + [-1]) + 1
        for n, color in colors.items():
            if n not in names:
                out.append({"label": n, "index": nxt, "color": color}); nxt += 1
        monday.gql("mutation ($b: ID!, $c: String!, $r: String!, $s: UpdateStatusColumnSettingsInput) { update_status_column("
                   "board_id: $b, id: $c, revision: $r, settings: $s) { id } }",
                   {"b": board_id, "c": col, "r": c["revision"], "s": {"labels": out}}, purpose="set status colors")
        return True

    def attach_once(self, board_id, item_id, column_title, path):
        """Attach a file to an item's file column unless a file with that name is already there."""
        cid = self.columns[board_id][column_title]
        cur = monday.gql("query ($i: [ID!]) { items(ids: $i) { column_values(ids: [\"%s\"]) { text } } }" % cid,
                         {"i": [item_id]}, purpose="read file column")["items"][0]["column_values"][0]["text"] or ""
        if os.path.basename(path) in cur:
            return False
        monday.upload_file(item_id, cid, path)
        return True

    def archive_template_rows(self, board_id):
        """create_board adds a placeholder "Task 1" row. Archive (recoverable, not delete) any row on a board
        this sync owns that has no Key: it can only be a template row, never client data we wrote."""
        cols = self.columns[board_id]
        items = monday.all_items(board_id, "id name column_values { id value }", purpose="find template rows")
        # Only monday's own placeholder: named "Task N" with every column empty. A Key-less row is NOT enough:
        # staff add questions by hand without a Key, and archiving those would delete real work (K30).
        import re as _re
        stray = [i for i in items if _re.fullmatch(r"Task \d+", i["name"] or "")
                 and not any(c["value"] for c in i["column_values"])]
        for i in stray:
            monday.gql("mutation ($i: ID!) { archive_item(item_id: $i) { id } }", {"i": i["id"]}, purpose="archive template row")
        return [i["name"] for i in stray]

    def comment(self, item_id, body):
        return monday.gql("mutation ($i: ID!, $b: String!) { create_update(item_id: $i, body: $b) { id } }",
                          {"i": item_id, "b": body}, purpose="post update")["create_update"]["id"]


def _norm(v):
    """Compare a stored column value with the one we would write, ignoring monday's extra metadata."""
    if v is None:
        return None
    if isinstance(v, str):
        try:
            v = json.loads(v)
        except ValueError:
            return v.strip()
    if isinstance(v, dict):
        for k in ("text", "label", "index"):
            if k in v:
                return str(v[k]).strip() if k != "index" else v[k]
        return json.dumps({k: v[k] for k in sorted(v) if k not in ("changed_at", "post_id")})
    return str(v).strip()


# Column-value helpers (formats from the monday docs) ---------------------------------------------------
# monday.com StatusColumnColors values (each used once per column). Its three default labels keep their own colors,
# which the API refuses to change, so ours take the nearest free shade. STATE_HEX is what monday.com reports for
# each, used to skip the write when the board already matches and to color the boards page the same way.
DEFAULT_COLORS = {"Working on it": "working_orange", "Done": "done_green", "Stuck": "stuck_red"}
STATE_COLORS = {"Answered": "grass_green", "Needs review": "egg_yolk", "Not addressed in RFP": "american_gray",
                "AI unavailable": "dark_red", "Refused to guess": "sunset"}
STATE_HEX = {"Answered": "#037f4c", "Needs review": "#ffcb00", "Not addressed in RFP": "#757575",
             "AI unavailable": "#bb3354", "Refused to guess": "#ff7575"}
SPARE_COLORS = ["berry", "tan", "bright_green", "explosive", "dark_blue", "purple"]


def text(v):
    return str(v)[:2000]


def long_text(v):
    return {"text": str(v)}


def status(label):
    return {"label": label}


def number(v):
    return str(v)
