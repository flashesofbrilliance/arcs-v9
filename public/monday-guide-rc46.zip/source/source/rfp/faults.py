"""Fault injection for the test harness: data-quality and ingest risks applied to document text.

Each fault is a pure function text -> text (or a list of documents -> list), so a run is reproducible
from (documents, faults, seed). Model-side faults live in provider.py (MODEL_PROVIDER=mock).
"""
import random
import re

DOC_FAULTS = {
    "delete_clause": "Remove one clause entirely (param: clause id, e.g. 7.1)",
    "change_figure": "Replace a figure everywhere (param: old=>new, e.g. $75,000=>$80,000)",
    "unknown_amendment_phrasing": "Rewrite amendment clauses in phrasing no rule knows ('hereby struck and replaced')",
    "page_break_loss": "Drop every 15th line, as layout-mode PDF extraction did early in this build",
    "ocr_noise": "Swap characters at a small rate: O->0, l->1, S->5 (param: rate, default 0.01)",
    "legacy_encoding": "A byte-order mark, then a Windows-1252 file read as UTF-8: section signs and dashes become replacement characters",
    "typographic_figures": "Non-breaking spaces as thousands separators in figures ($100 000), curly quotes, non-breaking hyphens",
    "crlf_line_endings": "Windows line endings (CR LF) on every line",
    "abbreviated_figures": "Figures written short: $100,000 becomes $100K",
}
INGEST_FAULTS = {
    "duplicate_upload": "Upload every document twice",
    "reformatted_duplicate": "Upload a whitespace-reformatted copy of every document",
    "amendment_first": "Ingest amendments before the base RFP",
    "conflicting_amendment": "Add a second 'Amendment No. 1' with a different deposit",
}


def delete_clause(text, clause_id):
    lines, out, skipping = text.splitlines(), [], False
    head = re.compile(r"^(A?\d+\.\d+) ")
    for line in lines:
        m = head.match(line.strip())
        if m:
            skipping = m.group(1) == clause_id
        elif line.strip().startswith(("SECTION", "=", "APPENDICES")):
            skipping = False
        if not skipping:
            out.append(line)
    return "\n".join(out) + "\n"


def change_figure(text, spec):
    old, new = [s.strip() for s in spec.split("=>", 1)]
    return text.replace(old, new)


def unknown_amendment_phrasing(text):
    return re.sub(r"\) is revised:", ") is hereby struck and replaced as follows:", text)


def page_break_loss(text):
    return "\n".join(l for i, l in enumerate(text.splitlines()) if i % 15 != 14) + "\n"


def ocr_noise(text, rate=0.01, seed=7):
    rng, swap = random.Random(seed), {"O": "0", "l": "1", "S": "5", "0": "O"}
    return "".join(swap[c] if c in swap and rng.random() < rate else c for c in text)


def legacy_encoding(text):
    return "\ufeff" + text.encode("cp1252", "replace").decode("utf-8", "replace")


def typographic_figures(text):
    text = re.sub(r"(?<=\d),(?=\d{3}\b)", "\u00a0", text)
    text = re.sub(r'"([^"\n]*)"', "\u201c\\1\u201d", text).replace("'", "\u2019")
    return re.sub(r"(?<=\w)-(?=\w)", "\u2011", text)


def crlf_line_endings(text):
    return text.replace("\r\n", "\n").replace("\n", "\r\n")


def abbreviated_figures(text):
    return re.sub(r"\$(\d{1,3}),000(?![,.\d])", r"$\1K", text)


TEXT_FAULTS = {"legacy_encoding": legacy_encoding, "typographic_figures": typographic_figures,
               "crlf_line_endings": crlf_line_endings, "abbreviated_figures": abbreviated_figures}


def apply_doc_faults(text, faults, is_amendment):
    for f in faults:
        name, param = f.get("name"), f.get("param") or ""
        if name == "delete_clause" and param:
            text = delete_clause(text, param)
        elif name == "change_figure" and "=>" in param:
            text = change_figure(text, param)
        elif name == "unknown_amendment_phrasing" and is_amendment:
            text = unknown_amendment_phrasing(text)
        elif name == "page_break_loss":
            text = page_break_loss(text)
        elif name == "ocr_noise":
            text = ocr_noise(text, float(param or 0.01))
        elif name in TEXT_FAULTS:
            text = TEXT_FAULTS[name](text)
    return text


def ingest_sequence(base, amendments, faults):
    """Return the ordered (label, text) uploads implied by the ingest faults."""
    names = {f.get("name") for f in faults}
    seq = [("base", base)] + [("amendment %d" % (i + 1), a) for i, a in enumerate(amendments)]
    if "amendment_first" in names:
        seq = seq[1:] + seq[:1]
    if "duplicate_upload" in names:
        seq += [(l + " (duplicate)", t) for l, t in seq]
    if "reformatted_duplicate" in names:
        seq += [(l + " (reformatted)", "\n".join("  " + x + " " for x in t.splitlines()) + "\n\n") for l, t in seq[:len(amendments) + 1]]
    if "conflicting_amendment" in names and amendments:
        seq.append(("conflicting Amendment No. 1", amendments[0].replace("$100,000", "$110,000")))
    return seq
