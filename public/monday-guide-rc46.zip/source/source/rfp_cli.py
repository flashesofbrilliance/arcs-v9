"""One entry point for everything a support team runs. ./rfp <command> --help for options.

  status          what is running on this computer (poller, test bench) and monday.com calls left today
  stop            stop the poller and the test bench, wherever they were started
  start           one interactive session: pre-flight checks, then the test bench and the poller [--reset] [--provider claude|local]
  ask "question" [--provider mock|local|claude] [--fault none|timeout|garbage|wrong_figure|fake_citation|refuse]
  sync            refresh Solicitations, Key Facts and Questions boards (safe to re-run)
  scorecard       refresh the Pilot Scorecard board (safe to re-run)
  poll            answer new questions on the board [--once] [--interval 60] [--max-idle-min 30]
  reset           archive [rehearsal] questions before a demo
  samples         put RET's 14 sample questions on the Questions board and answer them there (safe to re-run)
  eval            run the test questions [--set wave1|wave2|wave3] [--provider claude|local|mock]
  scenarios       run every combination of faults on the free mock
  check           seam tests + mutation check + regression check (the two-minute pre-demo check)
  serve           start the build deck and test bench on http://127.0.0.1:8765 [--paid: allow Claude calls from the page]
  wargame         stakeholder attacks on the system, rerunnable [--persona sam|nina|elena] [--provider mock|claude]
  verify-proof    re-check the proof of one answer (hashes, quotes, conclusion, guards, script-free page, PDF)
  e2e             end-to-end dry run of the demo path vs pre-registered outputs [--runs 3] [--provider mock|claude] [--monday fake|live] [--from-zip]
  canaries        checks on the checks: gate self-tests, paraphrase, path drift, premise, cherry-pick [--bless]
  build           regenerate evidence, deck figures, deck PDF and status page from the records [--check: report only]
"""
import argparse
import json
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))


def py(*args):
    return subprocess.call([sys.executable] + list(args), cwd=HERE)


def main():
    ap = argparse.ArgumentParser(prog="rfp", description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    a = sub.add_parser("ask"); a.add_argument("question"); a.add_argument("--provider", default="claude", choices=["mock", "local", "claude"])
    a.add_argument("--fault", default="none"); a.add_argument("--json", action="store_true")
    sub.add_parser("status", help="what is running, from any copy on this computer, and calls left today")
    sub.add_parser("stop", help="stop the poller and the test bench, from any copy on this computer")
    st = sub.add_parser("start", help="pre-flight checks, then the test bench and the poller, in this terminal")
    st.add_argument("--reset", action="store_true"); st.add_argument("--provider", choices=["claude", "local"]); st.add_argument("--no-sync", action="store_true")
    sub.add_parser("sync"); sub.add_parser("scorecard"); sub.add_parser("reset"); sub.add_parser("samples"); sub.add_parser("scenarios")
    sub.add_parser("check"); sv = sub.add_parser("serve"); sv.add_argument("--paid", action="store_true", help="let the page make paid Claude calls")
    b = sub.add_parser("build"); b.add_argument("--check", action="store_true")
    c = sub.add_parser("canaries"); c.add_argument("--bless", action="store_true")
    sub.add_parser("verify-proof"); sub.add_parser("doctor", help="is this machine ready? Python, .env, keys, one free monday.com call")
    rh = sub.add_parser("rehearse", help="dress rehearsal: the whole submission path as a graph, in loops"); rh.add_argument("--loops", type=int, default=1); rh.add_argument("--live", action="store_true"); rh.add_argument("--plant", action="store_true")
    e2 = sub.add_parser("e2e"); e2.add_argument("--runs", type=int, default=3); e2.add_argument("--provider", default="mock", choices=["mock", "claude"]); e2.add_argument("--monday", default="fake", choices=["fake", "live"]); e2.add_argument("--from-zip", action="store_true")
    w = sub.add_parser("wargame"); w.add_argument("--persona", choices=["sam", "nina", "elena"]); w.add_argument("--provider", default="mock", choices=["mock", "claude"])
    p = sub.add_parser("poll"); p.add_argument("--once", action="store_true"); p.add_argument("--interval", type=int, default=60)
    p.add_argument("--max-idle-min", type=int, default=30)
    e = sub.add_parser("eval"); e.add_argument("--set", default="wave1", choices=["wave1", "wave2", "wave3"]); e.add_argument("--provider", default="claude")
    args = ap.parse_args()

    if args.cmd == "ask":
        os.environ["MODEL_PROVIDER"], os.environ["MOCK_FAULT"] = args.provider, args.fault
        from rfp import answer
        from sync_boards import load
        r = answer.answer(load(), args.question)
        if args.json:
            print(json.dumps(r, indent=1, default=str)); return 0
        print("[%s] %s\n" % (r["status"], r["answer"]))
        for c in r.get("citations", []):
            print("  §%s  %s" % (c["clause_id"], c["cite"]))
        for n in r.get("notes") or []:
            print("  note: " + n)
        print("\n  check: %s · model call: %s" % (r.get("gate"), (r.get("provenance") or {}).get("call_id") or "none"))
        return 0
    if args.cmd in ("status", "stop"):
        sys.path.insert(0, HERE)
        from rfp import runlock
        bad = 0
        for name in ("poller", "bench"):
            if args.cmd == "stop":
                ok, msg = runlock.stop(name)
                bad += not ok
                print(msg)
            else:
                h = runlock.holder(name)
                print("%-7s %s" % (name, "running: pid %s in %s, since %s" % (h.get("pid"), h.get("folder"), h.get("started")) if h else "not running"))
        if args.cmd == "status":
            print("calls   %d of 1,000 monday.com calls left today (all copies on this computer)" % runlock.calls_left())
        return 1 if bad else 0
    if args.cmd == "start":
        return py("start.py", *(["--reset"] if args.reset else []), *(["--provider", args.provider] if args.provider else []), *(["--no-sync"] if args.no_sync else []))
    if args.cmd == "sync":
        return py("sync_boards.py")
    if args.cmd == "scorecard":
        return py("scorecard_sync.py")
    if args.cmd == "reset":
        return py("demo_reset.py")
    if args.cmd == "samples":
        return py("seed_samples.py")
    if args.cmd == "poll":
        return py("live_questions.py", "--interval", str(args.interval), "--max-idle-min", str(args.max_idle_min), *(["--once"] if args.once else []))
    if args.cmd == "eval":
        return py("-m", "eval.run_eval", "--provider", args.provider, "--golden", {"wave1": "golden.json", "wave2": "golden_wave2.json", "wave3": "golden_wave3.json"}[args.set])
    if args.cmd == "scenarios":
        return py("-m", "sim.scenarios", "matrix")
    if args.cmd == "check":
        return py("-m", "unittest", "-q", "tests.test_seams") or py("-m", "tests.mutate") or py("-m", "eval.regress", "check") or subprocess.call([sys.executable, os.path.join(HERE, "..", "scripts", "build.py"), "--check"])
    if args.cmd == "serve":
        if args.paid:
            os.environ["RFP_ALLOW_PAID"] = "1"
        return py("-m", "harness.server")
    if args.cmd == "doctor":
        return py("doctor.py")
    if args.cmd == "rehearse":
        return subprocess.call([sys.executable, os.path.join(HERE, "..", "scripts", "rehearse.py"), "--loops", str(args.loops)] + (["--live"] if args.live else []) + (["--plant"] if args.plant else []))
    if args.cmd == "verify-proof":
        return subprocess.call([sys.executable, os.path.join(HERE, "..", "scripts", "proof.py"), "--verify"])
    if args.cmd == "e2e":
        return py("-m", "sim.e2e", "--runs", str(args.runs), "--provider", args.provider, "--monday", args.monday, *(["--from-zip"] if args.from_zip else []))
    if args.cmd == "canaries":
        return subprocess.call([sys.executable, os.path.join(HERE, "..", "scripts", "canaries.py")] + (["--bless"] if args.bless else []))
    if args.cmd == "wargame":
        return py("-m", "sim.wargame", "--provider", args.provider, *(["--persona", args.persona] if args.persona else []))
    if args.cmd == "build":
        return subprocess.call([sys.executable, os.path.join(HERE, "..", "scripts", "build.py")] + (["--check"] if args.check else []))


if __name__ == "__main__":
    sys.exit(main())
