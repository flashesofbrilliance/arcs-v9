# Unit economics: the right tool for each job

Principle: give each job the cheapest tool that does it correctly, and spend model calls only where
judgment is needed. Every figure carries its evidence: `[E:<id>]` points to `evidence/evidence.jsonl`;
`[ASSUMPTION]` marks a value we chose and RET has not confirmed. `scripts/provenance_lint.py` fails the
commit on any figure without one.

## Per stage

| Stage | Job | Tool | Cost per unit | Rejected alternative, and why |
|---|---|---|---|---|
| Ingest | Parse sections, hash, dedupe | Python stdlib + SQLite | no model call | An LLM to "read" the RFP: per-page cost, nondeterministic, cannot be byte-verbatim |
| Amendment resolution | Replace / add / no-change / missing-ref | 4 regex rules; unknown phrasing goes to a human | no model call | An LLM classifier: the phrasing is formulaic legal language, and a wrong guess is the incident Elena describes |
| Retrieval | Find ~8 candidate clauses | IDF term overlap + reviewable glossary | no model call | Embeddings + a vector DB: another moving part for Sam Ito's team; the 600-page path is on the rollout slide |
| Key facts (planned) | Deadline, deposit, security, weights | Deterministic table, no model | no model call | A model call per lookup: pays for a lookup and sends the question out |
| Answer | Select clauses, one plain sentence | Claude Sonnet 5.5 | $0.0038 per question [E:E-cost-per-q] | Whole document per question (below) |
| Verification | Figures verbatim, supersession attached | Code gate | no model call | A second model as judge: pays twice and still is not verbatim |
| Local option | Same answer step, nothing leaves the box | Qwen 2.5 7B via Ollama | no API charge; 11.2 s and 14/18 on the eval [E:E-local-eval] | As primary: misses the inference cases Nina cares about |

## Per year

| | Arithmetic | Result |
|---|---|---|
| Model cost per response cycle | 180 questions [E:E-questions] x $0.0038 [E:E-cost-per-q] | ~$0.69 per cycle |
| Model cost per year | ~12 solicitations [E:E-solicitations] x $0.69 [E:E-cost-per-q] | ~$8 per year |
| Whole-document alternative | ~600 pages x ~500 tokens/page = ~300,000 tokens x $2/M [ASSUMPTION] | ~$0.60 per question, ~157x the selected-clause path [ASSUMPTION] |
| Context | RET's estimate of manual RFP operations, $1.6M/yr [E:E-manual-cost] | the model line is not the business case |

The value is in hours, not tokens: 650 intake hours per cycle against a 150-hour target [E:E-intake-hours].
The model line shows the AI does not eat the savings.

## Build cost

API spend for the whole build so far: $0.29 [E:E-build-spend], including every eval run and the Qwen
comparison. Build time comes from timestamps in `JOURNEY.md`, not estimates (KINTSUGI K10).
